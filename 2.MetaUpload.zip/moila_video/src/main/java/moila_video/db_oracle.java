package moila_video;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class db_oracle {
    
    public Connection conn = null;
    
    public db_oracle(String url, String user, String password) {
        connectDB(url, user, password);
    }
    
    public void Close() {
        disconnectDB(); 
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 오라클 접속
    // --------------------------------------------------------------------------------------------------------
    private void connectDB(String url, String user, String password) 
    {
        
        try  
        {
            String driver = "oracle.jdbc.driver.OracleDriver";
            
            Class.forName(driver);      // 드라이버 로드
            conn = DriverManager.getConnection(url, user, password);
            
            System.out.println("데이터베이스 접속 성공");

        }
        catch (ClassNotFoundException e)
        {
            System.out.println("connectDB() ClassNotFoundException");
        }
        catch (SQLException e)
        {
            System.out.println("connectDB() SQLException");
            e.printStackTrace();
        }
//        catch (IOException e) 
//        {
//          System.out.println("connectDB() IOException");
//            e.printStackTrace();
//        }
        catch (Exception e) 
        {
            System.out.println("connectDB() Exception");
            e.printStackTrace();
        }

    }
    
    // --------------------------------------------------------------------------------------------------------
    // 오라클 연결 해제
    // --------------------------------------------------------------------------------------------------------
    private void disconnectDB() 
    {
        try 
        {
            if (conn != null) {
                conn.close();
                System.out.println("데이터베이스 접속 해제");
            }
        }
        catch (SQLException e)
        {
            System.out.println("disconnectDB() SQLException");
            e.printStackTrace();
        }
        catch (Exception e) 
        {
            System.out.println("disconnectDB() Exception");
          e.printStackTrace();
        }

        
    }
    
    // --------------------------------------------------------------------------------------------------------
    // SQL 문 실행(DELETE/UPDATE/INSERT 등의 SQL문
    // --------------------------------------------------------------------------------------------------------
    public boolean executeSQL(String sql, SQLResult sqlResult) 
    {
        sqlResult.code = 0;
        sqlResult.msg = "";
        
        PreparedStatement pstmt = null;
                
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.executeQuery();
            pstmt.clearParameters();
            pstmt.close();
        }
        catch (SQLException se) 
        {
            sqlResult.code = se.getErrorCode();
            sqlResult.msg = se.getMessage();

            System.out.println(sqlResult.code + " : " + sqlResult.msg);
            // se.printStackTrace();
            
            try {
                pstmt.clearParameters();
                pstmt.close();
            }
            catch (SQLException se2) {
            }
            return false;
        }
        catch (Exception e) 
        {
          e.printStackTrace();
          return false;
        }
        
        return true;

    }

    PreparedStatement pstmt = null;
    // --------------------------------------------------------------------------------------------------------
    // SQL 문 실행(DELETE/UPDATE/INSERT 등의 SQL문
    // --------------------------------------------------------------------------------------------------------
    public ResultSet selectSQL(String sql) 
    {
        ResultSet rs = null;
        
        try {
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            pstmt.clearParameters();
        }
        catch (SQLException se) 
        {
            se.printStackTrace();
            return rs;
        }
        catch (Exception e) 
        {
          e.printStackTrace();
          return rs;
        }
        
        return rs;

    }

}