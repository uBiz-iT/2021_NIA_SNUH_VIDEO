package moila_video;


import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Locale;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.io.BufferedReader;
import java.text.SimpleDateFormat; 
import java.util.Date;


// properties 처리
import java.util.Properties;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.nio.file.Paths;

public class upload_video 
{
    static String projectCode = "";
    static String dataDir = "";

    // 오라클 연결 및 SQL문 실행
    static db_oracle db = null;      

    static int update_cnt = 0;
    static int insert_cnt = 0;
    static int event_update_cnt = 0;
    static int event_insert_cnt = 0; 
    static int image_update_cnt = 0;
    static int image_insert_cnt = 0; 
    
    static String dataRootPath = "";

    static String configFileName = "";
    static String db_user = "";
    static String db_passwd = "";
    static String db_connString = "";
    static SQLResult sqlResult = new SQLResult();
    
    static TarFiles tar = null; 

    public static void main(String[] args) 
    {
        
        if (args.length <= 1) {
            System.out.println("설정 파일명과 프로젝트 코드를 입력하세요.");
            return;
        }
        
        // 1번째(배열 0) 인자가 설정 파일 이름
        // 2번째(배열 1) 인자는 프로젝트 코드
        configFileName = args[0];
        
        if (!ReadProperties()) return;
        
        if (!ConnectDB()) return;
        
        tar = new TarFiles();
        
        try
        {
            db.conn.setAutoCommit(false);
            
            // -------------------------------------------------------------------------------
            // 프로젝트 정보 읽어옴
            // -------------------------------------------------------------------------------
            String sql = "";
            sql  = " SELECT PROJECT_CD, DATA_DIR";
            sql += " FROM   MST_PROJECT";
            sql += " WHERE  PROJECT_CD = '" + args[1] + "'";
            
            ResultSet rs = db.selectSQL(sql);
            
            System.out.println("");
            System.out.println("프로젝트 코드 " + args[1] + "의 검사 데이터를 데이터베이스에 반영합니다.");
            System.out.println("");

            boolean exist_project = false;
            while(rs.next())
            {
                projectCode = rs.getString("PROJECT_CD");
                dataDir = rs.getString("DATA_DIR");
                exist_project = true;
                break;
            }
            
            rs.close();
            db.pstmt.close();

            // -------------------------------------------------------------------------------
            // 프로젝트가 없으면 종료
            // -------------------------------------------------------------------------------
            if (!exist_project) {
                System.out.println("입력된 프로젝트 코드가 없습니다.");
                db.Close();
                return;
            }
            
            Path filePath = Paths.get(dataRootPath, dataDir);
            System.out.println("프로젝트 데이터 디렉토리 경로 : " + filePath.toString());
            System.out.println();

            File dataRoot = new File(filePath.toString());

            // -------------------------------------------------------------------------------
            // 프로젝트 데이터 디렉토리가 존재하는지 체크하여 없으면 종료
            // -------------------------------------------------------------------------------
            if(!dataRoot.exists())
            {
                System.out.println("데이터 경로 " + dataDir + "이 존재하지 않습니다.");
                db.Close();
                return;
            }
            
            // -------------------------------------------------------------------------------
            // 데이터 디렉토리 Path가 디렉토리가 아니면 종료
            // -------------------------------------------------------------------------------
            if(!dataRoot.isDirectory())
            {
                System.out.println("데이터 파일 경로가 디렉토리가 아닙니다.");
                db.Close();
                return;
            }

            // -------------------------------------------------------------------------------
            // 이미 테이블에 있는 PSG 테이블의 AUTO_LOAD_FG의 값을 'N'으로 전체 변경
            // 향후에 'N'으로 남아 있는 놈은 테이블에서 삭제 대상
            // -------------------------------------------------------------------------------
            sql  = " UPDATE MST_PSG";
            sql += " SET    AUTO_LOAD_FG = 'N'";
            sql += " WHERE  PROJECT_CD = '" + projectCode + "'";
            
            if (!db.executeSQL(sql, sqlResult)) {
                System.out.println("Error SQL : " + sql);
                System.out.println("에러가 발생하여 프로그램을 종료합니다.");
                db.Close();
                System.exit(1);
            }

            File[] dataRootFileList = dataRoot.listFiles();
            Arrays.sort(dataRootFileList);

            // -------------------------------------------------------------------------------
            // 이미지 디렉토리 하나씩 검색
            // -------------------------------------------------------------------------------
            for(File dataRootFile : dataRootFileList)
            {   
                // 디렉토리가 아닌 것은 처리할 필요가 없음
                if(!dataRootFile.isDirectory())
                {
                    continue;
                }

                switch (dataRootFile.getName())
                {   
                    case "result":          // 앱에서 업로드한 파일 저장 위치. 필요시 사용
                        break;
                    
                    case "source":          // 검사ID별 디렉토리
                        manageSourceDirectory(dataRootFile);
                        break;                            
                    
                    default:                
                        break;
                } 
            } 
            
            // -------------------------------------------------------------------------------
            // PSG 검사 목록 테이블에서 AUTO_LOAD_FG = 'N'로 여전히 있는 놈에 해당하는 진단 정보 데이터 삭제
            // -------------------------------------------------------------------------------
            sql  = " DELETE FROM MST_DI_INFO";
            sql += " WHERE  PROJECT_CD = '" + projectCode + "'";
            sql += " AND    PSG_ID  IN (SELECT PSG_ID";
            sql += "                    FROM   MST_PSG";
            sql += "                    WHERE  PROJECT_CD   = '" + projectCode + "'";
            sql += "                    AND    AUTO_LOAD_FG = 'N')";
            
            if (!db.executeSQL(sql, sqlResult)) {
                System.out.println("Error SQL : " + sql);
                System.out.println("에러가 발생하여 프로그램을 종료합니다.");
                db.Close();
                System.exit(1);
            }
            
            // -------------------------------------------------------------------------------
            // PSG 검사 목록 테이블에서 AUTO_LOAD_FG = 'N'로 여전히 있는 놈은 삭제
            // -------------------------------------------------------------------------------
            sql  = " DELETE FROM MST_PSG";
            sql += " WHERE  PROJECT_CD   = '" + projectCode + "'";
            sql += " AND    AUTO_LOAD_FG = 'N'";
            
            if (!db.executeSQL(sql, sqlResult)) {
                System.out.println("Error SQL : " + sql);
                System.out.println("에러가 발생하여 프로그램을 종료합니다.");
                db.Close();
                System.exit(1);
            }

            // -------------------------------------------------------------------------------
            // SUB 이미지 테이블에서 AUTO_LOAD_FG = 'N'로 여전히 있는 놈은 삭제
            // -------------------------------------------------------------------------------
            sql  = " DELETE FROM MST_PSG_IMAGE";
            sql += " WHERE  PROJECT_CD   = '" + projectCode + "'";
            sql += " AND    AUTO_LOAD_FG = 'N'";
            
            if (!db.executeSQL(sql, sqlResult)) {
                System.out.println("Error SQL : " + sql);
                System.out.println("에러가 발생하여 프로그램을 종료합니다.");
                db.Close();
                System.exit(1);
            }

            // -------------------------------------------------------------------------------
            // 이미지 및 이벤트 등록 건수 저장
            // -------------------------------------------------------------------------------
            sql  = " MERGE INTO MST_PSG P";
            sql += " USING  (SELECT T1.PROJECT_CD, T1.PSG_ID, NVL(IMAGE_CNT,0) IMAGE_CNT, NVL(EVENT_CNT,0) EVENT_CNT";
            sql += "         FROM (SELECT PROJECT_CD, PSG_ID";
            sql += "               FROM   MST_PSG P";
            sql += "               WHERE  PROJECT_CD = '" + projectCode + "'";
            sql += "              ) T1";
            sql += "               LEFT OUTER JOIN";
            sql += "              (SELECT PROJECT_CD, PSG_ID, COUNT(*) IMAGE_CNT";
            sql += "               FROM   MST_PSG_IMAGE";
            sql += "               WHERE  PROJECT_CD = '" + projectCode + "'";
            sql += "               GROUP BY PROJECT_CD, PSG_ID";
            sql += "              ) T2";
            sql += "         ON    T1.PROJECT_CD = T2.PROJECT_CD";
            sql += "         AND   T1.PSG_ID     = T2.PSG_ID";
            sql += "               LEFT OUTER JOIN";
            sql += "              (SELECT PROJECT_CD, PSG_ID, COUNT(*) EVENT_CNT";
            sql += "               FROM   MSV_EVENT_DATA";
            sql += "               WHERE  PROJECT_CD = '" + projectCode + "'";
            sql += "               GROUP BY PROJECT_CD, PSG_ID";
            sql += "              ) T3";
            sql += "         ON    T1.PROJECT_CD = T3.PROJECT_CD";
            sql += "         AND   T1.PSG_ID     = T3.PSG_ID";
            sql += "        ) C";
            sql += " ON (P.PROJECT_CD = C.PROJECT_CD";
            sql += " AND P.PSG_ID     = C.PSG_ID) ";
            sql += " WHEN MATCHED THEN";
            sql += " UPDATE SET P.IMAGE_REG_CNT = C.IMAGE_CNT,";
            sql += "            P.EVENT_CNT     = C.EVENT_CNT";
            
            if (!db.executeSQL(sql, sqlResult)) {
                System.out.println("Error SQL : " + sql);
                System.out.println("에러가 발생하여 프로그램을 종료합니다.");
                db.Close();
                System.exit(1);
            }

            // -------------------------------------------------------------------------------
            // PSG 검사 등록 건수 및 이벤트 전체 건수 저장
            // -------------------------------------------------------------------------------
            sql  = " MERGE INTO MST_PROJECT P";
            sql += " USING (";
            sql += "     SELECT PROJECT_CD, COUNT(*) CNT, SUM(EVENT_CNT) EVENT_CNT";
            sql += "     FROM   MST_PSG";
            sql += "     WHERE  PROJECT_CD = '" + projectCode + "'";
            sql += "     GROUP BY PROJECT_CD";
            sql += " ) S";
            sql += " ON (P.PROJECT_CD = S.PROJECT_CD)";
            sql += " WHEN MATCHED THEN";
            sql += " UPDATE SET P.PSG_CNT      = S.CNT,";
            sql += "            P.EVENT_CNT    = S.EVENT_CNT,";
            sql += "            P.PSG_REG_DATE = TO_CHAR(SYSDATE, 'YYYYMMDD')";
            
            if (!db.executeSQL(sql, sqlResult)) {
                System.out.println("Error SQL : " + sql);
                System.out.println("에러가 발생하여 프로그램을 종료합니다.");
                db.Close();
                System.exit(1);
            }

            System.out.println();
            System.out.println(update_cnt + "개의 검사 데이터가 수정 반영되었습니다.");
            System.out.println(insert_cnt + "개의 검사 데이터가 등록되었습니다.");

            db.conn.commit();
        }
        catch (SQLException e)
        {
            System.out.println("main() SQLException");
            e.printStackTrace();
        }
        catch (Exception e)
        {
            System.out.println("main() Exception");
            e.printStackTrace();
        }
        
        try {
            db.conn.rollback();
        }
        catch (SQLException e)
        {
            System.out.println("main() db.conn.rollback() SQLException");
            e.printStackTrace();
        }
        catch (Exception e)
        {
            System.out.println("main() db.conn.rollback() Exception");
            e.printStackTrace();
        }
        
        db.Close();

    }
    
    // --------------------------------------------------------------------------------------------------------
    // 설정 파일 읽기(DB 접속 정보 및 이미지 루트 경로)
    // --------------------------------------------------------------------------------------------------------
    private static boolean ReadProperties() 
    {
        try 
        {
            Properties pro = new Properties();

            InputStream is = new FileInputStream(configFileName);
            pro.load(is);

            db_connString = pro.getProperty("connectionString");
            db_user = pro.getProperty("userid");
            db_passwd = pro.getProperty("passwd");
            dataRootPath = pro.getProperty("dataRootDir");
            
            return true;
        }
        catch (IOException e) 
        {
            System.out.println("ReadProperties() IOException");
            e.printStackTrace();
            return false;
        }
        catch (Exception e) 
        {
            System.out.println("ReadProperties() Exception");
            e.printStackTrace();
            return false;
        }
        
    }
    

    // --------------------------------------------------------------------------------------------------------
    // 데이터베이스 연결
    // --------------------------------------------------------------------------------------------------------
    private static boolean ConnectDB() 
    {
        try 
        {
            String url = db_connString;
            String user = db_user;
            String password = db_passwd;
            
            db = new db_oracle(url, user, password);
            if (db.conn == null) return false;
            else return true;
            
        }
        catch (Exception e) 
        {
            System.out.println("connectDB() Exception");
            e.printStackTrace();
            return false;
        }
        
    }

    
    public static void manageSourceDirectory(File psgPath) 
    {
        File[] patientIDList = psgPath.listFiles();
        Arrays.sort(patientIDList);

        for(File patientID : patientIDList)
        {
            if(patientID.isDirectory())
            {
                File[] patientIDFileList = patientID.listFiles();
                Arrays.sort(patientIDFileList);

                manageDetailDirectory(patientID);
                
                // 한세트마다 commit
                try {
                    db.conn.commit();
                }
                catch (SQLException e)
                {
                    System.out.println("manageSourceDirectory db.conn.commit() SQLException");
                    e.printStackTrace();
                }
                catch (Exception e)
                {
                    System.out.println("manageSourceDirectory db.conn.commit() Exception");
                    e.printStackTrace();
                }

            }
        }
    }
    
    
    // --------------------------------------------------------------------------------------------------------
    // PSG 검사 id(환자 ID) 폴더 밑에 세부 데이터가 존재함
    // --------------------------------------------------------------------------------------------------------
    public static void manageDetailDirectory(File patientID) 
    {
        
        String psgID = patientID.getName();
        System.out.print("Patient ID : " + psgID);

        // -------------------------------------------------------------------------------
        // 이부분에서 환자의 진단 정보를 읽어 오는 부분 처리
        // -------------------------------------------------------------------------------
        Diagnosis diag = readDiagnosisInfo(patientID);

        // -------------------------------------------------------------------------------
        // MST_PSG와 진단정보 저장
        // -------------------------------------------------------------------------------
        insertPSGInfo(psgID);
        insertDiagInfo(psgID, diag);
        
        // -------------------------------------------------------------------------------
        // MST_SUB_IMAGE 저장
        // -------------------------------------------------------------------------------
        String sql = "";
        sql += " UPDATE MST_PSG_IMAGE";
        sql += " SET    AUTO_LOAD_FG = 'N'";
        sql += " WHERE  PROJECT_CD = '" + projectCode + "'";
        sql += " AND    PSG_ID     = '" + psgID + "'";
        
        if (!db.executeSQL(sql, sqlResult)) {
            System.out.println("Error SQL : " + sql);
            System.out.println("에러가 발생하여 프로그램을 종료합니다.");
            db.Close();
            System.exit(1);
        }
        
        File psgImageDir = new File(patientID, psgID.trim() + "_screenshot");      // 스크린샷(patient_id + '_screen')
        
        if (!psgImageDir.exists()) {
            System.out.println("        [에러] PSG 이미지 디렉토리 없음 : " + psgID.trim() + "_screenshot");
            return; 
        }
        
        File[] psgImageFileList = psgImageDir.listFiles();
        
        if (psgImageFileList.length == 0) {
            System.out.println("        [경고] PSG 이미지 디렉토리에 이미지 없음 : " + psgID.trim() + "_standard");
        }
        
        Arrays.sort(psgImageFileList);

        image_update_cnt = 0;
        image_insert_cnt = 0;
        event_update_cnt = 0;
        event_insert_cnt = 0;
        
        for(File psgImageFile : psgImageFileList)
        {
            // 이미지 ID가 파일인지 체크
            if(psgImageFile.isFile())
            {
                insertPSGImageInfo(psgID, getImageID(psgImageFile), psgImageFile.getName());
            }
        }

        // --------------------------------------------------------------------------------------------------------
        // 파일 묶기
        // --------------------------------------------------------------------------------------------------------
        String tarFileName = Paths.get(patientID.toString(), psgID.trim() + "_images.tar").toString().replace("\\", "/");
        try {
            tar.compress(tarFileName, psgImageDir, false);
        } 
        catch (IOException e) {
            e.printStackTrace();
            System.out.println("tar 파일 생성 중 에러가 발생하여 프로그램을 종료합니다.");
            db.Close();
            System.exit(1);
        }
        
        // --------------------------------------------------------------------------------------------------------
        // 이벤트 등록
        // --------------------------------------------------------------------------------------------------------
        manageEventInfo(psgID);
        
        int image_cnt = image_update_cnt + image_insert_cnt;
        int event_cnt = event_update_cnt + event_insert_cnt;
        
        System.out.print("이미지 " + image_cnt + "건, " + "이벤트 " + event_cnt + "건");
        System.out.println();

    }
    
    // --------------------------------------------------------------------------------------------------------
    // 이미지 파일명으로부터 확장자 빼고 가져와서 image ID로 사용
    // --------------------------------------------------------------------------------------------------------
    public static String getImageID(File dataRootFile) 
    {
        int Idx = dataRootFile.getName().lastIndexOf(".");
        return dataRootFile.getName().substring(0, Idx);
    }
    
    
    // --------------------------------------------------------------------------------------------------------
    // PSG 검사 목록 및 동영상 파일 정보 넣기
    // --------------------------------------------------------------------------------------------------------
    public static void insertPSGInfo(String psgID) {
        
        String videoFileName = psgID.trim() + "_video.mp4";
        String tarFileName = psgID.trim() + "_images.tar";
        String filePathString = Paths.get(dataDir, "source", psgID.trim(), videoFileName.trim()).toString().replace("\\", "/");
        String tarPathString = Paths.get(dataDir, "source", psgID.trim(), tarFileName.trim()).toString().replace("\\", "/");
        
        ResultSet rs = null;
        String sql = "";
        
        try {
            sql  = " SELECT *";
            sql += " FROM   MST_PSG";
            sql += " WHERE  PROJECT_CD = '" + projectCode + "'";
            sql += " AND    PSG_ID     = '" + psgID + "'";

            rs = db.selectSQL(sql);
            
            if(rs.next())
            {
                sql  = " UPDATE MST_PSG";
                sql += " SET    FILE_NAME       = '" + videoFileName + "'";
                sql += "       ,VIDEO_FILE_PATH = '" + filePathString + "'";
                sql += "       ,TAR_FILE_PATH = '" + tarPathString + "'";
                sql += "       ,AUTO_LOAD_FG    = 'Y'";
                sql += " WHERE  PROJECT_CD = '" + projectCode + "'";
                sql += " AND    PSG_ID     = '" + psgID + "'";

                System.out.print(" 등록중(수정).. ");

                if (!db.executeSQL(sql, sqlResult)) {
                    System.out.println("Error SQL : " + sql);
                    System.out.println("에러가 발생하여 프로그램을 종료합니다.");
                    db.Close();
                    System.exit(1);
                }

                update_cnt++;
            }
            else
            {
                sql  = " INSERT INTO MST_PSG";
                sql += "       (PROJECT_CD,";
                sql += "        PSG_ID,";
                sql += "        FILE_NAME,";
                sql += "        VIDEO_FILE_PATH,";
                sql += "        TAR_FILE_PATH,";
                sql += "        AUTO_LOAD_FG";
                sql += "       )";
                sql += " VALUES ('" + projectCode + "',";
                sql += "        '" + psgID +"',";
                sql += "        '" + videoFileName + "',";
                sql += "        '" + filePathString + "',";
                sql += "        '" + tarPathString + "',";
                sql += "        'Y')";
                
                System.out.print(" 등록중.. ");

                if (!db.executeSQL(sql, sqlResult)) {
                    System.out.println("Error SQL : " + sql);
                    System.out.println("에러가 발생하여 프로그램을 종료합니다.");
                    db.Close();
                    System.exit(1);
                }

                insert_cnt++;
            };

        }
        catch (SQLException se) 
        {
            System.out.println("Error SQL : " + sql);
            se.printStackTrace();
        }
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (db.pstmt != null) {
                    db.pstmt.close();
                }
            }
            catch(SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 진단 정보 테이블에 진단 정보 넣기
    // --------------------------------------------------------------------------------------------------------
    public static void insertDiagInfo(String psgID, Diagnosis diag) {
        
        ResultSet rs = null;
        
        String sql = "";
        
        try {
            sql  = " SELECT *";
            sql += " FROM   MST_DI_INFO";
            sql += " WHERE  PROJECT_CD = '" + projectCode + "'";
            sql += " AND    PSG_ID = '" + psgID + "'";

            rs = db.selectSQL(sql);
            
            if(rs.next())
            {
                sql = "UPDATE MST_DI_INFO SET DI_GENDER = '" + diag.gender 
                    + "', DI_AGE = '" + diag.age 
                    + "', DI_BMI = '" + diag.bmi 
                    + "', DI_TOT_SLEEP_TIME = '" + diag.tot_sleep_time 
                    + "', DI_SLEEP_EFFI = '" + diag.sleep_effi 
                    + "', DI_SLEEP_LATENCY = '" + diag.sleep_latency 
                    + "', DI_AHI = '" + diag.ahi 
                    + "', DI_RDI = '" + diag.rdi 
                    + "', DI_OXY_SATU_AVG = '" + diag.oxy_satu_avg 
                    + "', DI_OXY_SATU_MIN = '" + diag.oxy_satu_min 
                    + "', DI_TOT_LM_INDEX = '" + diag.tot_lm_index 
                    + "', DI_TOT_LM_AROU = '" + diag.tot_lm_arou 
                    + "', DI_AROU_INDEX = '" + diag.arou_index 
                    + "' WHERE PROJECT_CD = '" + projectCode + "' AND PSG_ID = '" + psgID + "'";

                if (!db.executeSQL(sql, sqlResult)) {
                    System.out.println("Error SQL : " + sql);
                    System.out.println("에러가 발생하여 프로그램을 종료합니다.");
                    db.Close();
                    System.exit(1);
                }

            }
            else
            {
                sql = "INSERT INTO MST_DI_INFO(PROJECT_CD, PSG_ID, " 
                    + "DI_GENDER, " 
                    + "DI_AGE, " 
                    + "DI_BMI, " 
                    + "DI_TOT_SLEEP_TIME, " 
                    + "DI_SLEEP_EFFI, " 
                    + "DI_SLEEP_LATENCY, " 
                    + "DI_AHI, " 
                    + "DI_RDI, " 
                    + "DI_OXY_SATU_AVG, " 
                    + "DI_OXY_SATU_MIN, " 
                    + "DI_TOT_LM_INDEX, " 
                    + "DI_TOT_LM_AROU, " 
                    + "DI_AROU_INDEX) " 
                    + "VALUES('" + projectCode + "', '" + psgID
                    + "', '" + diag.gender   
                    + "', '" + diag.age
                    + "', '" + diag.bmi  
                    + "', '" + diag.tot_sleep_time  
                    + "', '" + diag.sleep_effi  
                    + "', '" + diag.sleep_latency  
                    + "', '" + diag.ahi  
                    + "', '" + diag.rdi  
                    + "', '" + diag.oxy_satu_avg  
                    + "', '" + diag.oxy_satu_min  
                    + "', '" + diag.tot_lm_index
                    + "', '" + diag.tot_lm_arou  
                    + "', '" + diag.arou_index  
                    + "')";
                
                if (!db.executeSQL(sql, sqlResult)) {
                    System.out.println("Error SQL : " + sql);
                    System.out.println("에러가 발생하여 프로그램을 종료합니다.");
                    db.Close();
                    System.exit(1);
                }

            }

        }
        catch (SQLException se) 
        {
            System.out.println("Error SQL : " + sql);
            se.printStackTrace();
        }
        catch (Exception e) 
        {
          e.printStackTrace();
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (db.pstmt != null) {
                    db.pstmt.close();
                }
            }
            catch(SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 이 함수에서 진단 정보 파일을 읽어서 클래스에 담아 넘겨야 함.
    // --------------------------------------------------------------------------------------------------------
    public static Diagnosis readDiagnosisInfo(File patientID) 
    {
        Diagnosis diag = new Diagnosis();
        
        diag.gender = "";
        diag.age = "";
        diag.bmi = "";
        diag.tot_sleep_time = "";
        diag.sleep_effi = "";
        diag.sleep_latency = "";
        diag.ahi = "";
        diag.rdi = "";
        diag.oxy_satu_avg = "";
        diag.oxy_satu_min = "";
        diag.tot_lm_index = "";
        diag.tot_lm_arou = "";
        diag.arou_index = "";

        String multiImageID = patientID.getName();
        
        BufferedReader br = null;
        
        try{
            br = Files.newBufferedReader(Paths.get(dataRootPath, dataDir, "source", multiImageID.trim(), multiImageID.trim() + "_report.txt"), Charset.defaultCharset());
            String line = "";
            
            line = br.readLine();       // 1개 라인에 정보가 다 있음. 한번만 읽음
            if (line != null) {
                String diagArray[] = line.split(",");
                
                diag.gender = diagArray[1];
                diag.age = diagArray[2];
                diag.bmi = diagArray[3];
                diag.tot_sleep_time = diagArray[6];
                diag.sleep_effi = diagArray[7];
                diag.sleep_latency = diagArray[8];
                diag.ahi = diagArray[41];
                diag.rdi = diagArray[44];
                diag.oxy_satu_avg = diagArray[69];
                diag.oxy_satu_min = diagArray[72];
                diag.tot_lm_index = diagArray[78];
                diag.tot_lm_arou = diagArray[81];
                diag.arou_index = diagArray[83];
            }
                    
        }
        catch(FileNotFoundException e){
            e.printStackTrace();
        }
        catch(IOException e){
            e.printStackTrace();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally {
            try {
                if(br != null) {
                    br.close();
                }
            }
            catch(IOException e) {
                e.printStackTrace();
            }
        }

        return diag;
    }
    
    // --------------------------------------------------------------------------------------------------------
    // PSG 이미지 테이블에 PSG 이미지 파일 정보 넣기
    // --------------------------------------------------------------------------------------------------------
    public static void insertPSGImageInfo(String psgID, String imageID, String fileName) 
    {   
        // 데이터 디렉토리 + source + PSG ID + PSG ID_screenshot + PSG이미지파일명
        String imagePathString = Paths.get(dataDir, "source", psgID, psgID.trim() + "_screenshot", fileName.trim()).toString().replace("\\", "/");
        
        ResultSet rs = null;
        
        int epo_no = 0;
        try {
            epo_no = Integer.parseInt(imageID.substring(imageID.length()-4, imageID.length()));
        }
        catch (Exception e) {
            epo_no = 0;
        }
        
        String sql = "";

        try 
        {
            sql += " SELECT *";
            sql += " FROM   MST_PSG_IMAGE";
            sql += " WHERE  PROJECT_CD   = '" + projectCode + "'";
            sql += " AND    PSG_ID       = '" + psgID + "'";
            sql += " AND    IMAGE_ID     = '" + imageID + "'";
            
            rs = db.selectSQL(sql);

            if(rs.next())
            {
                sql  = " UPDATE MST_PSG_IMAGE";
                sql += " SET    EPO_NO        =  " + epo_no;
                sql += "      , FILE_NAME     = '" + fileName + "'";
                sql += "      , FILE_PATH     = '" + imagePathString + "'";
                sql += "      , AUTO_LOAD_FG  = 'Y'";
                sql += " WHERE  PROJECT_CD    = '" + projectCode + "'";
                sql += " AND    PSG_ID        = '" + psgID + "'";
                sql += " AND    IMAGE_ID      = '" + imageID + "'";
                
                if (!db.executeSQL(sql, sqlResult)) {
                    System.out.println("Error SQL : " + sql);
                    System.out.println("에러가 발생하여 프로그램을 종료합니다.");
                    db.Close();
                    System.exit(1);
                }

                image_update_cnt++;
            }
            else
            {
                sql  = " INSERT INTO MST_PSG_IMAGE";
                sql += "       (PROJECT_CD";
                sql += "      , PSG_ID";
                sql += "      , IMAGE_ID";
                sql += "      , EPO_NO";
                sql += "      , FILE_NAME";
                sql += "      , FILE_PATH";
                sql += "      , AUTO_LOAD_FG";
                sql += "       )";
                sql += " VALUES('" + projectCode + "'";
                sql += "      , '" + psgID + "'";
                sql += "      , '" + imageID + "'";
                sql += "      ,  " + epo_no;
                sql += "      , '" + fileName + "'";
                sql += "      , '" + imagePathString + "'";
                sql += "      , 'Y'";
                sql += "       )";
                
                if (!db.executeSQL(sql, sqlResult)) {
                    System.out.println("Error SQL : " + sql);
                    System.out.println("에러가 발생하여 프로그램을 종료합니다.");
                    db.Close();
                    System.exit(1);
                }

                image_insert_cnt++;
            };

        }
        catch (SQLException se) {
            System.out.println("Error SQL : " + sql);
            se.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (db.pstmt != null) {
                    db.pstmt.close();
                }
            }
            catch(SQLException e) {
                e.printStackTrace();
            }
        }
        
    }

    // --------------------------------------------------------------------------------------------------------
    // 이벤트 정보 생성
    // --------------------------------------------------------------------------------------------------------
    public static void manageEventInfo(String psgID) {
        
        BufferedReader br = null;
        
        int eventcount = 0;
        boolean startOk = false;
        
        SimpleDateFormat dtFormat = new SimpleDateFormat("M/d/yyyy h:mm:ss a", Locale.US);  // 3/7/2019 1:06:00 PM, Locale.US를 하지 않으면 기본적으로 한글 오전,오후로 처리하여 인식 불가
        SimpleDateFormat newDtFormat = new SimpleDateFormat("yyyyMMddHHmmss");              // 20190307130630 오라클에 날짜 타입으로 저장하기 좋게 미리 형식을 이쁘게 변경
        Date formatDate = new Date();
        Date startDate = new Date();
        
        // 1번째 라인은 타이틀
        // 2번째 라인은 타입?
        // 3번째 라인은 분석 시작 시각
        // 4번째 라인부터 데이터
        
        ResultSet rs = null;
        String sql = "";
        int result_cnt = 0;

        try 
        {
            sql  = " SELECT COUNT(*) CNT";
            sql += " FROM   WRK_EVENT_RESULT";
            sql += " WHERE  PROJECT_CD   = '" + projectCode + "'";
            sql += " AND    PSG_ID       = '" + psgID + "'";
            
            rs = db.selectSQL(sql);

            if(rs.next())
            {
                result_cnt = rs.getInt("CNT");
            }
        }
        catch (SQLException se) {
            System.out.println("Error SQL : " + sql);
            se.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (db.pstmt != null) {
                    db.pstmt.close();
                }
            }
            catch(SQLException e) {
                e.printStackTrace();
            }
        }
        
        if (result_cnt > 0) {
            System.out.print("이벤트 검수 결과 존재로 등록 취소. ");
            return;
        }

        sql  = " DELETE FROM MST_EVENT_DATA";
        sql += " WHERE  PROJECT_CD = '" + projectCode + "'";
        sql += " AND    PSG_ID = '" + psgID + "'";

        if (!db.executeSQL(sql, sqlResult)) {
            System.out.println("Error SQL : " + sql);
            System.out.println("에러가 발생하여 프로그램을 종료합니다.");
            db.Close();
            System.exit(1);
        }

        try{
            br = Files.newBufferedReader(Paths.get(dataRootPath, dataDir, "source", psgID.trim(), psgID.trim() + "_event.csv"), Charset.defaultCharset());
            String lineData = "";
            
            PSGEvent psgEvent = new PSGEvent();
            
            while (true) {

                lineData = br.readLine();

                if (lineData == null) {
                    break;
                }

                String columns[] = lineData.split(",");
                
                if (columns[0].equals("Analysis Start")) {
                    startOk = true;
                    startDate = dtFormat.parse(columns[2]);
                    continue;
                }
                
                if (startOk) {
                    eventcount = eventcount + 1;
                    try {
                        psgEvent.event_seq = eventcount;
                        psgEvent.event_name = columns[0].trim();
                        psgEvent.elapsed_seconds = Math.round(Float.parseFloat(columns[1])*1000)/(float)1000.0;
                        
                        formatDate = dtFormat.parse(columns[2]);
                        psgEvent.begin_date = newDtFormat.format(formatDate);
                        psgEvent.begin_second = (int) (formatDate.getTime() - startDate.getTime()) / 1000;     // 맨 처음부터 몇초인가
                        
                        //System.out.println("begin_second : " + psgEvent.begin_second + "(" + formatDate + "," + startDate);
                        
                        formatDate = dtFormat.parse(columns[3]);
                        psgEvent.end_date = newDtFormat.format(formatDate);
                        psgEvent.end_second = (int) (formatDate.getTime() - startDate.getTime()) / 1000;       // 맨 처음부터 몇초인가
                        
                        //System.out.println("end_second : " + psgEvent.end_second + "(" + formatDate + "," + startDate);

                        psgEvent.begin_epoch_no = Integer.parseInt(columns[4]);
                        psgEvent.end_epoch_no = Integer.parseInt(columns[5]);
                        
                        insertEventInfo(psgID, psgEvent);
                        
                    } 
                    catch (NumberFormatException e) {
                        e.printStackTrace();
                        continue;
                    }
                    
                }
                
            }
                    
        }
        catch(FileNotFoundException e){
            e.printStackTrace();
        }
        catch(IOException e){
            e.printStackTrace();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally {
            try {
                if(br != null) {
                    br.close();
                }
            }
            catch(IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    // --------------------------------------------------------------------------------------------------------
    // 진단 정보 테이블에 진단 정보 넣기
    // --------------------------------------------------------------------------------------------------------
    public static void insertEventInfo(String psgID, PSGEvent psgEvent) {
        
        ResultSet rs = null;
        
        String sql = "";
        
        try {
            
            sql  = " INSERT INTO MST_EVENT_DATA";
            sql += "        (PROJECT_CD";
            sql += "        ,PSG_ID";
            sql += "        ,EVENT_SEQ";
            sql += "        ,EVENT_NM";
            sql += "        ,BEG_DT";
            sql += "        ,END_DT";
            sql += "        ,BEG_EPO_NO";
            sql += "        ,END_EPO_NO";
            sql += "        ,BEG_SEC";
            sql += "        ,END_SEC";
            sql += "        ,ELAPSED_SEC";
            sql += "        )";
            sql += " VALUES ('" + projectCode + "'";
            sql += "        ,'" + psgID + "'";
            sql += "        , " + psgEvent.event_seq;
            sql += "        ,'" + psgEvent.event_name + "'";
            sql += "        , TO_DATE('" + psgEvent.begin_date + "', 'YYYYMMDDHH24MISS')";
            sql += "        , TO_DATE('" + psgEvent.end_date + "', 'YYYYMMDDHH24MISS')";
            sql += "        , " + psgEvent.begin_epoch_no;
            sql += "        , " + psgEvent.end_epoch_no;
            sql += "        , " + psgEvent.begin_second;
            sql += "        , " + psgEvent.end_second;
            sql += "        , " + psgEvent.elapsed_seconds;
            sql += "        )";

            if (!db.executeSQL(sql, sqlResult)) {
                if (sqlResult.code == 2291) {
                    System.out.println(psgEvent.event_seq + "," + psgEvent.event_name + "," + psgEvent.elapsed_seconds + "," + psgEvent.begin_date + "," + psgEvent.end_date + "," + psgEvent.begin_epoch_no + "," + psgEvent.end_epoch_no);
                    System.out.println("미등록 이벤트 코드 : " + psgEvent.event_name);
                }
                else {
                    System.out.println("Error SQL : " + sql);
                    System.out.println("에러가 발생하여 프로그램을 종료합니다.");
                    db.Close();
                    System.exit(1);
                }
            }
            
            event_insert_cnt = event_insert_cnt + 1;

        }
        catch (Exception e) 
        {
            System.out.println("허허 이상허네");
            e.printStackTrace();
            db.Close();
            System.exit(1);
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (db.pstmt != null) {
                    db.pstmt.close();
                }
            }
            catch(SQLException e) {
                e.printStackTrace();
            }
        }
    }

}
