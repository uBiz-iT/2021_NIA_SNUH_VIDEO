package moila_video;

public class PSGEvent {
    public int event_seq;
    public String event_name;
    public String begin_date;
    public String end_date;
    public int begin_epoch_no;
    public int end_epoch_no;
    public int begin_second;
    public int end_second;
    public float elapsed_seconds;
}
