package moila_video;

public class SQLResult {
    public Integer code; 
    public String msg;   
}
