//
//  LoginVC.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 02/11/2018.
//  Copyright © 2018 uBiz Information Technology. All rights reserved.
//

import UIKit

class LoginVC: UIViewController {

    @IBOutlet var myNaviBar: UINavigationBar!
    
    //@IBOutlet var tableViewLogin: UITableView!
    @IBOutlet var serverAddress: UITextField!
    @IBOutlet var loginIDTitleLabel: UILabel!
    @IBOutlet var loginNameTitleLabel: UILabel!
    @IBOutlet var passwordTitleLabel: UILabel!
    @IBOutlet var LoginIDText: UITextField!
    @IBOutlet var LoginNameText: UITextField!
    @IBOutlet var PasswordText: UITextField!
    @IBOutlet var ConfirmButton: UIButton!
    @IBOutlet weak var IsManagerButton: UIButton!
    
    var befServerAddr:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // 2 touch 2 taps
        let doubleTapGesture = UIShortTapGestureRecognizer(target: self, action: #selector(doubleTapped(_:)))
        doubleTapGesture.numberOfTouchesRequired = 2
        doubleTapGesture.numberOfTapsRequired = 2
        self.view.addGestureRecognizer(doubleTapGesture)
        
        self.title = "로그인/로그아웃"

        setRadioImage()
        
        ConfirmButton.setRounded()
        isManagerButtonChecked = isManager
        initContents()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    var errorMessage: String = "No Error!"
    
    var isManagerButtonChecked = false {
        didSet {
            IsManagerButton.setImage(isManagerButtonChecked ? checkedBoxImage : uncheckedBoxImage, for: .normal)
        }
    }

    var checkedBoxImage: UIImage?
    var uncheckedBoxImage: UIImage?

    func setRadioImage() {
        if #available(iOS 13.0, *) {
            checkedBoxImage = UIImage(systemName: "checkmark.square")
            uncheckedBoxImage = UIImage(systemName: "square")
        }
        else {
            checkedBoxImage = UIImage(named: "checkbox-checked")
            uncheckedBoxImage = UIImage(named: "checkbox-unchecked")
        }
    }
    

    @IBAction func ConfirmButtonTapped(_ sender: Any) {
        
        self.view.endEditing(true)
        
        if (isLogin) {
            
            let dialogMessage:UIAlertController
            
            if (EXIST_NOTSAVEDDATA) {
                dialogMessage = UIAlertController(title: "확인", message: "저장되지 않은 데이터가 있습니다. \n 로그아웃 하시겠습니까?", preferredStyle: .alert)
            }
            else {
                dialogMessage = UIAlertController(title: "확인", message: "로그아웃 하시겠습니까?", preferredStyle: .alert)
            }
            
            let ok = UIAlertAction(title: "예", style: .destructive, handler: { (action) -> Void in
                self.logOut()
                
            })
            let cancel = UIAlertAction(title: "아니오", style: .cancel) { (action) -> Void in
            }
            dialogMessage.addAction(ok)
            dialogMessage.addAction(cancel)
            self.present(dialogMessage, animated: true, completion: nil)
        }
        else {
            
            befServerAddr = UserDefaults.standard.string(forKey: DefaultKey_ServerAddress)
            SetServerAddress(serverAddress.text!)
            
            // ------------------------------------------------
            // 진행중 메세지 표시
            // ------------------------------------------------
            let alertProgressNoAction = UIAlertController(title: "로그인 중...\n\n\n", message: nil, preferredStyle: .alert)
            let spinnerIndicator = UIActivityIndicatorView(style: .large)
            spinnerIndicator.center = CGPoint(x: 135.0, y: 85.5)
            spinnerIndicator.color = UIColor.black
            spinnerIndicator.startAnimating()
            alertProgressNoAction.view.addSubview(spinnerIndicator)
            self.present(alertProgressNoAction, animated: false, completion: nil)

            DoEvents(f: 0.01)   // 그릴 시간...

            let success = requestLogin()
            if (success) {
                isLogin = true
                p("Log in 성공 : \(LoginID), \(LoginName)")
                alertProgressNoAction.dismiss(animated: false, completion: nil)
            }
            else {
                isLogin = false
                p("Log in 실패 : \(LoginID)")
                spinnerIndicator.removeFromSuperview()
                let otherAction = UIAlertAction(title: "OK", style: .default, handler: { action in
                    alertProgressNoAction.dismiss(animated: true, completion: nil)
                })
                alertProgressNoAction.title = "로그인 실패!\n\n\(LastURLErrorMessage)\n\n"
                alertProgressNoAction.addAction(otherAction)
            }
            
            logInOut()
        }
    }
    
    @IBAction func IsManagerButtionPressed(_ sender: Any) {
        isManagerButtonChecked = !isManagerButtonChecked
    }
    
    var isUbizServer = false
    
    @objc func doubleTapped(_ gesture: UITapGestureRecognizer) {
        
        if isLogin { return }
        
        isUbizServer.toggle() 
        if isUbizServer {
            serverAddress.text = "http://ubizit.kr:8080/VIDEO"
        }
        else {
            serverAddress.text = "http://211.192.49.71:3002/VIDEO"
        }

    }
    

    func logOut() {
        let success = requestLogout()
        if (success) {
            isLogin = false
            
            if let sessionUrl = SESSION_URL {
                deleteCookies(forURL: sessionUrl)
            }
            
            // ---------------------------------------------------------
            // 로그아웃하면 진행중인 다운로드 태스크 중지하고 다운로드 대기중인 것 모두 삭제
            // ---------------------------------------------------------
            cancelAllDownloadGlobal()
            
            p("Log out 성공", LoginName)
            
        }
        else {
            isLogin = true
            self.view.showToast(toastMessage: "로그아웃 에러. 재시도하시기 바랍니다.", duration: 0.6)
            p("Log out 실패 : ", LoginName)
        }
        if !isLogin {
            logInOut()
        }
    }
    
    func initContents() {
        serverAddress.text = ServerAddress
        LoginIDText.text = LoginID
        LoginNameText.isEnabled = false

        if (isLogin) {
            loginIDTitleLabel.text = "로그인 ID"
            
            loginNameTitleLabel.isHidden = false
            LoginNameText.isHidden = false
            
            LoginNameText.text = LoginName
            ConfirmButton.setTitle("Log out", for: .normal)
            passwordTitleLabel.isHidden = true
            PasswordText.isHidden = true
            PasswordText.text = ""
            
            serverAddress.isEnabled = false
            LoginIDText.isEnabled = false
            IsManagerButton.isEnabled = false
        }
        else {
            loginIDTitleLabel.text = "로그인 ID"
            
            loginNameTitleLabel.isHidden = true
            LoginNameText.isHidden = true
            
            LoginNameText.text = ""
            ConfirmButton.setTitle("Log in", for: .normal)
            passwordTitleLabel.isHidden = false
            PasswordText.isHidden = false
            PasswordText.text = ""

            serverAddress.isEnabled = true
            LoginIDText.isEnabled = true
            IsManagerButton.isEnabled = true
        }
    }
    
    func logInOut() {

        if (isLogin) {
            if let befId = UserDefaults.standard.string(forKey: DefaultKey_loginId),
               let befAddr = befServerAddr,
               befId == LoginID && befAddr == ServerAddress {
                UserDefaultWorkingProjectCode = WorkingProjectCode
            }
            
            UserDefaults.standard.set(true, forKey: DefaultKey_isLogin)
            UserDefaults.standard.set(LoginID, forKey: DefaultKey_loginId)
            UserDefaults.standard.set(LoginName, forKey: DefaultKey_loginName)
            UserDefaults.standard.set(isManager, forKey: DefaultKey_isManager)
        }
        else {
            LoginName = "Not signed."
            UserDefaults.standard.set(false, forKey: DefaultKey_isLogin)
            UserDefaults.standard.removeObject(forKey: DefaultKey_loginName)
            UserDefaults.standard.removeObject(forKey: DefaultKey_isManager)
        }
        initContents()
        
        // login이면 기존 프로젝트 정보 클리어 및 새로 요청
        if (isLogin) {
            clearProject()
            let rp = RequestProject()
            
            let (success, code) = rp.projectList()
            
            if (success) {
                let ud = MyUserDefaults()
                ud.setWorkingProjectInfo()

                // 로그인 창을 닫는다.
                if (isWorking) {
                    performSegue(withIdentifier: "unwindFromNewLogin", sender: self)
                    self.dismiss(animated: true, completion: nil)
                }
                else {
                    performSegue(withIdentifier: "unwindFromNewLogin", sender: self)
                    self.dismiss(animated: true, completion: nil)
                }
            }
            else {
                if needToLogin(errno: code!) {
                    self.view.showToast(toastMessage: "\n    권한 에러   \u{200c}\n", duration: 1.0)
                }
                else {
                    alertSimpleMessage("확인", LastURLErrorMessage)
                }
                isLogin = false
                LoginName = "Not signed."
                UserDefaults.standard.set(false, forKey: DefaultKey_isLogin)
                UserDefaults.standard.removeObject(forKey: DefaultKey_loginName)
                UserDefaults.standard.removeObject(forKey: DefaultKey_isManager)
                initContents()
                
            }
        }
    }
    
    func clearProject() {
        // 전역 리스트 변수 내용 제거
        ProjectList.removeAll()
        psgList.removeAll()
        LabelList.arrayLabelInfo.removeAll()
        
        // 전역 변수 초기화
        isWorking = false
        WorkingProjectCode = ""
        WorkingProjectName = "프로젝트 선택되지 않음"
        WorkingProjectImageDir = ""
        WorkingImageIndex = 0
        WorkingImageId = ""
        LastLabelingImageId = ""
        WorkingSubImageIndex = 0
        WorkingSubImageId = ""
        LastLabelingSubImageId = ""
        WorkingEventIndex = 0

        // 유저디폴트 초기화
        UserDefaults.standard.set(isWorking, forKey: DefaultKey_isWorking)
        UserDefaults.standard.removeObject(forKey: DefaultKey_ProjectCode)
        UserDefaults.standard.removeObject(forKey: DefaultKey_ProjectName)
        UserDefaults.standard.removeObject(forKey: DefaultKey_ProjectImageDir)          // 20200826
        UserDefaults.standard.removeObject(forKey: DefaultKey_ImageIndex)
        UserDefaults.standard.removeObject(forKey: DefaultKey_ImageId)
        UserDefaults.standard.removeObject(forKey: DefaultKey_LastLabelingImageId)
        UserDefaults.standard.removeObject(forKey: DefaultKey_SubImageIndex)
        UserDefaults.standard.removeObject(forKey: DefaultKey_SubImageId)
        UserDefaults.standard.removeObject(forKey: DefaultKey_LastLabelingSubImageId)
        UserDefaults.standard.removeObject(forKey: DefaultKey_EventIndex)
    }
}

