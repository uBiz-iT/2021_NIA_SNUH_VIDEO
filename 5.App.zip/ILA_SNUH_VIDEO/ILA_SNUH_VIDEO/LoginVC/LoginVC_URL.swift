//
//  LoginVC_URL.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 06/11/2018.
//  Copyright © 2018 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LoginVC {

    enum typeURLRequest:Int {
        case Login = 0, Logout, End
    }
    
    enum typeJsonParsing:Int {
        case Login, Logout, Success, ErrorMessage, End
    }

    // 로그인 체크
    // ==========================================================================
    func requestLogin() -> Bool {
        // ------------------------------------------------
        let requestURL = makeURLRequestForJsonFromServer(requestType: .Login)
        var result = false
        
        LastURLErrorMessage = ""

        let (success, error, err_code, err_msg, json ) = SendRequestForJSON(requestURL: requestURL, isNeedSetSession: true)
        
        do {
            if (!success!) {
                if let e = error {
                    throw e
                }
                else {
                    throw ResponseDataError.RequestURLForJSON
                }
            }

            guard let getSuccess = self.parseJson(parsingType: .Success, jsonFormat: json) as? Bool
                else {
                    throw ResponseDataError.JsonParsing
            }
            
            if (!getSuccess) {
                guard let msg:String =
                    self.parseJson(parsingType: .ErrorMessage, jsonFormat: json) as? String
                    else { throw ResponseDataError.JsonParsing }
                
                LastURLErrorMessage = msg
                
                throw ResponseDataError.ReturnValue
            }
            
            p("---------------------------------")
            guard let loginName:String =
                self.parseJson(parsingType: .Login, jsonFormat: json) as? String
                else { throw ResponseDataError.JsonParsing }
            
            LoginName = loginName
            
            result = true

        }
        catch let error as RequestURLError {
            if (error == RequestURLError.URLSession) {
                LastURLErrorMessage = "[\(String(describing: err_code!))]" + err_msg!
            }
            else {
                LastURLErrorMessage = error.rawValue
            }
        }
        catch let error as ResponseDataError {
            if (LastURLErrorMessage == "") {
                LastURLErrorMessage = error.rawValue
            }
            p("[ResponseDataError] \(error.rawValue)")
        }
        catch let error as NSError {
            LastURLErrorMessage = error.debugDescription
            p("[NSError  ] \(error.debugDescription)")
        }
        catch let error {
            LastURLErrorMessage = error.localizedDescription
            p("[Error  ] \(error.localizedDescription)")
        }
        
        return result
    }
    
    // 로그아웃
    // ==========================================================================
    func requestLogout() -> Bool {
        // ------------------------------------------------
        let requestURL = makeURLRequestForJsonFromServer(requestType: .Logout)
        var result = false
        
        LastURLErrorMessage = ""

        result = true
        //let (success, error, err_code, err_msg, json ) = SendRequestForJSON(requestURL: requestURL)
        let (_, _, _, _, _) = SendRequestForJSON(requestURL: requestURL)

//        do {
//            if (!success!) {
//                if let e = error {
//                    throw e
//                }
//                else {
//                    throw ResponseDataError.RequestURLForJSON
//                }
//            }
//
//            guard let getSuccess = self.parseJson(parsingType: .Success, jsonFormat: json) as? Bool
//                else {
//                    throw ResponseDataError.JsonParsing
//            }
//
//            if (!getSuccess) {
//                guard let msg:String =
//                    self.parseJson(parsingType: .ErrorMessage, jsonFormat: json) as? String
//                    else { throw ResponseDataError.JsonParsing }
//
//                LastURLErrorMessage = msg
//
//                throw ResponseDataError.ReturnValue
//            }
//
//            result = true
//
//        }
//        catch let error as RequestURLError {
//            if (error == RequestURLError.URLSession) {
//                LastURLErrorMessage = "[\(String(describing: err_code!))]" + err_msg!
//            }
//            else {
//                LastURLErrorMessage = error.rawValue
//            }
//        }
//        catch let error as ResponseDataError {
//            if (LastURLErrorMessage == "") {
//                LastURLErrorMessage = error.rawValue
//            }
//            p("[ResponseDataError] \(error.rawValue)")
//        }
//        catch let error as NSError {
//            LastURLErrorMessage = error.debugDescription
//            p("[NSError  ] \(error.debugDescription)")
//        }
//        catch let error {
//            LastURLErrorMessage = error.localizedDescription
//            p("[Error  ] \(error.localizedDescription)")
//        }
        
        return result
    }
    
    // 서버로부터 json 포맷으로 받기 위한 url request 생성하기
    // ==========================================================================
    func makeURLRequestForJsonFromServer(requestType:typeURLRequest) -> URLRequest? {
        
        var request:URLRequest? = nil
        
        switch requestType {
        case typeURLRequest.Login:  // 로그인
            
            LoginID = LoginIDText.text!
            
            struct RequestLoginInfo: Codable {
                var proc_name: String?
                var user_id: String?
                var passwd: String?
                var is_manager: String?
            }
            
            var requestLoginInfo = RequestLoginInfo();
            requestLoginInfo.proc_name = "P_LOGIN"
            requestLoginInfo.user_id = LoginID
            requestLoginInfo.passwd = PasswordText.text
            requestLoginInfo.is_manager = isManagerButtonChecked ? "Y" : "N"
            
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted]
            
            let jsonData = try? encoder.encode(requestLoginInfo);
            
            // 접속 server url 정의
            // -------------------------------------------------
            let endpoint = "\(ILA4ML_URL_LOGIN)?id=\(LoginID)"
            guard let endpointUrl = URL(string: endpoint) else {
                p("URL Error : \(endpoint)")
                return nil
            }
            
            // 요청할 최종 url 정의
            // -------------------------------------------------
            request = URLRequest(url: endpointUrl)
            request?.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            request!.httpMethod = "POST"
            request!.httpBody = jsonData
            
        case typeURLRequest.Logout:
            
            LoginID = LoginIDText.text!
            
            struct RequestLoginInfo: Codable {
                var proc_name: String?
                var user_id: String?
            }
            
            var requestLoginInfo = RequestLoginInfo();
            requestLoginInfo.proc_name = "P_LOGOUT"
            requestLoginInfo.user_id = LoginID
            
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted]
            
            let jsonData = try? encoder.encode(requestLoginInfo);
            
            // 접속 server url 정의
            // -------------------------------------------------
            let endpoint = "\(ILA4ML_URL_LOGOUT)?id=\(LoginID)"

            guard let endpointUrl = URL(string: endpoint) else {
                p("URL Error : \(endpoint)")
                return nil
            }
            
            // 요청할 최종 url 정의
            // -------------------------------------------------
            request = URLRequest(url: endpointUrl)
            request?.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            request!.httpMethod = "POST"
            request!.httpBody = jsonData
            
        default:
            break
        }
        
        return request
        
    }
    
    // JSON 포맷 파싱
    // ==========================================================================
    func parseJson(parsingType:typeJsonParsing, jsonFormat:Dictionary<String, Any>?) -> AnyObject? {
        
        let returnAnyObject:Bool = false
        
        guard let json = jsonFormat else {
            p("func parseJson:jsonFormat is nil")
            return returnAnyObject as AnyObject
        }
        
        switch parsingType {
        case typeJsonParsing.Success:  // 성공여부 가져오기
            
            do {
                guard let success = json["success"] as? Bool else {
                    throw ResponseDataError.JsonProtocol
                }
                return success as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }
            
        case typeJsonParsing.ErrorMessage:  //  에러 메시지 가져오기
            
            do {
                guard let errorMessage = json["err_msg"] as? String else {
                    throw ResponseDataError.JsonProtocol
                }
                return errorMessage as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }
        case typeJsonParsing.Login:  // 로그인
            do {
                
                guard let pass_rate = json["pass_rate"] as? Float,
                      let pass_cnt_rate = json["pass_cnt_rate"] as? Float,
                      let ver = json["ver"] as? String,
                      let build = json["build"] as? String,
                      let ver_content = json["ver_content"] as? String,
                      let ver_date = json["ver_date"] as? String
                else {
                    throw ResponseDataError.JsonProtocol
                }
                PASS_RATE = pass_rate
                PASS_COUNT_RATE = pass_cnt_rate
                APP_VERSION = ver
                APP_BUILD = build
                APP_CONTENT = ver_content
                APP_DIST_DATE = ver_date
                
                guard let userName = json["user_nm"] as? String,
                      let is_manager:String = json["is_manager"] as? String else {
                    throw ResponseDataError.JsonProtocol
                }
                isManager = (is_manager == "Y") ? true : false
                return userName as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }
            
        default:
            break
        }
        
        return returnAnyObject as AnyObject
        
    }
}
