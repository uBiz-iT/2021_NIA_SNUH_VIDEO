//
//  AboutVC.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 15/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit
import WebKit

class AboutVC: UIViewController, WKUIDelegate {

    var webView: WKWebView!
    
    override func loadView() {
        let webConfiguration = WKWebViewConfiguration()
        webView = WKWebView(frame: .zero, configuration: webConfiguration)
        webView.uiDelegate = self
        view = webView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "About..."

        let myURL = URL(string: ServerWebView)?.appendingPathComponent("about")
        let myRequest = URLRequest(url: myURL!)
        webView.load(myRequest)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        SetOrientation()
    }
    
}
