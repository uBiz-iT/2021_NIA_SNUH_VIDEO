//
//  MainVC_URL.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 26/10/2018.
//  Copyright © 2018 uBiz Information Technology. All rights reserved.
//

import Foundation
import UIKit

extension LabelingVC {
    
    enum typeURLRequest:Int {
        case GetLabelList = 0, GetLabelListWithResult, GetPSGList, SaveLabelingResult, GetSubImageList, GetEventList, DeleteEvent, End
    }
    
    enum typeJsonParsing:Int {
        case GetLabelList = 0, GetLabelListWithResult, GetPSGList, SaveLabelingResult, GetSubImageList, GetEventList, DeleteEvent, Success, ErrorMessage, ErrorCode, End
    }
    
    // =======================================================================================================
    // 서버로부터 프로젝트에 해당하는 라벨 정보 가져오기
    // =======================================================================================================
    func selectLabelList() -> (Bool, Int?) {
        // ------------------------------------------------
        let requestURL = makeURLRequestForJsonFromServer(requestType: .GetLabelList)
        var result = false
        
        LastURLErrorMessage = ""
        
        let (success, error, err_code, err_msg, json ) = SendRequestForJSON(requestURL: requestURL)
        
        do {
            if (!success!) {
                if let e = error {
                    throw e
                }
                else {
                    throw ResponseDataError.RequestURLForJSON
                }
            }

            guard let getSuccess = self.parseJson(parsingType: .Success, jsonFormat: json) as? Bool
                else { throw ResponseDataError.JsonParsing }
            
            if (!getSuccess) {
                guard let msg:String =
                    self.parseJson(parsingType: .ErrorMessage, jsonFormat: json) as? String
                    else { throw ResponseDataError.JsonParsing }
                
                LastURLErrorMessage = msg
                
                throw ResponseDataError.ReturnValue
            }
            
            guard let lList:[LabelInfo] =
                self.parseJson(parsingType: .GetLabelList, jsonFormat: json) as? [LabelInfo]
                else { throw ResponseDataError.JsonParsing }
            
            LabelList.arrayLabelInfo = lList
            
            result = true

        }
        catch let error as RequestURLError {
            if (error == RequestURLError.URLSession) {
                LastURLErrorMessage = "[\(String(describing: err_code!))]" + err_msg!
            }
            else {
                LastURLErrorMessage = error.rawValue
            }
        }
        catch let error as ResponseDataError {
            if (LastURLErrorMessage == "") {
                LastURLErrorMessage = error.rawValue
            }
            p("[ResponseDataError] \(error.rawValue)")
        }
        catch let error as NSError {
            LastURLErrorMessage = error.debugDescription
            p("[NSError  ] \(error.debugDescription)")
        }
        catch let error {
            LastURLErrorMessage = error.localizedDescription
            p("[Error  ] \(error.localizedDescription)")
        }
        
        return (result, err_code)
        
    }
    
    // =======================================================================================================
    // 서버로부터 프로젝트에 해당하는 라벨 정보 가져오기
    // =======================================================================================================
    func deleteEvent() -> (Bool, Int?) {
        // ------------------------------------------------
        let requestURL = makeURLRequestForJsonFromServer(requestType: .DeleteEvent)
        var result = false
        
        LastURLErrorMessage = ""
        
        let (success, error, err_code, err_msg, json ) = SendRequestForJSON(requestURL: requestURL)
        
        do {
            if (!success!) {
                if let e = error {
                    throw e
                }
                else {
                    throw ResponseDataError.RequestURLForJSON
                }
            }

            guard let getSuccess = self.parseJson(parsingType: .Success, jsonFormat: json) as? Bool
                else { throw ResponseDataError.JsonParsing }
            
            if (!getSuccess) {
                guard let msg:String =
                    self.parseJson(parsingType: .ErrorMessage, jsonFormat: json) as? String
                    else { throw ResponseDataError.JsonParsing }
                
                LastURLErrorMessage = msg
                
                throw ResponseDataError.ReturnValue
            }
            
            result = true

        }
        catch let error as RequestURLError {
            if (error == RequestURLError.URLSession) {
                LastURLErrorMessage = "[\(String(describing: err_code!))]" + err_msg!
            }
            else {
                LastURLErrorMessage = error.rawValue
            }
        }
        catch let error as ResponseDataError {
            if (LastURLErrorMessage == "") {
                LastURLErrorMessage = error.rawValue
            }
            p("[ResponseDataError] \(error.rawValue)")
        }
        catch let error as NSError {
            LastURLErrorMessage = error.debugDescription
            p("[NSError  ] \(error.debugDescription)")
        }
        catch let error {
            LastURLErrorMessage = error.localizedDescription
            p("[Error  ] \(error.localizedDescription)")
        }
        
        return (result, err_code)
        
    }
    
    // =======================================================================================================
    // 서버로부터 프로젝트에 해당하는 라벨 정보(라벨링 결과 포함) 가져오기
    // =======================================================================================================
    func selectLabelListWithResult() -> (Bool, Int?) {
        // ------------------------------------------------
        let requestURL = makeURLRequestForJsonFromServer(requestType: .GetLabelListWithResult)
        var result = false
        
        LastURLErrorMessage = ""
        
        let (success, error, err_code, err_msg, json ) = SendRequestForJSON(requestURL: requestURL)
        
        do {
            if (!success!) {
                if let e = error {
                    throw e
                }
                else {
                    throw ResponseDataError.RequestURLForJSON
                }
            }

            guard let getSuccess = self.parseJson(parsingType: .Success, jsonFormat: json) as? Bool
                else { throw ResponseDataError.JsonParsing }
            
            if (!getSuccess) {
                guard let msg:String =
                    self.parseJson(parsingType: .ErrorMessage, jsonFormat: json) as? String
                    else { throw ResponseDataError.JsonParsing }
                
                LastURLErrorMessage = msg
                
                throw ResponseDataError.ReturnValue
            }
            
            guard let lList:[LabelInfo] =
                self.parseJson(parsingType: .GetLabelList, jsonFormat: json) as? [LabelInfo]
                else { throw ResponseDataError.JsonParsing }
            
            LabelList.arrayLabelInfo = lList
            
            result = true

        }
        catch let error as RequestURLError {
            if (error == RequestURLError.URLSession) {
                LastURLErrorMessage = "[\(String(describing: err_code!))]" + err_msg!
            }
            else {
                LastURLErrorMessage = error.rawValue
            }
        }
        catch let error as ResponseDataError {
            if (LastURLErrorMessage == "") {
                LastURLErrorMessage = error.rawValue
            }
            p("[ResponseDataError] \(error.rawValue)")
        }
        catch let error as NSError {
            LastURLErrorMessage = error.debugDescription
            p("[NSError  ] \(error.debugDescription)")
        }
        catch let error {
            LastURLErrorMessage = error.localizedDescription
            p("[Error  ] \(error.localizedDescription)")
        }
        
        return (result, err_code)
        
    }
    
    // =======================================================================================================
    // 서버에 라벨링 결과 보내기
    // =======================================================================================================
    func saveLabelingResult() -> (Bool, Int?) {
        // ------------------------------------------------
        let requestURL = makeURLRequestForJsonFromServer(requestType: .SaveLabelingResult)
        var result = false
        
        LastURLErrorMessage = ""
        
        let (success, error, err_code, err_msg, json ) = SendRequestForJSON(requestURL: requestURL)
        
        do {
            if (!success!) {
                if let e = error {
                    throw e
                }
                else {
                    throw ResponseDataError.RequestURLForJSON
                }
            }

            guard let getSuccess = self.parseJson(parsingType: .Success, jsonFormat: json) as? Bool
                else { throw ResponseDataError.JsonParsing }
            
            if (!getSuccess) {
                guard let msg:String =
                    self.parseJson(parsingType: .ErrorMessage, jsonFormat: json) as? String
                    else { throw ResponseDataError.JsonParsing }
                
                LastURLErrorMessage = msg
                
                throw ResponseDataError.ReturnValue
            }
            
            guard let psg_chk_res:Int =
                    self.parseJson(parsingType: .SaveLabelingResult, jsonFormat: json) as? Int
                else { throw ResponseDataError.JsonParsing }

            psgArray[currentImageIndex].psg_chk_res = psg_chk_res
            psgArray[currentImageIndex].isLabelingDone = (psg_chk_res >= 0) ? true : false
            psgArray[currentImageIndex].memo = psgMemo

            result = true

        }
        catch let error as RequestURLError {
            if (error == RequestURLError.URLSession) {
                LastURLErrorMessage = "[\(String(describing: err_code!))]" + err_msg!
            }
            else {
                LastURLErrorMessage = error.rawValue
            }
        }
        catch let error as ResponseDataError {
            if (LastURLErrorMessage == "") {
                LastURLErrorMessage = error.rawValue
            }
            p("[ResponseDataError] \(error.rawValue)")
        }
        catch let error as NSError {
            LastURLErrorMessage = error.debugDescription
            p("[NSError  ] \(error.debugDescription)")
        }
        catch let error {
            LastURLErrorMessage = error.localizedDescription
            p("[Error  ] \(error.localizedDescription)")
        }
        
        return (result, err_code)
        
    }
    
    // =======================================================================================================
    // 서버로부터 이미지 목록 가져오기
    // =======================================================================================================
    func selectImageList() -> (Bool, Int?) {
        // ------------------------------------------------
        let requestURL = makeURLRequestForJsonFromServer(requestType: .GetPSGList)
        var result = false
        
        LastURLErrorMessage = ""
        
        let (success, error, err_code, err_msg, json ) = SendRequestForJSON(requestURL: requestURL)
        
        do {
            if (!success!) {
                if let e = error {
                    throw e
                }
                else {
                    throw ResponseDataError.RequestURLForJSON
                }
            }

            guard let getSuccess = self.parseJson(parsingType: .Success, jsonFormat: json) as? Bool
                else { throw ResponseDataError.JsonParsing }
            
            if (!getSuccess) {
                guard let msg:String =
                    self.parseJson(parsingType: .ErrorMessage, jsonFormat: json) as? String
                    else { throw ResponseDataError.JsonParsing }
                
                LastURLErrorMessage = msg
                
                throw ResponseDataError.ReturnValue
            }
            
            guard let list:[PSGInfo] =
                self.parseJson(parsingType: .GetPSGList, jsonFormat: json) as? [PSGInfo]
                else { throw ResponseDataError.JsonParsing }
            
            psgList.append(psgList: list)

            result = true

        }
        catch let error as RequestURLError {
            if (error == RequestURLError.URLSession) {
                LastURLErrorMessage = "[\(String(describing: err_code!))]" + err_msg!
            }
            else {
                LastURLErrorMessage = error.rawValue
            }
        }
        catch let error as ResponseDataError {
            if (LastURLErrorMessage == "") {
                LastURLErrorMessage = error.rawValue
            }
            p("[ResponseDataError] \(error.rawValue)")
        }
        catch let error as NSError {
            LastURLErrorMessage = error.debugDescription
            p("[NSError  ] \(error.debugDescription)")
        }
        catch let error {
            LastURLErrorMessage = error.localizedDescription
            p("[Error  ] \(error.localizedDescription)")
        }
        
        return (result, err_code)
        
    }

    // =======================================================================================================
    // 하위 이미지 목록 가져오기
    // =======================================================================================================
    func getSubImageList() -> (Bool, Int?) {
        // ------------------------------------------------
        let requestURL = makeURLRequestForJsonFromServer(requestType: .GetSubImageList)
        var result = false
        
        LastURLErrorMessage = ""
        
        let (success, error, err_code, err_msg, json ) = SendRequestForJSON(requestURL: requestURL)
        
        do {
            if (!success!) {
                if let e = error {
                    throw e
                }
                else {
                    throw ResponseDataError.RequestURLForJSON
                }
            }

            guard let getSuccess = self.parseJson(parsingType: .Success, jsonFormat: json) as? Bool
            else { throw ResponseDataError.JsonParsing }

            if (!getSuccess) {
                guard let msg:String = self.parseJson(parsingType: .ErrorMessage, jsonFormat: json) as? String
                else { throw ResponseDataError.JsonParsing }
             
                LastURLErrorMessage = msg
             
                throw ResponseDataError.ReturnValue
            }

            guard let iList:[SubImageInfo] = self.parseJson(parsingType: .GetSubImageList, jsonFormat: json) as? [SubImageInfo]
            else { throw ResponseDataError.JsonParsing }

            subImageList.append(subImageList: iList)

            result = true
             
        }
        catch let error as RequestURLError {
            if (error == RequestURLError.URLSession) {
                LastURLErrorMessage = "[\(String(describing: err_code!))]" + err_msg!
            }
            else {
                LastURLErrorMessage = error.rawValue
            }
        }
        catch let error as ResponseDataError {
            if (LastURLErrorMessage == "") {
                LastURLErrorMessage = error.rawValue
            }
            p("[ResponseDataError] \(error.rawValue)")
        }
        catch let error as NSError {
            LastURLErrorMessage = error.debugDescription
            p("[NSError  ] \(error.debugDescription)")
        }
        catch let error {
            LastURLErrorMessage = error.localizedDescription
            p("[Error  ] \(error.localizedDescription)")
        }
        
        return (result, err_code)
        
    }

    // =======================================================================================================
    // 이벤트 목록 가져오기
    // =======================================================================================================
    func getEventList() -> (Bool, Int?) {
        // ------------------------------------------------
        let requestURL = makeURLRequestForJsonFromServer(requestType: .GetEventList)
        var result = false
        
        LastURLErrorMessage = ""
        
        let (success, error, err_code, err_msg, json ) = SendRequestForJSON(requestURL: requestURL)
        
        do {
            if (!success!) {
                if let e = error {
                    throw e
                }
                else {
                    throw ResponseDataError.RequestURLForJSON
                }
            }

            guard let getSuccess = self.parseJson(parsingType: .Success, jsonFormat: json) as? Bool
            else { throw ResponseDataError.JsonParsing }

            if (!getSuccess) {
                guard let msg:String = self.parseJson(parsingType: .ErrorMessage, jsonFormat: json) as? String
                else { throw ResponseDataError.JsonParsing }
             
                LastURLErrorMessage = msg
             
                throw ResponseDataError.ReturnValue
            }

            guard let iList:[EventInfo] = self.parseJson(parsingType: .GetEventList, jsonFormat: json) as? [EventInfo]
            else { throw ResponseDataError.JsonParsing }

            // 추가하고 정렬
            eventList.append(eventList: iList)
            eventList.sortWithBegTime()
            eventList.copyAll()

            result = true
             
        }
        catch let error as RequestURLError {
            if (error == RequestURLError.URLSession) {
                LastURLErrorMessage = "[\(String(describing: err_code!))]" + err_msg!
            }
            else {
                LastURLErrorMessage = error.rawValue
            }
        }
        catch let error as ResponseDataError {
            if (LastURLErrorMessage == "") {
                LastURLErrorMessage = error.rawValue
            }
            p("[ResponseDataError] \(error.rawValue)")
        }
        catch let error as NSError {
            LastURLErrorMessage = error.debugDescription
            p("[NSError  ] \(error.debugDescription)")
        }
        catch let error {
            LastURLErrorMessage = error.localizedDescription
            p("[Error  ] \(error.localizedDescription)")
        }
        
        return (result, err_code)
        
    }


    
}

