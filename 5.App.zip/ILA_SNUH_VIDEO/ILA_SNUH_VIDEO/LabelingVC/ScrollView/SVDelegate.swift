//
//  SVDelegate.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/28.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC: UIScrollViewDelegate {

    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        if (scrollView.tag == 100) {
            return EditingImage
        }
        else if (scrollView.tag == 101) {
            return playerView
        }
        return EditingImage
    }
    
    func scrollViewDidZoom(_ scrollView: UIScrollView) {
        if (scrollView.tag == 100) {
            graphLabel.setGraphUILabelLocationByKindIndex(0, scrollView.contentOffset.x, scrollView.zoomScale)
            graphLabel.setGraphUILabelLocationByKindIndex(1, scrollView.contentOffset.x, scrollView.zoomScale)
        }
        else if (scrollView.tag == 101) {                   // 20200925 상대측도 동일하게 zooming
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if (scrollView.tag == 100) {
            graphLabel.setGraphUILabelLocationByKindIndex(0, scrollView.contentOffset.x, scrollView.zoomScale)
            graphLabel.setGraphUILabelLocationByKindIndex(1, scrollView.contentOffset.x, scrollView.zoomScale)
        }
        else if (scrollView.tag == 101) {
        }
    }
    
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        if (scrollView.tag == 3) {
            scrollViewDidEndScrollingAnimation_Thumbnail(scrollView)
        }
    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        if (scrollView.tag == 3) {
            scrollViewDidEndDragging_Thumbnail(scrollView, willDecelerate: decelerate)
        }
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        if (scrollView.tag == 3) {
            scrollViewDidEndDecelerating_Thumbnail(scrollView)
        }
    }
    
}
