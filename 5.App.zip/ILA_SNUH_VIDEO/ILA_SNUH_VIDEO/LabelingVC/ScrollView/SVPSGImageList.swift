//
//  SVPSGImageList.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/28.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {

    func scrollViewDidEndScrollingAnimation_Thumbnail(_ scrollView: UIScrollView) {
        p("--------------------------- scrollViewDidEndScrollingAnimation")
    }
    
    func scrollViewDidEndDragging_Thumbnail(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        p("--------------------------- scrollViewDidEndDragging")
        collectionViewThumbnail.reloadData()
    }
    
    func scrollViewDidEndDecelerating_Thumbnail(_ scrollView: UIScrollView) {
        p("--------------------------- scrollViewDidEndDecelerating")
        collectionViewThumbnail.reloadData()
    }
    

}
