//
//  LibCommon.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    @objc func keyboardWillShow(sender: NSNotification) {
        
        if let keyboardRectValue = (sender.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            let keyboardHeight = keyboardRectValue.height

            if memoView.isFirstResponder {
                self.view.frame.origin.y = keyboardHeight * -1
            }
            else if abnormalMemoText.isFirstResponder {
                // 이상행동 조정 뷰의 bottom 위치
                let a_y2 = self.abnormalView.frame.origin.y + self.abnormalView.frame.size.height
                // 키보드 시작 위치
                let k_y1 = self.view.frame.size.height - keyboardHeight
                if a_y2 > k_y1 {
                    self.abnormalView.frame.origin.y = k_y1 - self.abnormalView.frame.size.height
                }
            }
            else {
                if shouldKeyboardShown {
                    p("-------------------------- 3 \(shouldKeyboardShown)")
                    UIView.performWithoutAnimation {
                        self.view.frame.origin.y = keyboardHeight * -1 + 115
                    }
                }
                else {
                    self.view.frame.origin.y = keyboardHeight * -1 + 115
                }
            }
        }
        isKeyboardShown = true
    }

    @objc func keyboardWillHide(sender: NSNotification) {
        
        if memoView.isFirstResponder ||
            abnormalMemoText.isFirstResponder {
            self.view.frame.origin.y = 0
        }
        else {
            if shouldKeyboardShown {
                p("-------------------------- 2 \(shouldKeyboardShown)")
                UIView.performWithoutAnimation {
                    self.view.frame.origin.y = 0
                }
            }
            else {
                p("-------------------------- 4 \(shouldKeyboardShown)")
                self.view.frame.origin.y = 0
            }
        }
        isKeyboardShown = false
    }
    
    // -----------------------------------------------------------------------------------------------
    // 시간을 문자열로 변경
    // -----------------------------------------------------------------------------------------------
    func getTimeString(_ time:CMTime) -> String {
        
        let totalSeconds = CMTimeGetSeconds(time)
        let hours = Int(totalSeconds/3600)
        let minutes = Int(totalSeconds/60) % 60
        let seconds = Int(totalSeconds.truncatingRemainder(dividingBy: 60))
        
        return String(format: "%i:%02i:%02i", hours, minutes, seconds)
    }

    func getTimeString(_ seconds:Int) -> String {

        let totalSeconds = Float64(seconds)
        let hours = Int(totalSeconds/3600)
        let minutes = Int(totalSeconds/60) % 60
        let seconds = Int(totalSeconds.truncatingRemainder(dividingBy: 60))
        
        return String(format: "%i:%02i:%02i", hours, minutes, seconds)
    }
    
    func getTimeString(_ yyyymmddhhmiss:String) -> String! {
        if yyyymmddhhmiss.length == 14 {
            return yyyymmddhhmiss.substring(8..<10) + ":" + yyyymmddhhmiss.substring(10..<12) + ":" + yyyymmddhhmiss.substring(12..<14)
        }
        return "00:00:00";
    }

    func getTimeStringWithMSEC(_ time:CMTime) -> String {
        
        let totalSeconds = CMTimeGetSeconds(time)
        let hours = Int(totalSeconds/3600)
        let minutes = Int(totalSeconds/60) % 60
        let seconds = Int(totalSeconds.truncatingRemainder(dividingBy: 60))
        let milliseconds = Int(Float(Int(totalSeconds * 100)).truncatingRemainder(dividingBy: 100))
        
        if hours > 0 {
            return String(format: "%i:%02i:%02i.%01i", hours, minutes, seconds, milliseconds)
        }
        else {
            return String(format: "%02i:%02i.%01i", minutes, seconds, milliseconds)
        }
    }
    
    func getTimeString(_ date:Date) -> String! {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "HH:mm:ss"

        let dateString = dateFormatter.string(from: date)
        return dateString
    }

    // -----------------------------------------------------------------------------------------------
    // 두 날짜 사이의 차이를 초로 반환
    // -----------------------------------------------------------------------------------------------
    func getSecondsBetweenDate(start:Date, end:Date) -> Int {
        let calendar = Calendar.current
        let unitFlags = Set<Calendar.Component>([ .second])
        let datecomponents = calendar.dateComponents(unitFlags, from: start, to: end)
        return datecomponents.second!
    }
    

}
