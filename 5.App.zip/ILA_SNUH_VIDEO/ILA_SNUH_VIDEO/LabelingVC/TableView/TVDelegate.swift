//
//  LabelingVC_TV.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 24/10/2018.
//  Copyright © 2018 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC: UITableViewDelegate, UITableViewDataSource  {

    func numberOfSections(in tableView: UITableView) -> Int {
        if tableView.tag == 301 {
            return numberOfSections_eventGroup(in: tableView)
        }
        else if tableView.tag == 302 {
            return numberOfSections_eventKind(in: tableView)
        }
        else {
            return numberOfSections_event(in: tableView)
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView.tag == 301 {
            return tableView_eventGroup(tableView, numberOfRowsInSection: section)
        }
        else if tableView.tag == 302 {
            return tableView_eventKind(tableView, numberOfRowsInSection: section)
        }
        else {
            return tableView_event(tableView, numberOfRowsInSection: section)
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView.tag == 301 {
            return tableView_eventGroup(tableView, cellForRowAt: indexPath)
        }
        else if tableView.tag == 302 {
            return tableView_eventKind(tableView, cellForRowAt: indexPath)
        }
        else {
            return tableView_event(tableView, cellForRowAt: indexPath)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView.tag == 301 {
            return tableView_eventGroup(tableView, heightForRowAt: indexPath)
        }
        else if tableView.tag == 302 {
            return tableView_eventKind(tableView, heightForRowAt: indexPath)
        }
        else {
            return tableView_event(tableView, heightForRowAt: indexPath)
        }
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        if tableView.tag == 301 {
            return tableView_eventGroup(tableView, canEditRowAt: indexPath)
        }
        else if tableView.tag == 302 {
            return tableView_eventKind(tableView, canEditRowAt: indexPath)
        }
        else {
            return tableView_event(tableView, canEditRowAt: indexPath)
        }
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if tableView.tag == 301 {
            return
        }
        else if tableView.tag == 302 {
            return
        }
        else {
            tableView_event(tableView, commit: editingStyle, forRowAt: indexPath)
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView.tag == 301 {
            return tableView_eventGroup(tableView, didSelectRowAt: indexPath)
        }
        else if tableView.tag == 302 {
            return tableView_eventKind(tableView, didSelectRowAt: indexPath)
        }
        else {
            return tableView_event(tableView, didSelectRowAt: indexPath)
        }
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        if tableView.tag == 301 {
            return tableView_eventGroup(tableView, didDeselectRowAt: indexPath)
        }
        else if tableView.tag == 302 {
            return tableView_eventKind(tableView, didDeselectRowAt: indexPath)
        }
        else {
            return tableView_event(tableView, didDeselectRowAt: indexPath)
        }
    }
    
    //    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
    //        return tableView_event(tableView, trailingSwipeActionsConfigurationForRowAt: indexPath)
    //    }
        
}
