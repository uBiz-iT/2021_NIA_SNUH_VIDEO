//
//  TVEventKind.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/07/17.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {

    func numberOfSections_eventKind(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView_eventKind(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return eventKindArray.count
    }
    
    func tableView_eventKind(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "EventKindCell", for: indexPath)

        cell.textLabel?.lineBreakMode = .byWordWrapping
        cell.textLabel?.numberOfLines = 2
        cell.textLabel!.text = eventKindArray[indexPath.row]
        cell.textLabel?.textColor = (indexPath.row == selectedEventKindIndex) ? .white : .black
        cell.backgroundColor = (indexPath.row == selectedEventKindIndex) ? GetTintColor() : .ubizLightBackground
        
        return cell
    }
    
    func tableView_eventKind(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }    

    func tableView_eventKind(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return false
    }

    func tableView_eventKind(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        if (selectedEventKindIndex == indexPath.row) {
            tableView.reloadData()
            return
        }
        
        selectedEventKindIndex = indexPath.row
        tableView.reloadData()

        // 이벤트 목록에 해당하는 놈만 보여주기
        // 전체 선택이면 type 목록에서 선택한 것 보여주기
        if (selectedEventKindIndex == 0) {
            // 0이면 전체 선택임
            if (selectedEventGroupIndex == 0) {
                eventArray = eventList.eventsByType()
            }
            else {
                eventArray = eventList.eventsByType(type: eventGroupArray[selectedEventGroupIndex])
            }
        }
        else {
            eventArray = eventList.eventsByName(name: eventKindArray[selectedEventKindIndex])
        }
        selectedEventIndex = -1
        eventTV.reloadData()

    }
    
    func tableView_eventKind(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
    }

}
