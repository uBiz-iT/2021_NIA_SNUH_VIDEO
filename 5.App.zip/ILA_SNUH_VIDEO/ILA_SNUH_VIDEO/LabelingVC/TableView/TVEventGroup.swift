//
//  TVEventGroup.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/07/17.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {

    func numberOfSections_eventGroup(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView_eventGroup(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return eventGroupArray.count
    }
    
    func tableView_eventGroup(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "EventGroupCell", for: indexPath)
            
        cell.textLabel?.lineBreakMode = .byWordWrapping
        cell.textLabel?.numberOfLines = 2
        cell.textLabel!.text = eventGroupArray[indexPath.row]
        cell.textLabel?.textColor = (indexPath.row == selectedEventGroupIndex) ? .white : .black
        cell.backgroundColor = (indexPath.row == selectedEventGroupIndex) ? GetTintColor() : .ubizLightBackground
        
        return cell
    }
    
    func tableView_eventGroup(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }

    func tableView_eventGroup(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return false
    }
    
    func tableView_eventGroup(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if (selectedEventGroupIndex == indexPath.row) {
            tableView.reloadData()
            return
        }
        
        selectedEventGroupIndex = indexPath.row

        // 이벤트 이름 목록 초기화 및 선택
        if (indexPath.row == 0) {
            eventKindArray = eventList.nameList()
        }
        else {
            eventKindArray = eventList.nameList(typeName: eventGroupArray[selectedEventGroupIndex])
        }
        selectedEventKindIndex = 0

        tableView.reloadData()
        eventKindTV.reloadData()
        
        // 이벤트 목록에 해당하는 놈만 보여주기
        // 0이면 전체 선택임
        if (selectedEventGroupIndex == 0) {
            eventArray = eventList.eventsByType()
        }
        else {
            eventArray = eventList.eventsByType(type: eventGroupArray[selectedEventGroupIndex])
        }
        
        selectedEventIndex = -1
        eventTV.reloadData()
    }
    
    func tableView_eventGroup(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
    }
    
    
}
