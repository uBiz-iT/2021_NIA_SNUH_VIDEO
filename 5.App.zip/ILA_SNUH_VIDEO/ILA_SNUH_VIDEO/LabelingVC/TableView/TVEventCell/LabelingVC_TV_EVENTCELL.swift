//
//  LabelingVC_TV_EVENTCELL.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/03/25.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit


class LabelingVC_TV_EVENTCELL: UITableViewCell {

    @IBOutlet weak var eventSeq: UILabel!
    @IBOutlet weak var eventName: UILabel!
    @IBOutlet weak var startTime: UILabel!
    @IBOutlet weak var endTime: UILabel!
    @IBOutlet weak var duration: UILabel!
    @IBOutlet weak var OKButton: UIButton!
    @IBOutlet weak var NGButton: UIButton!
    @IBOutlet weak var OKTitle: UIButton!
    @IBOutlet weak var NGTitle: UIButton!
    @IBOutlet weak var begSec: UILabel!
    @IBOutlet weak var endSec: UILabel!
    @IBOutlet weak var begEpoNo: UILabel!
    @IBOutlet weak var endEpoNo: UILabel!
    
    @IBOutlet weak var moveFirstButton: UIButton!
    @IBOutlet weak var moveLastButton: UIButton!
    @IBOutlet weak var changeBegSecondButton: UIButton!
    @IBOutlet weak var changeEndSecondButton: UIButton!
    @IBOutlet weak var confirmButton: UIButton!
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var memoText: UITextField!
    @IBOutlet weak var memoExistImage: UIImageView!
    
    internal var befTextColor:UIColor? = UIColor.white
    internal var befBackColor:UIColor? = UIColor.red
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setdefaultColor()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    internal func setdefaultColor() {
        eventSeq.textColor = UIColor.black
        eventName.textColor = eventSeq.textColor
        begEpoNo.textColor = eventSeq.textColor
        endEpoNo.textColor = eventSeq.textColor
        begSec.textColor = eventSeq.textColor
        endSec.textColor = eventSeq.textColor
        duration.textColor = eventSeq.textColor
        startTime.textColor = eventSeq.textColor
        endTime.textColor = eventSeq.textColor
        contentView.backgroundColor = UIColor.white
    }
    
    enum ColorType {
        case basic
        case epoch
        case selected
        case new
        case update
    }
    
    func colorType(_ colorType:ColorType) {
        if (colorType == .basic) {
            setdefaultColor()
        }
        else if (colorType == .selected) {
            befTextColor = eventName.textColor
            befBackColor = contentView.backgroundColor
            eventSeq.textColor = UIColor.black
            eventName.textColor = eventSeq.textColor
            begEpoNo.textColor = eventSeq.textColor
            endEpoNo.textColor = eventSeq.textColor
            begSec.textColor = eventSeq.textColor
            endSec.textColor = eventSeq.textColor
            duration.textColor = eventSeq.textColor
            startTime.textColor = eventSeq.textColor
            endTime.textColor = eventSeq.textColor

            //contentView.backgroundColor = ColorWithHexString(hexString: "#DCDCDC")
            contentView.backgroundColor = .ubizLightBackground
        }
        else if (colorType == .epoch) {
            eventSeq.textColor = UIColor.systemBlue
            eventName.textColor = eventSeq.textColor
            begEpoNo.textColor = eventSeq.textColor
            endEpoNo.textColor = eventSeq.textColor
            begSec.textColor = eventSeq.textColor
            endSec.textColor = eventSeq.textColor
            duration.textColor = eventSeq.textColor
            startTime.textColor = eventSeq.textColor
            endTime.textColor = eventSeq.textColor
        }
        else if (colorType == .new) {
            eventSeq.textColor = UIColor.systemRed
            eventName.textColor = eventSeq.textColor
        }
        else if (colorType == .update) {
            eventSeq.textColor = UIColor.systemGreen
            eventName.textColor = eventSeq.textColor
        }
        else {
            setdefaultColor()
        }
    }
    
}
