//
//  LabelingVC_TV_EVENT.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/03/25.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit


extension LabelingVC: UITextFieldDelegate  {

    func numberOfSections_event(in tableView: UITableView) -> Int {
        //p("tableView.frame.height :", tableView.frame.height)
        return 1
    }
    
    func tableView_event(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return eventArray.count
    }
    
    func tableView_event(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        //p("cellForRowAt : \(indexPath.row)")
        
        let eventInfo = eventArray[indexPath.row]

        let isScrolling: Bool = tableView.isDragging || tableView.isDecelerating
        if isScrolling {
            autoEventScrollTimeCount = 0
        }

        if OrientationValue == .portrait {
            let cell = tableView.dequeueReusableCell(withIdentifier: "EventCellId_P", for: indexPath) as! LabelingVC_TV_EVENTCELL_P
            
            if (indexPath.row == selectedEventIndex) {
                cell.colorType(.selected)
                if shouldKeyboardShown {
                    cell.memoText.becomeFirstResponder()
                }
            }
            else {
                cell.colorType(.basic)
            }

            // 현재 시간에 해당되는지
            if isInEventRange(withSecond: Int(currentTime.seconds), event: eventInfo) {
                cell.colorType(.epoch)
            }
            if eventInfo.isCreated || eventInfo.eventSeq! > 1000 {
                cell.colorType(.new)
            }
            else if eventInfo.isUpdated || eventInfo.isMemoUpdated || eventInfo.isDataUpdated {
                cell.colorType(.update)
            }

            cell.eventSeq.text = "\(eventInfo.eventSeq!)"
            cell.eventName.lineBreakMode = .byWordWrapping
            cell.eventName.numberOfLines = 0
            cell.eventName.text = eventInfo.eventName
            cell.startTime.text = getTimeString(eventInfo.begDT!)
            cell.endTime.text = getTimeString(eventInfo.endDT!)
            cell.begSec.text = getTimeString(eventInfo.begSecond!)
            cell.endSec.text = getTimeString(eventInfo.endSecond!)
            cell.duration.text = String(format: "%4d", eventInfo.elapsedSeconds!)
            cell.begEpoNo.text = "\(eventInfo.begEpoNo!)"
            cell.endEpoNo.text = "\(eventInfo.endEpoNo!)"

            if #available(iOS 13.0, *) {
                cell.startTime.font = .monospacedSystemFont(ofSize: 14, weight: .regular)
                cell.endTime.font = .monospacedSystemFont(ofSize: 14, weight: .regular)
                cell.begSec.font = .monospacedSystemFont(ofSize: 14, weight: .regular)
                cell.endSec.font = .monospacedSystemFont(ofSize: 14, weight: .regular)
                cell.duration.font = .monospacedSystemFont(ofSize: 14, weight: .regular)
                cell.begEpoNo.font = .monospacedSystemFont(ofSize: 14, weight: .regular)
                cell.endEpoNo.font = .monospacedSystemFont(ofSize: 14, weight: .regular)
            } else {
                cell.startTime.font = .monospacedDigitSystemFont(ofSize: 14, weight: .regular)
                cell.endTime.font = .monospacedDigitSystemFont(ofSize: 14, weight: .regular)
                cell.begSec.font = .monospacedDigitSystemFont(ofSize: 14, weight: .regular)
                cell.endSec.font = .monospacedDigitSystemFont(ofSize: 14, weight: .regular)
                cell.duration.font = .monospacedDigitSystemFont(ofSize: 14, weight: .regular)
                cell.begEpoNo.font = .monospacedDigitSystemFont(ofSize: 14, weight: .regular)
                cell.endEpoNo.font = .monospacedDigitSystemFont(ofSize: 14, weight: .regular)
            }
            
            if eventInfo.isChecked {
                cell.OKButton.setImage(eventInfo.checkResult == 0 ? radioOnImage : radioOffImage, for: .normal)
                cell.NGButton.setImage(eventInfo.checkResult == 0 ? radioOffImage : radioOnImage, for: .normal)
            }
            else
            {
                cell.OKButton.setImage(radioOffImage, for: .normal)
                cell.NGButton.setImage(radioOffImage, for: .normal)
            }
            // 버튼 눌렀을 때 처리하기 위한 함수 설정. tag에 indexPath.row를 넘김
            cell.OKButton.tag = indexPath.row
            cell.NGButton.tag = indexPath.row
            cell.OKButton.addTarget(self, action: #selector(OKButtonPressed(_:)), for: .touchUpInside)
            cell.NGButton.addTarget(self, action: #selector(NGButtonPressed(_:)), for: .touchUpInside)
            cell.OKTitle.tag = indexPath.row
            cell.NGTitle.tag = indexPath.row
            cell.OKTitle.addTarget(self, action: #selector(OKButtonPressed(_:)), for: .touchUpInside)
            cell.NGTitle.addTarget(self, action: #selector(NGButtonPressed(_:)), for: .touchUpInside)

            cell.memoText.text = "\(eventInfo.memo)"
            cell.memoExistImage.isHidden = !(eventInfo.memo > "")
                
            // 버튼들
            setEventViewButtonShape(button: cell.changeBegSecondButton)
            setEventViewButtonShape(button: cell.changeEndSecondButton)
            setEventViewButtonShape(button: cell.confirmButton)
            setEventViewButtonShape(button: cell.cancelButton)

            cell.memoText.layer.cornerRadius = 3.0
            cell.memoText.layer.masksToBounds = true
            cell.memoText.layer.backgroundColor = UIColor.white.cgColor
            cell.memoText.layer.borderColor = UIColor.systemGray.cgColor
            cell.memoText.layer.borderWidth = 1.0

            cell.moveFirstButton.tag = indexPath.row
            cell.moveLastButton.tag = indexPath.row
            cell.changeBegSecondButton.tag = indexPath.row
            cell.changeEndSecondButton.tag = indexPath.row
            cell.confirmButton.tag = indexPath.row
            cell.cancelButton.tag = indexPath.row
            cell.memoText.tag = indexPath.row
            cell.memoText.delegate = self

            cell.moveFirstButton.addTarget(self, action: #selector(moveFirstButtonPressed(_:)), for: .touchUpInside)
            cell.moveLastButton.addTarget(self, action: #selector(moveLastButtonPressed(_:)), for: .touchUpInside)
            cell.changeBegSecondButton.addTarget(self, action: #selector(changeBegSecondButtonPressed(_:)), for: .touchUpInside)
            cell.changeEndSecondButton.addTarget(self, action: #selector(changeEndSecondButtonPressed(_:)), for: .touchUpInside)
            cell.confirmButton.addTarget(self, action: #selector(confirmButtonPressed(_:)), for: .touchUpInside)
            cell.cancelButton.addTarget(self, action: #selector(cancelButtonPressed(_:)), for: .touchUpInside)
            
            

            return cell

        }
        else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "EventCellId", for: indexPath) as! LabelingVC_TV_EVENTCELL
            
//            p("\(indexPath.row ), \(selectedEventIndex)")
            if (indexPath.row == selectedEventIndex) {
                cell.colorType(.selected)
                if shouldKeyboardShown {
                    cell.memoText.becomeFirstResponder()
                }
            }
            else {
                cell.colorType(.basic)
            }
            
            // 현재 시간에 해당되는지
            if isInEventRange(withDate: currentRealDate, event: eventInfo) {
                cell.colorType(.epoch)
            }
//            if isInEventRange(withSecond: Int(currentTime.seconds), event: eventInfo) {
//                cell.colorType(.epoch)
//            }

            if eventInfo.isCreated || eventInfo.eventSeq! > 1000 {
                cell.colorType(.new)
            }
            else if eventInfo.isUpdated || eventInfo.isMemoUpdated || eventInfo.isDataUpdated {
                cell.colorType(.update)
            }

            cell.eventSeq.text = "\(eventInfo.eventSeq!)"
            cell.eventName.lineBreakMode = .byWordWrapping
            cell.eventName.numberOfLines = 2
            cell.eventName.text = eventInfo.eventName
            cell.startTime.text = getTimeString(eventInfo.begDT!)
            cell.endTime.text = getTimeString(eventInfo.endDT!)
            cell.begSec.text = getTimeString(eventInfo.begSecond!)
            cell.endSec.text = getTimeString(eventInfo.endSecond!)
            cell.duration.text = String(format: "%4d", eventInfo.elapsedSeconds!)
            cell.begEpoNo.text = "\(eventInfo.begEpoNo!)"
            cell.endEpoNo.text = "\(eventInfo.endEpoNo!)"

            if #available(iOS 13.0, *) {
                cell.startTime.font = .monospacedSystemFont(ofSize: 14, weight: .regular)
                cell.endTime.font = .monospacedSystemFont(ofSize: 14, weight: .regular)
                cell.begSec.font = .monospacedSystemFont(ofSize: 14, weight: .regular)
                cell.endSec.font = .monospacedSystemFont(ofSize: 14, weight: .regular)
                cell.duration.font = .monospacedSystemFont(ofSize: 14, weight: .regular)
                cell.begEpoNo.font = .monospacedSystemFont(ofSize: 14, weight: .regular)
                cell.endEpoNo.font = .monospacedSystemFont(ofSize: 14, weight: .regular)
            } else {
                cell.startTime.font = .monospacedDigitSystemFont(ofSize: 14, weight: .regular)
                cell.endTime.font = .monospacedDigitSystemFont(ofSize: 14, weight: .regular)
                cell.begSec.font = .monospacedDigitSystemFont(ofSize: 14, weight: .regular)
                cell.endSec.font = .monospacedDigitSystemFont(ofSize: 14, weight: .regular)
                cell.duration.font = .monospacedDigitSystemFont(ofSize: 14, weight: .regular)
                cell.begEpoNo.font = .monospacedDigitSystemFont(ofSize: 14, weight: .regular)
                cell.endEpoNo.font = .monospacedDigitSystemFont(ofSize: 14, weight: .regular)
            }
            
            if eventInfo.isChecked {
                cell.OKButton.setImage(eventInfo.checkResult == 0 ? radioOnImage : radioOffImage, for: .normal)
                cell.NGButton.setImage(eventInfo.checkResult == 1 ? radioOnImage : radioOffImage, for: .normal)
            }
            else
            {
                cell.OKButton.setImage(radioOffImage, for: .normal)
                cell.NGButton.setImage(radioOffImage, for: .normal)
            }
            
            cell.memoText.text = "\(eventInfo.memo)"
            cell.memoExistImage.isHidden = !(eventInfo.memo > "")

            // 버튼 눌렀을 때 처리하기 위한 함수 설정. tag에 indexPath.row를 넘김
            cell.OKButton.tag = indexPath.row
            cell.NGButton.tag = indexPath.row
            cell.OKButton.addTarget(self, action: #selector(OKButtonPressed(_:)), for: .touchUpInside)
            cell.NGButton.addTarget(self, action: #selector(NGButtonPressed(_:)), for: .touchUpInside)
            
            cell.OKTitle.tag = indexPath.row
            cell.NGTitle.tag = indexPath.row
            cell.OKTitle.addTarget(self, action: #selector(OKButtonPressed(_:)), for: .touchUpInside)
            cell.NGTitle.addTarget(self, action: #selector(NGButtonPressed(_:)), for: .touchUpInside)
            
            // 버튼들
            setEventViewButtonShape(button: cell.changeBegSecondButton)
            setEventViewButtonShape(button: cell.changeEndSecondButton)
            setEventViewButtonShape(button: cell.confirmButton)
            setEventViewButtonShape(button: cell.cancelButton)

            cell.memoText.layer.cornerRadius = 3.0
            cell.memoText.layer.masksToBounds = true
            cell.memoText.layer.backgroundColor = UIColor.white.cgColor
            cell.memoText.layer.borderColor = UIColor.systemGray.cgColor
            cell.memoText.layer.borderWidth = 1.0

            cell.moveFirstButton.tag = indexPath.row
            cell.moveLastButton.tag = indexPath.row
            cell.changeBegSecondButton.tag = indexPath.row
            cell.changeEndSecondButton.tag = indexPath.row
            cell.confirmButton.tag = indexPath.row
            cell.cancelButton.tag = indexPath.row
            cell.memoText.tag = indexPath.row
            cell.memoText.delegate = self
            
            cell.moveFirstButton.addTarget(self, action: #selector(moveFirstButtonPressed(_:)), for: .touchUpInside)
            cell.moveLastButton.addTarget(self, action: #selector(moveLastButtonPressed(_:)), for: .touchUpInside)
            cell.changeBegSecondButton.addTarget(self, action: #selector(changeBegSecondButtonPressed(_:)), for: .touchUpInside)
            cell.changeEndSecondButton.addTarget(self, action: #selector(changeEndSecondButtonPressed(_:)), for: .touchUpInside)
            cell.confirmButton.addTarget(self, action: #selector(confirmButtonPressed(_:)), for: .touchUpInside)
            cell.cancelButton.addTarget(self, action: #selector(cancelButtonPressed(_:)), for: .touchUpInside)

            return cell
        }
    }
    
    func setEventViewButtonShape(button:UIButton) {
        button.layer.cornerRadius = 5
        button.layer.backgroundColor = UIColor.white.cgColor
    }
    
    func tableView_event(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if OrientationValue == .portrait {
            if indexPath.row == selectedEventIndex {
                return 125
            }
            else {
                return 60
            }
        }
        else {
            if indexPath.row == selectedEventIndex {
                return 120
            }
            else {
                return 50
            }
        }
    }
        
    func tableView_event(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        let index = indexPath.row
        if eventArray[index].eventSeq! > 1000 {
            return true
        }
        else {
            return false
        }
    }
    
    func tableView_event(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {

            // 선택된 놈이 삭제이면 선택해제먼저...
            if selectedEventIndex == indexPath.row {
                selectedEventIndex = -1
            }

            if !eventArray[indexPath.row].isCreated {
                let dialogMessage = UIAlertController(title: "확인", message: "서버에 이미 저장된 데이터입니다.\n삭제 하시겠습니까?", preferredStyle: .alert)
                let ok = UIAlertAction(title: "예", style: .destructive, handler: { [self] (action) -> Void in
                    actionDeleteEvent(index: indexPath.row)
                    tableView.deleteRows(at: [indexPath], with: .automatic)
                })

                let cancel = UIAlertAction(title: "아니오", style: .cancel) { (action) -> Void in
                }
                dialogMessage.addAction(ok)
                dialogMessage.addAction(cancel)
                self.present(dialogMessage, animated: true, completion: nil)
            }
            else {
                deleteEventFromArray(index: indexPath.row)
                tableView.deleteRows(at: [indexPath], with: .automatic)
            }
            
        }
    }
    
    func actionDeleteEvent(index:Int) {
        var success:Bool = true
        var code:Int? = 0

        eventSeqToDelete = eventArray[index].eventSeq!
        (success, code) = deleteEvent()
        
        if success {
            deleteEventFromArray(index: index)
        }
        else {
            handlingDbError(code: code!, self)
        }
    }
    
    func deleteEventFromArray(index:Int) {
        eventList.remove(eventSeq: eventArray[index].eventSeq!)
        eventArray.remove(at: index)
        saveButton.isEnabled = eventList.isChanged && !isManager
        setEventResultText()
    }

    func tableView_event(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        if (eventKindView.isHidden == false) {
            eventKindView.isHidden = true
        }
        
        if isShowAbnormalView {
            eventTV.deselectRow(at: indexPath, animated: false)
            return
        }

        // memo가 편집중이었는데 다른 row를 선택하면 그 row의 메모를 편집중으로 설정하기 위함
        shouldKeyboardShown = (keyboardBeginType == .event)
        //p("isKeyboardShown : \(isKeyboardShown), \(keyboardBeginType), \(shouldKeyboardShown)")

        // 한번 더 선택하면 선택 해제
        if (selectedEventIndex == indexPath.row) {
            if shouldKeyboardShown {
                shouldKeyboardShown = false
                view.endEditing(true)
            }
            eventArray[selectedEventIndex].set(event: backupSelectedEvent)
            selectedEventIndex = -1
            initSnapshot(time: currentTime)
        }
        else {
            // 플레이중이면 일단 정지
            if (isVideoPlaying) {
                stopPlay()
            }
            selectedEventIndex = indexPath.row

            UserDefaults.standard.set(selectedEventIndex, forKey: DefaultKey_EventIndex)
            WorkingEventIndex = selectedEventIndex
            eventSelected(event: eventArray[indexPath.row])

            moveEventBeginEndLine()

        }

        // reloadData extension 처리... reload가 완료되면 false로 set
        eventTV.reloadData() { [self] in
            shouldKeyboardShown = false
        }
    }
    
    func tableView_event(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        //eventTV.reloadRows(at: [indexPath], with: .automatic)
    }
    
    // -------------------------------------------------------------------------------
    // 이벤트 목록에서 버튼 프레스 이벤트 처리
    // -------------------------------------------------------------------------------
    @objc func OKButtonPressed(_ sender: UIButton) {

        let row = sender.tag
        let eventInfo = eventArray[row]

        // 기존에 ng이거나 nil이였는데 ok로 변경했으면
        if eventInfo.checkResult != 0 {
            eventCheckType = 9
            eventInfo.isChecked = true
            eventInfo.checkResult = 0

            eventInfo.isUpdated = !eventList.isSameWithBackup(eventSeq: eventInfo.eventSeq!)
            eventInfo.isMemoUpdated = !eventList.isSameMemoWithBackup(eventSeq: eventInfo.eventSeq!)
            eventInfo.isDataUpdated = !eventList.isSameDataWithBackup(eventSeq: eventInfo.eventSeq!)

            if let updatedEvent = eventList.updatedEventInfoByEventSeq(eventSeq: eventInfo.eventSeq!) {
                updatedEvent.set(event: eventInfo)
            }

            reloadRow(row: row)
        }
    }
    
    func reloadRow(row:Int) {
        
        let indexPath = IndexPath(row: row, section: 0)
        eventTV.reloadRows(at: [indexPath], with: .automatic)
        saveButton.isEnabled = isDataChanged && (!isManager)
        setEventResultText()
    }
    
    @objc func NGButtonPressed(_ sender: UIButton) {
        let row = sender.tag
        let eventInfo = eventArray[row]
        
        // 기존에 ok이거나 nil이였는데 ng로 변경했으면
        if eventInfo.checkResult != 1 {
            eventCheckType = 9
            eventInfo.isChecked = true
            eventInfo.checkResult = 1
            eventInfo.isUpdated = !eventList.isSameWithBackup(eventSeq: eventInfo.eventSeq!)
            eventInfo.isMemoUpdated = !eventList.isSameMemoWithBackup(eventSeq: eventInfo.eventSeq!)
            eventInfo.isDataUpdated = !eventList.isSameDataWithBackup(eventSeq: eventInfo.eventSeq!)

            if let updatedEvent = eventList.updatedEventInfoByEventSeq(eventSeq: eventInfo.eventSeq!) {
                updatedEvent.set(event: eventInfo)
            }
            reloadRow(row: row)
        }
    }
    
    @objc func moveFirstButtonPressed(_ sender: UIButton) {
        let row = sender.tag
        let eventInfo = eventArray[row]

        if eventInfo.begSecond! < 0 || eventInfo.endSecond! < 0 {
            return
        }
        setCurrentTime(seconds: eventInfo.begSecond!, method: .buttonPressed)
    }
    
    @objc func moveLastButtonPressed(_ sender: UIButton) {
        let row = sender.tag
        let eventInfo = eventArray[row]

        if eventInfo.begSecond! < 0 || eventInfo.endSecond! < 0 {
            return
        }
        setCurrentTime(seconds: eventInfo.endSecond!, method: .buttonPressed)
    }
    
    @objc func changeBegSecondButtonPressed(_ sender: UIButton) {
        let row = sender.tag
        let eventInfo = eventArray[row]
        eventInfo.begSecond = Int(currentTime.seconds)
        calcEventInfo(event: eventInfo)
        eventCheckType = 9
        saveButton.isEnabled = isDataChanged && (!isManager)
        setEventResultText()
        reloadRow(row: row)
        moveEventBeginEndLine()
    }
    
    @objc func changeEndSecondButtonPressed(_ sender: UIButton) {
        let row = sender.tag
        let eventInfo = eventArray[row]
        eventInfo.endSecond = Int(currentTime.seconds)
        calcEventInfo(event: eventInfo)
        eventCheckType = 9
        saveButton.isEnabled = isDataChanged && (!isManager)
        setEventResultText()
        reloadRow(row: row)
        moveEventBeginEndLine()
    }
    
    @objc func confirmButtonPressed(_ sender: UIButton) {
        let row = sender.tag
        let eventInfo = eventArray[row]
        
        calcEventInfo(event: eventInfo)
        if let updatedEvent = eventList.updatedEventInfoByEventSeq(eventSeq: eventInfo.eventSeq!) {
            updatedEvent.set(event: eventInfo)
        }

        eventCheckType = 9
        saveButton.isEnabled = isDataChanged && (!isManager)
        setEventResultText()

        selectedEventIndex = -1
        reloadRow(row: row)
        moveEventBeginEndLine()
    }
    
    func calcEventInfo(event:EventInfo) {
        event.elapsedSeconds = event.endSecond! - event.begSecond!
        event.begEpoNo = event.begSecond! / snapShotGapTime
        event.endEpoNo = event.endSecond! / snapShotGapTime
        event.checkResult = event.checkResult == -1 ? 0 : event.checkResult
        event.isChecked = true
        event.isUpdated = !eventList.isSameWithBackup(eventSeq: event.eventSeq!)
        event.isMemoUpdated = !eventList.isSameMemoWithBackup(eventSeq: event.eventSeq!)
        event.isDataUpdated = !eventList.isSameDataWithBackup(eventSeq: event.eventSeq!)

    }
    
    @objc func cancelButtonPressed(_ sender: UIButton) {
        let row = sender.tag
        let eventInfo = eventArray[row]

        if let updatedEvent = eventList.updatedEventInfoByEventSeq(eventSeq: eventInfo.eventSeq!) {
            eventInfo.set(event: updatedEvent)
        }
       
        selectedEventIndex = -1
        reloadRow(row: row)
        moveEventBeginEndLine()
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {

        keyboardBeginType = .none
        p("textFieldDidEndEditing : \(textField.tag), \(textField.text!), \(keyboardBeginType)")

        let row = textField.tag
        let eventInfo = eventArray[row]

        if eventInfo.memo == textField.text {
            return
        }
        
        eventInfo.memo = textField.text!
        eventInfo.checkResult = eventInfo.checkResult == -1 ? 0 : eventInfo.checkResult
        eventInfo.isChecked = true
        eventInfo.isUpdated = !eventList.isSameWithBackup(eventSeq: eventInfo.eventSeq!)
        eventInfo.isMemoUpdated = !eventList.isSameMemoWithBackup(eventSeq: eventInfo.eventSeq!)
        eventInfo.isDataUpdated = !eventList.isSameDataWithBackup(eventSeq: eventInfo.eventSeq!)

        eventCheckType = 9
        saveButton.isEnabled = isDataChanged && (!isManager)

        reloadRow(row: row)

    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        keyboardBeginType = .event
        p("textFieldDidBeginEditing : \(textField.tag), \(textField.text!), \(keyboardBeginType)")
    }

    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
