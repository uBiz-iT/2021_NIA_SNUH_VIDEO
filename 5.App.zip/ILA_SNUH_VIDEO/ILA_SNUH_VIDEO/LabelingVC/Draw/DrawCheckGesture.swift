//
//  DrawCheckGesture.swift
//  testSaveImage
//
//  Created by Myeong-Joon Son on 13/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {
    
    func compareLineImageViewBegan(gesture: UIGestureRecognizer) {
        let point = gesture.location(in: imageRegionView)
        
        if timeLineControlPoint.frame.contains(point) {
            panGestureBegan_TimeLine(point: point)
        }
        
    }
    
    func compareLineImageViewMoved(gesture: UIGestureRecognizer) {
        let point = gesture.location(in: imageRegionView)
        
        if isTimeLineMoving {
            panGestureMoved_TimeLine(point: point)
        }
    }
    
    func compareLineImageViewEnded(gesture: UIGestureRecognizer) {
        let point = gesture.location(in: imageRegionView) // 이미지뷰를 기준으로 위치 획득

        if isTimeLineMoving {
            panGestureEnded_TimeLine(point: point)
        }
    }

    
    func drawLineTapped(gesture: UITapGestureRecognizer) {
        let point = gesture.location(in: playerView)
        tapGesture_Rectangle(point: point)
    }
    
    func drawLineBegan(gesture: UIGestureRecognizer) {
        let point = gesture.location(in: playerView)
        befFreeCurvePoint = point
        panGestureBegan_Rectangle(point: point)
    }
    
    func drawLineMoved(gesture: UIGestureRecognizer) {
        
        let point = gesture.location(in: playerView)

        guard let befPoint = befFreeCurvePoint else { return }
        befFreeCurvePoint = point

        // 이전 포인트와 현재 포인트의 차이가 크면 갑자기 튀는 현상임.
        let xgap = abs(befPoint.x - point.x)
        let ygap = abs(befPoint.y - point.y)
        if (xgap == 0 && ygap == 0) { return }
        
        panGestureMoved_Rectangle(point: point)
    }
    
    func drawLineEnded(gesture: UIGestureRecognizer) {
        //let point = gesture.location(in: playerView)
    }

    func drawLineEnded() {
        drawRectangleEnded()
    }
}
