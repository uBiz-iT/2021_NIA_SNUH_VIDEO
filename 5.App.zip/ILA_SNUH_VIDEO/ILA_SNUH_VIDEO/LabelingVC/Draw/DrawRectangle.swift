//
//  DrawRectangle.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/26.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {

    func tapGesture_Rectangle(point:CGPoint) {
        if (canvas.isDrawing) {
            drawRectangleStop(point: point)
        }
        else {
            drawRectangleStart(point: point)
        }
    }
    
    func drawRectangleStart(point:CGPoint) {
        canvas.isDrawing = true
        panPrevPoint = point
        drawRectangle(point: point)
    }
    
    func drawRectangleStop(point:CGPoint) {
        drawMode(drawModeButton!)
    }
    
    func panGestureBegan_Rectangle(point:CGPoint) {

        if (!canvas.isDrawing) { return }

        panPrevPoint = point
        
        isSelectedRectangle = false
        isSelectedControlPoint = false

        if (containsInRectangle(frame: rectangleLayer.frame, point: point)) {
            isSelectedRectangle = true
        }
        else {
            let editMarkPoint = CGPoint(x:point.x - rectangleLayer.frame.origin.x,
                                        y:point.y - rectangleLayer.frame.origin.y)
            for (index, controlPoint) in controlPoints.enumerated() {
                if controlPoint.frame.contains(editMarkPoint) {
                    selectedControlPoint = controlPoint
                    isSelectedControlPoint = true
                    selectedControlPointPosition = index
                }
            }
        }
        
    }
    
    func panGestureMoved_Rectangle(point:CGPoint) {

        if (!canvas.isDrawing) { return }
        
        if (isSelectedControlPoint) {
            moveControlPoint_Rectangle(shapeLayer: rectangleLayer, controlPoint: selectedControlPoint,
                             position: selectedControlPointPosition,
                             x: point.x, y: point.y)
        }
        else if (isSelectedRectangle) {
            moveRectangle(shapeLayer: rectangleLayer, x: point.x, y: point.y)
        }
        
        calcThresHoldWithArea(videoRect: playerView.playerLayer.videoRect, markRect: rectangleLayer.frame)
    }
    
    func drawRectangleEnded() {

        if (!canvas.isDrawing) { return }
        canvas.isDrawing = false
        rectangleLayer.removeFromSuperlayer()

        calcThresHoldWithArea(videoRect: playerView.playerLayer.videoRect, markRect: rectangleLayer.frame)
    }
    
    // 화면상에서 터치한 포인트를 기준으로 디폴트 직사각형을 그린다.
    func drawRectangle(point:CGPoint) {
        
        // 최초 크기 설정
        let width = CGFloat(80)
        let height = CGFloat(80)
        let pointx = point.x - width / 2
        let pointy = point.y - height / 2
        
        let rect = CGRect(x: pointx, y: pointy, width: width, height: height)
        
        drawRectangle(rect: rect)
        
        calcThresHoldWithArea(videoRect: playerView.playerLayer.videoRect, markRect: rectangleLayer.frame)
        
    }
    
    func drawRectangle(rect:CGRect) {
        
        // 최초 크기 설정
        let width = rect.width
        let height = rect.height
        let pointx = rect.origin.x
        let pointy = rect.origin.y
        
        // 정의
        let rect = CGRect(x: 0, y: 0, width: width, height: height)
        let rectPath = UIBezierPath(rect: rect)
        
        // shapeLayer 생성
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = rectPath.cgPath               // 정의된 것을 layer에 지정
        shapeLayer.fillColor = UIColor.clear.cgColor
        shapeLayer.strokeColor = lineColor.cgColor
        shapeLayer.lineWidth = 2.0
        shapeLayer.frame = CGRect(x:pointx, y:pointy, width:width, height:height)
        
        addControlPointForRectangle(layer: shapeLayer)
        
        playerView.layer.addSublayer(shapeLayer)
        
        rectangleLayer = shapeLayer
        
    }
    
    func addControlPointForRectangle(layer:CAShapeLayer) {
        
        controlPoints.removeAll()

        let origin = CGPoint(x:0,y:0)
        let size = layer.frame.size
        
        let color = controlPointColor.cgColor
        
        // outline 추가
        let shapeLayer:CAShapeLayer = CAShapeLayer()
        let shapeRect = CGRect(x: 0, y: 0, width: size.width, height: size.height)

        shapeLayer.fillColor = UIColor.clear.cgColor
        //shapeLayer.strokeColor = color                        // 20200826 outlineLayer의 선을 보여주지 말자.
        shapeLayer.lineWidth = 1
        shapeLayer.lineDashPattern = [1,1]
        shapeLayer.path = UIBezierPath(roundedRect: shapeRect, cornerRadius: 0).cgPath
        shapeLayer.frame = CGRect(x:origin.x, y:origin.y, width:size.width, height:size.height)
        outlineLayer = shapeLayer
        layer.addSublayer(shapeLayer)
        
        // 꼭지점마다 컨트롤포인트 추가
        let controlPointSize = CGSize(width: 60, height: 60)
        let controlPointLayer:CAShapeLayer = CAShapeLayer()
        controlPointLayer.fillColor = UIColor.clear.cgColor
        controlPointLayer.strokeColor = color
        controlPointLayer.lineWidth = 1
        //controlPointLayer.lineDashPattern = [1,1]
        controlPointLayer.path =
            UIBezierPath(ovalIn:CGRect(x: 0, y: 0, width: controlPointSize.width, height: controlPointSize.height)).cgPath
        controlPointLayer.frame = CGRect(origin: CGPoint(x:0,y:0), size: controlPointSize)
        
        let controlPointLayerTopLeft = controlPointLayer.copyLayer()
        let controlPointLayerTopRight = controlPointLayer.copyLayer()
        let controlPointLayerBottomLeft = controlPointLayer.copyLayer()
        let controlPointLayerBottomRight = controlPointLayer.copyLayer()
        
        controlPointLayerTopLeft.frame =
            CGRect(origin: CGPoint(x:origin.x - controlPointSize.width/2,
                                   y:origin.y - controlPointSize.height/2),
                   size: controlPointSize)
        controlPointLayerTopRight.frame =
            CGRect(origin: CGPoint(x: origin.x + size.width - controlPointSize.width/2,
                                   y: origin.y - controlPointSize.height/2),
                   size: controlPointSize)
        controlPointLayerBottomLeft.frame =
            CGRect(origin: CGPoint(x:origin.x - controlPointSize.width/2,
                                   y: origin.y + size.height - controlPointSize.height/2),
                   size: controlPointSize)
        controlPointLayerBottomRight.frame =
            CGRect(origin: CGPoint(x:origin.x + size.width - controlPointSize.width/2,
                                   y: origin.y + size.height - controlPointSize.height/2),
                   size: controlPointSize)
        
        layer.addSublayer(controlPointLayerTopLeft)
        layer.addSublayer(controlPointLayerTopRight)
        layer.addSublayer(controlPointLayerBottomLeft)
        layer.addSublayer(controlPointLayerBottomRight)
        
        controlPoints.append(controlPointLayerTopLeft)
        controlPoints.append(controlPointLayerTopRight)
        controlPoints.append(controlPointLayerBottomLeft)
        controlPoints.append(controlPointLayerBottomRight)
        
        for (index, element) in controlPoints.enumerated() {
            p("enumerated:", index, ":", element.frame)
        }
        
    }

    // ------------------------------------------------------------------------------
    // 마크 이동, 컨트롤포인트 조절
    // ------------------------------------------------------------------------------
    func moveRectangle(shapeLayer: CAShapeLayer, x: CGFloat, y: CGFloat) {
        
        let prevOrigin = shapeLayer.frame.origin
        let gapPoint = CGPoint(x:x - panPrevPoint.x, y:y - panPrevPoint.y)
        
        panPrevPoint = CGPoint(x:x, y:y)
        
        let newOrigin = CGPoint(x:prevOrigin.x + gapPoint.x, y:prevOrigin.y + gapPoint.y)
        disableAnimation {
            shapeLayer.frame.origin = newOrigin
        }
    }
    
    func moveControlPoint_Rectangle(shapeLayer: CAShapeLayer, controlPoint: CAShapeLayer, position:Int, x: CGFloat, y: CGFloat) {
        
        // 이동 정지 여부 체크
        var pointx = x
        var pointy = y
        let gapPoint = CGPoint(x:x - panPrevPoint.x, y:y - panPrevPoint.y)
        
        switch position {
        case 0: // TopLeft
            if (shapeLayer.frame.origin.x + gapPoint.x >= shapeLayer.frame.origin.x + shapeLayer.frame.width) {
                pointx = panPrevPoint.x
            }
            if (shapeLayer.frame.origin.y + gapPoint.y >= shapeLayer.frame.origin.y + shapeLayer.frame.height) {
                pointy = panPrevPoint.y
            }
            break
        case 1: // TopRight
            if (shapeLayer.frame.origin.x + shapeLayer.frame.width + gapPoint.x <= shapeLayer.frame.origin.x) {
                pointx = panPrevPoint.x
            }
            if (shapeLayer.frame.origin.y + gapPoint.y >= shapeLayer.frame.origin.y + shapeLayer.frame.height) {
                pointy = panPrevPoint.y
            }
            break
        case 2: // BottomLeft
            if (shapeLayer.frame.origin.x + gapPoint.x >= shapeLayer.frame.origin.x + shapeLayer.frame.width) {
                pointx = panPrevPoint.x
            }
            if (shapeLayer.frame.origin.y + shapeLayer.frame.height + gapPoint.y <= shapeLayer.frame.origin.y) {
                pointy = panPrevPoint.y
            }
            break
        case 3: // BottomRight
            if (shapeLayer.frame.origin.x + shapeLayer.frame.width + gapPoint.x <= shapeLayer.frame.origin.x) {
                pointx = panPrevPoint.x
            }
            if (shapeLayer.frame.origin.y + shapeLayer.frame.height + gapPoint.y <= shapeLayer.frame.origin.y) {
                pointy = panPrevPoint.y
            }
            break
        default:
            break
        }
        
        // control point 이동
        moveControlPoints_Rectangle(shapeLayer: shapeLayer, controlPoint: controlPoint, position: position, x: pointx, y: pointy)
        
    }
    
    func moveControlPoints_Rectangle(shapeLayer: CAShapeLayer, controlPoint: CAShapeLayer, position:Int, x: CGFloat, y: CGFloat) {
        
        let gapPoint = CGPoint(x:x - panPrevPoint.x, y:y - panPrevPoint.y)
        var newOrigin:CGPoint = CGPoint()
        var index = 0
        
        switch position {
        case 0:
            // mark layer, topleft control layer
            newOrigin = CGPoint(x:shapeLayer.frame.origin.x + gapPoint.x,
                                y:shapeLayer.frame.origin.y + gapPoint.y)
            disableAnimation {
                shapeLayer.frame.origin = newOrigin
            }
            
            // topright control layer
            index = 1
            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x - gapPoint.x,
                                y:controlPoints[index].frame.origin.y)
            disableAnimation {
                controlPoints[index].frame.origin = newOrigin
            }
            
            // bottomleft control layer
            index = 2
            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x,
                                y:controlPoints[index].frame.origin.y - gapPoint.y)
            disableAnimation {
                controlPoints[index].frame.origin = newOrigin
            }
            
            // bottomright control layer
            index = 3
            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x - gapPoint.x,
                                y:controlPoints[index].frame.origin.y - gapPoint.y)
            disableAnimation {
                controlPoints[index].frame.origin = newOrigin
            }
            break
        case 1:
            // mark layer, topleft control layer
            newOrigin = CGPoint(x:shapeLayer.frame.origin.x,
                                y:shapeLayer.frame.origin.y + gapPoint.y)
            disableAnimation {
                shapeLayer.frame.origin = newOrigin
            }
            
            // topright control layer
            index = 1
            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x + gapPoint.x,
                                y:controlPoints[index].frame.origin.y)
            disableAnimation {
                controlPoints[index].frame.origin = newOrigin
            }
            
            // bottomleft control layer
            index = 2
            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x,
                                y:controlPoints[index].frame.origin.y - gapPoint.y)
            disableAnimation {
                controlPoints[index].frame.origin = newOrigin
            }
            // bottomright control layer
            index = 3
            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x + gapPoint.x,
                                y:controlPoints[index].frame.origin.y - gapPoint.y)
            disableAnimation {
                controlPoints[index].frame.origin = newOrigin
            }
            break
        case 2:
            // mark layer, topleft control layer
            newOrigin = CGPoint(x:shapeLayer.frame.origin.x + gapPoint.x,
                                y:shapeLayer.frame.origin.y)
            disableAnimation {
                shapeLayer.frame.origin = newOrigin
            }
            
            // topright control layer
            index = 1
            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x - gapPoint.x,
                                y:controlPoints[index].frame.origin.y)
            disableAnimation {
                controlPoints[index].frame.origin = newOrigin
            }
            
            // bottomleft control layer
            index = 2
            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x,
                                y:controlPoints[index].frame.origin.y + gapPoint.y)
            disableAnimation {
                controlPoints[index].frame.origin = newOrigin
            }
            
            // bottomright control layer
            index = 3
            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x - gapPoint.x,
                                y:controlPoints[index].frame.origin.y + gapPoint.y)
            disableAnimation {
                controlPoints[index].frame.origin = newOrigin
            }
            break
        case 3:
            // topright control layer
            index = 1
            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x + gapPoint.x,
                                y:controlPoints[index].frame.origin.y)
            disableAnimation {
                controlPoints[index].frame.origin = newOrigin
            }
            
            // bottomleft control layer
            index = 2
            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x,
                                y:controlPoints[index].frame.origin.y + gapPoint.y)
            disableAnimation {
                controlPoints[index].frame.origin = newOrigin
            }
            
            // bottomright control layer
            index = 3
            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x + gapPoint.x,
                                y:controlPoints[index].frame.origin.y + gapPoint.y)
            disableAnimation {
                controlPoints[index].frame.origin = newOrigin
            }
            break
        default:
            break
        }
        
        // outline과 rectangle 사이즈 조정
        let shapeWidth = controlPoints[1].frame.origin.x - controlPoints[0].frame.origin.x
        let shapeHeight = controlPoints[2].frame.origin.y - controlPoints[0].frame.origin.y
        let shapeSize = CGSize(width: shapeWidth, height: shapeHeight)
        let shapeRect = CGRect(origin: .zero, size: shapeSize)
        
        disableAnimation {
            shapeLayer.path = UIBezierPath(rect:shapeRect).cgPath
            shapeLayer.frame = CGRect(origin: shapeLayer.frame.origin, size: shapeSize)
//            outlineLayer.path = UIBezierPath(roundedRect: shapeRect, cornerRadius: 0).cgPath
//            outlineLayer.frame = CGRect(origin: .zero, size: shapeSize)
        }
        
        panPrevPoint = CGPoint(x:x, y:y)
        
    }

}
