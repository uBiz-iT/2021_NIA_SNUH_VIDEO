//
//  DrawTimeLine.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 2021/03/22.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {

    func drawTimeLine() {
    
        // ---------------------------------------
        // 이미 만들어진 layer를 super layer로 부터 제거
        // ---------------------------------------
        timeLineLayer.removeFromSuperlayer()
        timeLineControlPoint.removeFromSuperlayer()

        // 이미지 폭과 1초당 폭 구하기
        imageWidth = imageRegionView.frame.width - (imageOffsetInScrollImage + 30)
        secondWidth = imageWidth / CGFloat(snapShotGapTime)

        let height = imageRegionView.frame.height
        
        // ---------------------------------------
        // 세로로 타임 라인 그리기
        // ---------------------------------------
        timeLineApexStart = CGPoint(x: 0, y: 0)
        timeLineApexEnd = CGPoint(x: 0, y: height)

        // 영역의 높이 만큼 세로로 선을 긋는다
        let linePath = UIBezierPath()
        linePath.move(to: timeLineApexStart)
        linePath.addLine(to: timeLineApexEnd)
        
        // layer path에 선을 넣는다.
        timeLineLayer.path = linePath.cgPath
        timeLineLayer.strokeColor = timePointColor.cgColor
        timeLineLayer.lineWidth = 1
        timeLineLayer.lineJoin = CAShapeLayerLineJoin.round
        
        // layer의 크기와 위치를 지정하고 super layer에 추가
        timeLineLayer.frame = CGRect(origin: CGPoint(x:imageOffsetInScrollImage, y:0), size: CGSize(width: 0, height: height))
        imageRegionView.layer.addSublayer(timeLineLayer)

        // ---------------------------------------
        // 컨트롤 포인트(원형:손가락으로 끌기 쉽게) 생성
        // ---------------------------------------
        let controlPointSize = CGSize(width: 60, height: 60)

        // control point를 원형으로 만든다
        let controlPointPath = UIBezierPath(ovalIn:CGRect(x: 0, y: 0, width: controlPointSize.width, height: controlPointSize.height))

        // layer path에 만든 원을 넣는다.
        timeLineControlPoint.path = controlPointPath.cgPath
        timeLineControlPoint.fillColor = timePointColor.withAlphaComponent(0.3).cgColor
        timeLineControlPoint.strokeColor = timePointColor.cgColor
        timeLineControlPoint.lineWidth = 1
        
        // layer의 크기와 위치를 지정하고 super layer에 추가
        let x = timeLineLayer.frame.origin.x - (controlPointSize.width / 2)
        let y = timeLineLayer.frame.origin.y + 120
        timeLineControlPoint.frame = CGRect(origin: CGPoint(x:x,y:y), size: controlPointSize)
        imageRegionView.layer.addSublayer(timeLineControlPoint)

        // 수평선 추가
        let frameWidth = imageRegionView.frame.width
        timeLineApexStartH = CGPoint(x: 0, y: 0)
        timeLineApexEndH = CGPoint(x: frameWidth, y: 0)

        // 영역의 높이 만큼 가로로 선을 긋는다
        let linePathH = UIBezierPath()
        linePathH.move(to: timeLineApexStartH)
        linePathH.addLine(to: timeLineApexEndH)
        
        // layer path에 선을 넣는다.
        timeLineLayerH.path = linePathH.cgPath
        timeLineLayerH.strokeColor = timePointColor.cgColor
        timeLineLayerH.lineWidth = 1
        timeLineLayerH.lineJoin = CAShapeLayerLineJoin.round
        
        // layer의 크기와 위치를 지정하고 super layer에 추가
        timeLineLayerH.frame = CGRect(origin: CGPoint(x:0, y:y + 30), size: CGSize(width: frameWidth, height: 0))
        imageRegionView.layer.addSublayer(timeLineLayerH)

    }
    
    func redrawTimeLine() {
    
        let height = imageRegionView.frame.height
        if (timeLineApexEnd.y == height) { return }
        
        // 이미지 폭과 1초당 폭 구하기
        imageWidth = imageRegionView.frame.width - (imageOffsetInScrollImage + 30)
        secondWidth = imageWidth / CGFloat(snapShotGapTime)

        // ---------------------------------------
        // 세로로 타임 라인 그리기
        // ---------------------------------------
        timeLineApexStart = CGPoint(x: 0, y: 0)
        timeLineApexEnd = CGPoint(x: 0, y: height)

        // 영역의 높이 만큼 세로로 선을 긋는다
        let linePath = UIBezierPath()
        linePath.move(to: timeLineApexStart)
        linePath.addLine(to: timeLineApexEnd)
        
        // layer path에 선을 넣는다.
        timeLineLayer.path = linePath.cgPath
        
        // layer의 크기와 위치를 지정하고 super layer에 추가
        timeLineLayer.frame = CGRect(origin: timeLineLayer.frame.origin, size: CGSize(width: 0, height: height))

        // ---------------------------------------
        // 컨트롤 포인트(원형:손가락으로 끌기 쉽게) 생성
        // ---------------------------------------
        let controlPointSize = CGSize(width: 60, height: 60)

        // control point를 원형으로 만든다
        let controlPointPath = UIBezierPath(ovalIn:CGRect(x: 0, y: 0, width: controlPointSize.width, height: controlPointSize.height))

        // layer path에 만든 원을 넣는다.
        timeLineControlPoint.path = controlPointPath.cgPath
        
        // layer의 크기와 위치를 지정하고 super layer에 추가
        timeLineControlPoint.frame = CGRect(origin: timeLineControlPoint.frame.origin, size: controlPointSize)
        
        // 수평선
        let frameWidth = imageRegionView.frame.width
        timeLineApexStartH = CGPoint(x: 0, y: 0)
        timeLineApexEndH = CGPoint(x: frameWidth, y: 0)

        // 영역의 높이 만큼 가로로 선을 긋는다
        let linePathH = UIBezierPath()
        linePathH.move(to: timeLineApexStartH)
        linePathH.addLine(to: timeLineApexEndH)

        // layer path에 선을 넣는다.
        timeLineLayerH.path = linePathH.cgPath

        // layer의 크기와 위치를 지정하고 super layer에 추가
        timeLineLayerH.frame = CGRect(origin: timeLineLayerH.frame.origin, size: CGSize(width: frameWidth, height: 0))
        
    }
    
    func moveTimeLine(seconds:Float64) {
        if (isTimeLineMoving) {
            return
        }
        let remainder:CGFloat = CGFloat(seconds.truncatingRemainder(dividingBy: Float64(snapShotGapTime)))
        
        let newX = imageOffsetInScrollImage + (secondWidth * remainder)
        disableAnimation {
            timeLineLayer.position = CGPoint(x: newX, y: timeLineLayer.position.y)
            timeLineControlPoint.position = CGPoint(x: newX , y: timeLineControlPoint.position.y)
            timeLineLayer.layoutIfNeeded()
        }
    }
    
    func panGestureBegan_TimeLine(point:CGPoint) {
        panPrevPoint = point
        isTimeLineMoving = true

        // 플레이중이면 일단 멈춤
        if isVideoPlaying {
            if let vp = videoPlayer {
                vp.pause()
            }
        }
        
        setCurrentTime(time: currentTime, method: .timeLineBegin)

    }
    
    func panGestureMoved_TimeLine(point:CGPoint) {

        if (!isTimeLineMoving) { return }
        
        var x = point.x
        var y = point.y
        
        if x < 30 { x = 30 }
        if y < 30 { y = 30 }
        if x > imageRegionView.frame.width - 30 { x = imageRegionView.frame.width - 30 }
        if y > imageRegionView.frame.height - 30 { y = imageRegionView.frame.height - 30 }

        let gapPoint = CGPoint(x:x - panPrevPoint.x, y:y - panPrevPoint.y)
        let newPosition:CGPoint = CGPoint(x:timeLineControlPoint.position.x + gapPoint.x,
                                          y:timeLineControlPoint.position.y + gapPoint.y)

        disableAnimation {
            timeLineLayer.position = CGPoint(x: newPosition.x, y: timeLineLayer.position.y)
            timeLineLayerH.position = CGPoint(x: timeLineLayerH.position.x, y: newPosition.y)
            timeLineControlPoint.position = newPosition
        }

        setCurrentTime(seconds: getSecondsWithPosition(currentPositonX: timeLineLayer.position.x), method: .timeLineMoved)
        
        panPrevPoint = CGPoint(x: x, y: y)

    }
    
    func getSecondsWithPosition(currentPositonX x:CGFloat) -> Float {
        let prevSeconds = Float(selectedSubImageRowNum * snapShotGapTime)
        
        let sec:Float = Float(((x - imageOffsetInScrollImage) * CGFloat(snapShotGapTime)) / imageWidth)
        var currentSeconds:Float = round(sec * 10) / 10
        
        if currentSeconds < 0 { currentSeconds = 0 }
        else if currentSeconds > 29.6 { currentSeconds = 29.6 }
        
        return prevSeconds + currentSeconds
    }
    
    func panGestureEnded_TimeLine(point:CGPoint) {
        isTimeLineMoving = false

        setCurrentTime(time: currentTime, method: .timeLineEnd)

        // 플레이중이었으면 다시 플레이
        if isVideoPlaying {
            if let vp = videoPlayer {
                vp.play()
            }
        }
        
    }
    
}
