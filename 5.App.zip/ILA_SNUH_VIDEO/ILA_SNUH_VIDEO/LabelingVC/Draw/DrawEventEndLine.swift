//
//  DrawEventEndLine.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/05/23.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {

    func drawEndLine() {
    
        endLineLayer.removeFromSuperlayer()

        // 이미지 폭과 1초당 폭 구하기
        imageWidth = imageRegionView.frame.width - (imageOffsetInScrollImage + 30)
        secondWidth = imageWidth / CGFloat(snapShotGapTime)

        let height = imageRegionView.frame.height
        
        // ---------------------------------------
        // 세로로 라인 그리기
        // ---------------------------------------
        endLineApexStart = CGPoint(x: 0, y: 0)
        endLineApexEnd = CGPoint(x: 0, y: height)

        // 영역의 높이 만큼 세로로 선을 긋는다
        let linePath = UIBezierPath()
        linePath.move(to: endLineApexStart)
        linePath.addLine(to: endLineApexEnd)
        
        // layer path에 선을 넣는다.
        endLineLayer.path = linePath.cgPath
        endLineLayer.strokeColor = UIColor.systemGreen.cgColor
        endLineLayer.lineWidth = 3
        endLineLayer.lineDashPattern = [4, 2]
        endLineLayer.lineJoin = CAShapeLayerLineJoin.round
        
        // layer의 크기와 위치를 지정하고 super layer에 추가
        endLineLayer.frame = CGRect(origin: CGPoint(x:imageOffsetInScrollImage, y:0), size: CGSize(width: 0, height: height))
        imageRegionView.layer.addSublayer(endLineLayer)

    }
    
    func redrawEndLine() {

        let height = imageRegionView.frame.height
        if (endLineApexEnd.y == height) { return }
        
        imageWidth = imageRegionView.frame.width - (imageOffsetInScrollImage + 30)
        secondWidth = imageWidth / CGFloat(snapShotGapTime)

        // ---------------------------------------
        // 세로로 타임 라인 그리기
        // ---------------------------------------
        endLineApexStart = CGPoint(x: 0, y: 0)
        endLineApexEnd = CGPoint(x: 0, y: height)

        // 영역의 높이 만큼 세로로 선을 긋는다
        let linePath = UIBezierPath()
        linePath.move(to: endLineApexStart)
        linePath.addLine(to: endLineApexEnd)
        
        // layer path에 선을 넣는다.
        endLineLayer.path = linePath.cgPath
        endLineLayer.frame = CGRect(origin: endLineLayer.frame.origin, size: CGSize(width: 0, height: height))
    }
    
    func moveEndLine(seconds:Float64) {

        //p("moveEndLine : \(seconds)")
        
        let remainder:CGFloat = CGFloat(seconds.truncatingRemainder(dividingBy: Float64(snapShotGapTime)))
        
        let newX = imageOffsetInScrollImage + (secondWidth * remainder)
        disableAnimation {
            endLineLayer.position = CGPoint(x: newX, y: endLineLayer.position.y)
        }
    }
    
}
