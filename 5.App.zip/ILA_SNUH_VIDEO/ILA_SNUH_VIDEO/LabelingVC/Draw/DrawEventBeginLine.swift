//
//  DrawEventStartLine.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/05/23.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {

    func drawBeginLine() {
    
        beginLineLayer.removeFromSuperlayer()

        // 이미지 폭과 1초당 폭 구하기
        imageWidth = imageRegionView.frame.width - (imageOffsetInScrollImage + 30)
        secondWidth = imageWidth / CGFloat(snapShotGapTime)

        let height = imageRegionView.frame.height
        
        // ---------------------------------------
        // 세로로 라인 그리기
        // ---------------------------------------
        beginLineApexStart = CGPoint(x: 0, y: 0)
        beginLineApexEnd = CGPoint(x: 0, y: height)

        // 영역의 높이 만큼 세로로 선을 긋는다
        let linePath = UIBezierPath()
        linePath.move(to: beginLineApexStart)
        linePath.addLine(to: beginLineApexEnd)
        
        // layer path에 선을 넣는다.
        beginLineLayer.path = linePath.cgPath
        beginLineLayer.strokeColor = UIColor.systemPink.cgColor
        beginLineLayer.lineWidth = 3
        beginLineLayer.lineDashPattern = [4, 2]
        beginLineLayer.lineJoin = CAShapeLayerLineJoin.round
        
        // layer의 크기와 위치를 지정하고 super layer에 추가
        beginLineLayer.frame = CGRect(origin: CGPoint(x:imageOffsetInScrollImage, y:0), size: CGSize(width: 0, height: height))
        imageRegionView.layer.addSublayer(beginLineLayer)

    }
    
    func redrawBeginLine() {

        let height = imageRegionView.frame.height
        if (beginLineApexEnd.y == height) { return }
        
        imageWidth = imageRegionView.frame.width - (imageOffsetInScrollImage + 30)
        secondWidth = imageWidth / CGFloat(snapShotGapTime)

        // ---------------------------------------
        // 세로로 타임 라인 그리기
        // ---------------------------------------
        beginLineApexStart = CGPoint(x: 0, y: 0)
        beginLineApexEnd = CGPoint(x: 0, y: height)

        // 영역의 높이 만큼 세로로 선을 긋는다
        let linePath = UIBezierPath()
        linePath.move(to: beginLineApexStart)
        linePath.addLine(to: beginLineApexEnd)
        
        // layer path에 선을 넣는다.
        beginLineLayer.path = linePath.cgPath
        beginLineLayer.frame = CGRect(origin: beginLineLayer.frame.origin, size: CGSize(width: 0, height: height))
    }
    
    func moveBeginLine(seconds:Float64) {

        //p("moveBeginLine : \(seconds)")
        
        let remainder:CGFloat = CGFloat(seconds.truncatingRemainder(dividingBy: Float64(snapShotGapTime)))
        
        let newX = imageOffsetInScrollImage + (secondWidth * remainder)
        disableAnimation {
            beginLineLayer.position = CGPoint(x: newX, y: beginLineLayer.position.y)
        }
    }
    

}
