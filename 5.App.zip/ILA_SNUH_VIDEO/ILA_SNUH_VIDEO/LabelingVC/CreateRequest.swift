//
//  CreateURL.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import Foundation
import UIKit

extension LabelingVC {

    // =======================================================================================================
    // 서버로부터 json 포맷으로 받기 위한 url request 생성하기
    // =======================================================================================================
    func makeURLRequestForJsonFromServer(requestType:typeURLRequest) -> URLRequest? {
        
        var request:URLRequest? = nil
        
        switch requestType {
        case typeURLRequest.GetLabelList:  // 라벨 목록 가져오기
            
            struct RequestLabelList: Codable {
                var proc_name: String?
                var project_cd: String?
            }
            
            var requestLabelList = RequestLabelList();
            requestLabelList.proc_name = "P_GET_LABEL_LIST";
            requestLabelList.project_cd = WorkingProjectCode;
            
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted]
            
            let jsonData = try? encoder.encode(requestLabelList);
            
            // 접속 server url 정의
            // -------------------------------------------------
            let endpoint = "\(ILA4ML_URL_PROC)?id=\(LoginID)"
            guard let endpointUrl = URL(string: endpoint) else {
                p("URL Error : \(endpoint)")
                return nil
            }
            
            // 요청할 최종 url 정의
            // -------------------------------------------------
            
            request = URLRequest(url: endpointUrl)
            request?.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            request!.httpMethod = "POST"
            request!.httpBody = jsonData
            
        case typeURLRequest.GetLabelListWithResult:  // 라벨 목록(라벨링 결과 포함)
            
            struct RequestLabelList: Codable {
                var proc_name: String?
                var project_cd: String?
                var user_id: String?
            }
            
            var requestLabelList = RequestLabelList();
            requestLabelList.proc_name = "P_GET_LABEL_LIST_WITH_RESULT";
            requestLabelList.project_cd = WorkingProjectCode;
            requestLabelList.user_id = LoginID;
            
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted]
            
            let jsonData = try? encoder.encode(requestLabelList);
            
            // 접속 server url 정의
            // -------------------------------------------------
            let endpoint = "\(ILA4ML_URL_PROC)?id=\(LoginID)"
            guard let endpointUrl = URL(string: endpoint) else {
                p("URL Error : \(endpoint)")
                return nil
            }
            
            // 요청할 최종 url 정의
            // -------------------------------------------------
            request = URLRequest(url: endpointUrl)
            request?.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            request!.httpMethod = "POST"
            request!.httpBody = jsonData
            
        case typeURLRequest.GetPSGList:  // 이미지 목록
            
            struct RequestImageList: Codable {
                var proc_name: String?
                var project_cd: String?
                var user_id: String?
                var is_manager: String?
            }
            
            var requestImageList = RequestImageList();
            requestImageList.proc_name = "P_GET_PSG_LIST"
            requestImageList.user_id = LoginID
            requestImageList.project_cd = WorkingProjectCode
            requestImageList.is_manager = isManager ? "Y" : "N"
            
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted]
            
            let jsonData = try? encoder.encode(requestImageList);
            
            // 접속 server url 정의
            // -------------------------------------------------
            let endpoint = "\(ILA4ML_URL_PROC)?id=\(LoginID)"
            guard let endpointUrl = URL(string: endpoint) else {
                p("URL Error : \(endpoint)")
                return nil
            }
            
            // 요청할 최종 url 정의
            // -------------------------------------------------
            
            request = URLRequest(url: endpointUrl)
            request?.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            request!.httpMethod = "POST"
            request!.httpBody = jsonData
            
        case typeURLRequest.SaveLabelingResult:  // 라벨링 결과 저장
            
            var requestSaveLabelingResult = RequestSaveLabelingResult()
            
            requestSaveLabelingResult.proc_name = "P_SAVE_CHECK_RESULT"
            requestSaveLabelingResult.project_cd = WorkingProjectCode
            requestSaveLabelingResult.user_id = LoginID
            requestSaveLabelingResult.psg_id = psgArray[currentImageIndex].id
            requestSaveLabelingResult.psg_chk_res = psgCheckResult
            requestSaveLabelingResult.memo = psgMemo

            //var eventResult = EventResult();
            var eventResultAll = EventResultAll();

            let okCount = eventList.countByLabel(checkValue: 0)
            let ngCount = eventList.countByLabel(checkValue: 1)

            // 전체가 0 또는 1(NG)인지 확인
            if okCount == eventList.count {
                requestSaveLabelingResult.all_flag = 0
            }
            else if ngCount == eventList.count {
                requestSaveLabelingResult.all_flag = 1
            }
            else {
                requestSaveLabelingResult.all_flag = 9
            }
            
            // 기존 이벤트목록에서 개별 저장이고 수정된 것이 있는지 체크하여 전송
            // 기존 이벤트목록에서 일괄 저장이면 메모 데이터만 변경이 있는지 체크하여 전송
            for event in eventList.oldEvents {
                if (requestSaveLabelingResult.all_flag == 9) {
                    if (event.isNeedToSend) {
                        eventResultAll.seq = event.eventSeq
                        eventResultAll.res = event.checkResult
                        eventResultAll.memo = event.memo
                        eventResultAll.name = event.eventName
                        eventResultAll.begDT = event.begDT
                        eventResultAll.endDT = event.endDT
                        eventResultAll.begEpo = event.begEpoNo
                        eventResultAll.endEpo = event.endEpoNo
                        eventResultAll.begSec = event.begSecond
                        eventResultAll.endSec = event.endSecond
                        eventResultAll.elapsed = event.elapsedSeconds
                        eventResultAll.cud = event.isDataUpdated ? "U" : ""
                        requestSaveLabelingResult.event.append(eventResultAll)
                    }
                }
                else {
                    if event.isMemoUpdated || event.isDataUpdated {
                        eventResultAll.seq = event.eventSeq
                        eventResultAll.res = event.checkResult
                        eventResultAll.memo = event.memo
                        eventResultAll.name = event.eventName
                        eventResultAll.begDT = event.begDT
                        eventResultAll.endDT = event.endDT
                        eventResultAll.begEpo = event.begEpoNo
                        eventResultAll.endEpo = event.endEpoNo
                        eventResultAll.begSec = event.begSecond
                        eventResultAll.endSec = event.endSecond
                        eventResultAll.elapsed = event.elapsedSeconds
                        eventResultAll.cud = (event.eventSeq! > 1000) ? "C" : (event.isDataUpdated ? "U" : "")
                        requestSaveLabelingResult.event.append(eventResultAll)
                    }
                }
            }

            // 신규로 등록된 목록은 new_event에 추가하여 무조건 전송
            for event in eventList.newEvents {
                eventResultAll.seq = event.eventSeq
                eventResultAll.res = event.checkResult
                eventResultAll.name = event.eventName
                eventResultAll.begDT = event.begDT
                eventResultAll.endDT = event.endDT
                eventResultAll.begEpo = event.begEpoNo
                eventResultAll.endEpo = event.endEpoNo
                eventResultAll.begSec = event.begSecond
                eventResultAll.endSec = event.endSecond
                eventResultAll.elapsed = event.elapsedSeconds
                eventResultAll.memo = event.memo
                eventResultAll.cud = "C"
                requestSaveLabelingResult.new_event.append(eventResultAll)
            }
            
            // 여기까지 데이터 생성 후 이벤트 전체를 추가하여 json 파일을 만듬
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted]
            
            let jsonData = try? encoder.encode(requestSaveLabelingResult);
           
            // 접속 server url 정의
            // -------------------------------------------------
            let endpoint = "\(ILA4ML_URL_PROC)?id=\(LoginID)"
            guard let endpointUrl = URL(string: endpoint) else {
                p("URL Error : \(endpoint)")
                return nil
            }
            
            // 요청할 최종 url 정의
            // -------------------------------------------------
            request = URLRequest(url: endpointUrl)
            request?.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            request!.httpMethod = "POST"
            request!.httpBody = jsonData

            // JSON 파일 만들고 업로드 요청하러 감
            createAndUploadJsonResultFile()
            
        case typeURLRequest.GetSubImageList:  // 하위 이미지 목록
            
            struct RequestSubImageList: Codable {
                var proc_name: String?
                var user_id: String?
                var project_cd: String?
                var psg_id: String?
                var is_manager: String?
            }
            
            var requestSubImageList = RequestSubImageList();
            requestSubImageList.proc_name = "P_GET_PSG_IMAGE_LIST"
            requestSubImageList.user_id = LoginID
            requestSubImageList.project_cd = WorkingProjectCode
            requestSubImageList.psg_id = psgArray[currentImageIndex].id
            requestSubImageList.is_manager = isManager ? "Y" : "N"
            
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted]
            
            let jsonData = try? encoder.encode(requestSubImageList);

            // 접속 server url 정의
            // -------------------------------------------------
            let endpoint = "\(ILA4ML_URL_PROC)?id=\(LoginID)"
            guard let endpointUrl = URL(string: endpoint) else {
                p("URL Error : \(endpoint)")
                return nil
            }
            
            // 요청할 최종 url 정의
            // -------------------------------------------------
            request = URLRequest(url: endpointUrl)
            request?.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            request!.httpMethod = "POST"
            request!.httpBody = jsonData

        case typeURLRequest.GetEventList:  // 이벤트 목록
            
            struct RequestEventList: Codable {
                var proc_name: String?
                var user_id: String?
                var project_cd: String?
                var psg_id: String?
                var is_manager: String?
            }
            
            var requestEventList = RequestEventList();
            requestEventList.proc_name = "P_GET_EVENT_LIST"
            requestEventList.user_id = LoginID
            requestEventList.project_cd = WorkingProjectCode
            requestEventList.psg_id = psgArray[currentImageIndex].id
            requestEventList.is_manager = isManager ? "Y" : "N"
            
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted]
            
            let jsonData = try? encoder.encode(requestEventList);

            // 접속 server url 정의
            // -------------------------------------------------
            let endpoint = "\(ILA4ML_URL_PROC)?id=\(LoginID)"
            guard let endpointUrl = URL(string: endpoint) else {
                p("URL Error : \(endpoint)")
                return nil
            }
            
            // 요청할 최종 url 정의
            // -------------------------------------------------
            request = URLRequest(url: endpointUrl)
            request?.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            request!.httpMethod = "POST"
            request!.httpBody = jsonData
            
        case typeURLRequest.DeleteEvent:
            
            struct RequestDeleteEvent: Codable {
                var proc_name: String?
                var user_id: String?
                var project_cd: String?
                var psg_id: String?
                var event_seq: Int?
            }
            
            var requestDeleteEvent = RequestDeleteEvent();
            requestDeleteEvent.proc_name = "P_DELETE_EVENT"
            requestDeleteEvent.user_id = LoginID
            requestDeleteEvent.project_cd = WorkingProjectCode
            requestDeleteEvent.psg_id = psgArray[currentImageIndex].id
            requestDeleteEvent.event_seq = eventSeqToDelete
            
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted]
            
            let jsonData = try? encoder.encode(requestDeleteEvent);

            // 접속 server url 정의
            // -------------------------------------------------
            let endpoint = "\(ILA4ML_URL_PROC)?id=\(LoginID)"
            guard let endpointUrl = URL(string: endpoint) else {
                p("URL Error : \(endpoint)")
                return nil
            }
            
            // 요청할 최종 url 정의
            // -------------------------------------------------
            request = URLRequest(url: endpointUrl)
            request?.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            request!.httpMethod = "POST"
            request!.httpBody = jsonData
            
        default:
            break
        }
        
        return request
        
    }
    
    func getJsonFileUrl() -> URL {
        
        if (!makeDir(fullPath: markedImageDirectoryURL!.path)) {                    // 20200901
            p("getJsonFileUrl() : makeDir markedImageDirectoryURL error")
        }
        
        let serverFileName = String(format: "%@%@", psgArray[currentImageIndex].id!, markedImageNameSuffix)
        let jsonFileName = String(format: "%@.json", serverFileName)
        let jsonFileURL = markedImageDirectoryURL!.appendingPathComponent(jsonFileName)
        return jsonFileURL
    }
    
    func createAndUploadJsonResultFile() {
        
        var checkResult4Json = CheckResult4Json()
        var eventResultAll = EventResultAll();

        // json 파일용 변수에는 전체 이벤트 정보를 추가
        checkResult4Json.project_cd = WorkingProjectCode
        checkResult4Json.user_id = LoginID
        checkResult4Json.psg_id = psgArray[currentImageIndex].id
        checkResult4Json.psg_chk_res = psgCheckResult
        checkResult4Json.memo = psgMemo

        // 검수 완료된 것만 추출하여 저장
        for event in eventList.events.filter({ $0.isChecked }) {
            eventResultAll.seq = event.eventSeq
            eventResultAll.res = event.checkResult
            eventResultAll.name = event.eventName
            eventResultAll.begDT = event.begDT
            eventResultAll.endDT = event.endDT
            eventResultAll.begEpo = event.begEpoNo
            eventResultAll.endEpo = event.endEpoNo
            eventResultAll.begSec = event.begSecond
            eventResultAll.endSec = event.endSecond
            eventResultAll.elapsed = event.elapsedSeconds
            eventResultAll.memo = event.memo
            eventResultAll.cud = (event.eventSeq! > 1000) ? "C" : (event.isDataUpdated ? "U" : "")
            checkResult4Json.event.append(eventResultAll)
        }

        // json 파일용 변수를 실제 json 형식의 파일로 생성하고 전송 하도록 함
        do {
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            
            let jsonFile = try encoder.encode(checkResult4Json);
            try jsonFile.write(to: getJsonFileUrl(), options: [])

            // -----------------------------------------------------------------------------------
            // 20200828 추가 json 업로드
            // 저장된 json 파일 URL을 서버 위치에 업로드. 이미지보다 먼저 올림(이미지는 db에 저장 후 절차임)
            // -----------------------------------------------------------------------------------
            if let imageId = psgArray[currentImageIndex].id {
                let serverFileName = "\(imageId)\(markedImageNameSuffix)_\(LoginID)"
                let serverSourceImagePath = psgArray[currentImageIndex].serverLocation!
                appendUploadFileList(fileURL: getJsonFileUrl(), imageId: imageId, serverSourceImagePath: serverSourceImagePath, serverFileName: serverFileName, imageSeq: 0, line: nil)
            }

        } catch {
            p("jsonFile write : ", error.localizedDescription)
        }
        
    }

}
