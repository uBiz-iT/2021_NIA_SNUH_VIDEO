//
//  LabelingVC_CV.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 30/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

class LabelBottomCell: UICollectionViewCell {
    @IBOutlet var textLabel: UILabel!
}

extension LabelingVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    // MARK: - UICollectionViewDataSource protocol
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        // ----------------------------------------------------------------------------------------------
        // 섬네일이면~~~
        // ----------------------------------------------------------------------------------------------
        if (collectionView.tag == 3) {
            return 1
        }
        else if(collectionView.tag == 4) {
            return 1
        }
        else if(collectionView.tag == 5) {
            return 1
        }
        else if(collectionView.tag == 11) { // snapshot 20200320
            return 1
        }
        // ----------------------------------------------------------------------------------------------
        // 하단 라벨 목록이면~~~
        // ----------------------------------------------------------------------------------------------
        return 1
    }

    // tell the collection view how many cells to make
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {

        // ----------------------------------------------------------------------------------------------
        // 섬네일이면~~~
        // ----------------------------------------------------------------------------------------------
        if (collectionView.tag == 3) {
            return numberOfItemsInSection_Thumbnail(collectionView, numberOfItemsInSection: section)
        }
        // tag = 4
        return numberOfItemsInSection_MainImage(collectionView, numberOfItemsInSection: section)
        
    }
    
    // make a cell for each cell index path
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        // ----------------------------------------------------------------------------------------------
        // 섬네일이면~~~
        // ----------------------------------------------------------------------------------------------
        if (collectionView.tag == 3) {
            return cellForItemAt_Thumbnail(collectionView, cellForItemAt: indexPath)
        }
        
        // tag = 4
        return cellForItemAt_MainImage(collectionView, cellForItemAt: indexPath)

    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        // ----------------------------------------------------------------------------------------------
        // 섬네일이면~~~
        // ----------------------------------------------------------------------------------------------
        if (collectionView.tag == 3) {
            didSelectItemAt_Thumbnail(collectionView, didSelectItemAt: indexPath)
            return
        }

        // tag = 4
        didSelectItemAt_MainImage(collectionView, didSelectItemAt: indexPath)

    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        if (collectionView.tag == 3) {
            didDeselectItemAt_Thumbnail(collectionView, didDeselectItemAt: indexPath)
            return
        }

        // tag = 4
        didDeselectItemAt_MainImage(collectionView, didDeselectItemAt: indexPath)

    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        // ----------------------------------------------------------------------------------------------
        // 섬네일이면~~~
        // ----------------------------------------------------------------------------------------------
        if (collectionView.tag == 3) {
            return 1
        }

        // tag = 4
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {

        // ----------------------------------------------------------------------------------------------
        // 섬네일이면~~~
        // ----------------------------------------------------------------------------------------------
        if (collectionView.tag == 3) {
            return collectionViewLayout_Thumbnail(collectionView, layout: collectionViewLayout, minimumInteritemSpacingForSectionAt: section)
        }

        // tag = 4
        return collectionViewLayout_MainImage(collectionView, layout: collectionViewLayout, minimumInteritemSpacingForSectionAt: section)

    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        // ----------------------------------------------------------------------------------------------
        // 섬네일이면~~~
        // ----------------------------------------------------------------------------------------------
        if (collectionView.tag == 3) {
            return collectionViewLayout_Thumbnail(collectionView, layout: collectionViewLayout, sizeForItemAt: indexPath)
        }

        // tag = 4
        return collectionViewLayout_MainImage(collectionView, layout: collectionViewLayout, sizeForItemAt: indexPath)
    }
    
}
