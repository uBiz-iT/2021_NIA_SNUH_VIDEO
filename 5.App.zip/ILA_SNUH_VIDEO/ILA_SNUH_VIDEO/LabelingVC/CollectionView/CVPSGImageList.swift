//
//  LabelingVC_CV_Thumbnail.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 17/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit
import ImageIO
import AVKit
import AVFoundation

class ThumbnailCell: UICollectionViewCell {
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var cellImage: UIImageView!
    @IBOutlet weak var cellOrgImg: UIImageView!
    
    internal var befTextColor:UIColor? = UIColor.white
    internal var befBackColor:UIColor? = UIColor.red
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setdefaultColor()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    internal func setdefaultColor() {
        name.textColor = UIColor.white
        name.backgroundColor = UIColor.darkGray
    }
    
    enum ColorType {
        case basic
        case marked
        case selected
        case reject
    }
    
    func colorType(_ colorType:ColorType) {
        if (colorType == .basic) {
            setdefaultColor()
        }
        else if (colorType == .marked) {
            name.textColor = UIColor.black
            name.backgroundColor = UIColor.yellow
        }
        else if (colorType == .reject) {
            name.textColor = UIColor.white
            name.backgroundColor = UIColor.systemPink
        }
        else if (colorType == .selected) {
            befTextColor = name.textColor
            befBackColor = name.backgroundColor
            name.textColor = UIColor.white
            name.backgroundColor = GetTintColor()
        }
        else {
            setdefaultColor()
        }
    }
    

}

extension LabelingVC {


    // ================================================================================================================
    // 여기서부터 섬네일 컬렉션 뷰 델리게이트 영역
    // ================================================================================================================
    func numberOfItemsInSection_Thumbnail(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return subImageArray.count
    }
    
    func cellForItemAt_Thumbnail(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "IDImageCell", for: indexPath as IndexPath) as! ThumbnailCell

        if (subImageArray.count == 0) { return cell }
        
        cell.backgroundColor = UIColor.black
        if (indexPath.item >= subImageArray.count) { return cell }

        let seconds = indexPath.row * snapShotGapTime
        cell.name.text = "\(subImageArray[indexPath.item].row_num!.description)(\(seconds)))"

        if currentImageIndex >= 0 && currentImageIndex < psgArray.count {
            if let videoBegDate = psgArray[currentImageIndex].video_begDT?.toDate() {
                let imageDate = videoBegDate.addingTimeInterval(TimeInterval(seconds))
                cell.name.text = "\(subImageArray[indexPath.item].row_num!.description)(\(getTimeString(imageDate)!))"
            }
        }
        
        cell.cellImage.image = nil
        cell.cellOrgImg.image = nil

        let isScrolling: Bool = collectionView.isDragging || collectionView.isDecelerating
        if isScrolling {
            autoScrollTimeCount = 0
        }
        
        if subImageArray[indexPath.item].isLabelingDone! {
            
            cell.colorType(.marked)

            // 20201103 0(accept)이 아니면 색상을 달리하자..(reject). target은 0 하나 이므로 0인 경우만 체크하면 됨
            for item in subImageArray[indexPath.item].labelingResult {
                if (item.target_cd == 0) {
                    let index = LabelList.getIndexOfLabelCode(location: 0, labelCode: item.label_cd!)
                    if index != 0 {
                        cell.colorType(.reject)
                    }
                }
            }

        }
        else {
            cell.colorType(.basic)
        }

        if (selectedSubImageRowNum == indexPath.item) {
            cell.colorType(.selected)
        }
        
        if let fileUrl = subImageArray[indexPath.item].fileUrl {
            cell.cellImage.image = loadImageFromDisk(fileUrl: fileUrl)
        }

        return cell
        
    }
    
    func didSelectItemAt_Thumbnail(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if (eventKindView.isHidden == false) {
            eventKindView.isHidden = true
        }

        if (selectedSubImageRowNum == indexPath.item) { return }
        
        if (psgArray[currentImageIndex].tarDownloadFlag != .completed) {
            showNotRegisterdMessage()
            return
        }

        selectedSubImageRowNum = indexPath.item
        befProgressIndex = selectedSubImageRowNum
        setCurrentTime(subImageIndex: selectedSubImageRowNum, method: .subImageSelected)
//        seekVideoPosition(subImageIndex: selectedSubImageRowNum)
        
//        isTouchSnapShot = true
        collectionViewThumbnail.reloadData()
        loadSubImageOneFromUrl(subImageInfo: subImageArray[selectedSubImageRowNum])
    }
    
    func didDeselectItemAt_Thumbnail(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
    }
    
    func collectionViewLayout_Thumbnail(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    func collectionViewLayout_Thumbnail(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if (OrientationValue == .landscape) {
            return CGSize(width: 70, height: collectionView.frame.height)
        }
        else {
            return CGSize(width: 70, height: collectionView.frame.height)
        }
    }
    
    // ================================================================================================================
    // 여기까지 섬네일 컬렉션 뷰 델리게이트 영역
    // ================================================================================================================

}

