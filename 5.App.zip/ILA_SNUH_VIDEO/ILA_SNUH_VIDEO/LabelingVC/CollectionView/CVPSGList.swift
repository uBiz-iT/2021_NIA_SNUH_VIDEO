//
//  LabelingVC_CV_MainImage.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 26/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

class MainImageCell: UICollectionViewCell {
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var cellImage: UIImageView!
    @IBOutlet weak var downloadProgress: UIProgressView!
    @IBOutlet weak var tarDownloadProgress: UIProgressView!
    @IBOutlet weak var tarStatus: UILabel!
    @IBOutlet weak var mp4Status: UILabel!
    @IBOutlet weak var cancelDownButton: UIButton!
    @IBOutlet weak var pauseDownButton: UIButton!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setdefaultColor()
        downloadProgress.progress = 0.0
        tarDownloadProgress.progress = 0.0
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    internal func setdefaultColor() {
        name.textColor = UIColor.white
        name.backgroundColor = UIColor.darkGray
        downloadProgress.tintColor = .green
        tarDownloadProgress.tintColor = .systemGreen
        tarStatus.textColor = .yellow
        mp4Status.textColor = .yellow
        cellImage.tintColor = UIColor.white
        cancelDownButton.titleLabel?.textColor = UIColor.white
        pauseDownButton.titleLabel?.textColor = UIColor.white
    }
    
    var psgInfo:PSGInfo? {
        didSet {
            if let info = psgInfo {
                name.text = "\(info.row_num!)"
            }
            setColor()
            setVisible()
            setProgress()
            setStatus()
        }
    }
    
    @IBAction func cancelButtonTapped(_ sender: Any) {
        guard let img = psgInfo else { return }
        if img.videoDownloadProgress < 1.0 {
            videoDownCancel(psgInfo: img, fileType: .mp4)
            refreshProgress(.mp4, isEvent: true)
            p("Cancel  : \(FileType.mp4)")
        }
        if img.tarDownloadProgress < 1.0 {
            videoDownCancel(psgInfo: img, fileType: .tar)
            refreshProgress(.tar, isEvent: true)
            p("Cancel  : \(FileType.tar)")
        }
    }
    
    
    @IBAction func pauseButtonTapped(_ sender: Any) {
        guard let img = psgInfo else { return }
        if img.videoDownloadProgress < 1.0 {
            videoDownPause(psgInfo: img, fileType: .mp4)
            refreshProgress(.mp4, isEvent: true)
            p("Paused  : \(FileType.mp4)")
        }
        if img.tarDownloadProgress < 1.0 {
            videoDownPause(psgInfo: img, fileType: .tar)
            refreshProgress(.tar, isEvent: true)
            p("Paused  : \(FileType.tar)")
        }
    }
    
    var index:Int = -1
    
    override var isSelected: Bool {
        didSet {
//            setColor()
        }
    }
    
    var userSelected: Bool = false {
        didSet {
            setColor()
        }
    }
    
    func setColor() {
        
        if (userSelected) {
            name.textColor = UIColor.yellow
//            name.backgroundColor = GetTintColor()
            name.backgroundColor = UIColor.systemBlue
            downloadProgress.tintColor = .green
            tarDownloadProgress.tintColor = .systemGreen
            tarStatus.textColor = .yellow
            mp4Status.textColor = .yellow
            cellImage.tintColor = UIColor.white
            cancelDownButton.titleLabel?.textColor = UIColor.white
            pauseDownButton.titleLabel?.textColor = UIColor.white
        }
        else {
            if let info = self.psgInfo,
               let done = info.isLabelingDone, done {
                name.textColor = UIColor.black
                name.backgroundColor = UIColor.yellow
                downloadProgress.tintColor = .green
                tarDownloadProgress.tintColor = .systemGreen
                tarStatus.textColor = .black
                mp4Status.textColor = .black
                cellImage.tintColor = UIColor.systemBlue
                cancelDownButton.titleLabel?.textColor = UIColor.systemBlue
                pauseDownButton.titleLabel?.textColor = UIColor.systemBlue
            }
            else {
                setdefaultColor()
            }
        }

    }
    
    func setVisible() {

        cellImage.isHidden = false
        cancelDownButton.isHidden = false
        pauseDownButton.isHidden = false

        guard let info = self.psgInfo else { return }
        
        if (canDownloadStatus(info.videoDownloadFlag) || canDownloadStatus(info.tarDownloadFlag)) {
            cellImage.isHidden = false
            cancelDownButton.isHidden = true
            pauseDownButton.isHidden = true
        }
        else {
            cellImage.isHidden = true
            
            if (info.videoDownloadFlag == .completed && info.tarDownloadFlag == .completed) {
                cancelDownButton.isHidden = true
                pauseDownButton.isHidden = true
            }
            else {
                cancelDownButton.isHidden = false
                pauseDownButton.isHidden = false
            }
        }
    }
    
    func setProgress() {
        guard let info = psgInfo else { return }
        
        downloadProgress.progress = info.videoDownloadProgress
        tarDownloadProgress.progress = info.tarDownloadProgress
    }
    
    func setStatus() {
        guard let info = psgInfo else { return }
        mp4Status.text = info.videoDownloadFlag.title
        tarStatus.text = info.tarDownloadFlag.title
        if info.videoDownloadFlag == .completed {
            downloadProgress.progress = 1.0
        }
        if info.tarDownloadFlag == .completed {
            tarDownloadProgress.progress = 1.0
        }
    }
    
    func refreshProgress(_ fileType:FileType?, isEvent:Bool = false) {
        guard let type = fileType else { return }
        guard let info = psgInfo else { return }
        
        if type == .mp4 {
            downloadProgress.progress = info.videoDownloadProgress
            if isEvent {
                mp4Status.text = info.videoDownloadFlag.title
                if info.videoDownloadFlag == .completed {
                    downloadProgress.progress = 1.0
                }
                setVisible()
                setColor()
            }
            else {
                mp4Status.text = String(format: "%2.1f", info.videoDownloadProgress * 100)
                setColor()
            }
        }
        else {
            tarDownloadProgress.progress = info.tarDownloadProgress
            if isEvent {
                tarStatus.text = info.tarDownloadFlag.title
                if info.tarDownloadFlag == .completed {
                    tarDownloadProgress.progress = 1.0
                }
                setVisible()
                setColor()
            }
            else {
                tarStatus.text = String(format: "%2.1f", info.tarDownloadProgress * 100)
                setColor()
            }
        }
    }
}

extension LabelingVC {

    
    // ================================================================================================================
    // 여기서부터 섬네일 컬렉션 뷰 델리게이트 영역
    // ================================================================================================================
    func numberOfItemsInSection_MainImage(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return psgArray.count
    }
    
    func cellForItemAt_MainImage(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "IDMainImageCell", for: indexPath as IndexPath) as! MainImageCell
        if (psgArray.count == 0) { return cell }

        cell.backgroundColor = UIColor.black
        
        if (indexPath.item >= psgArray.count) { return cell }

        cell.index = indexPath.item
        cell.psgInfo = psgArray[indexPath.item]
        cell.userSelected = (currentImageIndex == indexPath.item)

        return cell
        
    }
    
    func getCellProgressLabelColor(psgInfo:PSGInfo, index:Int) -> UIColor {
        var color:UIColor!
        if (psgInfo.isLabelingDone!) {
            color = .black
        }
        else {
            color = .yellow
        }
        
        if (index == (psgInfo.row_num! - 1)) {
            color = .yellow
        }
        
        return color
    }
    
    func didSelectItemAt_MainImage(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {

        if (eventKindView.isHidden == false) {
            eventKindView.isHidden = true
        }

        if isKeyboardShown {
            view.endEditing(true)
        }

        if (canDownloadStatus(psgArray[indexPath.item].videoDownloadFlag ) ||
            canDownloadStatus(psgArray[indexPath.item].tarDownloadFlag)) {

            pushDownloadVideo(index: indexPath.item, isAutoDown: false)
            DispatchQueue.main.async { [self] in
                collectionViewMainImage.reloadItems(at: [indexPath])
                collectionViewMainImage.layoutIfNeeded()
            }
            return
        }
        
        if (currentImageIndex == indexPath.item) {
            return
        }
        
        if saveButton.isEnabled {
            let dialogMessage = UIAlertController(title: "확인", message: "저장되지 않은 데이터가 있습니다. \n 계속 하시겠습니까?", preferredStyle: .alert)
            let ok = UIAlertAction(title: "예", style: .destructive, handler: { [self] (action) -> Void in
                actionDidSelectItemAt_MainImage(collectionView, didSelectItemAt: indexPath)
            })

            let cancel = UIAlertAction(title: "아니오", style: .cancel) { (action) -> Void in
            }
            dialogMessage.addAction(ok)
            dialogMessage.addAction(cancel)
            self.present(dialogMessage, animated: true, completion: nil)
        }
        else {
            actionDidSelectItemAt_MainImage(collectionView, didSelectItemAt: indexPath)
        }
    }
    
    // ----------------------------
    // cell 정보 얻기
    // ----------------------------
    func getMainCell(index:Int) -> MainImageCell? {
        let indexPath = IndexPath(item: index, section: 0)
        return getMainCell(indexPath: indexPath)
    }

    func getMainCell(indexPath:IndexPath) -> MainImageCell? {
        return collectionViewMainImage.cellForItem(at: indexPath) as? MainImageCell
    }

    func actionDidSelectItemAt_MainImage(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        
//        p("DiskStatus.totalDiskSpace : \(DiskStatus.totalDiskSpace)")
//        p("DiskStatus.usedDiskSpace : \(DiskStatus.usedDiskSpace)")
//        p("DiskStatus.freeDiskSpace : \(DiskStatus.freeDiskSpace)")
//        p("DiskStatus.totalDiskSpaceInBytes : \(DiskStatus.totalDiskSpaceInBytes)")
//        p("DiskStatus.usedDiskSpaceInBytes : \(DiskStatus.usedDiskSpaceInBytes)")
//        p("DiskStatus.freeDiskSpaceInBytes : \(DiskStatus.freeDiskSpaceInBytes)")

        var befCellOK = false

        if (currentImageIndex >= 0 && currentImageIndex < psgArray.count) {
            if let befIndexPath = selectedMainImageCellIndexPath {
                if let befCell = getMainCell(indexPath: befIndexPath) {
                    befCell.userSelected = false
                    befCellOK = true
                }
            }
        }
        else {
            p("Array Index Error : didSelectItemAt_MainImage() number \(currentImageIndex)")
        }

        currentImageIndex = indexPath.item

        if let cell = getMainCell(indexPath: indexPath) {
            cell.userSelected = true
        }
        
        selectedMainImageCellIndexPath = indexPath

        loadVideoImageEvent(index: currentImageIndex)
        
//        if (!befCellOK) {
            collectionViewMainImage.reloadData()
//        }
    }
    
    func didDeselectItemAt_MainImage(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        //p("---------------------------------------------------------------------------------didDeselectItemAt : \(indexPath.item)")
        return
    }
    
    func collectionViewLayout_MainImage(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    func collectionViewLayout_MainImage(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        //p("collectionView.frame.width, collectionView.frame.height : \(collectionView.frame.width), \(collectionView.frame.height)")
        if (OrientationValue == .landscape) {
            return CGSize(width: 67, height: collectionView.frame.height - 2)
        }
        else {
            return CGSize(width: 67, height: collectionView.frame.height - 2)
        }
    }
    // ================================================================================================================
    // 여기까지 섬네일 컬렉션 뷰 델리게이트 영역
    // ================================================================================================================
}
