//
//  Clear.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC: UIScribbleInteractionDelegate {


    
    func clearLabelImage() {
        
        clearEvent()
        clearImage()
        clearSubImageList()
        clearPSG()
        resetPlayer()
        
        projectNameLabel.text = "________________________"
        imageIDLabel.text = " "
        subImageNumLabel.text = ""
        subImageFileNameLabel.text = ""
        setDiagValue(reset: true)
        setSaveValue(reset: true)
        setProgressValue()
        resetObjectsRelatedToLabeling()
    }


    func resetObjectsRelatedToLabeling() {
        saveButton.isEnabled = isDataChanged && (!isManager)
    }
 
    func initLabelingSettingItem(removeVideoFile:Bool = true) {
        
        setTitle()
        
        _ = removeDir(fullPath: sourceImageDirectoryURL!.path)
        _ = removeDir(fullPath: markedImageDirectoryURL!.path)
        
        if (removeVideoFile) {

            downloadingIndicator.stopAnimating()
            downloadVideoProgress.isHidden = true
            
            downloadingTarIndicator.stopAnimating()
            downloadTarProgress.isHidden = true
            
            // 다운중인 것 취소하고 대기중인 것도 전부 삭제.
            //removeVideosToDownload()
            cancelAllDownload()
            collectionViewMainImage.reloadData()
            
            // 다운로드 받아놓은 동영상파일도 모두 삭제
//            p("removeDir sourceVideoDirectoryURL : \(sourceVideoDirectoryURL!)")
//            _ = removeDir(fullPath: sourceVideoDirectoryURL!.path)
        }
    }
    
    // 히든 뷰를 일단 초기화
    func initHiddenView(view: UIView) {
        view.frame = self.view.frame
        view.backgroundColor = UIColor.white
        view.alpha = 0.35
        view.isHidden = true
        self.view.addSubview(view)
    }

    func checkHiddenView() {
        if (psgList.count == 0 || !isLogin) {
            hiddenView.isHidden = false
        }
        else {
            hiddenView.isHidden = true
        }
    }
    
    func setRadioImage() {
        if #available(iOS 13.0, *) {
            radioOnImage = UIImage(systemName: "record.circle")
            radioOffImage = UIImage(systemName: "circle")
        }
        else {
            radioOnImage = UIImage(named: "radio-button-checked-24")
            radioOffImage = UIImage(named: "radio-button-unchecked-24")
        }
    }
    
    func setCheckBoxImage() {
        if #available(iOS 13.0, *) {
            checkedBoxImage = UIImage(systemName: "checkmark.square")
            uncheckedBoxImage = UIImage(systemName: "square")
        }
        else {
            checkedBoxImage = UIImage(named: "checkbox-checked")
            uncheckedBoxImage = UIImage(named: "checkbox-unchecked")
        }
    }

    func setButtonProperty(button:UIButton) {
        button.backgroundColor = .ubizLightBackground
        button.layer.cornerRadius = 3.5
        button.layer.borderWidth = 1
        button.layer.borderColor = UIColor.lightGray.cgColor
    }


    // --------------------------------------------------------------------------
    // 버튼 코너 둥글게
    // --------------------------------------------------------------------------
    func buttonRadius(_ button: UIButton) {
        button.layer.backgroundColor = UIColor.init(red: 232/255.0, green: 232/255.0, blue: 232/255.0, alpha: 1.0).cgColor
        button.layer.cornerRadius = 10;
        button.clipsToBounds = true;
    }
    
    func disableAnimation(_ closure:()->Void){
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        closure()
        CATransaction.commit()
    }
    

}
