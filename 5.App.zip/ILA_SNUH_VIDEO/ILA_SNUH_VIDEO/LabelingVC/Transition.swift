//
//  ScreenTransition.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/10.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC: UIViewControllerTransitioningDelegate {


    // -----------------------------------------------------------------------------
    // dimming view를 탭하면 실행할 seclector 지정
    // -----------------------------------------------------------------------------
    func setupDimmingViewTapGestureRecognizer(view:UIView) {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dimmingViewTapped(_:)))
        view.addGestureRecognizer(tapGesture)
    }
    
    // -----------------------------------------------------------------------------
    // dimming view tab selector
    // -----------------------------------------------------------------------------
    @objc func dimmingViewTapped(_ gesture: UITapGestureRecognizer) {
        menuViewController.didTopMenuType?(MenuType.nothing)
        menuViewController.dismiss(animated: true, completion: nil)
        checkHiddenView()
    }
    
    // -----------------------------------------------------------------------------
    // 선택된 메뉴에 해당하는 화면을 콜
    // -----------------------------------------------------------------------------
    func transitionToNewContent(_ menuType: MenuType) {
        
        switch menuType {
        case .login:
            self.performSegue(withIdentifier: "segueLoginOut", sender: self)
            break
        case .projectList:
            self.performSegue(withIdentifier: "segueProjectList", sender: self)
            break
        case .help:
            self.performSegue(withIdentifier: "segueHelp", sender: self)
            break
        case .about:
            self.performSegue(withIdentifier: "segueAbout", sender: self)
            break
        case .labeling:
            self.performSegue(withIdentifier: "segueLabeling", sender: self)
            break
        case .nothing:
            break
        case .setting:
            self.performSegue(withIdentifier: "segueSetting", sender: self)
            break
        }
    }
    
    // -----------------------------------------------------------------------------
    // 메인 화면에서 매뉴 선택 후 다른 메뉴로 갈때 호출
    // -----------------------------------------------------------------------------
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

        p("UIStoryboardSegue : \(segue.identifier!)")
        
        if segue.identifier == "segueLoginOut" {
        }
        else if segue.identifier == "segueProjectList" {
        }
        else if segue.identifier == "segueHelp" {
        }
        else if segue.identifier == "segueAbout" {
        }
        else if segue.identifier == "segueLabeling" {
        }
    }
 
    // -----------------------------------------------------------------------------
    // 다른 화면으로 갔다가 돌아올 때 어떻게 할 것인지...
    // -----------------------------------------------------------------------------
    func returnFromOtherScreen(segue : UIStoryboardSegue) {
        
        displayMenuView = true
        
        isNewLogined = false
        isNewProjectBegan = false
        
        if let id = segue.identifier {
            p("returnFromsegueAction (segue identifier) : ", id)
            if (id == "unwindFromNewProject") {
                isFromProjectMenu = true
                isNewProjectBegan = true
                displayMenuView = false
                
                //새로 프로젝트가 시작되었으면 설정 값을 초기화
                initLabelingSettingItem(removeVideoFile: !IS_SAME_PROJECT)
                
            }
            else if (id == "unwindFromProjectList") {
                isFromProjectMenu = true
                isNewProjectBegan = false
            }
            else if (id == "unwindFromNewLogin") {
                isFromLoginMenu = true
                isNewLogined = true
                displayMenuView = false
            }
            else if (id == "unwindFromLoginOut") {
                isFromLoginMenu = true
                isNewLogined = false
            }
        }
        
    }
    

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        
        // size : Transition이 된 이후
        // self.view.frame.size : 다시 그리기 전의 이전 size
        
        if (size.width > self.view.frame.size.width) {
            p("----------- Landscape : \(size.width), \(self.view.frame.size.width)")
        } else {
            p("----------- Portrait  : \(size.width), \(self.view.frame.size.width)")
        }
        
        // zoom sacle을 초기화. 이걸 해줘야 제대로 위치에 다시 그림...
        ScrollImage.zoomScale = 1.0
        
        if (size.width != self.view.frame.size.width) {
            DispatchQueue.main.async {
                self.drawTimeLine()
                self.drawBeginLine()
                self.drawEndLine()
            }
        }

    }

    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)

        p("traitCollectionDidChange is called.")

        guard UIApplication.shared.applicationState == .inactive else {
            return
        }
        
        guard previousTraitCollection?.horizontalSizeClass != traitCollection.horizontalSizeClass else { return }
        
        p("traitCollection.horizontalSizeClass : \(traitCollection.horizontalSizeClass)")
    
        switch traitCollection.horizontalSizeClass {
        case .compact:
            break
        case .regular:
            break
        case .unspecified:
            break
        default:
            break
        }
        
        setDiagViewColor()
    }

    // Menu view 표시용
    // -----------------------------------------------------------------------------
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        menuTransition.isPresenting = true
        return menuTransition
    }
    
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        menuTransition.isPresenting = false
        return menuTransition
    }
}

