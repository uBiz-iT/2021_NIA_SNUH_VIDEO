//
//  ImageRegion.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import UIKit.UIGestureRecognizerSubclass

extension LabelingVC {

    func registerGestureImageRegion() {

        // ----------------------------------------------
        // 타임 라인 조정용
        // ----------------------------------------------
        compareLineGestureImage = UILongPressGestureRecognizer(target: self, action: #selector(compareLineImagePanned(_:)))
        compareLineGestureImage!.minimumPressDuration = 0.1    // 0.1이 딱 좋음. 더 작게하면 더블탭이 매우 힘듬.
        compareLineGestureImage!.allowableMovement = 15 // 15 points
        compareLineGestureImage!.delaysTouchesEnded = true
        imageRegionView.addGestureRecognizer(compareLineGestureImage!)
        
        // ----------------------------------------------
        // 비디오 재생/정지용
        // ----------------------------------------------
        tapGesture = UITapGestureRecognizer(target: self, action: #selector(imageTapped(_:)))
        tapGesture!.numberOfTouchesRequired = 1
        tapGesture!.numberOfTapsRequired = 1
        imageRegionView.addGestureRecognizer(tapGesture!)
        
        // ----------------------------------------------
        // 맨처음, 맨마지막으로 이미지 이동 및 스크롤 도중 선택된 곳으로 가는 용도
        // ----------------------------------------------
        doubleTapGesture = UIShortTapGestureRecognizer(target: self, action: #selector(scrollImageDoubleTapped(_:)))
        doubleTapGesture!.numberOfTouchesRequired = 1
        doubleTapGesture!.numberOfTapsRequired = 2
        imageRegionView.addGestureRecognizer(doubleTapGesture!)

        // 더블 탭 fail일 경우 싱글 탭 적용, 이렇게 하지 않으면 싱글 및 더블 탭 모두 이벤트 발생
        tapGesture!.require(toFail: doubleTapGesture!)

        // ----------------------------------------------
        // 이미지 크기 확대 도중 원상태로 돌리기
        // ----------------------------------------------
        tapGesture2 = UITapGestureRecognizer(target: self, action: #selector(imageTapped2(_:)))
        tapGesture2!.numberOfTouchesRequired = 2
        tapGesture2!.numberOfTapsRequired = 1
        ScrollImage.addGestureRecognizer(tapGesture2!)

        // ----------------------------------------------
        // 이미지를 좌우측으로 넘김
        // ----------------------------------------------
        swipeLeftGesture = UISwipeGestureRecognizer(target: self, action: #selector(editingImageSwiped(_:)))
        swipeLeftGesture!.direction = .left
        swipeLeftGesture!.numberOfTouchesRequired = 1
        imageRegionView.addGestureRecognizer(swipeLeftGesture!)

        swipeRightGesture = UISwipeGestureRecognizer(target: self, action: #selector(editingImageSwiped(_:)))
        swipeRightGesture!.direction = .right
        swipeRightGesture!.numberOfTouchesRequired = 1
        imageRegionView.addGestureRecognizer(swipeRightGesture!)


        // ----------------------------------------------
        // 메모이미지 터치 : 메모 뷰 보이도록
        // ----------------------------------------------
        let memoImageTabGesture:UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(memoImageTapped(_:)))
        memoImageTabGesture.numberOfTouchesRequired = 1
        memoImageTabGesture.numberOfTapsRequired = 1
        memoImage.addGestureRecognizer(memoImageTabGesture)

        // ----------------------------------------------
        // 입력된 메모 삭제 처리
        // ----------------------------------------------
        let memoImageLongGesture = UILongPressGestureRecognizer(target: self, action: #selector(memoImageLongPressed(_:)))
        memoImageLongGesture.minimumPressDuration = 0.3
        memoImageLongGesture.allowableMovement = 15 // 15 points
        memoImageLongGesture.delaysTouchesBegan = true
        memoImage.addGestureRecognizer(memoImageLongGesture)


    }
    

    //--------------------------------------------------------------------------------
    // 1 touch 1 tap
    //--------------------------------------------------------------------------------
    @objc func imageTapped(_ gesture: UITapGestureRecognizer) {
        
        if (eventKindView.isHidden == false) {
            eventKindView.isHidden = true
        }

        // 20201205
        if isKeyboardShown {
            view.endEditing(true)
            return
        }

        // 이미지도 탭하면 재생/정지
        togglePlay()

//        let point = gesture.location(in: imageRegionView)
//        let quadOfWidth = imageRegionView.frame.width / 4
//        //let quadOfWidth = imageRegionView.frame.width / 4
//
//        // 위치가 폭을 기준으로 폭 크기의 4분의 1 좌측이면 맨 처음으로 이동하고
//        if point.x < quadOfWidth {
//            arrowSubImageStepLeftClick(moveStepNumber)
//        }
//        // 폭 크기의 4분의 3보다 큰 위치를 탭했으면 맨 우측 이미지로 이동
//        else if point.x > (quadOfWidth * 3) {
//            arrowSubImageStepRightClick(moveStepNumber)
//        }
//        else {
//            togglePlay()
//        }

    }
    
    //--------------------------------------------------------------------------------
    // EditingImage 2 touch 1 tap
    //--------------------------------------------------------------------------------
    @objc func imageTapped2(_ gesture: UITapGestureRecognizer) {
        if (eventKindView.isHidden == false) {
            eventKindView.isHidden = true
        }

        ScrollImage.zoomScale = 1
    }
    
    //--------------------------------------------------------------------------------
    // player 영역 1 touch 2 tap
    //--------------------------------------------------------------------------------
    @objc func scrollImageDoubleTapped(_ gesture: UITapGestureRecognizer) {
        
        if (eventKindView.isHidden == false) {
            eventKindView.isHidden = true
        }

        // 20201205
        if (memoView.isFirstResponder) { return }
        
        let point = gesture.location(in: imageRegionView)
        let quadOfWidth = imageRegionView.frame.width / 4

        // 위치가 폭을 기준으로 폭 크기의 4분의 1 좌측이면 맨 처음으로 이동하고
        if point.x < quadOfWidth {
            arrowSubImageFirstClick()
        }
        // 폭 크기의 4분의 3보다 큰 위치를 탭했으면 맨 우측 이미지로 이동
        else if point.x > (quadOfWidth * 3) {
            arrowSubImageLastClick()
        }
        else {
            ScrollImage.zoomScale = 1
            collectionViewThumbnail.scrollToItem(at: IndexPath(item: selectedSubImageRowNum, section: 0), at: UICollectionView.ScrollPosition.centeredHorizontally, animated: true)
            collectionViewThumbnail.layoutIfNeeded()
        }
    }
    
    @objc func compareLineImagePanned(_ gesture: UIPanGestureRecognizer) {
        
        if (eventKindView.isHidden == false) {
            eventKindView.isHidden = true
        }

        struct Temp { static var numberOfTouchesWhenBegan = 0 }
        
        if (gesture.state == .began) {
            p("compareLineImagePanned.began")
            Temp.numberOfTouchesWhenBegan = gesture.numberOfTouches
            compareLineImageViewBegan(gesture: gesture)
        }
        if (gesture.state == .changed) {
            //p("compareLineImagePanned.changed")
            compareLineImageViewMoved(gesture: gesture)
        }
        if (gesture.state == .ended) {
            p("compareLineImagePanned.ended")
            compareLineImageViewEnded(gesture: gesture)
        }
        
    }
    
    @objc func editingImageSwiped(_ gesture: UISwipeGestureRecognizer) -> Void {

        if (eventKindView.isHidden == false) {
            eventKindView.isHidden = true
        }

        // 20201205
        if (memoView.isFirstResponder) { return }

        if gesture.numberOfTouches == 1 {
            if gesture.direction == UISwipeGestureRecognizer.Direction.right {
                arrowSubImageLeftClick()
            }
            else if gesture.direction == UISwipeGestureRecognizer.Direction.left {
                arrowSubImageRightClick()
            }
        }
    }
    
    @objc func imageSwiped(_ gesture: UISwipeGestureRecognizer) -> Void {
        
        if (eventKindView.isHidden == false) {
            eventKindView.isHidden = true
        }

        // 20201205
        if (memoView.isFirstResponder) { return }

        let point = gesture.location(in: imageRegionView)
        
        // swipe가 발생하였는데 컨트롤포인트 위치인 경우에는 swipe 처리하지 않음
        if timeLineControlPoint.frame.contains(point) {
            return
        }
        
        if gesture.numberOfTouches == 1 {
            if gesture.direction == UISwipeGestureRecognizer.Direction.right {
                arrowSubImageLeftClick()
            }
            else if gesture.direction == UISwipeGestureRecognizer.Direction.left {
                arrowSubImageRightClick()
            }
        }
    }
    
    //--------------------------------------------------------------------------------
    // 20201205 메모이미지 탭
    //--------------------------------------------------------------------------------
    @objc func memoImageTapped(_ gesture: UITapGestureRecognizer) {
        isDisplayMemo = !isDisplayMemo
        p("isDisplayMemo : \(isDisplayMemo)")
        memoView.isHidden = !isDisplayMemo
        if (memoView.isHidden) {
            view.endEditing(true)
        }
        else {
        }
        view.layoutIfNeeded()
    }
    
    @objc func memoImageLongPressed(_ gesture: UILongPressGestureRecognizer) {
        memoView.text = ""
    }
}
