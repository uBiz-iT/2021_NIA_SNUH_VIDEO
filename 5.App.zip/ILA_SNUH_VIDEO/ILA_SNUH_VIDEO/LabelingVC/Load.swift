//
//  ViewLoadAppear.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/10.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        let ud = MyUserDefaults()
        ud.getUserDefaultAfterDidBecomeActive()

        setCheckBoxImage()
        setRadioImage()

        // 이미지 디렉토리 URL 지정
        sourceImageDirectoryURL = DocumentsDirectoryURL.appendingPathComponent(sourceImageDirectoryName)
        markedImageDirectoryURL = DocumentsDirectoryURL.appendingPathComponent(markedImageDirectoryName)
        sourceVideoDirectoryParentURL = DocumentsDirectoryURL.appendingPathComponent(sourceVideoDirectoryName)

        setTitle()
        
        let reloadItem = UIBarButtonItem(image: #imageLiteral(resourceName: "Reload-50"), style: .plain, target: self, action: #selector(reloadPSGList(_:)))
        showDiag  = UIBarButtonItem(title: "진단정보확인", style: .plain, target: self, action: #selector(didTapShowDiag(_:)))
        self.navigationItem.rightBarButtonItems = [reloadItem, showDiag]
        
        // 하단 네비게이션 툴바 히든 처리
        self.navigationController?.toolbar.isHidden = true

        // 히든용 뷰를 하나 만들어서 제스처에 사용
        initHiddenView(view: hiddenView)
        checkHiddenView()

        viewDidLoad_PSGList()
        viewDidLoad_Diagnosis()
        viewDidLoad_ImageList()
        viewDidLoad_Image()
        viewDidLoad_Event()
        viewDidLoad_Player()
        viewDidLoad_Save()
        
        registerGestureAll()
        
        initLabelingSettingItem(removeVideoFile: false)
        
        // --------------------------------------------------------------------------
        // 이미지 상단 컨트롤 레이아웃 수동 지정을 위한 자동 레이아웃 설정 disable
        // --------------------------------------------------------------------------
        disableAutoresizingMask()

        autoUpload.start()

        videoDownStart()
        runLoopStart()
        
        setCurrentTime(time: .zero, method: .other)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(sender:)), name: UIResponder.keyboardWillShowNotification, object: nil);

        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(sender:)), name: UIResponder.keyboardWillHideNotification, object: nil);

    }
    
}
