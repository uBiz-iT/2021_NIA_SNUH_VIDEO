//
//  Layout.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    // --------------------------------------------------------------------------
    // 이미지 상단 컨트롤 레이아웃 수동 지정을 위한 자동 레이아웃 설정 disable
    // --------------------------------------------------------------------------
    func disableAutoresizingMask() {
        
        hiddenView.translatesAutoresizingMaskIntoConstraints = false
        
        regionView.translatesAutoresizingMaskIntoConstraints = false                    // 20200814
        
        imageRegionView.translatesAutoresizingMaskIntoConstraints = false
        playerRegionView.translatesAutoresizingMaskIntoConstraints = false             // 20200814
        regionSplitView.translatesAutoresizingMaskIntoConstraints = false
        
        eventSplitView.translatesAutoresizingMaskIntoConstraints = false
        //eventTV.translatesAutoresizingMaskIntoConstraints = false
        eventRegionView.translatesAutoresizingMaskIntoConstraints = false
        eventMenuButton.translatesAutoresizingMaskIntoConstraints = false
        eventFirstButton.translatesAutoresizingMaskIntoConstraints = false
        eventLastButton.translatesAutoresizingMaskIntoConstraints = false
        eventUpButton.translatesAutoresizingMaskIntoConstraints = false
        eventDownButton.translatesAutoresizingMaskIntoConstraints = false
        eventGoSelectedRowButton.translatesAutoresizingMaskIntoConstraints = false

        thumbnailGroupView.translatesAutoresizingMaskIntoConstraints = false
        collectionViewThumbnail.translatesAutoresizingMaskIntoConstraints = false
        
        backwardButton.translatesAutoresizingMaskIntoConstraints = false
        forwardButton.translatesAutoresizingMaskIntoConstraints = false
        playButton.translatesAutoresizingMaskIntoConstraints = false
        firstButton.translatesAutoresizingMaskIntoConstraints = false
        lastButton.translatesAutoresizingMaskIntoConstraints = false

    }
}
