//
//  LabelingVC_Layout.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 03/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {
    
    func adjustLabelListViewLocation() {
        
        var lineTypeLocationOffset:CGFloat = 102

        collectionViewThumbnail.isHidden = false
        thumbnailGroupView.isHidden = false

        collectionThumbnailTopConstant = 75
        
        lineTypeLocationOffset = lineTypeLocationOffset - 47

        //-------------------------------------------------------------------------------
        //  썸네일뷰를 가로는 화면 좌측 위치에 아래로 길게 배열, 세로모드일 경우에는 상단 위치에 옆으로 길게 배열
        //-------------------------------------------------------------------------------
        if (OrientationValue == .landscape) {
            if let layout = collectionViewThumbnail.collectionViewLayout as? UICollectionViewFlowLayout {
                layout.scrollDirection = .horizontal
            }
        }
        else {
            if let layout = collectionViewThumbnail.collectionViewLayout as? UICollectionViewFlowLayout {
                layout.scrollDirection = .horizontal
            }
        }
        
        for constraint in constraints {
            constraint.isActive = false
        }
        constraints.removeAll()
        
        var newConstarint:NSLayoutConstraint?
        
        newConstarint = hiddenView.topAnchor.constraint(equalTo: view.topAnchor)
        constraints.append(newConstarint!)
        newConstarint = hiddenView.leftAnchor.constraint(equalTo: view.leftAnchor)
        constraints.append(newConstarint!)
        newConstarint = hiddenView.rightAnchor.constraint(equalTo: view.rightAnchor)
        constraints.append(newConstarint!)
        newConstarint = hiddenView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        constraints.append(newConstarint!)

        if (OrientationValue == .landscape) {

            newConstarint = thumbnailGroupView.topAnchor.constraint(equalTo: view.topAnchor, constant: collectionThumbnailTopConstant)
            constraints.append(newConstarint!)
            newConstarint = thumbnailGroupView.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 1)
            constraints.append(newConstarint!)
            newConstarint = thumbnailGroupView.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -1)
            constraints.append(newConstarint!)
            //newConstarint = thumbnailGroupView.heightAnchor.constraint(equalToConstant: 109)
            newConstarint = thumbnailGroupView.heightAnchor.constraint(equalToConstant: 65)
            constraints.append(newConstarint!)

        }
        else {
            newConstarint = thumbnailGroupView.topAnchor.constraint(equalTo: view.topAnchor, constant: collectionThumbnailTopConstant)
            constraints.append(newConstarint!)
            newConstarint = thumbnailGroupView.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 1)
            constraints.append(newConstarint!)
            newConstarint = thumbnailGroupView.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -1)
            constraints.append(newConstarint!)
            //newConstarint = thumbnailGroupView.heightAnchor.constraint(equalToConstant: 109)
            newConstarint = thumbnailGroupView.heightAnchor.constraint(equalToConstant: 65)
            constraints.append(newConstarint!)
        }

        newConstarint = regionView.topAnchor.constraint(equalTo: thumbnailGroupView.bottomAnchor, constant: 0)
        constraints.append(newConstarint!)
        newConstarint = regionView.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 1)
        constraints.append(newConstarint!)
        newConstarint = regionView.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -1)
        constraints.append(newConstarint!)
        newConstarint = regionView.bottomAnchor.constraint(equalTo: collectionViewMainImage.topAnchor, constant: -1)
        constraints.append(newConstarint!)

        if (OrientationValue == .landscape) {
            newConstarint = regionSplitView.topAnchor.constraint(equalTo: regionView.topAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = regionSplitView.centerXAnchor.constraint(equalTo: regionView.centerXAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = regionSplitView.widthAnchor.constraint(equalToConstant: 1)
            constraints.append(newConstarint!)
            newConstarint = regionSplitView.bottomAnchor.constraint(equalTo: regionView.bottomAnchor, constant: 0)
            constraints.append(newConstarint!)

            newConstarint = playerRegionView.topAnchor.constraint(equalTo: regionView.topAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = playerRegionView.leftAnchor.constraint(equalTo: regionView.leftAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = playerRegionView.rightAnchor.constraint(equalTo: regionSplitView.leftAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = playerRegionView.bottomAnchor.constraint(equalTo: regionView.bottomAnchor, constant: 0)
            constraints.append(newConstarint!)

            newConstarint = eventSplitView.leftAnchor.constraint(equalTo: regionSplitView.rightAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = eventSplitView.centerYAnchor.constraint(equalTo: regionView.centerYAnchor, constant: -30)
            constraints.append(newConstarint!)
            newConstarint = eventSplitView.heightAnchor.constraint(equalToConstant: 1)
            constraints.append(newConstarint!)
            newConstarint = eventSplitView.rightAnchor.constraint(equalTo: regionView.rightAnchor, constant: 0)
            constraints.append(newConstarint!)

            newConstarint = imageRegionView.topAnchor.constraint(equalTo: regionView.topAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = imageRegionView.leftAnchor.constraint(equalTo: regionSplitView.rightAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = imageRegionView.rightAnchor.constraint(equalTo: regionView.rightAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = imageRegionView.bottomAnchor.constraint(equalTo: eventSplitView.topAnchor, constant: 0)
            constraints.append(newConstarint!)

            newConstarint = eventRegionView.topAnchor.constraint(equalTo: eventSplitView.bottomAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = eventRegionView.leftAnchor.constraint(equalTo: regionSplitView.rightAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = eventRegionView.rightAnchor.constraint(equalTo: regionView.rightAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = eventRegionView.bottomAnchor.constraint(equalTo: regionView.bottomAnchor, constant: 0)
            constraints.append(newConstarint!)
        }
        else {
            newConstarint = regionSplitView.leftAnchor.constraint(equalTo: regionView.leftAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = regionSplitView.centerYAnchor.constraint(equalTo: regionView.centerYAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = regionSplitView.heightAnchor.constraint(equalToConstant: 3)
            constraints.append(newConstarint!)
            newConstarint = regionSplitView.rightAnchor.constraint(equalTo: regionView.rightAnchor, constant: 0)
            constraints.append(newConstarint!)

            newConstarint = playerRegionView.topAnchor.constraint(equalTo: regionView.topAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = playerRegionView.leftAnchor.constraint(equalTo: regionView.leftAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = playerRegionView.rightAnchor.constraint(equalTo: regionView.rightAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = playerRegionView.bottomAnchor.constraint(equalTo: regionSplitView.topAnchor, constant: 0)
            constraints.append(newConstarint!)

            newConstarint = eventSplitView.topAnchor.constraint(equalTo: regionSplitView.bottomAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = eventSplitView.centerXAnchor.constraint(equalTo: regionView.centerXAnchor, constant: 40)
            constraints.append(newConstarint!)
            newConstarint = eventSplitView.widthAnchor.constraint(equalToConstant: 1)
            constraints.append(newConstarint!)
            newConstarint = eventSplitView.bottomAnchor.constraint(equalTo: regionView.bottomAnchor, constant: 0)
            constraints.append(newConstarint!)

            newConstarint = imageRegionView.topAnchor.constraint(equalTo: regionSplitView.bottomAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = imageRegionView.leftAnchor.constraint(equalTo: regionView.leftAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = imageRegionView.rightAnchor.constraint(equalTo: eventSplitView.rightAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = imageRegionView.bottomAnchor.constraint(equalTo: regionView.bottomAnchor, constant: 0)
            constraints.append(newConstarint!)

            newConstarint = eventRegionView.topAnchor.constraint(equalTo: regionSplitView.bottomAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = eventRegionView.leftAnchor.constraint(equalTo: eventSplitView.rightAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = eventRegionView.rightAnchor.constraint(equalTo: regionView.rightAnchor, constant: 0)
            constraints.append(newConstarint!)
            newConstarint = eventRegionView.bottomAnchor.constraint(equalTo: regionView.bottomAnchor, constant: 0)
            constraints.append(newConstarint!)

        }

        newConstarint = eventMenuButton.topAnchor.constraint(equalTo: eventRegionView.topAnchor, constant: 0)
        constraints.append(newConstarint!)
        newConstarint = eventMenuButton.rightAnchor.constraint(equalTo: eventRegionView.rightAnchor, constant: 0)
        constraints.append(newConstarint!)
        newConstarint = eventMenuButton.heightAnchor.constraint(equalTo: eventRegionView.heightAnchor, multiplier: 0.17, constant: -9)
        constraints.append(newConstarint!)
        newConstarint = eventMenuButton.widthAnchor.constraint(equalToConstant: 44)
        constraints.append(newConstarint!)
        
        newConstarint = eventFirstButton.topAnchor.constraint(equalTo: eventMenuButton.bottomAnchor, constant: 0)
        constraints.append(newConstarint!)
        newConstarint = eventFirstButton.rightAnchor.constraint(equalTo: eventRegionView.rightAnchor, constant: 0)
        constraints.append(newConstarint!)
        newConstarint = eventFirstButton.heightAnchor.constraint(equalTo: eventMenuButton.heightAnchor)
        constraints.append(newConstarint!)
        newConstarint = eventFirstButton.widthAnchor.constraint(equalTo: eventMenuButton.widthAnchor)
        constraints.append(newConstarint!)
        
        newConstarint = eventUpButton.topAnchor.constraint(equalTo: eventFirstButton.bottomAnchor, constant: 0)
        constraints.append(newConstarint!)
        newConstarint = eventUpButton.rightAnchor.constraint(equalTo: eventRegionView.rightAnchor, constant: 0)
        constraints.append(newConstarint!)
        newConstarint = eventUpButton.heightAnchor.constraint(equalTo: eventFirstButton.heightAnchor)
        constraints.append(newConstarint!)
        newConstarint = eventUpButton.widthAnchor.constraint(equalTo: eventFirstButton.widthAnchor)
        constraints.append(newConstarint!)
        
        newConstarint = eventGoSelectedRowButton.topAnchor.constraint(equalTo: eventUpButton.bottomAnchor, constant: 0)
        constraints.append(newConstarint!)
        newConstarint = eventGoSelectedRowButton.rightAnchor.constraint(equalTo: eventFirstButton.rightAnchor, constant: 0)
        constraints.append(newConstarint!)
        newConstarint = eventGoSelectedRowButton.heightAnchor.constraint(equalTo: eventFirstButton.heightAnchor)
        constraints.append(newConstarint!)
        newConstarint = eventGoSelectedRowButton.widthAnchor.constraint(equalTo: eventFirstButton.widthAnchor)
        constraints.append(newConstarint!)
        
        newConstarint = eventDownButton.topAnchor.constraint(equalTo: eventGoSelectedRowButton.bottomAnchor, constant: 0)
        constraints.append(newConstarint!)
        newConstarint = eventDownButton.rightAnchor.constraint(equalTo: eventFirstButton.rightAnchor, constant: 0)
        constraints.append(newConstarint!)
        newConstarint = eventDownButton.heightAnchor.constraint(equalTo: eventFirstButton.heightAnchor)
        constraints.append(newConstarint!)
        newConstarint = eventDownButton.widthAnchor.constraint(equalTo: eventFirstButton.widthAnchor)
        constraints.append(newConstarint!)
        
        newConstarint = eventLastButton.topAnchor.constraint(equalTo: eventDownButton.bottomAnchor, constant: 0)
        constraints.append(newConstarint!)
        newConstarint = eventLastButton.rightAnchor.constraint(equalTo: eventFirstButton.rightAnchor, constant: 0)
        constraints.append(newConstarint!)
        newConstarint = eventLastButton.heightAnchor.constraint(equalTo: eventFirstButton.heightAnchor)
        constraints.append(newConstarint!)
        newConstarint = eventLastButton.widthAnchor.constraint(equalTo: eventFirstButton.widthAnchor)
        constraints.append(newConstarint!)
        
        newConstarint = playButton.bottomAnchor.constraint(equalTo: playerRegionView.bottomAnchor, constant: -6)
        constraints.append(newConstarint!)
        newConstarint = playButton.centerXAnchor.constraint(equalTo: playerRegionView.centerXAnchor, constant: 0)
        constraints.append(newConstarint!)
        newConstarint = playButton.heightAnchor.constraint(equalToConstant: 40)
        constraints.append(newConstarint!)
        newConstarint = playButton.widthAnchor.constraint(equalToConstant: 50)
        constraints.append(newConstarint!)
        
        newConstarint = backwardButton.bottomAnchor.constraint(equalTo: playButton.bottomAnchor)
        constraints.append(newConstarint!)
        newConstarint = backwardButton.rightAnchor.constraint(equalTo: playButton.leftAnchor, constant: -30)
        constraints.append(newConstarint!)
        newConstarint = backwardButton.heightAnchor.constraint(equalTo: playButton.heightAnchor)
        constraints.append(newConstarint!)
        newConstarint = backwardButton.widthAnchor.constraint(equalTo: playButton.widthAnchor)
        constraints.append(newConstarint!)
        
        newConstarint = firstButton.bottomAnchor.constraint(equalTo: playButton.bottomAnchor)
        constraints.append(newConstarint!)
        newConstarint = firstButton.rightAnchor.constraint(equalTo: backwardButton.leftAnchor, constant: -30)
        constraints.append(newConstarint!)
        newConstarint = firstButton.heightAnchor.constraint(equalTo: playButton.heightAnchor)
        constraints.append(newConstarint!)
        newConstarint = firstButton.widthAnchor.constraint(equalTo: playButton.widthAnchor)
        constraints.append(newConstarint!)
        
        newConstarint = forwardButton.bottomAnchor.constraint(equalTo: playButton.bottomAnchor)
        constraints.append(newConstarint!)
        newConstarint = forwardButton.leftAnchor.constraint(equalTo: playButton.rightAnchor, constant: 30)
        constraints.append(newConstarint!)
        newConstarint = forwardButton.heightAnchor.constraint(equalTo: playButton.heightAnchor)
        constraints.append(newConstarint!)
        newConstarint = forwardButton.widthAnchor.constraint(equalTo: playButton.widthAnchor)
        constraints.append(newConstarint!)
        
        newConstarint = lastButton.bottomAnchor.constraint(equalTo: playButton.bottomAnchor)
        constraints.append(newConstarint!)
        newConstarint = lastButton.leftAnchor.constraint(equalTo: forwardButton.rightAnchor, constant: 30)
        constraints.append(newConstarint!)
        newConstarint = lastButton.heightAnchor.constraint(equalTo: playButton.heightAnchor)
        constraints.append(newConstarint!)
        newConstarint = lastButton.widthAnchor.constraint(equalTo: playButton.widthAnchor)
        constraints.append(newConstarint!)
        
        for constraint in constraints {
            constraint.isActive = true
        }
        
    }
    
    func clearConstraints(_ constraint:NSLayoutConstraint?) {
        if constraint != nil {
            constraint!.isActive = false
        }
    }
    
}
