//
//  LabelingVC.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 2020. 08. 10..
//  Copyright © 2020년 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

// 디렉토리 및 Path
// ------------------------------------------------------------------------------
let sourceImageDirectoryName = "SourceImage"
let sourceVideoDirectoryName = "SourceVideo"        // 20200818
let markedImageDirectoryName = "MarkedImage"
var sourceImageDirectoryURL:URL?
var sourceVideoDirectoryURL:URL?                 // 20210731 프로젝트별 디렉토리로 사용하고...
var markedImageDirectoryURL:URL?
let markedImageNameSuffix = "_CHECK"
var sourceVideoDirectoryParentURL:URL?           // 20210731 프로젝트별 디렉토리 부모 설정


class LabelingVC: UIViewController {

    //===============================================================================
    // 네이게이션 및 화면 전환 등
    //-------------------------------------------------------------------------------
    @IBOutlet var menuButton: UIBarButtonItem!

    let hiddenView = UIView()
    var showDiag  = UIBarButtonItem()
    
    var naviBarBlinkEndless = false
    var naviBarBlinkRunning = false
    var naviBarColor = UIColor.white

    var beforeOrientation = OrientationValue

    // 특정 화면에서 복귀할 때 다시 메뉴를 보여줄지를 담는 변수
    var displayMenuView = false
    var diagDisplayExtendOk: Bool = false {
        didSet {
            showDiag.title = diagDisplayExtendOk ? "진단정보숨기기" : "진단정보확인"
            showDiagView(diagDisplayExtendOk)
        }
    }

    let menuTransition = SlideMenuInTransition()
    var menuViewController:MenuVC = MenuVC()
    
    @IBAction func didTapMenu(_ sender: UIBarButtonItem) {

        
        // 저장되지 않은 데이터가 있는지 저장
        EXIST_NOTSAVEDDATA = saveButton.isEnabled
        
        menuViewController = storyboard?.instantiateViewController(withIdentifier: "MenuVC") as! MenuVC
        
        menuViewController.didTopMenuType = { menuType in
            p(menuType)
            self.transitionToNewContent(menuType)
        }
        menuViewController.modalPresentationStyle = .overCurrentContext
        menuViewController.transitioningDelegate = self // transitioningdeligate 설정
        present(menuViewController, animated: true)
        
        // 홈화면 위를 흐리게 하기 위해서 dimming view를 사용
        // dimming view를 탭하면 메뉴 뷰 사라지게 함
        setupDimmingViewTapGestureRecognizer(view: menuTransition.dimmingView)
        
    }
    
    @IBAction func returnFromsegueAction(segue : UIStoryboardSegue) {
        returnFromOtherScreen(segue: segue)
    }



    //===============================================================================
    // 그룹 영역 뷰
    //-------------------------------------------------------------------------------
    @IBOutlet var imageRegionView: UIView!
    @IBOutlet var playerRegionView: UIView!                   // 20200814
    @IBOutlet var regionView: UIView!                           // 20200814
    @IBOutlet var regionSplitView: UIView!                      // 20200814
    @IBOutlet weak var eventSplitView: UIView!              // 이벤트 영역 분리 뷰
    @IBOutlet weak var eventRegionView: UIView!             // 이벤트 표시 및 검수 영역
    @IBOutlet weak var eventAllCheckRegion: UIView!         // 전체검수 영역

    // 레이아웃 관련 변수 정의
    // ------------------------------------------------------------------------------
    var constraints = [NSLayoutConstraint]()
    var collectionThumbnailTopConstant:CGFloat = 75

    
    
    
    //===============================================================================
    // PSG 검사 목록 뷰
    //-------------------------------------------------------------------------------
    @IBOutlet weak var collectionViewMainImage: UICollectionView!

    // PSG 검사 목록 변수
    //-------------------------------------------------------------------------------
    var currentImageIndex = -1
    var image_last_row_num:Int = -1 // 서버로부터 가져온 메인 이미지 목록의 마지막 번호
    var image_count:Int = 0
    var mainImageNeedDownLoad = true

    var psgArray:[PSGInfo] = [PSGInfo]()
    var selectedMainImageCellIndexPath:IndexPath?

    // PSG 목록 갱신
    //-------------------------------------------------------------------------------
    var isReloadTapped = false      // 20201110     reload가 탭되었을 경우에는 현재 보여지고 있던 sub image를 보여주기 위하여
    


    //===============================================================================
    // 진단 정보 뷰
    //-------------------------------------------------------------------------------
    @IBOutlet var diagDisplayView: UIView!
    @IBOutlet var signedUserNameLabel: UILabel!
    @IBOutlet var projectNameLabel: UILabel!
    @IBOutlet var progress: UIProgressView!
    @IBOutlet var progressLabel: UILabel!
    @IBOutlet var imageIDLabel: UILabel!
    @IBOutlet var genderLabel: UILabel!
    @IBOutlet var ageLabel: UILabel!
    @IBOutlet var bmiLabel: UILabel!
    @IBOutlet var sltmLabel: UILabel!
    @IBOutlet var slef: UILabel!
    @IBOutlet var sllaLabel: UILabel!
    @IBOutlet var ahiLabel: UILabel!
    @IBOutlet var rdiLabel: UILabel!
    @IBOutlet var oxavg: UILabel!
    @IBOutlet var oxmin: UILabel!
    @IBOutlet var lmiLabel: UILabel!
    @IBOutlet var lmarLabel: UILabel!
    @IBOutlet var ariLabel: UILabel!
    @IBOutlet var diagLabel: UILabel!
    
    // ------------------------------------------------------------------------------
    // 이미지 라벨링 갯수 저장용
    // ------------------------------------------------------------------------------
    var total_count = 0     // 전체 이미지 갯수
    var complete_count = 0  // 완료 이미지 갯수
    var sub_total_count = 0     // sub 전체 이미지 갯수 20200820
    var sub_complete_count = 0  // sub 완료 이미지 갯수 20200820

    
    
    //===============================================================================
    // PSG 이미지 목록 뷰
    // ------------------------------------------------------------------------------
    @IBOutlet weak var thumbnailGroupView: UIView!
    @IBOutlet weak var collectionViewThumbnail: UICollectionView!

    var subImageArray:[SubImageInfo] = [SubImageInfo]()
    var last_row_num:Int = -1                                    // 섬네일컬렉션뷰
    var sub_image_count:Int = 0
    var selectedSubImageId:String = ""
    var selectedSubImageRowNum:Int = -1
    var sumImageNeedDownLoad = true

    var selectedThumbnailCellIndexPath:IndexPath?

    var snapShotImageArray:[SnapShotImageInfo] = [SnapShotImageInfo]()
    var isTouchSnapShot = false

    // snapshot index가 이전 index와 동일한 경우에는 아무것도 안하기 위함
    var befProgressIndex = -1
    // snapshot 이미지 간격, 몇초마다 snapshot을 만들건지 정의
    let snapShotGapTime = 30

    // 오토 스크롤 관련
    //-------------------------------------------------------------------------------
    var autoScrollTimeCount:Int = 6
    let autoScrollTimeOut:Int = 5



    
    //===============================================================================
    // 이미지 뷰
    //-------------------------------------------------------------------------------
    @IBOutlet var EditingImage : UIImageView!
    @IBOutlet var ScrollImage: UIScrollView!
    @IBOutlet weak var subImageNumLabel: UILabel!   // 이미지 리전 뷰쪽에 이미지 번호 보이기
    @IBOutlet weak var subImageFileNameLabel: UILabel!
    
    var originalImage:UIImage?
    var realImage:UIImage?
    var existImage = false
    var graphLabel = ClassGraphLabel()

    // 이미지 뷰 제스처
    //-------------------------------------------------------------------------------
    var tapGesture:UITapGestureRecognizer?
    var doubleTapGesture:UITapGestureRecognizer?
    var tapGesture2:UITapGestureRecognizer?
    var compareLineGestureImage:UILongPressGestureRecognizer?
    var swipeLeftGesture:UISwipeGestureRecognizer?
    var swipeRightGesture:UISwipeGestureRecognizer?
    
    // ------------------------------------------------------------------------------
    //  이미지 뷰의 타임라인용
    // ------------------------------------------------------------------------------
    var timeLineControlPoint = CAShapeLayer()
    var timePointColor:UIColor = UIColor.systemBlue

    var timeLineLayer = CAShapeLayer()
    var timeLineApexStart = CGPoint()
    var timeLineApexEnd = CGPoint()
    var isTimeLineMoving = false

    var timeLineLayerH = CAShapeLayer()
    var timeLineApexStartH = CGPoint()
    var timeLineApexEndH = CGPoint()

    var panPrevPoint = CGPoint(x:0,y:0)

    // ------------------------------------------------------------------------------
    // 이미지 뷰의 start/end line
    // ------------------------------------------------------------------------------
    var beginLineLayer = CAShapeLayer()
    var beginLineApexStart = CGPoint()
    var beginLineApexEnd = CGPoint()

    var endLineLayer = CAShapeLayer()
    var endLineApexStart = CGPoint()
    var endLineApexEnd = CGPoint()

    // scroll view안의 이미지 뷰의 위치 설정
    // ------------------------------------------------------------------------------
    var imageOffsetInScrollImage:CGFloat = 90
    var imageWidth:CGFloat = 0
    var secondWidth:CGFloat = 0     // 1초당 화면 폭


    
    //===============================================================================
    // 플레이어 오브젝트
    //-------------------------------------------------------------------------------
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var firstButton: UIButton!
    @IBOutlet weak var backwardButton: UIButton!
    @IBOutlet weak var forwardButton: UIButton!
    @IBOutlet weak var lastButton: UIButton!
    
    @IBOutlet weak var jumpStepSegmented: UISegmentedControl!
    @IBOutlet weak var speedSegmented: UISegmentedControl!
    @IBOutlet weak var gravitySegmented: UISegmentedControl!
    
    @IBOutlet weak var soundOnSwitch: UISwitch!
    
    @IBOutlet weak var timeSlider: UISlider!
    @IBOutlet weak var currentTimeLabel: UILabel!
    
    @IBOutlet weak var playTypeLabel: UILabel!
    @IBOutlet weak var currentTimeLargeLabel: UILabel!
    @IBOutlet weak var durationLabel: UILabel!
    
    @IBOutlet weak var playerScroll: UIScrollView!
    @IBOutlet weak var playerView: PlayerView!

    @IBOutlet weak var downloadVideoProgress: UIProgressView!
    @IBOutlet weak var downloadVideoProgressLabel: UILabel!
    @IBOutlet weak var downloadImageProgressLabel: UILabel!
    @IBOutlet weak var downloadTarProgress: UIProgressView!
    @IBOutlet weak var downloadingIndicator: UIActivityIndicatorView!
    @IBOutlet weak var downloadingTarIndicator: UIActivityIndicatorView!

    // 비디오 다운로드
    //-------------------------------------------------------------------------------
    var videoDownEndless = false
    var videoDownRunning = false

    lazy var downloadsSession: URLSession = {

        // 백그라운드 모드로 전환되었을때도 다운받던 것은 다운받도록 background 지원으로 구성 설정
        let config = URLSessionConfiguration.background(withIdentifier: "snuhvideo.kr.co.ubizit.bgSessionConfiguration")
        config.isDiscretionary = false
        config.sessionSendsLaunchEvents = true
        config.shouldUseExtendedBackgroundIdleMode = true
        config.timeoutIntervalForRequest = TimeInterval(10)      // timeout 시간
        
//        config.requestCachePolicy = .reloadIgnoringLocalCacheData
//        config.requestCachePolicy =
        config.urlCache = .none

        config.httpCookieAcceptPolicy = .never
        config.httpShouldSetCookies = true
        
        return URLSession(configuration: config, delegate: self, delegateQueue: nil)

    }()

    // 비디오 재생속도를 2배 이상하기 위해서 MixComposition을 사용하는데 여기에 사용할 sacleTimeRange
    //-------------------------------------------------------------------------------
    let videoMultiplier:Float64 = 1 / 10
    var videoPlayer:VideoPlayer?
    
    var diffRate:Float = 0 {
        didSet {
            testLabel.text = "\(diffRate)"
        }
    }
    
    var jumpStepDefaultIndex: Int = 2
    var videoGravity: AVLayerVideoGravity = .resizeAspect
    var isSoundOn = true
    var playSpeed: Float = 5.0
    var jumpStep: Float = 30.0
    var currentTime: CMTime = CMTime.zero {
        didSet {
            currentTimeLabel.text = getTimeString(currentTime)
            if let realDate = currentRealDate {
                currentTimeLargeLabel.text = getTimeString(realDate)
            }
            else {
                currentTimeLargeLabel.text = "시간정보 없음"
            }
        }
    }
    
    var currentRealDate:Date? {
        get {
            if currentImageIndex >= 0 && currentImageIndex < psgArray.count {
                if let videoBegDT = psgArray[currentImageIndex].video_begDT?.toDate() {
                    return videoBegDT.addingTimeInterval(currentTime.seconds)
                }
                else {
                    return nil
                }
            }
            else {
                return nil
            }
        }
    }

    var isTimeSliderValueChanging = false        // time slider를 움직이고 있는 중인지
    
    var currentProgress: Float64 = 0
    var duration: CMTime = CMTime.zero {
        didSet {
            durationLabel.text = getTimeString(duration)
            timeSlider.maximumValue = Float(duration.seconds)
        }
    }
    var isReadyPlay: Bool = false {
        didSet {
            playButton.isEnabled = isReadyPlay
            backwardButton.isEnabled = isReadyPlay
            forwardButton.isEnabled = isReadyPlay
        }
    }
    
    var isVideoPlaying: Bool = false {
        didSet {
            playButton.setImage(isVideoPlaying ? pauseImage : playImage, for: .normal)
            abnormalPlayButton.setImage(isVideoPlaying ? pauseImage : playImage, for: .normal)
        }
    }


    // 플레이어 뷰 제스처
    //-------------------------------------------------------------------------------
    var swipeLeftGesturePlayerRegion:UISwipeGestureRecognizer?
    var swipeRightGesturePlayerRegion:UISwipeGestureRecognizer?
    var playerViewPanGesture:UIPanGestureRecognizer?
    var tapGesturePlayer:UITapGestureRecognizer?                // player scroll 1 tap, 재생/정지, 포워딩, 백워딩에 사용
    var tapGesture2Player:UITapGestureRecognizer?               // player 2 touches 탭, 영상 원래 크기로 돌릴 때 사용
    var doubleTapGesturePlayer:UITapGestureRecognizer?          // player 1 touch 2 tap

    var befPlayerViewPanPoint:CGPoint?


    @IBAction func playPressed(_ sender: UIButton) {
        togglePlay()
    }
    
    @IBAction func firstPressed(_ sender: Any) {
        setCurrentTime(time: .zero, method: .buttonPressed)
    }
    
    @IBAction func forwardPressed(_ sender: UIButton) {
        jumpForward()
    }
    
    @IBAction func lastPressed(_ sender: Any) {
        setCurrentTime(time: duration, method: .buttonPressed)
    }
    
    @IBAction func backwardPressed(_ sender: Any) {
        jumpBackward()
    }
    
    @IBAction func gravitySegmentedValueChanged(_ sender: UISegmentedControl) {
        let gravity: AVLayerVideoGravity = EnumVideoGravity(rawValue: sender.selectedSegmentIndex)!.value
        setGravity(gravity)
    }
    
    
    @IBAction func speedSegmentedIndexChanged(_ sender: UISegmentedControl) {
        let playSpeed: Float = EnumSpeed(rawValue: sender.selectedSegmentIndex)!.value * Float(videoMultiplier)
        setSpeed(playSpeed)
    }
    
    @IBAction func jumpStepSegmentedIndexChanged(_ sender: UISegmentedControl) {
        let jumpStep: Float = EnumJumpStep(rawValue: sender.selectedSegmentIndex)!.value
        self.jumpStep = jumpStep
    }
    
    @IBAction func soundSwitchValueChanged(_ sender: UISwitch) {
        setSoundOn(sender.isOn)
    }
    
    //-------------------------------------------------------------------------------
    // 이상행동 검출 관련 오브젝트
    //-------------------------------------------------------------------------------
    @IBOutlet weak var abnormalAutoCreateButton: UIButton!
    @IBOutlet weak var abnormalAutoCreateButton2: UIButton!
    
    @IBOutlet weak var abnormalControlView: UIView!
    
    @IBOutlet weak var abnormalBegSecondLabel: UILabel!
    @IBOutlet weak var abnormalEndSecondLabel: UILabel!
    @IBOutlet weak var showAbnormalViewButton: UIButton!
    @IBOutlet weak var abnormalThresholdSlider: UISlider!
    @IBOutlet weak var abnormalThresholdValue: UILabel!
    @IBOutlet weak var DiffImage: UIImageView!
    @IBOutlet weak var testImageViewOut: UIImageView!
    @IBOutlet weak var testLabel: UILabel!
    @IBOutlet weak var drawModeButton: UIButton!
    @IBOutlet weak var drawModeInfo: UILabel!
    @IBOutlet weak var passIfExistEventButton: UIButton!
    @IBOutlet weak var passIfExistEventButton2: UIButton!
    
    // 사람의 크기를 알기 위하여 그리기 모드
    var canvas = Canvas()
    var isSelectedRectangle = false
    var isSelectedControlPoint = false
    var rectangleLayer = CAShapeLayer()
    var controlPoints: Array<CAShapeLayer> = Array()
    var selectedControlPointPosition = -1                       // 선택된 control point의 번호
    var lineColor:UIColor = UIColor.yellow
    var controlPointColor:UIColor = UIColor.systemBlue
    var outlineLayer = CAShapeLayer()                           // mark의 frame에 매칭되는 shape layer
    var selectedControlPoint = CAShapeLayer()                   // 선택된 control point
    var befFreeCurvePoint:CGPoint?
    var isDrawMode = false
    
    var befSnapshot = SnapShotImageInfo()
    var curSnapshot = SnapShotImageInfo()
    var isAbnormalStatus = false {
        didSet {
            timePointColor = isAbnormalStatus ? .systemRed : .systemBlue
            timeLineLayer.strokeColor = timePointColor.cgColor
            timeLineControlPoint.fillColor = timePointColor.withAlphaComponent(0.3).cgColor
            timeLineControlPoint.strokeColor = timePointColor.cgColor
            testLabel.textColor = isAbnormalStatus ? .systemRed : .white
        }
    }
    var isAbnormalAutoCreateBackup = false
    var isAbnormalAutoCreate = false {
        didSet {
            abnormalAutoCreateButton.setImage(isAbnormalAutoCreate ? checkedBoxImage : uncheckedBoxImage, for: .normal)
            abnormalControlView.isHidden = !isAbnormalAutoCreate
        }
    }
    var isPassIfExistEvent = true {
        didSet {
            passIfExistEventButton.setImage(isPassIfExistEvent ? checkedBoxImage : uncheckedBoxImage, for: .normal)
        }
    }
    
    var createdAbnormalList = [CreatedAbnormal]()
    
    var isShowAbnormalView = false
    var isAlreadyEvent = false

    var abnormalBegSecond:Float = -1 {
        didSet {
            if abnormalBegSecond < 0 {
                abnormalBegSecondLabel.text = "--:--"
                abnormalBegSecondLabel.stopBlink()
                abnormalBegSecondLabel.textColor = .white
                currentTimeLargeLabel.stopBlink()
            }
            else {
                abnormalBegSecondLabel.text = "\(getTimeString(Int(abnormalBegSecond)))"
                abnormalBegSecondLabel.startBlink()
                abnormalBegSecondLabel.textColor = .systemPink
                currentTimeLargeLabel.startBlink()
            }
            moveEventBeginEndLine()
            showAbnormalViewButton.isHidden = abnormalBegSecond < 0 || abnormalEndSecond < 0 || isShowAbnormalView
        }
    }
    var abnormalEndSecond:Float = -1 {
        didSet {
            if abnormalEndSecond < 0 {
                abnormalEndSecondLabel.text = "--:--"
                abnormalEndSecondLabel.stopBlink()
                abnormalEndSecondLabel.textColor = .white
            }
            else {
                abnormalEndSecondLabel.text = "\(getTimeString(Int(abnormalEndSecond)))"
                abnormalEndSecondLabel.startBlink()
                abnormalEndSecondLabel.textColor = .systemPink
            }
            moveEventBeginEndLine()
            showAbnormalViewButton.isHidden = abnormalBegSecond < 0 || abnormalEndSecond < 0 || isShowAbnormalView
        }
    }
    
    @IBAction func thresholdSliderChanged(_ sender: UISlider) {
        let value = Float(Int(sender.value * 10)) / Float(10)
        sender.value = value
        abnormalThresholdValue.text = "\(value)"
    }

    @IBAction func drawMode(_ sender: Any) {
        isDrawMode.toggle()

        if isDrawMode {
            drawModeInfo.isHidden = false
            
            p("playerScroll.bounds.size : \(playerScroll.bounds.size)")
            p("playerScroll.contentSize : \(playerScroll.contentSize)")
            p("playerScroll.contentInset : \(playerScroll.contentInset)")
            p("playerScroll.contentOffset : \(playerScroll.contentOffset)")

            // 화면에 보이는 부분에서의 중앙을 찾아서...(화면이 확대된 상태를 고려하여 계산 필요)
            let widthRate = playerScroll.bounds.size.width / playerScroll.contentSize.width
            let heightRate = playerScroll.bounds.size.height / playerScroll.contentSize.height
            
            let x = playerScroll.center.x * widthRate + playerScroll.contentOffset.x * widthRate
            let y = playerScroll.center.y * heightRate + playerScroll.contentOffset.y * heightRate
            
            tapGesture_Rectangle(point: CGPoint(x: x, y: y))

            if (isVideoPlaying) {
                stopPlay()
            }
        }
        else {
            drawRectangleEnded()
            drawModeInfo.isHidden = true
        }
    }
    
    @IBAction func abnormalAutoCreateButtonTapped(_ sender: Any) {
        isAbnormalAutoCreate = !isAbnormalAutoCreate
        isAbnormalAutoCreateBackup = isAbnormalAutoCreate
    }
    
    @IBAction func passIfExistEventButtonTapped(_ sender: Any) {
        isPassIfExistEvent = !isPassIfExistEvent
    }
    
    @IBAction func showAbnormalViewButtonTapped(_ sender: Any) {
        if abnormalBegSecond >= 0 && abnormalEndSecond >= 0 {
            if !isTimeSliderValueChanging && !isTimeLineMoving && selectedEventIndex < 0 && !isShowAbnormalView {
                showAbnormalView(isAlready: false, eventName: "신규이벤트", begSec: Int(abnormalBegSecond), endSec: Int(abnormalEndSecond))
            }
        }
    }

    

    //===============================================================================
    // 이상행동 조정 뷰
    //-------------------------------------------------------------------------------
    @IBOutlet weak var abnormalView: UIView!
    @IBOutlet weak var closeAbnormalViewButton: UIButton!
    @IBOutlet weak var saveAbnormalBehaviorButton: UIButton!
    @IBOutlet weak var abnormalPlayButton: UIButton!
    @IBOutlet weak var abnormalPlayFirstButton: UIButton!
    @IBOutlet weak var abnormalPlayLastButton: UIButton!
    @IBOutlet weak var abnormalViewBegLabel: UILabel!
    @IBOutlet weak var abnormalViewEndLabel: UILabel!
    @IBOutlet weak var abnormalViewRealBegLabel: UILabel!
    @IBOutlet weak var abnormalViewRealEndLabel: UILabel!
    @IBOutlet weak var abnormalViewTitleLabel: UILabel!
    @IBOutlet weak var abnormalBegChangeButton: UIButton!
    @IBOutlet weak var abnormalEndChangeButton: UIButton!
    @IBOutlet weak var abnormalMemoText: UITextField!

    // 이상행동 조정 뷰 변수
    //-------------------------------------------------------------------------------
    var befAbnormalViewPanPoint:CGPoint?

    var abnormalViewBegSecond:Float = -1 {
        didSet {
            if abnormalViewBegSecond < 0 {
                abnormalViewBegLabel.text = "--:--:--"
                abnormalViewRealBegLabel.text = "--:--:--"
            }
            else {
                abnormalViewBegLabel.text = "\(getTimeString(Int(abnormalViewBegSecond)))"
                if currentImageIndex >= 0 && currentImageIndex < psgArray.count {
                    if let videoBegDate = psgArray[currentImageIndex].video_begDT?.toDate() {
                        abnormalViewRealBegLabel.text = getTimeString(videoBegDate.addingTimeInterval(TimeInterval(abnormalViewBegSecond)))
                    }
                    else {
                        abnormalViewRealBegLabel.text = "--:--:--"
                    }
                }
                else {
                    abnormalViewRealBegLabel.text = "--:--:--"
                }
                moveEventBeginEndLine()
            }
        }
    }
    var abnormalViewEndSecond:Float = -1 {
        didSet {
            if abnormalViewEndSecond < 0 {
                abnormalViewEndLabel.text = "--:--:--"
                abnormalViewRealEndLabel.text = "--:--:--"
            }
            else {
                abnormalViewEndLabel.text = "\(getTimeString(Int(abnormalViewEndSecond)))"
                if currentImageIndex >= 0 && currentImageIndex < psgArray.count {
                    if let videoBegDate = psgArray[currentImageIndex].video_begDT?.toDate() {
                        abnormalViewRealEndLabel.text = getTimeString(videoBegDate.addingTimeInterval(TimeInterval(abnormalViewEndSecond)))
                    }
                    else {
                        abnormalViewRealEndLabel.text = "--:--:--"
                    }
                }
                else {
                    abnormalViewRealEndLabel.text = "--:--:--"
                }
                moveEventBeginEndLine()
            }
        }
    }

    @IBAction func closeAbnormalViewTapped(_ sender: UIButton) {
        setCurrentTime(seconds: abnormalViewEndSecond, method: .other)
        hideAbnormalView()

        abnormalBegSecond = -1
        abnormalEndSecond = -1
        isAbnormalStatus = false
        selectedEventIndex = -1
        eventTV.reloadData()
        
        // 단순 닫기이면 재생 시작
        if !isVideoPlaying {
            startPlay()
        }
    }
    
    @IBAction func saveAbnormalBehaviorTapped(_ sender: Any) {
        // 이벤트 목록에 추가 또는 수정하자. 저장에러이면 바로 return
        if !saveAbnormalEvent() {
            return
        }
        hideAbnormalView()

        setCurrentTime(seconds: abnormalViewEndSecond, method: .other)
        isAbnormalStatus = false
        abnormalBegSecond = -1
        abnormalEndSecond = -1

        // 저장이면 정지...
        if isVideoPlaying {
            stopPlay()
        }
    }
    

    @IBAction func abnormalPlayButtonTapped(_ sender: Any) {
        if abnormalViewBegSecond < 0 || abnormalViewEndSecond < 0 {
            return
        }
        togglePlay()
    }
    @IBAction func abnormalPlayFirstButtonTapped(_ sender: Any) {
        if abnormalViewBegSecond < 0 || abnormalViewEndSecond < 0 {
            return
        }
        setCurrentTime(seconds: abnormalViewBegSecond, method: .buttonPressed)
    }
    
    @IBAction func abnormalPlayLastButtonTapped(_ sender: Any) {
        if abnormalViewBegSecond < 0 || abnormalViewEndSecond < 0 {
            return
        }
        setCurrentTime(seconds: abnormalViewEndSecond, method: .buttonPressed)
    }
    
    
    @IBAction func abnormalBegChangeButtonTapped(_ sender: Any) {
        abnormalViewBegSecond = Float(Int(currentTime.seconds))
    }
    
    @IBAction func abnormalEndChangeButtonTapped(_ sender: Any) {
        abnormalViewEndSecond = Float(Int(currentTime.seconds))
    }
    
    @IBAction func abnormalViewMemoBeginEditing(_ textField: UITextField) {
        keyboardBeginType = .abnormal
        p("abnormalViewMemoBeginEditing : \(textField.tag), \(textField.text!), \(keyboardBeginType)")
    }
    
    @IBAction func abnormalViewMemoEndEditing(_ textField: UITextField) {
        keyboardBeginType = .none
        p("abnormalViewMemoEndEditing : \(textField.tag), \(textField.text!), \(keyboardBeginType)")
    }
    
    
    //===============================================================================
    // 이벤트 정보 관련 오브젝트
    //-------------------------------------------------------------------------------
    @IBOutlet weak var eventTV: UITableView!
    @IBOutlet weak var checkResultLabel: UILabel!
    @IBOutlet weak var allOKButton: UIButton!
    @IBOutlet weak var eachButton: UIButton!
    @IBOutlet weak var allNGButton: UIButton!
        
    @IBOutlet weak var eventMenuButton: UIButton!
    @IBOutlet weak var eventFirstButton: UIButton!
    @IBOutlet weak var eventLastButton: UIButton!
    @IBOutlet weak var eventDownButton: UIButton!
    @IBOutlet weak var eventUpButton: UIButton!
    @IBOutlet weak var eventGoSelectedRowButton: UIButton!

    // 이벤트 변수
    //-------------------------------------------------------------------------------
    var eventArray = [EventInfo]()
    var eventArrayBackup = [EventInfo]()
    var eventGroupArray = [String]()
    var eventKindArray = [String]()

    var befEventKindViewPanPoint:CGPoint?

    var selectedEventIndex = -1 {
        didSet {
            playTypeLabel.isHidden = (selectedEventIndex < 0)
            // 이벤트 선택 중에는 이상행동 검출 안함
            if selectedEventIndex >= 0 {
                abnormalAutoCreateButton.isHidden = true
                abnormalAutoCreateButton2.isHidden = true
                isAbnormalAutoCreate = false
            }
            else {
                isAbnormalAutoCreate = isAbnormalAutoCreateBackup
                abnormalAutoCreateButton.isHidden = false
                abnormalAutoCreateButton2.isHidden = false
            }
        }
    }
    
    var selectedEventGroupIndex = -1
    var selectedEventKindIndex = -1
    
    var befFoundFirstIndex:Int = -1
    var backupSelectedEvent:EventInfo = EventInfo()

    var eventSeqToDelete:Int = -1
    
    // 오토 스크롤 관련
    //-------------------------------------------------------------------------------
    var autoEventScrollTimeCount:Int = 6
    let autoEventScrollTimeOut:Int = 5
    var executeTimeEventReload:Date = Date()


    var eventCheckType = 9 {
        didSet {
            switch eventCheckType {
            case 0: // OK일때
                eachButton.setImage(radioOffImage, for: .normal)
                allOKButton.setImage(radioOnImage, for: .normal)
                allNGButton.setImage(radioOffImage, for: .normal)
                break
            case 1: // NG일때
                eachButton.setImage(radioOffImage, for: .normal)
                allOKButton.setImage(radioOffImage, for: .normal)
                allNGButton.setImage(radioOnImage, for: .normal)
                break
            case 9: // 개별모드일때
                eachButton.setImage(radioOnImage, for: .normal)
                allOKButton.setImage(radioOffImage, for: .normal)
                allNGButton.setImage(radioOffImage, for: .normal)
                break
            case -1: // 아무것도 선택이 안되었을 때
                eachButton.setImage(radioOffImage, for: .normal)
                allOKButton.setImage(radioOffImage, for: .normal)
                allNGButton.setImage(radioOffImage, for: .normal)
                break
            default:
                break
            }
        }
    }
    
    // 이벤트 관련 버튼 tap
    //--------------------------------------------------------------------------------
    @IBAction func eventMenuButtonTapped(_ sender: UIButton) {
        showEventKindView(eventKindView.isHidden)
    }
    
    @IBAction func eventFirstButtonTapped(_ sender: UIButton) {
        arrowEventFirst()
    }
    
    @IBAction func eventUpButtonTapped(_ sender: UIButton) {
        arrowEventPrevStep()
    }
    
    @IBAction func eventGoCurrentRowButtonTapped(_ sender: UIButton) {
        if selectedEventIndex < 0 { return }
        arrowEvent(num: selectedEventIndex)
    }
    
    @IBAction func eventDownButtonTapped(_ sender: UIButton) {
        arrowEventNextStep()
    }
    
    @IBAction func eventLastButtonTapped(_ sender: UIButton) {
        arrowEventLast()
    }

    @IBAction func allOKTapped(_ sender: UIButton) {
        eventCheckType = 0
        eventCheckAction(.allok)
        eventTV.reloadData()
    }
    
    @IBAction func allNGTapped(_ sender: UIButton) {
        eventCheckType = 1
        eventCheckAction(.allng)
        eventTV.reloadData()
    }
    
    @IBAction func eachCheckTapped(_ sender: UIButton) {
        eventCheckType = 9
        eventCheckAction(.each)
        eventTV.reloadData()
    }
    
    @IBAction func reloadCheckTapped(_ sender: UIButton) {
        eventCheckType = -1
        eventCheckAction(.reload)
        selectedEventIndex = -1
        eventTV.reloadData()
    }
    
    //===============================================================================
    // 이벤트 종류 선택 오브젝트
    //-------------------------------------------------------------------------------
    @IBOutlet weak var eventKindView: UIView!
    @IBOutlet weak var eventGroupTV: UITableView!
    @IBOutlet weak var eventKindTV: UITableView!
    
    @IBAction func closeEventKindViewTapped(_ sender: Any) {
        showEventKindView(false)
    }
    
    //===============================================================================
    // 저장 오브젝트
    //-------------------------------------------------------------------------------
    @IBOutlet var saveButton: UIButton!
    @IBOutlet weak var psgPassButton: UIButton!
    @IBOutlet weak var psgFailButton: UIButton!
    @IBOutlet weak var memoImage: UIImageView!
    @IBOutlet weak var memoView: UITextView!

    var psgMemo:String = "" {
        didSet {
            if psgMemo > "" {
                memoView.text = psgMemo
                memoView.textColor = UIColor.black
            }
            else {
                memoView.text = "메모 입력시 탭하세요"
                memoView.textColor = UIColor.lightGray
            }
            saveButton.isEnabled = isDataChanged && (!isManager)
        }
    }
    var psgCheckResult:Int = -1 {
        didSet {
            psgPassButton.setImage(psgCheckResult == 0 ? radioOnImage : radioOffImage, for: .normal)
            psgFailButton.setImage(psgCheckResult == 1 ? radioOnImage : radioOffImage, for: .normal)
            saveButton.isEnabled = isDataChanged && (!isManager)
        }
    }
    
    // psg 자제 검증 결과 또는 이벤트 검증 결과가 뭐라도 변경되었는지...
    var isDataChanged:Bool {
        get {
            return eventList.isChanged || isPSGChanged
        }
    }
    
    // psg 변경이 있는지
    var isPSGChanged:Bool {
        get {
            if currentImageIndex >= 0 && currentImageIndex < psgArray.count {
                if psgMemo == psgArray[currentImageIndex].memo &&
                    psgCheckResult == psgArray[currentImageIndex].psg_chk_res {
                    return false
                }
                else {
                    return true
                }
            }
            else {
                return false
            }
        }
    }

    var isDisplayMemo:Bool = true

    @IBAction func didTapSaveButton(_ sender: Any) {
        if isKeyboardShown {
            view.endEditing(true)
        }
        execSave()
    }
    
    @IBAction func psgPassTapped(_ sender: Any) {
        psgCheckResult = (psgCheckResult == 0) ? -1 : 0
    }
    
    @IBAction func psgFailTapped(_ sender: Any) {
        psgCheckResult = (psgCheckResult == 1) ? -1 : 1
    }
    

    //===============================================================================
    // 무한 루프용 변수
    //-------------------------------------------------------------------------------
    var autoUpload = UploadThread()

    
    //===============================================================================
    // 에러 처리
    //-------------------------------------------------------------------------------
    var errorMessage: String = "Error~"

    
    //===============================================================================
    // 오브젝트 기본 속성
    //-------------------------------------------------------------------------------

    // color
    // ------------------------------------------------------------------------------
    let defaultCellBackgroundColor = UIColor.white
    let defaultCellTextColor = UIColor.black
    let selectedCellBackgroundColor = UIColor.orange
    let selectedCellTextColor = UIColor.white
    var befTintColor:UIColor = GetTintColor()

    
//    // 디렉토리 및 Path
//    // ------------------------------------------------------------------------------
//    let sourceImageDirectoryName = "SourceImage"
//    let sourceVideoDirectoryName = "SourceVideo"        // 20200818
//    let markedImageDirectoryName = "MarkedImage"
//    var sourceImageDirectoryURL:URL?
//    var sourceVideoDirectoryURL:URL?                 // 20200818
//    var markedImageDirectoryURL:URL?
//    let markedImageNameSuffix = "_CHECK"
//
    // 이미지 파일 url 변수 정의
    // ------------------------------------------------------------------------------
    var savedMarkedImageUrlPath:String?
    var savedJsonFileUrlPath:String?                    // 20200828
    var savedSourceImageUrlPath:String?

    // 이미지 설정
    // ------------------------------------------------------------------------------
    var playImage: UIImage? = UIImage(systemName: "play.fill")
    var pauseImage: UIImage? = UIImage(systemName: "pause.fill")
    var forwardImage: UIImage? = UIImage(systemName: "forward.fill")
    var backwardImage: UIImage? = UIImage(systemName: "backward.fill")
    var forwardEndImage: UIImage? = UIImage(systemName: "forward.end.fill")
    var backwardEndImage: UIImage? = UIImage(systemName: "backward.end.fill")
    var checkedBoxImage: UIImage?
    var uncheckedBoxImage: UIImage?
    var radioOnImage: UIImage?
    var radioOffImage: UIImage?


    // 키보드 표시 여부
    var isKeyboardShown:Bool = false
    // 키보드가 표시된 상태에서 이벤트가 선택된 경우에는 이벤트의 메모가 firstResponder가 되도록 하기 위하여~~
    var shouldKeyboardShown:Bool = false
    var keyboardBeginType: KeyboardBeginType = .none

    enum KeyboardBeginType {
        case psg
        case event
        case abnormal
        case none
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        p("------------------------------------------- didReceiveMemoryWarning is called.")
    }
    
    
}
