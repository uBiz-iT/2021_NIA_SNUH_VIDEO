//
//  NavigationTitle.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/10.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    func setTitle() {
        
        self.title = "수면 영상 검수 작업"
        
        let total = psgList.count
        let done = psgList.doneImages().count

        if isManager {
            if isLogin {
                if total > 0 && currentImageIndex >= 0 {
                    self.title = String(format: "수면 영상 관리자 모드 [ %@, %@, %d개 - %@ ]", LoginID, WorkingProjectCode, total, psgArray[currentImageIndex].id! )
                }
            }
        }
        else {
            if isLogin {
                if total > 0 && currentImageIndex >= 0 {
                    let value = Float(done) / Float(total)
                    self.title = String(format: "수면 영상 검수 작업 [ %@, %@, %4.1f%% (%d/%d) - %@ ]", LoginID, WorkingProjectCode, value * 100, done, total, psgArray[currentImageIndex].id! )
                }
            }
        }
    }
    
    func naviBarBlinkRunLoop() {
        
        self.naviBarBlinkRunning = true
        
        while (naviBarBlinkEndless) {

            if naviBarColor != UIColor.white {
                naviBarColor = UIColor.white
            }
            else {
                naviBarColor = UIColor.yellow
            }

            DispatchQueue.main.async {
                UIView.animate(withDuration: 0.25) {
                    self.navigationController?.navigationBar.barTintColor = self.naviBarColor
                    self.navigationController?.navigationBar.layoutIfNeeded()
                }
            }
            
            Thread.sleep(forTimeInterval: 0.5)
        }
    }
    
    func naviBarBlinkStart() {
        
        if (naviBarBlinkRunning) {
            p("이미 title blink 프로세스가 동작중입니다.")
            return
        }
        
        DispatchQueue.global(qos: .background).async {
            p("title Blink Start")
            self.naviBarBlinkEndless = true
            self.naviBarBlinkRunLoop()
            DispatchQueue.main.async {
                p("title blink Stop")
                self.naviBarBlinkRunning = false
            }
        }
    }
    
    func naviBarBlinkStop() {
        if (!naviBarBlinkRunning) {
            p("이미 title blink 프로세스가 정지 상태입니다.")
            return
        }
        naviBarBlinkEndless = false
    }
}
