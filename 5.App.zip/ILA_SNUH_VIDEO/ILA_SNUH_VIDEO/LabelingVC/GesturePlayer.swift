//
//  PlayerRegion.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import UIKit.UIGestureRecognizerSubclass


extension LabelingVC {

    func registerGesturePlayerRegion() {

        // ----------------------------------------------
        // player용 -> 재생/정지로 사용
        // ----------------------------------------------
        tapGesturePlayer = UITapGestureRecognizer(target: self, action: #selector(playerRegionTapped(_:)))
        tapGesturePlayer!.numberOfTouchesRequired = 1
        tapGesturePlayer!.numberOfTapsRequired = 1
        playerRegionView.addGestureRecognizer(tapGesturePlayer!)

        // ----------------------------------------------
        // player용 -> 크기 원상태로 돌림
        // ----------------------------------------------
        tapGesture2Player = UITapGestureRecognizer(target: self, action: #selector(playerScrollTapped2(_:)))
        tapGesture2Player!.numberOfTouchesRequired = 2
        tapGesture2Player!.numberOfTapsRequired = 1
        playerScroll.addGestureRecognizer(tapGesture2Player!)
        
        // ----------------------------------------------
        // player용 -> 등록만 하고 사용하지 않음
        // ----------------------------------------------
        doubleTapGesturePlayer = UIShortTapGestureRecognizer(target: self, action: #selector(playerRegionDoubleTapped(_:)))
        doubleTapGesturePlayer!.numberOfTouchesRequired = 1
        doubleTapGesturePlayer!.numberOfTapsRequired = 2
        playerRegionView.addGestureRecognizer(doubleTapGesturePlayer!)

        // 더블 탭 fail일 경우 싱글 탭 적용, 이렇게 하지 않으면 싱글 및 더블 탭 모두 이벤트 발생
        tapGesturePlayer!.require(toFail: doubleTapGesturePlayer!)

        //---------------------------------------------------------------------
        // 재생 시간 좌우 이동으로 사용
        //---------------------------------------------------------------------
        playerViewPanGesture = UIPanGestureRecognizer(target: self, action: #selector(playerRegionPanned(_:)))
        playerViewPanGesture!.minimumNumberOfTouches = 1
        playerViewPanGesture!.maximumNumberOfTouches = 1
        playerView.addGestureRecognizer(playerViewPanGesture!)
        

    }
    
    //--------------------------------------------------------------------------------
    // player region panning
    //--------------------------------------------------------------------------------
    @objc func playerRegionPanned(_ gesture: UIPanGestureRecognizer) {
        
        struct Temp { static var numberOfTouchesWhenBegan = 0 }

        if isDrawMode {
            if (gesture.state == .began) {
                Temp.numberOfTouchesWhenBegan = gesture.numberOfTouches
                drawLineBegan(gesture: gesture)
            }
            if (gesture.state == .changed) {
                drawLineMoved(gesture: gesture)
            }
            if (gesture.state == .ended) {
                drawLineEnded(gesture: gesture)
            }
        }
        else {
            let point = gesture.location(in: playerView)
            
            if point.y > (playerView.frame.height - 100) {
                return
            }

            if (gesture.state == .began) {
                befPlayerViewPanPoint = point

                // 오토 스크롤 on하기 위함
                autoScrollTimeCount = autoScrollTimeOut
                autoEventScrollTimeCount = autoEventScrollTimeOut
                isTimeSliderValueChanging = true
                if isVideoPlaying {
                    if let vp = videoPlayer {
                        vp.pause()
                    }
                }
                setCurrentTime(seconds: currentTime.seconds, method: .videoRegionBegin)
            }
            else if (gesture.state == .changed) {
                if let bef = befPlayerViewPanPoint {
                    let gap = Float(point.x - bef.x) / 4
                    setCurrentTime(seconds: currentTime.seconds + Double(gap), method: .videoRegionMoved)
                }
                befPlayerViewPanPoint = point
            }
            else if (gesture.state == .ended) {
                if isVideoPlaying {
                    if let vp = videoPlayer {
                        vp.play()
                    }
                }
                isTimeSliderValueChanging = false
                setCurrentTime(seconds: currentTime.seconds, method: .videoRegionEnd)
            }
        }
    }
    
    //--------------------------------------------------------------------------------
    // playerRegionView 1 touch 1 tap
    //--------------------------------------------------------------------------------
    @objc func playerRegionTapped(_ gesture: UITapGestureRecognizer) {
        
        if isKeyboardShown {
            view.endEditing(true)
            return
        }
        
        if isDrawMode {
            drawLineTapped(gesture: gesture)
        }
        else {
            let point = gesture.location(in: playerView)
            
            if point.y > (playerView.frame.height - 120) || point.y < (playerView.frame.origin.y + 120) {
                return
            }
            togglePlay()
        }
    }
    
    //--------------------------------------------------------------------------------
    // playerRegionView 1 touch 2 tap
    //--------------------------------------------------------------------------------
    @objc func playerRegionDoubleTapped(_ gesture: UITapGestureRecognizer) {
        
        let point = gesture.location(in: playerRegionView)
        let quadOfWidth = playerScroll.frame.width / 3
        
        // 위치가 폭을 기준으로 폭 크기의 3분의 1 좌측이면 맨 처음으로 이동하고
        if point.x < quadOfWidth {
            // fast backward
        }
        // 폭 크기의 4분의 3보다 큰 위치를 탭했으면 맨 우측 이미지로 이동
        else if point.x > (quadOfWidth * 2) {
            // fast forward
        }
        else {
            // play/pouse
            
        }

    }

    //--------------------------------------------------------------------------------
    // player 영역 2 touch 1 tap
    //--------------------------------------------------------------------------------
    @objc func playerScrollTapped2(_ gesture: UITapGestureRecognizer) {
        playerScroll.zoomScale = 1
    }
    
    @objc func playerViewSwiped(_ gesture: UISwipeGestureRecognizer) -> Void {

        if gesture.numberOfTouches == 1 {
            if gesture.direction == UISwipeGestureRecognizer.Direction.right {
                jumpBackward()
            }
            else if gesture.direction == UISwipeGestureRecognizer.Direction.left {
                jumpForward()
            }
        }
    }
    
    
}
