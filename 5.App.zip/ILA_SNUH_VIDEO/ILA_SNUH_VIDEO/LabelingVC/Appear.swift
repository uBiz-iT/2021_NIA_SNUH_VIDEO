//
//  Appear.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        SetOrientation()
        
        if (displayMenuView) {
            if (isLogin && isWorking) {
            }
            else {
                if (!isFromProjectMenu) {
                    didTapMenu(menuButton)
                }
                displayMenuView = false
            }
        }

        checkHiddenView()
        
        if WorkingProjectCode > " " {
            sourceVideoDirectoryURL = sourceVideoDirectoryParentURL?.appendingPathComponent(WorkingProjectCode)
        }

    }
    
    // ---------------------------------------------------------------------
    // viewDidAppear
    // ---------------------------------------------------------------------
    override func viewDidAppear(_ animated: Bool) {

        super.viewDidAppear(animated)

        // ------------------------------------------------
        // 플레이어 20200320
        // ------------------------------------------------
        if isVideoPlaying {
            if let vp = videoPlayer {
                vp.play()
            }
        }

        // 이미지 파일 자동 업로드                            // 20200830 세로 가로 모드 체크 전으로 이동
        //autoUpload.start()
        //videoDownStart()
        
        // 틴트 색상이 변경되었으면 다시 그리기 위해서.. tableview와 collection 뷰의 선택된 항목은 tint색상으로 하기 때문임
        if (befTintColor != GetTintColor()) {
            collectionViewMainImage.reloadData()
            collectionViewThumbnail.reloadData()
            eventTV.reloadData()
            befTintColor = GetTintColor()
        }
        
        if (beforeOrientation != OrientationValue) {
            beforeOrientation = OrientationValue
            abnormalView.center = view.center
            
            if !FirstDidBecomeActive {                  // 20200830
                return
            }
        }

        // ------------------------------------------------
        // 스피너 시작
        // ------------------------------------------------
        let child = SpinnerViewController()
        child.view.frame = self.view.frame
        self.view.addSubview(child.view)
        child.didMove(toParent: self)
        
        DoEvents(f: 0.01)     // 20200827
        
        if (FirstDidBecomeActive) {
            checkLoginOutInfo(newLogin: isLogin)
            //drawCompareLine()
            drawTimeLine()
            drawBeginLine()
            drawEndLine()
            FirstDidBecomeActive = false
        }
        
        if (isFromLoginMenu) {
            p("---------------------------------------------------------- isFromLoginMenu")
            if (isNewLogined) {
                WorkingImageIndex = 0
                WorkingSubImageIndex = 0
                WorkingEventIndex = 0
                LabelList.arrayLabelInfo.removeAll()
                initLabelingSettingItem(removeVideoFile: !IS_SAME_PROJECT)
            }
            checkLoginOutInfo(newLogin: isNewLogined)
            isFromLoginMenu = false
        }
        else if (isFromProjectMenu) {
            p("---------------------------------------------------------- isFromProjectMenu")
            if (!isLogin) {
                checkLoginOutInfo(newLogin: false, goLogin: true)
            }
            else {
                if (isNewProjectBegan) {
                    WorkingImageIndex = 0
                    WorkingSubImageIndex = 0
                    WorkingEventIndex = 0
                    LabelList.arrayLabelInfo.removeAll()
                    myImageCache.removeAll()    // 프로젝트가 변경되면 캐시 이미지 삭제 20201210
                    initLabelingSettingItem(removeVideoFile: !IS_SAME_PROJECT)
                }
                checkWorkingProjectInfo(newProject: isNewProjectBegan)
                isFromProjectMenu = false
            }
        }

        // ------------------------------------------------
        // 스피너 종료
        // ------------------------------------------------
        child.willMove(toParent: nil)
        child.view.removeFromSuperview()
        child.removeFromParent()

        if IsVersionUp {
            alertVersionMessage()
        }
    }
    
    // ---------------------------------------------------------------------
    // viewWillDisappear
    // ---------------------------------------------------------------------
    override func viewWillDisappear(_ animated: Bool) {
        AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.all)
    }
    
    
    // ---------------------------------------------------------------------
    // viewDidDisappear
    // ---------------------------------------------------------------------
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        if isVideoPlaying {
            stopPlay()
            DoEvents(f: 0.1)
        }

        eventKindView.isHidden = true
        
        //autoUpload.stop()
    }
    
}
