//
//  AbnormalView.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import UIKit.UIGestureRecognizerSubclass

extension LabelingVC {
    
    func registerGestureAbnormalView() {
        
        //---------------------------------------------------------------------
        // panning gesture 설정(이상행동 검출 뷰 위치 이동)
        //---------------------------------------------------------------------
        let abnormalViewPanGesture = UIPanGestureRecognizer(target: self, action: #selector(abnormalViewPanned(_:)))
        abnormalView.addGestureRecognizer(abnormalViewPanGesture)

    }
    

    @objc func abnormalViewPanned(_ gesture: UIPanGestureRecognizer) {
        
        let point = gesture.location(in: view)
        
        if (gesture.state == .began) {
            befAbnormalViewPanPoint = point
        }
        else if (gesture.state == .changed) {
            // 오른쪽으로
            let gapX = point.x - befAbnormalViewPanPoint!.x
            let gapY = point.y - befAbnormalViewPanPoint!.y

            abnormalView.frame.origin.x = abnormalView.frame.origin.x + gapX
            abnormalView.frame.origin.y = abnormalView.frame.origin.y + gapY
            befAbnormalViewPanPoint = point
        }
        else if (gesture.state == .ended) {
        }
    }

}
