//
//  DiagnosisRegion.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import UIKit.UIGestureRecognizerSubclass


extension LabelingVC {

    func registerGestureDiagnosisView() {

        // ----------------------------------------------
        // 진단정보 표시 뷰 터치
        // ----------------------------------------------
        let diagViewTapGesture:UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(diagViewTapped(_:)))
        diagViewTapGesture.numberOfTouchesRequired = 1
        diagViewTapGesture.numberOfTapsRequired = 1
        diagDisplayView.addGestureRecognizer(diagViewTapGesture)
        

    }
    
    @objc func diagViewTapped(_ gesture: UITapGestureRecognizer) {
        diagDisplayExtendOk = !diagDisplayExtendOk
    }
    
}
