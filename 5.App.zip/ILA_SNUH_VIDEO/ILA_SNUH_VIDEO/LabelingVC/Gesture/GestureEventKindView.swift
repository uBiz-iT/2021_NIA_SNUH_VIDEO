//
//  GestureEventKindView.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/07/18.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import UIKit.UIGestureRecognizerSubclass

extension LabelingVC {

    func registerGestureEventKindView() {
        
        //---------------------------------------------------------------------
        // panning gesture 설정(이벤트 타입, 종류 선택 뷰 위치 이동)
        //---------------------------------------------------------------------
        let eventKindViewPanGesture = UIPanGestureRecognizer(target: self, action: #selector(eventKindViewPanned(_:)))
        eventKindView.addGestureRecognizer(eventKindViewPanGesture)

    }

    @objc func eventKindViewPanned(_ gesture: UIPanGestureRecognizer) {
        
        let point = gesture.location(in: view)
        
        if (gesture.state == .began) {
            befEventKindViewPanPoint = point
        }
        else if (gesture.state == .changed) {
            // 오른쪽으로
            let gapX = point.x - befEventKindViewPanPoint!.x
            let gapY = point.y - befEventKindViewPanPoint!.y

            eventKindView.frame.origin.x = eventKindView.frame.origin.x + gapX
            eventKindView.frame.origin.y = eventKindView.frame.origin.y + gapY
            befEventKindViewPanPoint = point
        }
        else if (gesture.state == .ended) {
        }
    }

}
