//
//  MainVC_Gesture.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 06/11/2018.
//  Copyright © 2018 uBiz Information Technology. All rights reserved.
//

import UIKit
import UIKit.UIGestureRecognizerSubclass


extension LabelingVC {
    
    func registerGestureAll() {
        setScrollViewPropertyForImage()
        registerGesturePlayerRegion()
        registerGestureAbnormalView()
        //registerGestureEventKindView()
        registerGestureDiagnosisView()
        registerGestureImageRegion()
    }
    
}
