//
//  LabelingVC_Save.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 03/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {

    struct EventResult: Codable {
        var seq:Int?
        var res:Int?
        var memo:String?
    }
    
    struct EventResultAll: Codable {
        var seq:Int?
        var name:String?
        var res:Int?
        var begDT:String?
        var endDT:String?
        var begEpo:Int?
        var endEpo:Int?
        var begSec:Int?
        var endSec:Int?
        var elapsed:Int?
        var memo:String?
        var cud:String?
    }
    
    struct RequestSaveLabelingResult: Codable {
        var proc_name: String?
        var project_cd: String?
        var user_id: String?
        var psg_id: String?
        var psg_chk_res: Int?
        var memo: String?
        var all_flag: Int?  // 0 : All Ok, 1: All NG, 9:each
        var event: [EventResultAll] = []
        var new_event: [EventResultAll] = []
    }
    
    struct CheckResult4Json: Codable {
        var project_cd: String?
        var user_id: String?
        var psg_id: String?
        var psg_chk_res: Int?
        var memo: String?
        var event: [EventResultAll] = []
    }
    
    // -----------------------------------------------------------------------------
    // 실제 라벨링 결과 저장 20200819. didTapSaveButton에서 빼서 함수로 변경함
    // -----------------------------------------------------------------------------
    func execSave() {
        // save하기 전에 원래대로 필터가 없는 원본이미지를 매핑
        EditingImage.image = originalImage

        if isDataChanged == false {
            self.view.showToast(toastMessage: "변경된 사항이 없습니다", duration: 0.6)
            return
        }
        
        saveLabelingResultAndMark()
    }
    
    // --------------------------------------------------------------------------------------
    // save 버튼이 클릭되었을때 라벨링 결과와 마킹된 마크 이미지들을 저장
    // --------------------------------------------------------------------------------------
    func saveLabelingResultAndMark() {
        
        ScrollImage.zoomScale = 1.0             // 20200901

        // ------------------------------------------------
        // 스피너 시작
        // ------------------------------------------------
        let child = SpinnerViewController()
        child.view.frame = view.frame
        view.addSubview(child.view)
        child.didMove(toParent: self)

        DoEvents(f:0.01)        // 20200827
        
        let (success, code) = saveLabelingResult()
        if (success) {

            eventCheckAction(.save)
            setProgressValue()
            
            let imageId = psgArray[currentImageIndex].id!
            
            // 마지막에 저장했던 이미지를 유저디폴트에 저장
            UserDefaults.standard.set(imageId, forKey: DefaultKey_LastLabelingImageId)
            LastLabelingImageId = imageId
            
            // 20200820
//            if (selectedSubImageRowNum >= 0) {
//                if let subImageId = subImageArray[selectedSubImageRowNum].sub_image_id {
//                    UserDefaults.standard.set(subImageId, forKey: DefaultKey_LastLabelingSubImageId)
//                    LastLabelingSubImageId = subImageId
//                }
//            }

            setEventResultText(false)
            
            self.view.showToast(toastMessage: "\n    저장 완료    \u{200c}\n", duration: 0.6) // \u{200c} 문자열 뒤에 있는 스페이스가 trimming되는 것 방지
                
            if IsVersionUp {
                alertVersionMessage()
            }
            
        }
        else {
            handlingDbError(code: code!, self)
//            if (LastURLErrorMessage != "") {
//                let alertProgressNoAction = UIAlertController(title: "메시지 확인", message: "\n\(LastURLErrorMessage)\n\n", preferredStyle: .alert)
//                let otherAction = UIAlertAction(title: "확인", style: .default, handler: { action in
//                    alertProgressNoAction.dismiss(animated: true, completion: nil)
//                })
//                alertProgressNoAction.addAction(otherAction)
//                self.present(alertProgressNoAction, animated: false, completion: nil)
//            }
        }
        
        // ------------------------------------------------
        // 스피너 종료
        // ------------------------------------------------
        child.willMove(toParent: nil)
        child.view.removeFromSuperview()
        child.removeFromParent()
        
    }
    
    // --------------------------------------------------------------------------------------
    // 이벤트 정보 전체를 OK/NG 처리할 때 사용
    // --------------------------------------------------------------------------------------
    func checkAllEvent(_ res:Int, _ reloadView:Bool = false) {
        if eventArray.count > 0 {
            for event in eventArray {
                event.isChecked = true
                event.checkResult = res
            }
        }
        if (reloadView) {
            eventTV.reloadData()
        }
    }
    

    
}
