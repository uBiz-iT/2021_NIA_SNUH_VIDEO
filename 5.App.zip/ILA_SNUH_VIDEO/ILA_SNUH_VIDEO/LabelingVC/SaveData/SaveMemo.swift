//
//  MemoHandler.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/10.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC: UITextViewDelegate {

    // 20201205
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if (textView.tag == 0) {
            if text == "\n" {
                textView.resignFirstResponder()
                return false
            }
            let newText = (textView.text as NSString).replacingCharacters(in: range, with: text)
            let numberOfChars = newText.count
            return numberOfChars < 100
        }
        return true
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        // psg memo 입력 시작시
        if (textView.tag == 0) {

            keyboardBeginType = .psg
            p("memoView textViewDidBeginEditing : \(textView.tag), \(textView.text!), \(keyboardBeginType)")

            if psgMemo == "" {
                textView.text = nil
                textView.textColor = UIColor.black
            }
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        // psg memo 입력 종료시
        if (textView.tag == 0) {

            keyboardBeginType = .none
            p("memoView textViewDidEndEditing : \(textView.tag), \(textView.text!), \(keyboardBeginType)")

            textView.text = textView.text.trimmingCharacters(in: .whitespaces)
            psgMemo = textView.text
        }
    }
    
    func textViewDidChangeSelection(_ textView: UITextView) {
    }
    
   
    func setMemoViewSize() {

        var fixedWidth:CGFloat = 250.0
        let fixedHeight:CGFloat = 95.0
        let minWidth:CGFloat = 50.0

        if (!memoView.isFirstResponder) {
            var newSize = memoView.sizeThatFits(CGSize(width: fixedWidth, height: fixedHeight))
            memoView.frame.size = CGSize(width: max(newSize.width, fixedWidth), height: newSize.height)

            // 오토 사이즈 on하여 크기 재조정
            memoView.translatesAutoresizingMaskIntoConstraints = true
            memoView.sizeToFit()
            memoView.isScrollEnabled = false

            memoView.translatesAutoresizingMaskIntoConstraints = false
            memoView.isScrollEnabled = true

            fixedWidth = max(memoView.frame.width, minWidth)
            
            UIView.animate(withDuration: 0.1, animations: {
                self.memoView.frame.origin.x = self.memoImage.frame.origin.x - fixedWidth - 5
                newSize = self.memoView.sizeThatFits(CGSize(width: fixedWidth, height: CGFloat.greatestFiniteMagnitude))
                self.memoView.frame.size = CGSize(width: max(newSize.width, fixedWidth), height: min(newSize.height, fixedHeight))
            })
        }
        else {
            memoView.translatesAutoresizingMaskIntoConstraints = false
            if (!memoView.isScrollEnabled) {
                memoView.isScrollEnabled = true
            }
            UIView.animate(withDuration: 0.1, animations: {
                self.memoView.frame.origin.x = self.memoImage.frame.origin.x - fixedWidth - 5
                self.memoView.frame.size = CGSize(width: fixedWidth, height: fixedHeight)
            })
        }
        
    }
    
    // 20201205
//    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
//        if (textView.tag == 0) {
//            let newText = (textView.text as NSString).replacingCharacters(in: range, with: text)
//            let numberOfChars = newText.count
//            return numberOfChars < 200
//        }
//        return true
//    }
//
//    func textViewDidBeginEditing(_ textView: UITextView) {
//        if (textView.tag == 0) {
//            memoView.alpha = 1.0
//            setMemoViewSize()
//        }
//    }
//
//    func textViewDidEndEditing(_ textView: UITextView) {
//        if (textView.tag == 0) {
//            memoView.alpha = 0.7
//            memoView.text = memoView.text.trimmingCharacters(in: .whitespaces)
//            setMemoViewSize()
//        }
//    }
//
//    func textViewDidChangeSelection(_ textView: UITextView) {
//        if (textView.tag == 0) {
//            setMemoViewSize()
//        }
//    }
//
//    func setMemoViewSize() {
//
//        var fixedWidth:CGFloat = 250.0
//        let fixedHeight:CGFloat = 95.0
//        let minWidth:CGFloat = 50.0
//
//        if (!memoView.isFirstResponder) {
//            var newSize = memoView.sizeThatFits(CGSize(width: fixedWidth, height: fixedHeight))
//            memoView.frame.size = CGSize(width: max(newSize.width, fixedWidth), height: newSize.height)
//
//            // 오토 사이즈 on하여 크기 재조정
//            memoView.translatesAutoresizingMaskIntoConstraints = true
//            memoView.sizeToFit()
//            memoView.isScrollEnabled = false
//
//            memoView.translatesAutoresizingMaskIntoConstraints = false
//            memoView.isScrollEnabled = true
//
//            fixedWidth = max(memoView.frame.width, minWidth)
//
//            UIView.animate(withDuration: 0.1, animations: {
//                self.memoView.frame.origin.x = self.memoImage.frame.origin.x - fixedWidth - 5
//                newSize = self.memoView.sizeThatFits(CGSize(width: fixedWidth, height: CGFloat.greatestFiniteMagnitude))
//                self.memoView.frame.size = CGSize(width: max(newSize.width, fixedWidth), height: min(newSize.height, fixedHeight))
//            })
//        }
//        else {
//            memoView.translatesAutoresizingMaskIntoConstraints = false
//            if (!memoView.isScrollEnabled) {
//                memoView.isScrollEnabled = true
//            }
//            UIView.animate(withDuration: 0.1, animations: {
//                self.memoView.frame.origin.x = self.memoImage.frame.origin.x - fixedWidth - 5
//                self.memoView.frame.size = CGSize(width: fixedWidth, height: fixedHeight)
//            })
//        }
//
//    }
}
