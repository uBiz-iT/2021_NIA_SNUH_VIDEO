//
//  SaveInit.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/14.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {

    func viewDidLoad_Save() {
        
        psgPassButton.imageView?.tintColor = .systemBlue
        psgFailButton.imageView?.tintColor = .systemRed
        
        psgMemo = ""
        memoView.layer.borderColor = UIColor.systemGray.cgColor
        memoView.layer.borderWidth = 1.0;
        memoView.layer.cornerRadius = 3.0;
        memoView.layer.backgroundColor = UIColor.white.cgColor
        psgCheckResult = -1
        
        saveButton.isEnabled = false
        buttonRadius(saveButton)
    }
    
    func setSaveValue(reset:Bool, index:Int = 0) {
        if reset {
            psgMemo = ""
            psgCheckResult = -1
        }
        else {
            psgMemo = psgArray[index].memo
            psgCheckResult = psgArray[index].psg_chk_res
        }
    }
}
