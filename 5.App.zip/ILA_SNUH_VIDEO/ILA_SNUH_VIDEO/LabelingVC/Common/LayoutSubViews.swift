//
//  LayoutSubViews.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    // ---------------------------------------------------------------------
    // viewWillLayoutSubviews
    // ---------------------------------------------------------------------
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        adjustLabelListViewLocation()
        
    }
    
    // ---------------------------------------------------------------------
    // viewDidLayoutSubviews
    // ---------------------------------------------------------------------
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        eventTV.reloadData()

        view.layoutIfNeeded()
        //redrawCompareLine()
        redrawTimeLine()
        redrawBeginLine()
        redrawEndLine()
        
        // 20201118  y축 레이블 처리. 항상 zoom을 초기화한후 수행해야 정확한 위치를 계산할 수 있음
        
        let beforeZoomScale = ScrollImage.zoomScale
        let beforeContentOffset = ScrollImage.contentOffset
        let beforePlayerZoomScale = playerScroll.zoomScale
        let beforePlayerContentOffset = playerScroll.contentOffset

        ScrollImage.zoomScale = 1.0
        playerScroll.zoomScale = 1.0
        
        graphLabel.initialize(ScrollImage, EditingImage)
        
        // 원래의 zoom 크기와 offset으로 원복
        playerScroll.zoomScale = beforePlayerZoomScale
        playerScroll.contentOffset = beforePlayerContentOffset
        ScrollImage.zoomScale = beforeZoomScale
        ScrollImage.contentOffset = beforeContentOffset
        
    }
}
