//
//  LabelingVC_Runloop.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/05/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {

    // -----------------------------------------------------------------------------------------------
    // 파일이 다운로드 완료되었을 때 그 파일이 선택된 PSG인 경우 화면에 이것 저것 표시하기 위하여 무한 감시
    // -----------------------------------------------------------------------------------------------
    func runLoopStart() {
        DispatchQueue.global(qos: .background).async {
            self.runLoop()
        }
    }
    
    fileprivate func runLoop() {
        
        while (true) {
            
            DispatchQueue.main.async { [self] in

                // 이미지 tar 파일용 인디케이터가 동작중이면 다운로드 중임...
                // -------------------------------------------------------------------
                if (downloadingTarIndicator.isAnimating) {
                    if (currentImageIndex >= 0 && currentImageIndex < psgArray.count) {
                        // 다운로드 완료되었으면 할일 하러 감
                        if (psgArray[currentImageIndex].tarDownloadFlag == .completed) {
                            actionIfCurrentImageDownloadComplete(fileType: .tar)
                        }
                    }
                }

                // 비디오 다운로드용 인디케이터가 동작중이면 다운로드 중임...
                // -------------------------------------------------------------------
                if (downloadingIndicator.isAnimating) {
                    if (currentImageIndex >= 0 && currentImageIndex < psgArray.count) {
                        // 다운로드 완료되었으면 할일 하러 감
                        if (psgArray[currentImageIndex].videoDownloadFlag == .completed) {
                            actionIfCurrentImageDownloadComplete(fileType: .mp4)
                        }
                    }
                }
                
                // snapshot 스크롤을 하면 0으로 reset됨. 5초이상 스크롤링이 없으면 snapshot 컬렉션 뷰에 현재 재생위치로 자동 이동
                // 스크롤중에는 재생위치로 자동 이동 못하게 하기 위함
                // 이와 동일하게 이벤트 테이블 뷰에도 적용함
                // -------------------------------------------------------------------
                autoScrollTimeCount = autoScrollTimeCount + 1
                if autoScrollTimeCount >= autoScrollTimeOut {
                    autoScrollTimeCount = autoScrollTimeOut
                }
                
                // 이와 동일하게 이벤트 테이블 뷰에도 적용함
                // -------------------------------------------------------------------
                autoEventScrollTimeCount = autoEventScrollTimeCount + 1
                if autoEventScrollTimeCount >= autoEventScrollTimeOut {
                    autoEventScrollTimeCount = autoEventScrollTimeOut
                }
            }
            
            Thread.sleep(forTimeInterval: 0.5)
        }
    }
    
}
