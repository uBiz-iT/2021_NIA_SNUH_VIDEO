//
//  LoadData.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    // ------------------------------------------------------------------------------
    // loadData()
    // ------------------------------------------------------------------------------
    func loadData() {
        if (isWorking) {
            projectNameLabel.text = WorkingProjectName
            loadPSGList()
        }
    }
    


}
