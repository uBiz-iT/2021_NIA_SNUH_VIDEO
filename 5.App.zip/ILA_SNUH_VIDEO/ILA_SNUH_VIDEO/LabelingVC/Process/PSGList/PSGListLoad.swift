//
//  LabelingVC_Load.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 03/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {
    
    // ------------------------------------------------------------------------------
    // 해당 프로젝트에 해당하는 PSG 목록 로드
    // ------------------------------------------------------------------------------
    func loadPSGList() {
        
        resetObjectsRelatedToLabeling()

        if (!isReloadTapped) {
            currentImageIndex = -1
        }
        
        psgList.removeAll()
        
        image_last_row_num = 0
        image_count = 0

        let (success, code) = selectImageList()
        if (success) {

            if (psgList.count == 0) {
                self.view.showToast(toastMessage: "PSG 영상 데이터가 등록되어 있지 않습니다.", duration: 1.5)
                return
            }
            
            psgArray = psgList.images
            collectionViewMainImage.reloadData()
            
            setProgressValue()
            
            if (psgArray.count == 0) {
                self.view.showToast(toastMessage: "해당하는 PSG 영상 데이터가 없습니다.", duration: 1.5)
            }
            else {

                // 20201110 if 추가
                if (isReloadTapped) {
                    WorkingImageIndex = currentImageIndex
                }
                else {
                    let foundIndex = psgList.indexByImageId(imageId: LastLabelingImageId)
                    if (foundIndex >= 0) {
                        WorkingImageIndex = foundIndex
                        //WorkingImageIndex = ((foundIndex + 1) >= mainImageList.count) ? foundIndex : foundIndex + 1
                    }
                }

                currentImageIndex = WorkingImageIndex
                
                if (currentImageIndex >= 0 && currentImageIndex < psgArray.count) {
                    let indexPath = IndexPath(item: currentImageIndex, section: 0)
                    DispatchQueue.main.async {
                        self.collectionViewMainImage.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: false)
                        self.view.layoutIfNeeded()
                        //DoEvents(f: 0.01)
                    }
                    
                    loadVideoImageEvent(index: currentImageIndex)    // 이미지를 가져옴
                }
                else {
                    p("Array Index Error : loadImageList() number \(currentImageIndex)")
                }
            }
        }
        else {
            handlingDbError(code: code!, self)
//            if (needToLogin(errno: code!)) {
//                DispatchQueue.main.async() {
//                    isLogin = false
//                    self.performSegue(withIdentifier: "segueLoginOut", sender: nil)
//                }
//            }
//            else {
//                if (LastURLErrorMessage.trimmingCharacters(in: [" "]) != "") {
//                    let alertProgressNoAction = UIAlertController(title: "메시지 확인", message: "\n\(LastURLErrorMessage)\n\n", preferredStyle: .alert)
//                    let otherAction = UIAlertAction(title: "확인", style: .default, handler: { action in
//                        alertProgressNoAction.dismiss(animated: true, completion: nil)
//                    })
//                    alertProgressNoAction.addAction(otherAction)
//                    self.present(alertProgressNoAction, animated: false, completion: nil)
//                }
//            }
        }
        checkHiddenView()
        
    }
 
    // ------------------------------------------------------------------------------
    // 해당하는 인덱스에 해당하는 비디오, 이미지목록, 이벤트 정보를 불러온다
    // ------------------------------------------------------------------------------
    func loadVideoImageEvent(index:Int) {
        
        EditingImage.image = nil
        EditingImage.layoutIfNeeded()
        
        // 동영상 로드
        // ----------------------------------------
        loadVideo(psgIndex: index)

        // 이미지 Tar 파일 체크하여 화면에 관련 정보 표시
        // ----------------------------------------
        checkTarFileStatus(psgIndex: index)

        // ------------------------------------------------
        // 현재 보고 있는 PSG 정보의 다음 PSG 정보에 대한 파일을 다운로드 함
        // ------------------------------------------------
        downloadNextPSGFiles(psgIndex: index)

        setDiagValue(reset: false, index: currentImageIndex)
        setSaveValue(reset: false, index: currentImageIndex)

        resetSubImageList()
        
        let imageId = psgArray[index].id
        
        // ------------------------------------------------
        // 스피너 시작
        // ------------------------------------------------
        let child = SpinnerViewController()
        child.view.frame = view.frame
        view.addSubview(child.view)
        child.didMove(toParent: self)
        DoEvents(f: 0.01)
        
        // 이벤트 먼저 읽어 오고 이미지 읽어오자
        let success = loadEventList()     // 이벤트 목록 불러오기
        DoEvents(f: 0.01)
        
        if let ok = success, ok == false {
            child.willMove(toParent: nil)
            child.view.removeFromSuperview()
            child.removeFromParent()
            return
        }
        
        loadSubImageList()  // 이미지 목록 불러오기

        // ------------------------------------------------
        // 스피너 종료
        // ------------------------------------------------
        child.willMove(toParent: nil)
        child.view.removeFromSuperview()
        child.removeFromParent()

        if (selectedSubImageRowNum >= 0 && selectedSubImageRowNum < subImageArray.count) {
            loadSubImageOneFromUrl(subImageInfo: subImageArray[selectedSubImageRowNum])
        }

        checkHiddenView()

        // 유저디폴트에 저장
        UserDefaults.standard.set(index, forKey: DefaultKey_ImageIndex)
        WorkingImageIndex = index
        
        // 마지막 로딩했던 이미지를 저장
        UserDefaults.standard.set(imageId, forKey: DefaultKey_ImageId)
        WorkingImageId = imageId!
        
        // 20201116 그래프 레이블 추가
        graphLabel.initialize(ScrollImage, EditingImage)
        

    }


}
