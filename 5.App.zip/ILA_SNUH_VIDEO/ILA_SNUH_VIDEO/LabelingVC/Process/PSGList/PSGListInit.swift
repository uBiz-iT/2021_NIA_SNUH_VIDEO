//
//  PSGListInit.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    func viewDidLoad_PSGList() {
        
        initPSGCollectionView()
        
    }

    // --------------------------------------------------------------------------
    // 컬렉션뷰 기본 설정
    // --------------------------------------------------------------------------
    func initPSGCollectionView() {
        collectionViewMainImage.delegate = self
        collectionViewMainImage.dataSource = self
        collectionViewMainImage.tag = 4
        
        if let layout = collectionViewMainImage.collectionViewLayout as? UICollectionViewFlowLayout {
            layout.scrollDirection = .horizontal
        }
        
        collectionViewMainImage.backgroundColor = UIColor.white
        
        imageCache.countLimit = 200
        imageCache.totalCostLimit = 0
    }
    
    func clearPSG() {
        psgList.removeAll()
        psgArray.removeAll()
        collectionViewMainImage.reloadData()
        downloadVideoProgressLabel.isHidden = true
        downloadingIndicator.isHidden = true
    }
    

}
