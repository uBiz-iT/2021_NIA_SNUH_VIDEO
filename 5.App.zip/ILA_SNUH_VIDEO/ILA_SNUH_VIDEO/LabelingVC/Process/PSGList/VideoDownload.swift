//
//  LabelingVC_VideoDownload.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/05/10.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

enum FileType {
    case mp4
    case tar
}

// download할 이미지 파일 정보
class VideoInfoToDownload {
    var isWaiting = true                // 대기중이냐
    var isDownloaded = false            // 완료되었느냐?
    var isError = false                 // 완료인데 에러가 난거냐?
    var requestUrl: URLRequest?         // 요청할 URL
    var fileUrl: URL?                   // 저장할 파일 URL
    var resumeData: Data?               // 중간에 멈춘후 재개시 사용할 것.. 지금까지 받은 데이터
    var progress: Float = 0             // 다운로드 진행률
    var downBytes: Int64 = 0            // 다운로드 완료 바이트수
    var totalBytes: Int64 = 0           // 파일 전체 바이트수
    var collectionViewIndex:Int?        // collectionview index 값 저장
    var fileType:FileType?              // 파일 종류
    var doReloadItem:Bool = true        // item을 reload 할것인지
    var psgInfo:PSGInfo!
    var task:URLSessionDownloadTask?
    
    // 백그라운드 태스크로 다운로드하는 경우에는 인터넷이 끊겼어도 그냥 대기한다. 그래서 타이머를 써서 지속적으로 받는지 체크하자.. 20210729
    var checkTimer:Timer? = nil {
        willSet {
            checkTimer?.invalidate()
        }
    }
    var lastUpdateDate:Date = Date()    // 가장 최근에 데이터를 받은 시간 20210729
}

var activeDownloads:[URL: VideoInfoToDownload] = [:]

//var VideosToDownload:[VideoInfoToDownload] = []
var VideoDownloadCheckCount:Int = 0
var VideoDownloadProgressCount:Int = 0
//var DownloadingVideo = VideoInfoToDownload()
//var VideoDownloadTask:URLSessionDownloadTask? = nil
var sameCount:Int = 0
var befProgress:Float = 0

// 다운로드 중인 태스크 취소
func videoDownPause(url:URL) {
    guard let download = activeDownloads[url] else {
      return
    }

    videoDownPause(download: download)
//    download.task?.cancel(byProducingResumeData: { resumeData in
//        guard let data = resumeData else {
//            return
//        }
//        download.resumeData = data
//        download.isWaiting = true
//    })
    
}

// 다운로드 중인 태스크 취소
func videoDownPause(download: VideoInfoToDownload) {
    download.task?.cancel(byProducingResumeData: { resumeData in

        download.isWaiting = true
        download.checkTimer = nil

        guard let data = resumeData else {
            return
        }
        download.resumeData = data
    })
    
}

func videoDownPause(psgInfo: PSGInfo, fileType: FileType) {
    if fileType == .mp4 {
        if let url = psgInfo.videoUrl {
            videoDownPause(url: url)
            psgInfo.videoDownloadFlag = .paused
        }
    }
    else {
        if let url = psgInfo.tarUrl {
            videoDownPause(url: url)
            psgInfo.tarDownloadFlag = .paused
        }
    }
}

func videoDownCancel(url:URL) {
    guard let download = activeDownloads[url] else {
        return
    }
    videoDownCancel(download: download)
}

// 다운로드 중인 태스크 취소
func videoDownCancel(download: VideoInfoToDownload) {
    download.task?.cancel(byProducingResumeData: { resumeData in
        download.checkTimer = nil
        download.isWaiting = true
        download.resumeData = nil
    })
}

func videoDownCancel(psgInfo: PSGInfo, fileType: FileType) {
    if fileType == .mp4 {
        if let url = psgInfo.videoUrl {
            videoDownCancel(url: url)
            psgInfo.videoDownloadFlag = .wait
            psgInfo.videoDownloadProgress = 0.0
            activeDownloads[url] = nil
        }
    }
    else {
        if let url = psgInfo.tarUrl {
            videoDownCancel(url: url)
            psgInfo.tarDownloadFlag = .wait
            psgInfo.tarDownloadProgress = 0.0
            activeDownloads[url] = nil
        }
    }
}

func cancelAllDownloadGlobal() {
    for (_, download) in activeDownloads {
        download.task?.cancel()
        download.checkTimer = nil
    }
    activeDownloads.removeAll()
}


// --------------------------------------------------------------------------------
// Video Download start/pause
// --------------------------------------------------------------------------------
extension LabelingVC {
    
    func videoDownRunLoop() {
        
        self.videoDownRunning = true
        
        while (videoDownEndless) {
            Thread.sleep(forTimeInterval: 1)
            printVideoDownloadList()
        }
        
        self.videoDownRunning = false
        
    }

    
    func printVideoDownloadList(_ prt:Bool = false) {
        
        var doPrint = prt
        
        VideoDownloadCheckCount += 1
        if VideoDownloadCheckCount >= 10 {
            doPrint = true
            VideoDownloadCheckCount = 0
        }
        
        if doPrint {
            p("-------- File Download Count : \(activeDownloads.count)      ---------")
            for (_, video) in activeDownloads {
                p("    isWaiting    : \(video.isWaiting)")
                p("    isDownloaded : \(video.isDownloaded)")
                p("    isError      : \(video.isError)")
                p("    progress     : \(video.progress)")
                if let reqUrl = video.requestUrl,
                   let fileUrl = video.fileUrl,
                   let colIndex = video.collectionViewIndex,
                   let task = video.task {
                    p("    requestUrl   : \(reqUrl)")
                    p("    fileUrl      : \(fileUrl.lastPathComponent)")
                    p("    psg index    : \(colIndex)")
                    p("    task         : \(task)")
                }
                if let resumeData = video.resumeData {
                    p("    resume       : \(resumeData.count)")
                }
                p("--------------------------------------------------")
            }
        }
    }
    
    func videoDownStart() {
        
        if (videoDownRunning) {
            p("이미 비디오 다운로드 프로세스가 동작중입니다.")
            return
        }
        
        let downloadQueue = DispatchQueue(label: "downloadQueue", attributes: .concurrent)
        downloadQueue.async {
            p("VideosToDownloadThread Start")
            self.videoDownEndless = true
            self.videoDownRunLoop()
            DispatchQueue.main.async {
                p("VideosToDownloadThread Stop")
                self.videoDownRunning = false
            }
        }
    }
    
    func videoStop() {
        if (!videoDownRunning) {
            p("이미 비디오 다운로드 프로세스가 정지 상태입니다.")
            return
        }
        videoDownEndless = false
    }

    // 모든 작업을 취소하고 딕셔너리에서 제거
    func cancelAllDownload() {
        for (_, download) in activeDownloads {
            download.task?.cancel()
            download.checkTimer = nil
            actionAfterCancel(download: download)
        }
        activeDownloads.removeAll()
    }

    func actionAfterCancel(download:VideoInfoToDownload) {
        
        // 진행 상태 에러 처리
        DispatchQueue.main.async { [self] in
            
            if download.fileType == .mp4 {
                download.psgInfo.videoDownloadFlag = .error
            }
            else {
                download.psgInfo.tarDownloadFlag = .error
            }

            if let index = download.collectionViewIndex,
               let imageCell = getMainCell(index: index) {
                imageCell.refreshProgress(download.fileType, isEvent: true)
            }
        }
    }

    // ------------------------------------------------------------------------
    // 다운로드 시작...
    // ------------------------------------------------------------------------
    func startDownload(download:VideoInfoToDownload) {

        if let resumeData = download.resumeData {
            p("resumeDownload resumeData : \(download.requestUrl!)")
            download.task = downloadsSession.downloadTask(withResumeData: resumeData)
        }
        else {
            p("resumeDownload requestUrl : \(download.requestUrl!)")
            download.task = downloadsSession.downloadTask(with: download.requestUrl!)
        }
        
        download.isWaiting = false
        download.isDownloaded = false
        
        if let index = download.collectionViewIndex {
            if index < psgArray.count {
                
                // 진행 상태 시작 처리
                DispatchQueue.main.async { [self] in
                    
                    if download.fileType == .mp4 {
                        download.psgInfo.videoDownloadFlag = .started
                    }
                    else {
                        download.psgInfo.tarDownloadFlag = .started
                    }

                    if let imageCell = getMainCell(index: download.collectionViewIndex!) {
                        imageCell.refreshProgress(download.fileType, isEvent: true)
                    }
                    
                }
                
            }
        }
        
        download.task?.resume()

        // 아래 두줄 추가. 다운로드하다가 인터넷 끊겼는지 체크  20210729  20210730 다시 막음. 백그라운드로 갔을 때 이상해짐...
        download.lastUpdateDate = Date()
        // download.checkTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(checkInternetDrop(timer:)), userInfo: download, repeats: true)
    }

    // 함수 만들고 사용은 안함. 20210730
    // ------------------------------------------------------------------------
    // 일정 주기마다 다운로드가 계속 잘 되고 있는지 체크하는 함수
    // 다운로드가 안되고 있는 상황이면 정지 상태로 변경
    // ------------------------------------------------------------------------
    @objc func checkInternetDrop(timer: Timer) {
        let download = timer.userInfo as! VideoInfoToDownload
        let interval = Date().timeIntervalSince(download.lastUpdateDate)
        
        p("connection check : \(download.collectionViewIndex!), \(download.fileType!), \(download.lastUpdateDate)");

        if (interval > 10) {

            p("connection dropped");
            
            // 진행 상태 일시정지 처리
            DispatchQueue.main.async { [self] in
                videoDownPause(download: download)
                if download.fileType == .mp4 {
                    download.psgInfo.videoDownloadFlag = .paused
                }
                else {
                    download.psgInfo.tarDownloadFlag = .paused
                }
                
                if let imageCell = getMainCell(index: download.collectionViewIndex!) {
                    imageCell.refreshProgress(download.fileType, isEvent: true)
                }
                
                //self.view.showToast(toastMessage: "인터넷 연결 상태 또는 서버 상태가 좋지 않습니다.\n다운로드를 중지합니다.", duration: 3.0)
            }
            
            download.checkTimer = nil
        }
    }

    // ------------------------------------------------------------------------
    // 영상 파일과 이미지 파일 다운로드 push하기
    // ------------------------------------------------------------------------
    func pushDownloadVideo(index:Int, isAutoDown:Bool = true) {
        
        let availableDiskBytes = DiskStatus.freeDiskSpaceInBytes
        p("available disk free bytes = \(availableDiskBytes)")
        
        if availableDiskBytes < 4096000000 {
            if !isAutoDown {
                self.view.showToast(toastMessage: "최소 4 GB 이상의 용량이 필요합니다.\n불필요한 파일을 삭제하시기 바랍니다.", duration: 1.5)
            }
            return
        }
        
        var isAvailableDownload = false
        
        // 저장 위치 디렉토리 생성
        if (!makeDir(fullPath: sourceVideoDirectoryURL!.path)) {
            p("didTapLoadVideoButton() makeDir sourceVideoDirectoryURL error")
        }

        // 먼저 이미지 tar 파일부터 다운로드 요청
        if let source = psgArray[index].tarFileServerPath,
           let target = psgArray[index].tarFileUrl, canDownloadStatus(psgArray[index].tarDownloadFlag)  {

            if activeDownloads.count < 4 {
                isAvailableDownload = true
            }
            else {
                if  let url = getDownloadUrl(source),
                    let _ = activeDownloads[url] {
                    isAvailableDownload = true
                }
            }
            if isAvailableDownload {
                pushDownloadList(source: source, target: target, fileType: .tar, index: index, imageInfo: psgArray[index])
            }
            else {
                toastManyDownMessage(isAutoDown: isAutoDown)
                return
            }
        }
        
        // 다음에 동영상 요청
        if let source = psgArray[index].serverLocation,
           let target = psgArray[index].videoFileUrl, canDownloadStatus(psgArray[index].videoDownloadFlag)  {
            pushDownloadList(source: source, target: target, fileType: .mp4, index: index, imageInfo: psgArray[index])
        }

    }
    
    // ------------------------------------------------------------------------
    // 다운로드 중인 파일이 많다는 메세지 보여주기
    // ------------------------------------------------------------------------
    func toastManyDownMessage(isAutoDown:Bool = true) {
        if !isAutoDown {
            self.view.showToast(toastMessage: "\n       다운로드 중인 파일이 많습니다.       \u{200c}\n나중에 시도하시기 바랍니다.\n", duration: 0.8)
        }
    }
    
    // ------------------------------------------------------------------------
    // 파일 다운로드 요청용 URL 생성하기
    // ------------------------------------------------------------------------
    func getDownloadUrl(_ fileString:String) -> URL? {

        let file = fileString as NSString

        let file_name = file.lastPathComponent
        let file_path = file.deletingLastPathComponent

        guard let encoded_file_name = file_name.addingPercentEncoding(withAllowedCharacters: .alphanumerics),
              let encoded_file_path = file_path.addingPercentEncoding(withAllowedCharacters: .alphanumerics) else {
            return nil
        }

        guard let url = URL(string: "\(ILA4ML_URL_GETVIDEO)?file_name=\(encoded_file_name)&file_path=\(encoded_file_path)&id=\(LoginID)") else {
            return nil
        }
        
        return url
    }
    
    // ------------------------------------------------------------------------
    // 다운로드 리스트에 추가하고 다운로드 시작하기
    // ------------------------------------------------------------------------
    func pushDownloadList(source fileString:String, target fileUrl:URL, fileType:FileType, index:Int, imageInfo:PSGInfo) {
    
        guard let url = getDownloadUrl(fileString)
        else { return }

        var requestUrl = URLRequest(url: url)
        requestUrl.httpShouldHandleCookies = true
        requestUrl.allHTTPHeaderFields = getHeaderFields(forURL: SESSION_URL)
        requestUrl.httpMethod = "GET"

//        var sss:String
//        if fileType == .mp4 {
//            sss = "https://ubizit.kr/psgvideo/psg0.mp4"
//        }
//        else {
//            sss = "https://ubizit.kr/psgvideo/psg1.mp4"
//        }
//        guard let url = URL(string: sss) else {
//            return
//        }
//        var requestUrl = URLRequest(url: url)
////        requestUrl.allHTTPHeaderFields = getHeaderFields(forURL: SESSION_URL)
//        requestUrl.httpMethod = "GET"

        // 기존에 저장된 파일이 혹시 있으면 삭제
        let fileManager = FileManager.default
        try? fileManager.removeItem(at: fileUrl)
        
        let download:VideoInfoToDownload
        if let alreadyDownload = activeDownloads[url] {
            download = alreadyDownload
        }
        else {
            download = VideoInfoToDownload()
            download.requestUrl = requestUrl
            download.fileUrl = fileUrl
            download.resumeData = nil
            download.progress = 0
            download.collectionViewIndex = index
            download.fileType = fileType
            download.psgInfo = imageInfo
        }
        download.isWaiting = true
        download.isDownloaded = false
        download.isError = false

        activeDownloads[url] = download

        printVideoDownloadList(true)

        if fileType == .mp4 {
            imageInfo.videoDownloadFlag = .added
            imageInfo.videoDownloadProgress = download.progress
            imageInfo.videoFileUrl = download.fileUrl
            imageInfo.videoUrl = url
        }
        else if fileType == .tar {
            imageInfo.tarDownloadFlag = .added
            imageInfo.tarDownloadProgress = download.progress
            imageInfo.tarFileUrl = download.fileUrl
            imageInfo.tarUrl = url
        }
        
        if let imageCell = getMainCell(index: index) {
            imageCell.refreshProgress(download.fileType, isEvent: true)
        }

        startDownload(download: download)
        
        return
    }
    
}

// --------------------------------------------------------------------------------
// URLSessionDownloadDelegate
// --------------------------------------------------------------------------------
extension LabelingVC : URLSessionDownloadDelegate {
    
    func checkDownloadTask(downloadTask: URLSessionDownloadTask) -> (VideoInfoToDownload?, URL?) {

        let downloads = activeDownloads.filter { $0.value.task == downloadTask }
        if downloads.count == 0 {
            p("해당하는 다운로드 태스크가 사라졌네용 Count == 0 : \(downloadTask)")
            return (nil, nil)
        }
        
        guard let first = downloads.first
        else {
            p("해당하는 다운로드 태스크가 사라졌네용 first nil : \(downloadTask)")
            return (nil, nil)
        }

        let url = first.key
        
        guard let download = activeDownloads[url]
        else {
            p("해당하는 다운로드 태스크가 사라졌네용 activeDownloads : \(downloadTask)")
            return (nil, nil)
        }
        
        return (download, url)

    }
    
    // ---------------------------------------------------
    // 다운로드 진행중
    // ---------------------------------------------------
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {

        let (down, _) = checkDownloadTask(downloadTask: downloadTask)
        
        guard let download = down
        else {
            downloadTask.cancel()
            return
        }
        
//        guard
//            let url = (activeDownloads.filter { $0.value.task == downloadTask }).first?.key,
//            let download = activeDownloads[url]
//        else {
//            p("해당하는 다운로드 태스크가 사라졌네용 : \(downloadTask)")
//            downloadTask.cancel()
//            return
//        }
        
        download.lastUpdateDate = Date()        // 가장 최근에 수신한 시간 저장  20210729
        
//        if let httpResponse = downloadTask.response as? HTTPURLResponse,
//           let fields = httpResponse.allHeaderFields as? [String: String] {
//            if download.fileType == .mp4 {
//                p("totalBytesWritten : \(httpResponse.statusCode), \(totalBytesWritten), \(totalBytesExpectedToWrite), \(fields)")
//            }
//        }
        
        //p("prog : \(totalBytesWritten) : \(totalBytesExpectedToWrite)")

        let progress = Double(totalBytesWritten) / Double(totalBytesExpectedToWrite)
        download.progress = Float(progress)
        download.downBytes = totalBytesWritten
        download.totalBytes = totalBytesExpectedToWrite
        
        DispatchQueue.main.async { [self] in
            
            if download.fileType == .mp4 {
                download.psgInfo.videoDownloadProgress = download.progress
            }
            else {
                download.psgInfo.tarDownloadProgress = download.progress
            }
            
            if downloadTask.state == .running {
                
                if let index = download.collectionViewIndex,
                   let imageCell = getMainCell(index: index) {
                    imageCell.refreshProgress(download.fileType)
                    //p("진행중인것 : \(download.fileType!)")
                }
                if let index = download.collectionViewIndex, index == currentImageIndex {
                    if download.fileType == .mp4 {
                        downloadVideoProgress.progress = download.progress
                        downloadVideoProgressLabel.text = String(format: "%4.1f%(%@/%@)", download.progress * 100, download.downBytes.withCommas(), download.totalBytes.withCommas() )
                    }
                    else {
                        downloadTarProgress.progress = download.progress
                        downloadImageProgressLabel.text = String(format: "%4.1f%(%@/%@)", download.progress * 100, download.downBytes.withCommas(), download.totalBytes.withCommas() )
                    }
                }
            }
        }

    }
    

    // ---------------------------------------------------
    // resume
    // ---------------------------------------------------
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didResumeAtOffset fileOffset: Int64, expectedTotalBytes: Int64) {

        let (down, _) = checkDownloadTask(downloadTask: downloadTask)
        
        guard let download = down
        else {
            return
        }

//        guard
//            let url = (activeDownloads.filter { $0.value.task == downloadTask }).first?.key,
//            let download = activeDownloads[url]
//        else {
//            return
//        }

        if let httpResponse = downloadTask.response as? HTTPURLResponse,
           let fields = httpResponse.allHeaderFields as? [String: String] {
            if download.fileType == .mp4 {
                p("didResumeAtOffset: \(httpResponse.statusCode), \(fileOffset), expected : \(expectedTotalBytes), \(fields)")
            }
        }
        
    }
    
    // ---------------------------------------------------
    // 다운로드 완료시
    // ---------------------------------------------------
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        
        let (videoDown, videoDownurl) = checkDownloadTask(downloadTask: downloadTask)
        
        guard let download = videoDown,
              let url = videoDownurl
        else {
            return
        }
        
//        guard
//            let url = (activeDownloads.filter { $0.value.task == downloadTask }).first?.key,
//            let download = activeDownloads[url]
//        else {
//            return
//        }

        if let httpResponse = downloadTask.response as? HTTPURLResponse,
           let fields = httpResponse.allHeaderFields as? [String: String] {
            
            p("didFinishDownloadingTo fields : \(fields)")
            
            if !(200...299).contains(httpResponse.statusCode) {
                
                p("didFinishDownloadingTo Error : \(httpResponse.statusCode), \(httpResponse.statusMessage!)")

                if needToLogin(errno: httpResponse.statusCode ) {
                    DispatchQueue.main.async() { [self] in
                        isLogin = false
                        self.performSegue(withIdentifier: "segueLoginOut", sender: nil)
                    }
                }
                
                // 진행 상태 에러 처리
                DispatchQueue.main.async { [self] in
                    
                    if download.fileType == .mp4 {
                        download.psgInfo.videoDownloadFlag = .error
                    }
                    else {
                        download.psgInfo.tarDownloadFlag = .error
                    }
                    if let imageCell = getMainCell(index: download.collectionViewIndex!) {
                        imageCell.refreshProgress(download.fileType, isEvent: true)
                    }
                    
                }
                
                download.checkTimer = nil
                activeDownloads[url] = nil

                return
                
            }
            p("didFinishDownloadingTo : \(httpResponse.statusCode), \(download.collectionViewIndex!), \(download.fileUrl!.lastPathComponent)")
        }
        else {
            print("didFinishDownloadingTo downloadTask.response nil Error ~~~")
            download.checkTimer = nil
            activeDownloads[url] = nil
            return
        }
        
        let fileManager = FileManager.default
        try? fileManager.removeItem(at: download.fileUrl!)

        do {
            try fileManager.moveItem(at: location, to: download.fileUrl!)
        } catch {
            p("file move error: \(error)")
        }

        p("다운완료 : \(download.collectionViewIndex as Any), \(download.fileUrl?.lastPathComponent as Any)")

        // 이미지 어레이에 완료 처리
        if download.fileType == .tar {
            // 타르 파일인 경우 압축을 푼다.
            extractImageTar(tarFileUrl: download.fileUrl!, psgID: download.psgInfo.id!)
        }

        // 진행 상태 완료 처리
        DispatchQueue.main.async { [self] in
            
            if download.fileType == .mp4 {
                download.psgInfo.videoDownloadFlag = .completed
                download.psgInfo.videoDownloadProgress = 1.0
            }
            else {
                download.psgInfo.tarDownloadFlag = .completed
                download.psgInfo.tarDownloadProgress = 1.0
            }
            
            if let imageCell = getMainCell(index: download.collectionViewIndex!) {
                imageCell.refreshProgress(download.fileType, isEvent: true)
            }
            
            if let index = download.collectionViewIndex, index == currentImageIndex {
                actionIfCurrentImageDownloadComplete(fileType: download.fileType!)
            }
            
            download.checkTimer = nil
            activeDownloads[url] = nil
        }
        
    }
    
   
    func actionIfCurrentImageDownloadComplete(fileType:FileType) {
        
        if fileType == .tar {
            downloadingTarIndicator.stopAnimating()
            downloadTarProgress.isHidden = true
            downloadImageProgressLabel.isHidden = true
            
            loadSubImageList()
            if (selectedSubImageRowNum >= 0 && selectedSubImageRowNum < subImageArray.count) {
                loadSubImageOneFromUrl(subImageInfo: subImageArray[selectedSubImageRowNum])
            }
//            (_, _) = getSubImageListFromDisk()
//
//            if (subImageArray.count > 0) {
//                selectedSubImageRowNum = 0
//                loadSubImageOneFromUrl(subImageInfo: subImageArray[selectedSubImageRowNum])
//            }
//            collectionViewThumbnail.reloadData()
//            collectionViewThumbnail.layoutIfNeeded()
        }
        else {
            downloadingIndicator.stopAnimating()
            downloadVideoProgress.isHidden = true
            downloadVideoProgressLabel.isHidden = true
            preparePlayer(fileURL: psgArray[currentImageIndex].videoFileUrl! as NSURL)

        }

        downloadNextPSGFiles(psgIndex: currentImageIndex)

    }
    
}

// --------------------------------------------------------------------------------
// URLSessionTaskDelegate
// --------------------------------------------------------------------------------
extension LabelingVC: URLSessionTaskDelegate {

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        
        guard let downloadTask = task as? URLSessionDownloadTask
        else {
            return
        }
        
        let (videoDown, videoDownurl) = checkDownloadTask(downloadTask: downloadTask)
        
        guard let download = videoDown,
              let url = videoDownurl
        else {
            return
        }

//        guard
//            let url = (activeDownloads.filter { $0.value.task == task }).first?.key,
//            let download = activeDownloads[url]
//        else {
//            return
//        }

        guard let error = error else {
            p("TaskDelegate didCompleteWithError : \(download.collectionViewIndex!), \(download.fileType!), Success!")
            return
        }
        
        let nsError = error as NSError
        
        p("TaskDelegate didCompleteWithError : \(nsError.code), \(nsError.description)")

        if let resumeData = nsError.userInfo[NSURLSessionDownloadTaskResumeData] as? Data {
            p("TaskDelegate resumeData bytes : \(resumeData.bytes.count)")
            activeDownloads[url]?.resumeData = resumeData
            activeDownloads[url]?.isWaiting = true
            if download.fileType == .mp4 {
                activeDownloads[url]?.psgInfo.videoDownloadFlag = .paused
            }
            else {
                activeDownloads[url]?.psgInfo.tarDownloadFlag = .paused
            }
        }
        else {
            p("NSURLSessionDownloadTaskResumeData is null")
        }
        
    }

}

// --------------------------------------------------------------------------------
// URLSessionDelegate
// --------------------------------------------------------------------------------
extension LabelingVC: URLSessionDelegate {

    func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        
        if (session == downloadsSession) {
            p("urlSessionDidFinishEvents is called.")
            DispatchQueue.main.async {
                guard let appDelegate = UIApplication.shared.delegate as? AppDelegate,
                    let backgroundCompletionHandler =
                        appDelegate.backgroundSessionCompletionHandler else {
                        return
                }
                backgroundCompletionHandler()
            }
        }

    }
    
    func urlSession(_ session: URLSession, didBecomeInvalidWithError error: Error?) {
        if (session == downloadsSession) {
            if (error == nil) {
                p("didBecomeInvalidWithError: No error")
            }
            else {
                p("didBecomeInvalidWithError : \(error.debugDescription)")
            }
        }
    }

}


