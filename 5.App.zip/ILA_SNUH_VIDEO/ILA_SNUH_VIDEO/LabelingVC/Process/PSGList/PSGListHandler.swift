//
//  PSGListHandler.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/10.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    @objc func reloadPSGList(_ sender: UIButton) {

        if !isLogin {
            return
        }
        
        if saveButton.isEnabled {
            let dialogMessage = UIAlertController(title: "확인", message: "저장되지 않은 데이터가 있습니다. \n 계속 하시겠습니까?", preferredStyle: .alert)
            let ok = UIAlertAction(title: "예", style: .destructive, handler: { [self] (action) -> Void in
                actionReloadPSGList()
            })

            let cancel = UIAlertAction(title: "아니오", style: .cancel) { (action) -> Void in
            }
            dialogMessage.addAction(ok)
            dialogMessage.addAction(cancel)
            self.present(dialogMessage, animated: true, completion: nil)
        }
        else {
            actionReloadPSGList()
        }

    }
    

    func actionReloadPSGList() {

        if (!isWorking) { return }
        
        // ------------------------------------------------
        // 스피너 시작
        // ------------------------------------------------
        let child = SpinnerViewController()
        child.view.frame = view.frame
        view.addSubview(child.view)
        child.didMove(toParent: self)
        DoEvents(f: 0.01)
        
        isReloadTapped = true

        clearLabelImage()
        //removeVideosToDownload()
        cancelAllDownload()
        collectionViewMainImage.reloadData()

        loadData()

        isReloadTapped = false
        
        // ------------------------------------------------
        // 스피너 종료
        // ------------------------------------------------
        child.willMove(toParent: nil)
        child.view.removeFromSuperview()
        child.removeFromParent()
    }
    
    // ------------------------------------------------
    // 현재 보고 있는 PSG 정보의 다음 PSG 정보에 대한 파일을 다운로드 함
    // ------------------------------------------------
    func downloadNextPSGFiles(psgIndex:Int) {
        
        // psg건수가 0이거나 인덱스가 psg건수보다 크면 수행 안함
        if psgArray.count == 0 || psgIndex >= psgArray.count {
            return
        }
        
        if (psgArray[psgIndex].videoDownloadFlag == .completed && psgArray[psgIndex].tarDownloadFlag == .completed) {

            let nextIndex = psgIndex + 1

            if (nextIndex < psgArray.count) {
                // 에러가 났었거나 다운로드 안된게 있으면 시도
                if (canDownloadStatus(psgArray[nextIndex].videoDownloadFlag) ||
                    canDownloadStatus(psgArray[nextIndex].tarDownloadFlag)) {
                    pushDownloadVideo(index: nextIndex)
                }
            }
        }
    }
}
