//
//  PSGListArrow.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    func arrowLeftClick(_ sender: Any? = nil) {

        let num = currentImageIndex - 1
        
        if (num < 0) {
            self.view.showToast(toastMessage: "처음 이미지 입니다.", duration: 0.5)
            return
        }

        arrowImage(num:num)
        animation(view: EditingImage, direction: .LeftToRight)

        return
    }
    

    func arrowRightClick(_ sender: Any? = nil) {

        let num = currentImageIndex + 1
        
        if (num > psgArray.count - 1) {
            self.view.showToast(toastMessage: "마지막 이미지 입니다.", duration: 0.5)
            return
        }

        arrowImage(num:num)
        animation(view: EditingImage, direction: .RightToLeft)

        return

    }
    
    // -----------------------------------------------------------------------------------------
    // 20200902
    // -----------------------------------------------------------------------------------------
    func arrowImageLastClick() {

        let num = psgArray.count - 1
        
        if (psgArray.count == 0 || currentImageIndex == num) {
            return
        }
        
        arrowImage(num: num)
        animation(view: EditingImage, direction: .RightToLeft)

        return
    }
    
    // -----------------------------------------------------------------------------------------
    // 20200902
    // -----------------------------------------------------------------------------------------
    func arrowImageFirstClick() {

        let num = 0
        
        if (psgArray.count == 0 || currentImageIndex == 0) {
            return
        }
        
        arrowImage(num:num)
        animation(view: EditingImage, direction: .LeftToRight)

        return
    }
    


    func arrowImage(num:Int) {
        
        if let befIndexPath = selectedMainImageCellIndexPath {
            if let befCell = getMainCell(indexPath: befIndexPath) {
                befCell.userSelected = false
            }
        }

        currentImageIndex = num
        
        let indexPath = IndexPath(item: currentImageIndex, section: 0)

        DispatchQueue.main.async {
            self.collectionViewMainImage.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: false)
            self.collectionViewMainImage.layoutIfNeeded()

            if let cell = self.getMainCell(indexPath: indexPath) {
                cell.userSelected = true
            }
            self.selectedMainImageCellIndexPath = indexPath

        }
        
        loadVideoImageEvent(index: currentImageIndex)    // 이미지를 가져옴

    }
}
