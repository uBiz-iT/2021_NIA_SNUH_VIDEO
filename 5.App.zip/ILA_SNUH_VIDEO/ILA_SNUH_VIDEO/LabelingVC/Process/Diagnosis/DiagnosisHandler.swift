//
//  DiagnosisHandler.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/10.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    @objc func didTapShowDiag(_ sender: UIButton) {
        if !isLogin {
            return
        }
        diagDisplayExtendOk = !diagDisplayExtendOk
    }

    func showDiagView(_ isShown:Bool)  {
        if (isShown) {
            diagDisplayView.center.y -= diagDisplayView.bounds.height
            UIView.animate(withDuration: 0.2, delay: 0, options: [.curveEaseIn],
                           animations: { [self] in
                            diagDisplayView.center.y = diagDisplayView.bounds.height
                            diagDisplayView.layoutIfNeeded()
            }, completion: nil)
            diagDisplayView.isHidden = false
        }
        else {
            UIView.animate(withDuration: 0.2, delay: 0, options: [.curveLinear],
                           animations: { [self] in
                            diagDisplayView.center.y -= diagDisplayView.bounds.height
                            diagDisplayView.layoutIfNeeded()
            },  completion: { [self] (_ completed: Bool) -> Void in
                diagDisplayView.isHidden = true
            })
        }
    }
    
    // --------------------------------------------------------------------------
    // 화면 상의 버튼 등 오브젝트 등의 속성 초기화
    // --------------------------------------------------------------------------
    func setProgressValue() {
        
        setTitle()
        
        total_count = psgList.count
        complete_count = psgList.doneImages().count
        
        if (total_count == 0) {
            progress.progress = 0
            progressLabel.text = "[0%(0/0)],[0/0]"
            return
        }

        // 20200820 sub 이미지 관련 추가
        sub_total_count = subImageList.count
        sub_complete_count = subImageList.doneImages().count
        
        // 이미지 랜덤 가져오는 부분에서 전체수와 완료를 가져와서 해당 변수에 저장한 것을 사용
        let value = Float(complete_count) / Float(total_count)
        progress.progress = value
        
        progressLabel.text = String(format: "[%4.1f%%(%d%/%d)][%d]", value * 100, complete_count, total_count, sub_total_count)
//        progressLabel.text = String(format: "[%4.1f%%(%d%/%d)][%d%/%d]", value * 100, complete_count, total_count, sub_complete_count, sub_total_count)

        setDiagViewColor()

    }


}
