//
//  DiagnosisInit.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    func viewDidLoad_Diagnosis() {
        
        // 진행률 오브젝트
        progress.transform = CGAffineTransform(scaleX: 1, y: 5)
        progress.clipsToBounds = true
        setProgressValue()

        diagLabel.lineBreakMode = .byCharWrapping
        diagLabel.numberOfLines = 2
        
        self.view.bringSubviewToFront(diagDisplayView)
        diagDisplayView.isHidden = true
        

    }

    func setDiagValue(reset:Bool, index:Int = 0) {
        if reset {
            genderLabel.text = ""
            ageLabel.text = ""
            bmiLabel.text = ""
            sltmLabel.text = ""
            slef.text = ""
            sllaLabel.text = ""
            ahiLabel.text = ""
            rdiLabel.text = ""
            oxavg.text = ""
            oxmin.text = ""
            lmiLabel.text = ""
            lmarLabel.text = ""
            ariLabel.text = ""
            diagLabel.text = ""
        }
        else {
            genderLabel.text = (psgArray[index].gender == "") ? "__" : psgArray[index].gender
            ageLabel.text = (psgArray[index].age == "") ? "__" : psgArray[index].age
            bmiLabel.text = (psgArray[index].bmi == "") ? "__" : psgArray[index].bmi
            sltmLabel.text = (psgArray[index].sltm == "") ? "__" : psgArray[index].sltm
            slef.text = (psgArray[index].slef == "") ? "__" : psgArray[index].slef
            sllaLabel.text = (psgArray[index].slla == "") ? "__" : psgArray[index].slla
            ahiLabel.text = (psgArray[index].ahi == "") ? "__" : psgArray[index].ahi
            rdiLabel.text = (psgArray[index].rdi == "") ? "__" : psgArray[index].rdi
            oxavg.text = (psgArray[index].oxavg == "") ? "__" : psgArray[index].oxavg
            oxmin.text = (psgArray[index].oxmin == "") ? "__" : psgArray[index].oxmin
            lmiLabel.text = (psgArray[index].lmi == "") ? "__" : psgArray[index].lmi
            lmarLabel.text = (psgArray[index].lmar == "") ? "__" : psgArray[index].lmar
            ariLabel.text = (psgArray[index].ari == "") ? "__" : psgArray[index].ari
            diagLabel.text = (psgArray[index].diag == "") ? "[최종진단]  not defined" : psgArray[index].diag
        }
    }
    
    func setDiagViewColor() {
        if (complete_count == total_count) {
            progressLabel.textColor = isDarkMode ? UIColor.yellow : UIColor.red
        }
        else if (sub_complete_count == sub_total_count) {
            progressLabel.textColor = isDarkMode ? UIColor.green : UIColor.blue
        }
        else {
            progressLabel.textColor = isDarkMode ? UIColor.white : UIColor.black
        }
        diagLabel.textColor = isDarkMode ? UIColor.yellow : UIColor.blue
    }
 


}
