//
//  ImageLoad.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import AVKit
import AVFoundation

extension LabelingVC {

    func loadSubImageOneFromUrl(subImageInfo:SubImageInfo) {
        
        if (currentImageIndex < 0 || currentImageIndex >= psgArray.count) {
            p("Array Index Error : loadSubImageOneFromUrl() number \(currentImageIndex)")
            return
        }
        
        guard let subImageFullPath = subImageInfo.sub_server_location else { return }

        existImage = false
        savedJsonFileUrlPath = nil
        
        var cacheStdImage:UIImage? = nil

        // cache에 표준 이미지 요청한 url이 남아 있으면 cache 이미지를 가져다 사용 20201106
//        if let file_name = subImageInfo.sub_server_location {
//            let encoded = file_name.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
//            let url = URL(string: "\(ILA4ML_URL_GETIMAGE)?file_name=\(encoded!)")?.absoluteString
//
//            p(url!)
//
//            if let imageFromCache = myImageCache.getImage(urlString: url!) {
//                cacheStdImage = imageFromCache
//            }
//        }

        cacheStdImage = loadImageFromDisk(fileUrl: subImageInfo.fileUrl!)
        
        // 캐쉬에서 이미지를 가지고 있으면 그 이미지를 화면에 표시하고 그렇지 않으면 다운로드한다. 20201106
        if let standardImage = cacheStdImage {
            savedSourceImageUrlPath  = getSourceImageFromSubImageInfo(imageId: subImageInfo.sub_image_id!, image: standardImage)
        }
//        else {
//            savedSourceImageUrlPath = downloadSourceImage(subImageInfo.sub_image_id!, subImageFullPath)
//        }
        
        if savedSourceImageUrlPath == nil {
            existImage = false
            realImage = #imageLiteral(resourceName: "ImageNotRegistered")                   // 디폴트 이미지 세팅
            realImage = nil
            //showNotRegisterdMessage()
        }
        else {
            existImage = true
//            realImage = UIImage(contentsOfFile: savedSourceImageUrlPath!)
            realImage = cacheStdImage
        }
        
        EditingImage.image = realImage
        originalImage = realImage

        // 이미지 변경되었을때 관련된 오브젝트 리셋
        resetObjectsRelatedToLabeling()

        resetWhenImageChanged()
        
        imageIDLabel.text = psgArray[currentImageIndex].id
        if let sub_row_num = subImageArray[selectedSubImageRowNum].row_num,
           let fileUrl = subImageArray[selectedSubImageRowNum].fileUrl {
            subImageNumLabel.text = "\(sub_row_num)"
            subImageFileNameLabel.text = "\(fileUrl.lastPathComponent)"
        }
        else {
            subImageNumLabel.text = ""
            subImageFileNameLabel.text = ""
        }

        // json 파일로부터 mark 좌표를 읽어서 그림. 20200831
        // drawMarkAllFromJson()
        
        // 유저디폴트에 저장
        UserDefaults.standard.set(selectedSubImageRowNum, forKey: DefaultKey_SubImageIndex)     // 20200820
        WorkingSubImageIndex = selectedSubImageRowNum                                           // 20200820
        
        // 마지막 로딩했던 이미지를 저장
        UserDefaults.standard.set(subImageInfo.sub_image_id, forKey: DefaultKey_SubImageId)                   // 20200820
        WorkingSubImageId = subImageInfo.sub_image_id!                                                        // 20200820

        moveEventBeginEndLine()
        
    }
    
    // -----------------------------------------------------------------------------
    // 디스크에서 이미지를 읽어옴
    // -----------------------------------------------------------------------------
    public func loadImageFromDisk(fileUrl: URL) -> UIImage? {
        do {
            let imageData = try Data(contentsOf: fileUrl)
            return UIImage(data: imageData)
        } catch {
            // p("loadImageFromDisk : \(fileUrl), Error : \(error)")
        }
        return nil
    }
    
}
