//
//  ImageViewerHandler.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/10.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    //--------------------------------------------------------------------------------
    // 이미지를 보여줄때 애니메이션을 함 20200821
    //--------------------------------------------------------------------------------
    func animation(view: UIView, direction:AnimationDirection) {
        
        let x = view.frame.origin.x
        let y = view.frame.origin.y

        view.alpha = 0
        
        var duration = 0.15

        if direction == .LeftToRight {
            view.frame = CGRect(x: view.frame.origin.x - view.frame.width, y: view.frame.origin.y, width: view.frame.width, height: view.frame.height)
        }
        else if direction == .RightToLeft {
            view.frame = CGRect(x: view.frame.origin.x + view.frame.width, y: view.frame.origin.y, width: view.frame.width, height: view.frame.height)
        }
        else if direction == .TopToBottom {
            view.frame = CGRect(x: view.frame.origin.x, y: view.frame.origin.y - view.frame.height, width: view.frame.width, height: view.frame.height)
            duration = 0.2
        }
        else if direction == .BottomToTop {
            view.frame = CGRect(x: view.frame.origin.x, y: view.frame.origin.y + view.frame.height, width: view.frame.width, height: view.frame.height)
            duration = 0.2
        }

        UIView.animate(withDuration: duration, delay: 0, options: .curveEaseIn, animations: {
            view.frame = CGRect(x: x, y: y, width: view.frame.width, height: view.frame.height)
            view.alpha = 1
        }, completion: nil)
    }


}
