//
//  ImageInit.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    func viewDidLoad_Image() {

        // -----------------------------------------------------------
        // 이미지 스크롤 뷰안의 이미지 frame 초기화
        // -----------------------------------------------------------
        EditingImage.frame.origin.x = CGFloat(imageOffsetInScrollImage)
        EditingImage.frame.origin.y = 0
        EditingImage.frame.size.width = ScrollImage.frame.size.width - CGFloat(imageOffsetInScrollImage + 30)
        EditingImage.frame.size.height = ScrollImage.frame.size.height


        initImageViewProperty()

        // 20201205 메모 모양
        memoView.layer.cornerRadius = 8.0;
        memoView.textColor = UIColor.black
        memoView.backgroundColor = UIColor.white
        

    }

    // --------------------------------------------------------------------------
    // 메인 이미지뷰 속성 설정 및 초기 이미지 설정
    // --------------------------------------------------------------------------
    func initImageViewProperty() {
        EditingImage.isUserInteractionEnabled = true
        EditingImage.clipsToBounds = true
        EditingImage.backgroundColor = UIColor.black
        ScrollImage.backgroundColor = UIColor.lightGray

        // 초기 이미지 설정
        EditingImage.image = #imageLiteral(resourceName: "서울대병원야경")
        EditingImage.contentMode = .scaleToFill
        
        originalImage = EditingImage.image
    }
    
    func resetWhenImageChanged() {
        ScrollImage.zoomScale = 1
        EditingImage.isUserInteractionEnabled = true
        playerView.isUserInteractionEnabled = true             // 20200814
        EditingImage.contentMode = .scaleToFill
    }
    
    func clearImage() {
        ScrollImage.zoomScale = 1
        EditingImage.image = #imageLiteral(resourceName: "서울대병원야경")
        EditingImage.contentMode = .scaleToFill
    }
    
    //-------------------------------------------------------------------------------------
    // ScrollImage : 이미지의 확대/축소/확대된 이미지 이동 등을 위하여 사용, 이미지를 scroll view 안에서 사용
    //-------------------------------------------------------------------------------------
    func setScrollViewPropertyForImage() {
        ScrollImage.contentSize = EditingImage.bounds.size
        ScrollImage.autoresizingMask = [UIView.AutoresizingMask.flexibleWidth, UIView.AutoresizingMask.flexibleHeight]
        
        ScrollImage.alwaysBounceVertical = false
        ScrollImage.alwaysBounceHorizontal = false
        ScrollImage.showsVerticalScrollIndicator = true
        ScrollImage.flashScrollIndicators()
        
        // 최소 터치수를 최소2개, 최대2개로 설정
        // 싱글터치는 이미지 자체 Pan 이벤트로 사용함.(mark용도로)
        ScrollImage.panGestureRecognizer.minimumNumberOfTouches = 1
        ScrollImage.panGestureRecognizer.maximumNumberOfTouches = 2
        setImageZoomScaleInScrollView()
    }
    
    func setImageZoomScaleInScrollView() {
        let imageViewSize = EditingImage.bounds.size
        let scrollViewSize = ScrollImage.bounds.size
        let widthScale = scrollViewSize.width / imageViewSize.width
        let heightScale = scrollViewSize.height / imageViewSize.height
        
        ScrollImage.minimumZoomScale = min(widthScale, heightScale)
        ScrollImage.maximumZoomScale = ScrollImage.minimumZoomScale * 5.0
    }
    
    
    func downloadSourceImage(_ imageId:String, _ file_name:String) -> String? {

        let encoded = file_name.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
        let url = URL(string: "\(ILA4ML_URL_GETIMAGE)?file_name=\(encoded!)&id=\(LoginID)")
        if let data = try? Data(contentsOf: url!) {
            
            let f = imageId + ".jpg"
            
            if (!makeDir(fullPath: sourceImageDirectoryURL!.path)) {
                p("downloadSourceImage() makeDir sourceImageDirectoryURL error")
            }
            
            let saveImageUrl = sourceImageDirectoryURL!.appendingPathComponent(f)
            do {
                try data.write(to: saveImageUrl)
            } catch {
                p(error.localizedDescription)
            }
            
            return saveImageUrl.path
            
        }
        else {
            p("Error downloadSourceImage url : \(file_name)")
            return nil
        }
        
    }

    func getSourceImageFromSubImageInfo(imageId:String, image:UIImage) -> String? {

        if let data = image.jpegData(compressionQuality: 1.0) {
            
            let f = imageId + ".jpg"
            
            if (!makeDir(fullPath: sourceImageDirectoryURL!.path)) {
                p("imageId() makeDir sourceImageDirectoryURL error")
            }
            
            let saveImageUrl = sourceImageDirectoryURL!.appendingPathComponent(f)
            do {
                try data.write(to: saveImageUrl)
            } catch {
                p(error.localizedDescription)
            }
            
            return saveImageUrl.path
            
        }
        else {
            p("Error getSourceImageFromSubImageInfo : \(imageId)")
            return nil
        }

    }

    func downloadSourceOrgImage(_ imageId:String, _ file_name:String) -> String? {

        let encoded = file_name.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
        let url = URL(string: "\(ILA4ML_URL_GETIMAGE)?file_name=\(encoded!)&id=\(LoginID)")
        if let data = try? Data(contentsOf: url!) {
            
            let f = "Org_" + imageId + ".jpg"
            
            if (!makeDir(fullPath: sourceImageDirectoryURL!.path)) {
                p("downloadSourceOrgImage() makeDir sourceImageDirectoryURL error")
            }
            
            let saveImageUrl = sourceImageDirectoryURL!.appendingPathComponent(f)
            do {
                try data.write(to: saveImageUrl)
            } catch {
                p(error.localizedDescription)
            }
            
            return saveImageUrl.path
            
        }
        else {
            p("Error downloadSourceImage url : \(file_name)")
            return nil
        }
        
    }

    func getSourceOrgImageFromSubImageInfo(imageId:String, image:UIImage) -> String? {

        if let data = image.jpegData(compressionQuality: 1.0) {
            
            let f = "Org_" + imageId + ".jpg"
            
            if (!makeDir(fullPath: sourceImageDirectoryURL!.path)) {
                p("imageId() makeDir sourceImageDirectoryURL error")
            }
            
            let saveImageUrl = sourceImageDirectoryURL!.appendingPathComponent(f)
            do {
                try data.write(to: saveImageUrl)
            } catch {
                p(error.localizedDescription)
            }
            
            return saveImageUrl.path
            
        }
        else {
            p("Error getSourceOrgImageFromSubImageInfo : \(imageId)")
            return nil
        }

    }


    func downloadMarkedImage(_ imageId:String, _ file_name_url:URL) -> String? {

        let encoded = file_name_url.relativePath.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
        let url = URL(string: "\(ILA4ML_URL_GETIMAGE)?file_name=\(encoded!)&id=\(LoginID)")
        
        if let data = try? Data(contentsOf: url!) {
            
            let f = file_name_url.lastPathComponent
            if (!makeDir(fullPath: markedImageDirectoryURL!.path)) {
                p("downloadMarkedImage() makeDir markedImageDirectoryURL error")
            }
            
            let saveImageUrl = markedImageDirectoryURL!.appendingPathComponent(f)
            do {
                try data.write(to: saveImageUrl)
            } catch {
                p(error.localizedDescription)
            }
            
            return saveImageUrl.path
            
        }
        else {
            p("Error downloadMarkedImage url : \(file_name_url.relativePath)")
            return nil
        }
        
    }
    
    func appendUploadFileList(fileURL:URL, imageId:String, serverSourceImagePath:String, serverFileName:String, imageSeq:Int, line:Line?) {
        
        let serverMarkedImageDir = getMarkedImageDirectoryOnServer(serverSourceImagePath: serverSourceImagePath, imageId: imageId)
        var fileToUpload = FileToUpload()
        fileToUpload.projectCode = WorkingProjectCode
        fileToUpload.projectName = WorkingProjectName
        fileToUpload.imageID = imageId
        fileToUpload.imageSeq = imageSeq
        fileToUpload.name = serverFileName
        fileToUpload.location = serverMarkedImageDir.relativePath // 상대경로 지정, path로 하면 맨앞에 '/'이 붙어 서버에서 루트로 인식
        fileToUpload.fileUrl = fileURL
        FileListToUpload.append(fileToUpload)
        autoUpload.printUploadList(true)
        
    }
    
}
