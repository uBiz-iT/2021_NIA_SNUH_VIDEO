//
//  PSGImageViewerGraphLabel.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {
    
    struct GraphLabel {
        
        var initLoc:CGFloat = 0.0
        let locX:CGFloat = 5.0
        let fontsize:CGFloat = 9.0
        let width:CGFloat = 80
        let height:CGFloat = 12
        
        var uiLabel:UILabel = UILabel()
        
        init(_ text:String, _ initLoc:CGFloat, textColor _textColor:UIColor = UIColor.yellow, backColor _backColor:UIColor = UIColor.clear) {
            uiLabel.text = text
            uiLabel.textColor = _textColor
            uiLabel.backgroundColor = _backColor
            uiLabel.font = uiLabel.font.withSize(fontsize)
            uiLabel.textAlignment = .right
            self.initLoc = initLoc
            uiLabel.frame.origin.x = self.locX
            uiLabel.frame.origin.y = initLoc + 1
            uiLabel.frame.size.width = width
            uiLabel.frame.size.height = height
        }
    }
    
    class ClassGraphLabel {
        
        var orgLabellist: [GraphLabel] = []
        var stdLabellist: [GraphLabel] = []
        
        func getGraphUILabelByKindIndex(_ kindIndex:Int, _ contentOffsetX:CGFloat, _ zoomScale:CGFloat) -> [UILabel] {
            var list: [GraphLabel] = []
            if (kindIndex == 0) {
                list = orgLabellist
            }
            else {
                list = stdLabellist
            }
            var uiLabelList = [UILabel]()
            for gl in list {
                gl.uiLabel.frame.origin.x = gl.locX + contentOffsetX
                gl.uiLabel.frame.origin.y = gl.initLoc * zoomScale
                uiLabelList.append(gl.uiLabel)
            }
            return uiLabelList
        }
        
        func setGraphUILabelLocationByKindIndex(_ kindIndex:Int, _ contentOffsetX:CGFloat, _ zoomScale:CGFloat) {
            var list: [GraphLabel] = []
            if (kindIndex == 0) {
                list = orgLabellist
            }
            else {
                list = stdLabellist
            }
            for gl in list {
                gl.uiLabel.frame.origin.x = gl.locX + contentOffsetX
                gl.uiLabel.frame.origin.y = gl.initLoc * zoomScale
                gl.uiLabel.font = gl.uiLabel.font.withSize(gl.fontsize * zoomScale)
                gl.uiLabel.frame.size.width = gl.width * zoomScale
                gl.uiLabel.frame.size.height = gl.height * zoomScale
            }
        }
        
        // screenShotKind : 0 nx, 1 em
        func initialize(_ imageScrollView:UIScrollView, _ imageView:UIImageView) {

            // 기존 레이블 모두 제거후 작업
            for gl in orgLabellist {
                gl.uiLabel.removeFromSuperview()
            }
            for gl in stdLabellist {
                gl.uiLabel.removeFromSuperview()
            }
            orgLabellist.removeAll()
            stdLabellist.removeAll()

            // --------------------------------------------------------------------
            // 표준 이미지
            // --------------------------------------------------------------------
            //let height = imageView.frameOfImage.height
            let height = imageScrollView.frame.height

//            let base:CGFloat = height * 0.05 + imageView.frameOfImage.origin.y
            let base:CGFloat = height * 0.05
            var step:CGFloat = 0.042
            stdLabellist.append(GraphLabel("X Axis", base, textColor: UIColor.blue))
            stdLabellist.append(GraphLabel("Y Axis", base + (height * step * 1), textColor: UIColor.blue))
            stdLabellist.append(GraphLabel("Z Axis", base + (height * step * 2), textColor: UIColor.blue))
            stdLabellist.append(GraphLabel("C3-M2", base + (height * step * 3), textColor: UIColor.blue))
            stdLabellist.append(GraphLabel("C4-M1", base + (height * step * 4), textColor: UIColor.blue))
            stdLabellist.append(GraphLabel("O1-M2", base + (height * step * 5), textColor: UIColor.blue))
            stdLabellist.append(GraphLabel("O2-M1", base + (height * step * 6), textColor: UIColor.blue))
            stdLabellist.append(GraphLabel("E1-M2", base + (height * step * 7), textColor: UIColor.blue))
            stdLabellist.append(GraphLabel("E2-M1", base + (height * step * 8), textColor: UIColor.blue))
            stdLabellist.append(GraphLabel("Chin", base + (height * step * 9), textColor: UIColor.blue))
            stdLabellist.append(GraphLabel("ECG", base + (height * step * 10), textColor: UIColor.blue))
            stdLabellist.append(GraphLabel("Flow", base + (height * step * 12), textColor: UIColor.blue))
            step = 0.0416
            stdLabellist.append(GraphLabel("Thermistor", base + (height * step * 14), textColor: UIColor.blue))
            stdLabellist.append(GraphLabel("Thorax", base + (height * step * 15), textColor: UIColor.blue))
            stdLabellist.append(GraphLabel("Abdomen", base + (height * step * 16), textColor: UIColor.blue))
            stdLabellist.append(GraphLabel("Snore", base + (height * step * 17), textColor: UIColor.blue))
            stdLabellist.append(GraphLabel("Audio Volume", base + (height * step * 18), textColor: UIColor.blue))
            stdLabellist.append(GraphLabel("Left Leg", base + (height * step * 19), textColor: UIColor.blue))
            stdLabellist.append(GraphLabel("Right Leg", base + (height * step * 20), textColor: UIColor.blue))
            stdLabellist.append(GraphLabel("SpO₂", base + (height * step * 21.5), textColor: UIColor.blue))
            
//            let base:CGFloat = 0
//            let step:CGFloat = 0.04
//            stdLabellist.append(GraphLabel("X Axis", base + height * step * 0))
//            stdLabellist.append(GraphLabel("Y Axis", base + height * step * 1))
//            stdLabellist.append(GraphLabel("Z Axis", base + height * step * 2))
//            stdLabellist.append(GraphLabel("C3-M2", base + height * step * 3))
//            stdLabellist.append(GraphLabel("C4-M1", base + height * step * 4))
//            stdLabellist.append(GraphLabel("O1-M2", base + height * step * 5))
//            stdLabellist.append(GraphLabel("O2-M1", base + height * step * 6))
//            stdLabellist.append(GraphLabel("E1-M2", base + height * step * 7))
//            stdLabellist.append(GraphLabel("E2-M1", base + height * step * 8))
//            stdLabellist.append(GraphLabel("Chin", base + height * step * 9))
//            stdLabellist.append(GraphLabel("ECG", base + height * step * 10))
//            stdLabellist.append(GraphLabel("Flow", base + height * step * 12))
//            stdLabellist.append(GraphLabel("Thermistor", base + height * step * 14))
//            stdLabellist.append(GraphLabel("Thorax", base + height * step * 15))
//            stdLabellist.append(GraphLabel("Abdomen", base + height * step * 16))
//            stdLabellist.append(GraphLabel("Snore", base + height * step * 17))
//            stdLabellist.append(GraphLabel("Audio Volume", base + height * step * 18))
//            stdLabellist.append(GraphLabel("Left Leg", base + height * step * 19))
//            stdLabellist.append(GraphLabel("Right Leg", base + height * step * 20))
//            stdLabellist.append(GraphLabel("SpO₂(85~100%)", base + height * step * 21.5))
//            stdLabellist.append(GraphLabel("SpO₂(40~100%)", base + height * step * 23))

            for gl in stdLabellist {
                imageScrollView.addSubview(gl.uiLabel)
            }
            
        }

    }
    
}
