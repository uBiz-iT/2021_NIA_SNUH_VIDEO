//
//  ImageDrawLine.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    // -----------------------------------------------------------------------------------------------
    // 이벤트가 선택되었거나 이상행동 검출이 되었을 때 시작시점과 종료시점을 PSG이미지 위에 세로선으로 위치를 표시
    // -----------------------------------------------------------------------------------------------
    func moveEventBeginEndLine() {
        
        if (selectedEventIndex >= 0 && selectedEventIndex < eventArray.count) {
            if let begSec = eventArray[selectedEventIndex].begSecond {
                let index = Int(begSec / snapShotGapTime)
                if index == selectedSubImageRowNum {
                    moveBeginLine(seconds: Float64(begSec))
                    beginLineLayer.isHidden = false
                }
                else {
                    beginLineLayer.isHidden = true
                }
            }
            else {
                beginLineLayer.isHidden = true
            }
            
            if let endSec = eventArray[selectedEventIndex].endSecond {
                let index = Int(endSec / snapShotGapTime)
                if index == selectedSubImageRowNum {
                    moveEndLine(seconds: Float64(endSec))
                    endLineLayer.isHidden = false
                }
                else {
                    endLineLayer.isHidden = true
                }
            }
            else {
                endLineLayer.isHidden = true
            }
        }
        else if (selectedEventIndex < 0) {
            moveAbnormalBeginLine()
            moveAbnormalEndLine()
        }
        else {
            beginLineLayer.isHidden = true
            endLineLayer.isHidden = true
        }
        
    }
    
    // -----------------------------------------------------------------------------------------------
    // 이상행동 검출이 되었을 때 시작시점을 PSG이미지 위에 세로선으로 위치를 표시
    // -----------------------------------------------------------------------------------------------
    func moveAbnormalBeginLine() {
        
        let second = isShowAbnormalView ? abnormalViewBegSecond : abnormalBegSecond

        if second < 0 {
            beginLineLayer.isHidden = true
            return
        }
        let begSec = Int(second)
        let index = Int(begSec / snapShotGapTime)
        if index == selectedSubImageRowNum {
            moveBeginLine(seconds: Float64(begSec))
            beginLineLayer.isHidden = false
        }
        else {
            beginLineLayer.isHidden = true
        }
    }

    // -----------------------------------------------------------------------------------------------
    // 이상행동 검출이 되었을 때 종료시점을 PSG이미지 위에 세로선으로 위치를 표시
    // -----------------------------------------------------------------------------------------------
    func moveAbnormalEndLine() {
        
        let second = isShowAbnormalView ? abnormalViewEndSecond : abnormalEndSecond

        if second < 0 {
            endLineLayer.isHidden = true
            return
        }

        let endSec = Int(second)
        let index = Int(endSec / snapShotGapTime)
        if index == selectedSubImageRowNum {
            moveEndLine(seconds: Float64(endSec))
            endLineLayer.isHidden = false
        }
        else {
            endLineLayer.isHidden = true
        }
    }
}
