//
//  LabelingVC_SetCurrentTime.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/10.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    // ---------------------------------------------------------------------
    // 재생 시점 변경
    // ---------------------------------------------------------------------
    enum TIME_ADJUST_METHOD {
        case readyPlay
        case auto
        case eventSelected
        case eventDeselected
        case subImageSelected
        case timeSliderChanged
        case timeLineBegin
        case timeLineMoved
        case timeLineEnd
        case videoRegionBegin
        case videoRegionMoved
        case videoRegionEnd
        case buttonPressed
        case other
        case autoStop
    }
    
    func setCurrentTime(time:CMTime, method:TIME_ADJUST_METHOD) {
        
        if method == .auto && !isVideoPlaying { return }                                // auto인데 멈춘상태이면 수행안함

//        if method != .readyPlay && abs(time.seconds - currentTime.seconds) < 0.1 {      // 최소 0.2초 이상 났을 때만 이것 저것 수행.. 부하 감소.
//            p("부하 감소")
//            return
//        }
        
//        p("setCurrentTime : \(time.seconds), \(method)")

        let tempTime = currentTime
        
        if time < .zero {
            currentTime = .zero
        }
        else if time > duration {
            currentTime = duration
        }
        else {
            currentTime = time
        }
        
        checkStopVideo(withTime: Int(currentTime.seconds))
        
        if abs(time.seconds - tempTime.seconds) > 0.1 {
            findFirstEvent(withTime: Int(currentTime.seconds))
        }
        
        if method != .subImageSelected {
            findSubImage(withTime: Int(currentTime.seconds))
        }

        switch method {
        case .auto:
            timeSlider.value = Float(currentTime.seconds)
            moveTimeLine(seconds: currentTime.seconds)
            checkAbnormalBehavior(withTime: currentTime)
            break
        case .autoStop:
            timeSlider.value = Float(currentTime.seconds)
            moveTimeLine(seconds: currentTime.seconds)
            seekVideoPosition(seconds: Float(currentTime.seconds))
            break
        case .buttonPressed:
            timeSlider.value = Float(currentTime.seconds)
            moveTimeLine(seconds: currentTime.seconds)
            seekVideoPosition(seconds: Float(currentTime.seconds))
            initSnapshot(time: currentTime)
            break
        case .eventSelected:
            timeSlider.value = Float(currentTime.seconds)
            moveTimeLine(seconds: currentTime.seconds)
            seekVideoPosition(seconds: Float(currentTime.seconds))
            initSnapshot(time: currentTime)
            break
        case .eventDeselected:
            timeSlider.value = Float(currentTime.seconds)
            moveTimeLine(seconds: currentTime.seconds)
            seekVideoPosition(seconds: Float(currentTime.seconds))
            initSnapshot(time: currentTime)
            break
        case .other:
            timeSlider.value = Float(currentTime.seconds)
            moveTimeLine(seconds: currentTime.seconds)
            seekVideoPosition(seconds: Float(currentTime.seconds))
            initSnapshot(time: currentTime)
            break
        case .readyPlay:
            timeSlider.value = Float(currentTime.seconds)
            moveTimeLine(seconds: currentTime.seconds)
            seekVideoPosition(seconds: Float(currentTime.seconds))
            initSnapshot(time: currentTime)
            break
        case .subImageSelected:
            timeSlider.value = Float(currentTime.seconds)
            moveTimeLine(seconds: currentTime.seconds)
            seekVideoPosition(seconds: Float(currentTime.seconds))
            initSnapshot(time: currentTime)
            break
        case .timeLineBegin:
            initSnapshot(time: currentTime)
            break
        case .timeLineMoved:
            timeSlider.value = Float(currentTime.seconds)
            seekVideoPosition(seconds: Float(currentTime.seconds))
            checkAbnormalBehavior(withTime: currentTime)
            break
        case .timeLineEnd:
            break
        case .timeSliderChanged:
            moveTimeLine(seconds: currentTime.seconds)
            seekVideoPosition(seconds: Float(currentTime.seconds))
            break
        case .videoRegionBegin:
            initSnapshot(time: currentTime)
            break
        case .videoRegionMoved:
            timeSlider.value = Float(currentTime.seconds)
            moveTimeLine(seconds: currentTime.seconds)
            seekVideoPosition(seconds: Float(currentTime.seconds))
            checkAbnormalBehavior(withTime: currentTime)
            break
        case .videoRegionEnd:
            break
        }
        
    }
    
    func setCurrentTime(seconds:Float, method:TIME_ADJUST_METHOD) {
        let time = CMTime(seconds: Double(seconds), preferredTimescale: CMTimeScale(NSEC_PER_SEC))
        setCurrentTime(time: time, method: method)
    }
    
    func setCurrentTime(seconds:Double, method:TIME_ADJUST_METHOD) {
        let time = CMTime(seconds: seconds, preferredTimescale: CMTimeScale(NSEC_PER_SEC))
        setCurrentTime(time: time, method: method)
    }
    
    func setCurrentTime(seconds:Int, method:TIME_ADJUST_METHOD) {
        let time = CMTime(seconds: Double(seconds), preferredTimescale: CMTimeScale(NSEC_PER_SEC))
        setCurrentTime(time: time, method: method)
    }
    
    func setCurrentTime(subImageIndex:Int, method:TIME_ADJUST_METHOD) {
        if subImageIndex >= 0 && subImageIndex < subImageArray.count {
            let seconds = subImageIndex * snapShotGapTime
            setCurrentTime(seconds: seconds, method: method)
        }
    }
    // ---------------------------------------------------------------------

    
}
