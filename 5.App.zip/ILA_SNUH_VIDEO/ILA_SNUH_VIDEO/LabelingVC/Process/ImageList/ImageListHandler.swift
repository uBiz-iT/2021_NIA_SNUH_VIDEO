//
//  PSGImageHandler.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/10.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {


    // ------------------------------------------------------------------------
    // 현재 시점에 해당하는 PSG 이미지 찾기
    // ------------------------------------------------------------------------
    func findSubImage(withTime second:Int) {
        
        let index = second / snapShotGapTime

        if befProgressIndex != index {

//            p("비포 프로그레스 : \(befProgressIndex), \(index), \(isTouchSnapShot)")

            if isTouchSnapShot {
                isTouchSnapShot = false
            }
            else {
                // 자동 스크롤 Timeout이 경과된 경우에만 스크롤, 사용자가 스크롤을 하는 도중 자동 스크롤되는 것을 방지하기 위함
                if autoScrollTimeCount >= autoScrollTimeOut {
                    collectionViewThumbnail.scrollToItem(at: IndexPath(item: index, section: 0), at: UICollectionView.ScrollPosition.centeredHorizontally, animated: false)
                    collectionViewThumbnail.layoutIfNeeded()
                }
                collectionViewThumbnail.reloadData()
                if (index < subImageArray.count) {
                    selectedSubImageRowNum = index
                    loadSubImageOneFromUrl(subImageInfo: subImageArray[selectedSubImageRowNum])
                }
            }
            befProgressIndex = index
        }
    }
    


    
}
