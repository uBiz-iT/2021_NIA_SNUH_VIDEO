//
//  ImageListArrow.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    // -----------------------------------------------------------------------------------------
    // 20200822 썸네일 이미지 맨 오른쪽으로 이동
    // -----------------------------------------------------------------------------------------
    func arrowSubImageLastClick() {

        let num = subImageArray.count - 1
        
        //if (subImageArray.count == 0 || selectedSubImageRowNum == num) {
        if (subImageArray.count == 0) {
            return
        }
        
        arrowSubImage(num:num)
        animation(view: EditingImage, direction: .RightToLeft)

        return
    }
    
    // -----------------------------------------------------------------------------------------
    // 20200822 썸네일 이미지 맨 왼쪽으로 이동
    // -----------------------------------------------------------------------------------------
    func arrowSubImageFirstClick() {

        let num = 0
        
        //if (subImageArray.count == 0 || selectedSubImageRowNum == 0) {
        if (subImageArray.count == 0) {
            return
        }
        
        arrowSubImage(num:num)
        animation(view: EditingImage, direction: .LeftToRight)

        return
    }
    

    // -----------------------------------------------------------------------------------------
    // 20200819 썸네일 이미지 오른쪽으로 이동
    // -----------------------------------------------------------------------------------------
    func arrowSubImageRightClick(_ sender: Any? = nil) {

        let num = selectedSubImageRowNum + 1
        
        if (num > subImageArray.count - 1) {
            self.view.showToast(toastMessage: "마지막 이미지 입니다.", duration: 0.5)
            return
        }

        arrowSubImage(num:num)
        animation(view: EditingImage, direction: .RightToLeft)

        return
    }
    
    // -----------------------------------------------------------------------------------------
    // 20200819 썸네일 이미지 왼쪽으로 이동
    // -----------------------------------------------------------------------------------------
    func arrowSubImageLeftClick(_ sender: Any? = nil) {

        let num = selectedSubImageRowNum - 1
        
        if (num < 0) {
            self.view.showToast(toastMessage: "처음 이미지 입니다.", duration: 0.5)
            return
        }
        
        arrowSubImage(num:num)
        animation(view: EditingImage, direction: .LeftToRight)

        return

    }
    
    // -----------------------------------------------------------------------------------------
    // 20201118 썸네일 이미지 step(10칸) 오른쪽으로 이동
    // -----------------------------------------------------------------------------------------
    func arrowSubImageStepRightClick(_ step:Int) {

        var num = selectedSubImageRowNum + step

        if (subImageArray.count == 0) {
            return
        }

        if (num > subImageArray.count - 1) {
            num = subImageArray.count - 1
        }

        arrowSubImage(num:num)
        animation(view: EditingImage, direction: .RightToLeft)

        return
    }
    
    // -----------------------------------------------------------------------------------------
    // 20201118 썸네일 이미지 step(10칸) 왼쪽으로 이동
    // -----------------------------------------------------------------------------------------
    func arrowSubImageStepLeftClick(_ step:Int) {

        var num = selectedSubImageRowNum - step

        if (subImageArray.count == 0) {
            return
        }

        if (num < 0) {
            num = 0
        }

        arrowSubImage(num:num)
        animation(view: EditingImage, direction: .LeftToRight)

        return
    }
    
    func arrowSubImage(num:Int) {

        selectedSubImageRowNum = num
        let indexPath = IndexPath(item: selectedSubImageRowNum, section: 0)

        self.collectionViewThumbnail.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: false)
        self.collectionViewThumbnail.layoutIfNeeded()
        collectionViewThumbnail.reloadData()

        loadSubImageOneFromUrl(subImageInfo: subImageArray[selectedSubImageRowNum])

        setCurrentTime(subImageIndex: selectedSubImageRowNum, method: .subImageSelected)
    }
}
