//
//  ImageListInit.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {

    func viewDidLoad_ImageList() {
        
        resetSubImageList()
        
        downloadingTarIndicator.color = .yellow
        downloadingTarIndicator.style = .medium
        downloadTarProgress.tintColor = .white
        
        initImageCollectionView()

    }

    // --------------------------------------------------------------------------
    // 섬네일용 컬렉션뷰 기본 설정
    // --------------------------------------------------------------------------
    func initImageCollectionView() {
        collectionViewThumbnail.delegate = self
        collectionViewThumbnail.dataSource = self
        collectionViewThumbnail.tag = 3
        
        if let layout = collectionViewThumbnail.collectionViewLayout as? UICollectionViewFlowLayout {
            layout.scrollDirection = .horizontal
        }
        
        collectionViewThumbnail.backgroundColor = UIColor.white
        //imageCollectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "ImageCell")
        
        imageCache.countLimit = 200
        imageCache.totalCostLimit = 0
    }
    
    // -----------------------------------------------------------------------------
    // 섬네일 이미지를 훵하지 않게 뭐라도 보여주자
    // -----------------------------------------------------------------------------
    func resetSubImageList() {
        subImageList.removeAll()
        for i in 0...20 {
            let subImageInfo = SubImageInfo()
            subImageInfo.row_num = i
            subImageInfo.mark_num = 0
            subImageInfo.group = "default"
            subImageInfo.newMarking = false
            subImageInfo.isLabelingDone = false     // 20200819
            subImageInfo.newMarkedImage = nil
            subImageInfo.sub_image_id = "\(i)"
            subImageInfo.sub_server_location = nil
            subImageList.append(subImageInfo: subImageInfo)
        }
        subImageArray = subImageList.imagesByGroup(group: "default")
        collectionViewThumbnail.reloadData()
        collectionViewThumbnail.layoutIfNeeded()
    }
    
    func clearSubImageList() {
        resetSubImageList()
        downloadImageProgressLabel.isHidden = true
        downloadingTarIndicator.isHidden = true

    }

}
