//
//  LabelingVC_Load_Thumbnail.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 24/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {


    // --------------------------------------------------------------------------
    // 섬네일용 이미지 로딩
    // --------------------------------------------------------------------------
    func loadSubImageList() {
        
        subImageList.removeAll()
        subImageArray.removeAll()
        
        //resetSubImageList()
        last_row_num = -1
        sub_image_count = 0
        
        // 20201110 if 추가
//        if (!isReloadTapped) {
//            selectedSubImageRowNum = -1
//        }
        
        WorkingSubImageIndex = 0    // 20200820
        
//        let (success, code) = getSubImageList()
        let (success, code) = getSubImageListFromDisk()
        if (success) {
            
            if (subImageList.count == 0) {
                self.view.showToast(toastMessage: "PSG 이미지가 등록되어 있지 않습니다.", duration: 0.5)
                return
            }
            else {
                subImageArray = subImageList.images
                collectionViewThumbnail.reloadData()

                setProgressValue()

                // 20201110 if 추가
//                if (isReloadTapped) {
//                    WorkingSubImageIndex = selectedSubImageRowNum
//                }
                
                selectedSubImageRowNum = WorkingSubImageIndex
                
                collectionViewThumbnail.scrollToItem(at: IndexPath(item: selectedSubImageRowNum, section: 0), at: UICollectionView.ScrollPosition.centeredHorizontally, animated: false)
                collectionViewThumbnail.layoutIfNeeded()
                collectionViewThumbnail.reloadData()

            }
        }
        else {
            handlingDbError(code: code!, self)
//            if (LastURLErrorMessage.trimmingCharacters(in: [" "]) != "") {
//                let alertProgressNoAction = UIAlertController(title: "메시지 확인", message: "\n\(LastURLErrorMessage)\n\n", preferredStyle: .alert)
//                let otherAction = UIAlertAction(title: "확인", style: .default, handler: { action in
//                    alertProgressNoAction.dismiss(animated: true, completion: nil)
//                })
//                alertProgressNoAction.addAction(otherAction)
//                self.present(alertProgressNoAction, animated: false, completion: nil)
//            }
        }
        
    }
    
//    // -----------------------------------------------------------------------------
//    // 서버 상의 마킹 이미지 저장 path 설정
//    // 멀티레이어의 경우에는 source 이미지와 sub 이미지의 path 두개의 정보를 받음
//    // -----------------------------------------------------------------------------
//    func getMarkedImagePathOnServer(sourceImageFullPathOnServer:String, sourceSubImageFullPathOnServer:String, sequence:Int) -> URL {
//
//        var markedImageDirectroyUrl = URL(fileURLWithPath: WorkingProjectImageDir)                                             // 20200826
//
//        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent("result")                                  // marked 추가
//        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent(LoginID)                                   // LoginID 추가
//        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent("\(psgArray[currentImageIndex].id!)")    // ImageID(멀티레이어 메인 ID) 추가
//
//        let sourceSubImageFullPathUrl = URL(fileURLWithPath: sourceSubImageFullPathOnServer)
//        let sourceSubImageNameUrl = sourceSubImageFullPathUrl.deletingPathExtension().lastPathComponent
//
//        let markedImageFullPathUrl = markedImageDirectroyUrl.appendingPathComponent(String(format: "%@%@.jpg", sourceSubImageNameUrl, markedImageNameSuffix))  // 20200828
//
//        return markedImageFullPathUrl
//    }
//
//    // -----------------------------------------------------------------------------
//    // 멀티 json 파일 경로 얻기 20200828
//    // -----------------------------------------------------------------------------
//    func getJsonFilePathOnServer(sourceImageFullPathOnServer:String, sourceSubImageFullPathOnServer:String, sequence:Int) -> URL {
//
//        var markedImageDirectroyUrl = URL(fileURLWithPath: WorkingProjectImageDir)                                             // 20200826
//
//        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent("result")                                  // marked 추가
//        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent(LoginID)                                   // LoginID 추가
//        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent("\(psgArray[currentImageIndex].id!)")    // ImageID(멀티레이어 메인 ID) 추가
//
//        let sourceSubImageFullPathUrl = URL(fileURLWithPath: sourceSubImageFullPathOnServer)
//        let sourceSubImageNameUrl = sourceSubImageFullPathUrl.deletingPathExtension().lastPathComponent
//
//        let markedImageFullPathUrl = markedImageDirectroyUrl.appendingPathComponent(String(format: "%@%@_%@.json", sourceSubImageNameUrl, markedImageNameSuffix, LoginID))
//
//        return markedImageFullPathUrl
//    }
//
//    // -----------------------------------------------------------------------------
//    // 싱글 json 파일 경로 얻기 20200828
//    // -----------------------------------------------------------------------------
//    func getJsonFilePathOnServer(sourceImageFullPathOnServer:String, sequence:Int) -> URL {
//
//        let sourceImageFullPathUrl = URL(fileURLWithPath: sourceImageFullPathOnServer)
//        let sourceImageNameUrl = sourceImageFullPathUrl.deletingPathExtension().lastPathComponent
//
//        var markedImageDirectroyUrl = URL(fileURLWithPath: WorkingProjectImageDir)                                          // 20200826
//
//        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent("result")                                  // marked 추가
//        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent(LoginID)                                   // LoginID 추가
//
//        let markedImageFullPathUrl = markedImageDirectroyUrl.appendingPathComponent(String(format: "%@%@.json", sourceImageNameUrl, markedImageNameSuffix))
//
//        p(markedImageFullPathUrl.absoluteString)
//
//        return markedImageFullPathUrl
//    }


    func getMarkedImageDirectoryOnServer(serverSourceImagePath:String, imageId:String) -> URL {
        
        let serverSourceImageDir = URL(fileURLWithPath: WorkingProjectImageDir)
        
        var serverMarkedImageDir = serverSourceImageDir.appendingPathComponent("result")        // result
        serverMarkedImageDir = serverMarkedImageDir.appendingPathComponent(LoginID)             // 유저 추가
        p(serverMarkedImageDir.absoluteString)
        return serverMarkedImageDir
    }
    
    // -----------------------------------------------------------------------------
    // 서버로부터 다운 받은 이미지 tar 파일을 id 디렉토리에 풀어서 넣음
    // -----------------------------------------------------------------------------
    func extractImageTar(tarFileUrl file:URL, psgID id:String) {
        
        let source = file.path
        let dirPath = file.deletingLastPathComponent()
        let extractUrl = dirPath.appendingPathComponent(id)
        let extractPath = extractUrl.path

        let fileManager = FileManager.default
        
        do {
            let success = try fileManager.createFilesAndDirectories(path: extractPath, tarPath: source)
            //p("extractImageTar Result : \(success)")
            
            if success {
                let directoryContents = try FileManager.default.contentsOfDirectory(at: extractUrl, includingPropertiesForKeys: nil, options: [])
                //p(directoryContents)
                p("Untar 이미지 파일 갯수 : ", directoryContents.count)
            }
            else {
                p("PSG 이미지 압축 해제 에러")
                alertSimpleMessage("확인", "PSG 이미지 압축 해제 에러\n다시 로그인 후 재시도 하시기 바랍니다.\n지속적으로 문제 발생 시 관리자에 문의바랍니다.")
            }
        }
        catch let error as UntarError
        {
            p("extractImageTar : \(error.errorDescription!)")
            alertSimpleMessage("확인", "PSG 이미지 압축 해제 에러\n(\(error.errorDescription!))\n다시 로그인 후 재시도 하시기 바랍니다.\n지속적으로 문제 발생 시 관리자에 문의바랍니다.")
        }
        catch {
            p("extractImageTar : \(error.localizedDescription)")
            alertSimpleMessage("확인", "PSG 이미지 압축 해제 에러\n\(error.localizedDescription)\n다시 로그인 후 재시도 하시기 바랍니다.\n지속적으로 문제 발생 시 관리자에 문의바랍니다.")
        }
        
    }
    
    func getSubImageListFromDisk() -> (Bool, Int?) {
        
        // 이미지 파일의 디스크 경로
        let id = psgArray[currentImageIndex].id!
        let imageDirUrl = sourceVideoDirectoryURL!.appendingPathComponent(id)

        var sortedURLs:[URL]
        do {
            let directoryContents = try FileManager.default.contentsOfDirectory(at: imageDirUrl, includingPropertiesForKeys: nil, options: [])
            sortedURLs = directoryContents.sorted { a, b in
                                    return a.lastPathComponent.localizedStandardCompare(b.lastPathComponent) == ComparisonResult.orderedAscending
            }
        }
        catch {
            p("getSubImageListFromDisk error : \(error.localizedDescription)")
            return (false, -1)
        }

        // 이미지 목록
        var imageList:[SubImageInfo] = []
        var row_num = 0
        
        for fileUrl in sortedURLs {

            //p(fileUrl)
            
            row_num = row_num + 1
            
            let image_id:String = psgArray[currentImageIndex].id!
            let file_path:String = ""

            let imageInfo = SubImageInfo()
            imageInfo.row_num = row_num
            imageInfo.sub_image_id = image_id
            imageInfo.sub_server_location = file_path   // 20200814
            imageInfo.org_file_path = ""
            imageInfo.thu_file_path = ""
            
            imageInfo.mark_num = 0
            imageInfo.group = "default"
            imageInfo.newMarking = false
            imageInfo.newMarkedImage = nil
            imageInfo.isLabelingDone = false
            
            var labeling:LabelingLocationResult = LabelingLocationResult()    // 20200820
            labeling.target_cd = 0
            labeling.label_cd = -1
            labeling.memo = ""
            imageInfo.labelingResult.append(labeling)
            
            labeling = LabelingLocationResult()
            labeling.target_cd = 1
            labeling.label_cd = -1                                            // 무조건 -1 20200820. 타겟이 하나
            labeling.memo = ""
            imageInfo.labelingResult.append(labeling)
            
            imageInfo.fileUrl = fileUrl

            imageList.append(imageInfo)

        }
        
        subImageList.append(subImageList: imageList)
        
        return (true, 0)

    }
    
}
