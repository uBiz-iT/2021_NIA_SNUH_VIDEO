//
//  EventHandler.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/10.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    func eventSelected(event:EventInfo) {
        backupSelectedEvent = event.copy()
        setCurrentTime(seconds: eventArray[selectedEventIndex].begSecond!, method: .eventSelected)
    }

    func eventCheckAction(_ action:EVENT_ACTION) {
        
        switch action {
        case .allok:
            for event in eventArray {
                event.isChecked = true
                event.checkResult = 0
                event.isUpdated = !eventList.isSameWithBackup(eventSeq: event.eventSeq!)
                event.isMemoUpdated = !eventList.isSameMemoWithBackup(eventSeq: event.eventSeq!)
                event.isDataUpdated = !eventList.isSameDataWithBackup(eventSeq: event.eventSeq!)
            }
            break
        case .allng:
            for event in eventArray {
                event.isChecked = true
                event.checkResult = 1
                event.isUpdated = !eventList.isSameWithBackup(eventSeq: event.eventSeq!)
                event.isMemoUpdated = !eventList.isSameMemoWithBackup(eventSeq: event.eventSeq!)
                event.isDataUpdated = !eventList.isSameDataWithBackup(eventSeq: event.eventSeq!)
            }
            break
        case .reload:
            eventList.restoreAllFromBackup()
            break
        case .each:
            eventList.restoreAllFromUpdated()
            break
        case .save:
            eventList.removeDeletedEvent()
            eventList.copyAll()
            break
        }
        
        saveButton.isEnabled = isDataChanged && (!isManager)
        setEventResultText()
    }
    
    func setEventResultText(_ isModified:Bool = true) {

        checkResultLabel.text = ""

        if currentImageIndex >= 0 {
            
            var res:Int? = -1
            
//            let okPercent = eventList.count > 0 ? (Float(eventList.countByLabel(checkValue: 0)) / Float(eventList.count) * 100.0) : 0
            //let okPercentString = String(format: "%4.1f%%", okPercent)
            
            let passCountRate = eventList.count > 0 ? Float(eventList.doneCount) / Float(eventList.count) * 100.0 : 0
            let passCountRateString = String(format: "%4.1f%%", passCountRate)
            let passRate = eventList.doneCount > 0 ? Float(eventList.countByLabel(checkValue: 0)) / Float(eventList.doneCount) * 100.0 : 0
            let passRateString = String(format: "%4.1f%%", passRate)

            // true이면 계산, false이면 서버에서 받은대로 처리
            
            // 무조건 계산해서 추천값 표시 20210718
//            if isModified {
                if Float(eventList.doneCount) / Float(eventList.count) * 100.0 >= PASS_COUNT_RATE {
                    if Float(eventList.countByLabel(checkValue: 0)) / Float(eventList.doneCount) * 100.0 >= PASS_RATE {
                        res = 0
                    }
                    else {
                        res = 1
                    }
                }
                else {
                    res = -1
                }
//            }
//            else {
//                res = psgArray[currentImageIndex].psg_chk_res
//            }

            var restext = ""
            if res == 0 {
                restext = "Pass"
                checkResultLabel.textColor = UIColor.lightBlue
            }
            else if res == 1 {
                restext = "Fail"
                checkResultLabel.textColor = UIColor.youtubeRed
            }
            else {
                restext = "N/A"
                checkResultLabel.textColor = isDarkMode ? UIColor.white : UIColor.black
            }
            checkResultLabel.text = "\(restext) / (\(passRateString) OK)\(eventList.countByLabel(checkValue: 0))/\(eventList.doneCount)\n(\(passCountRateString) 완료)\(eventList.doneCount)/\(eventList.count)"
//            checkResultLabel.text = "(\(eventList.countByLabel(checkValue: 0)) OK,\(eventList.doneCount)/\(eventList.count))"
//            checkResultLabel.text = "\(restext)(\(eventList.countByLabel(checkValue: 0)) OK,\(eventList.doneCount)/\(eventList.count))"
        }
    }

    func saveAbnormalEvent() -> Bool {
        
        guard let videoBegDate = psgArray[currentImageIndex].video_begDT?.toDate() else {
            self.view.showToast(toastMessage: "비디오 시작 시간 정보가 없습니다.", duration: 1.0)
            return false
        }
        
        if isAlreadyEvent {
            let event = eventArray[selectedEventIndex]
            event.begDT = videoBegDate.addingTimeInterval(TimeInterval(abnormalViewBegSecond)).toYMDHMS()
            event.endDT = videoBegDate.addingTimeInterval(TimeInterval(abnormalViewEndSecond)).toYMDHMS()
            event.begSecond = Int(abnormalViewBegSecond)
            event.endSecond = Int(abnormalViewEndSecond)
            event.elapsedSeconds = event.endSecond! - event.begSecond!
            event.begEpoNo = event.begSecond! / snapShotGapTime
            event.endEpoNo = event.endSecond! / snapShotGapTime
            event.memo = abnormalMemoText.text!
            event.checkResult = 0   // 확인했으므로 OK

            event.isChecked = true
            event.isUpdated = !eventList.isSameWithBackup(eventSeq: event.eventSeq!)
            event.isMemoUpdated = !eventList.isSameMemoWithBackup(eventSeq: event.eventSeq!)
            event.isDataUpdated = !eventList.isSameDataWithBackup(eventSeq: event.eventSeq!)

            eventCheckType = 9
            saveButton.isEnabled = !isManager // 매니저가 아니면 무조건 enable
            setEventResultText()

            selectedEventIndex = -1
            eventTV.reloadData()

        }
        else {
            let event = EventInfo()
            event.eventSeq = eventList.maxSeqNewEvent() + 1
            event.eventName = "New event"
            event.begDT = videoBegDate.addingTimeInterval(TimeInterval(abnormalViewBegSecond)).toYMDHMS()
            event.endDT = videoBegDate.addingTimeInterval(TimeInterval(abnormalViewEndSecond)).toYMDHMS()
            event.begSecond = Int(abnormalViewBegSecond)
            event.endSecond = Int(abnormalViewEndSecond)
            event.elapsedSeconds = event.endSecond! - event.begSecond!
            event.begEpoNo = event.begSecond! / snapShotGapTime
            event.endEpoNo = event.endSecond! / snapShotGapTime
            event.memo = abnormalMemoText.text!
            event.checkResult = 0   // 확인했으므로 OK

            event.group = "default"
            event.note = ""
            event.typeName = "움직임 이벤트"
            
            event.isChecked = true
            event.isCreated = true
            
            // 추가하고 정렬 후 다시 가져옴
            eventList.append(eventInfo: event)
            eventList.sortWithBegTime()
            eventArray = eventList.eventsByGroup(group: "default")
            selectedEventIndex = -1
            eventTV.reloadData()

            eventGroupArray = eventList.typeList()
            eventKindArray = eventList.nameList()
            selectedEventGroupIndex = 0
            selectedEventKindIndex = 0
            eventGroupTV.reloadData()
            eventKindTV.reloadData()

            eventCheckType = 9
            saveButton.isEnabled = !isManager // 매니저가 아니면 무조건 enable
            setEventResultText()
            
            let index = eventList.indexByEventSeq(eventSeq: event.eventSeq!)
            let indexPath = IndexPath(item: index, section: 0)

            DispatchQueue.main.async { [self] in
                eventTV.scrollToRow(at: indexPath, at: .middle, animated: false)
                eventTV.layoutIfNeeded()
            }

        }
        
        if isAlreadyEvent {
        }

        return true
    }


    // -----------------------------------------------------------------------------------------------
    // 해당 시점에 해당하는 이벤트들 중 첫번재 것을 찾아서 이동
    // -----------------------------------------------------------------------------------------------
    func findFirstEvent(withTime second:Int) {

        // 이벤트 스크롤 중이면 무시
        if autoEventScrollTimeCount < autoEventScrollTimeOut {
            return
        }

        // 선택된 이벤트가 있으면 무시. 이벤트가 선택되었으면 리로드만 함.
        if selectedEventIndex >= 0 {
            // 이벤트 리로드를 너무 많이 하면 뻑뻑됨. 그래서 1초마다 한번씩만 하는 걸로
            let curDate = Date()
            if getSecondsBetweenDate(start: executeTimeEventReload, end: curDate) >= 1 {
                eventTV.reloadData()
                executeTimeEventReload = curDate
            }
            return
        }
        
        var found = false
        
        if let videoBegDate = psgArray[currentImageIndex].video_begDT?.toDate() {
//            if let index = eventArray.firstIndex(where: { second >= $0.begSecond! && second < $0.endSecond! }) {
            if let videoBegYMDHMS = videoBegDate.addingTimeInterval(TimeInterval(second)).toYMDHMS(),
               let index = eventArray.firstIndex(where: { videoBegYMDHMS >= $0.begDT! && videoBegYMDHMS < $0.endDT! }) {

                if index != befFoundFirstIndex {

                    found = true

                    let indexPath = IndexPath(row: index, section: 0)

                    DispatchQueue.main.async {
                        p("------ 이벤트 위치로 이동 시도 : \(videoBegYMDHMS), \(index)")
                        if (indexPath.row >= 0 && indexPath.row < self.eventTV.numberOfRows(inSection: 0)) {
                            self.eventTV.scrollToRow(at: indexPath, at: .middle, animated: false)
                            p("------ 이벤트 위치로 이동 완료")
                            self.eventTV.layoutIfNeeded()
                            self.eventTV.reloadData()
                            self.befFoundFirstIndex = index
                        }
                    }
                }
            }
        }
        
        if !found {
            // 이벤트 리로드를 너무 많이 하면 뻑뻑됨. 그래서 1초마다 한번씩만 하는 걸로
            let curDate = Date()
            if getSecondsBetweenDate(start: executeTimeEventReload, end: curDate) >= 1 {
                eventTV.reloadData()
                executeTimeEventReload = curDate
            }
        }
    }
    
    
    // -----------------------------------------------------------------------------------------------
    // 해당 시점이 이벤트의 시작과 종료 사이에 있는지 체크
    // -----------------------------------------------------------------------------------------------
    func isInEventRange(withSecond second:Int, event eventInfo:EventInfo) -> Bool {
        if second >= eventInfo.begSecond! && second < eventInfo.endSecond! {
            return true
        }
        else {
            return false
        }
    }

    // -----------------------------------------------------------------------------------------------
    // 해당 시점이 이벤트의 시작과 종료 사이에 있는지 체크
    // -----------------------------------------------------------------------------------------------
    func isInEventRange(withDate date:Date?, event eventInfo:EventInfo) -> Bool {
        if let compareDate = date,
           let begDate = eventInfo.begDT?.toDate(),
           let endDate = eventInfo.endDT?.toDate() {
            if compareDate >= begDate && compareDate < endDate {
                return true
            }
        }
        return false
    }

    
    func showEventKindView(_ isShown:Bool)  {

        let absoluteOrigin = eventRegionView.superview?.convert(eventRegionView.frame.origin, to: nil)
        
        if (isShown) {
            eventKindView.frame.origin.x = (absoluteOrigin?.x)! + eventRegionView.frame.size.width - eventKindView.frame.size.width
            eventKindView.frame.origin.y = (absoluteOrigin?.y)! - eventKindView.frame.size.height
            
            let y = eventKindView.frame.origin.y
            let height = eventKindView.frame.height
            eventKindView.frame.origin.y += height
            eventKindView.frame.size.height = 0

            UIView.animate(withDuration: 0.2, delay: 0, options: [.curveEaseIn],
                           animations: { [self] in
                            eventKindView.frame.origin.y = y
                            eventKindView.frame.size.height = height
                            eventKindView.layoutIfNeeded()
            }, completion: nil)
            eventKindView.isHidden = false
        }
        else {
            let height = eventKindView.frame.height
            UIView.animate(withDuration: 0.2, delay: 0, options: [.curveLinear],
                           animations: { [self] in
                            eventKindView.frame.origin.x = (absoluteOrigin?.x)! + eventRegionView.frame.size.width - eventKindView.frame.size.width
                            eventKindView.frame.origin.y = (absoluteOrigin?.y)!
                            eventKindView.frame.size.height = 0
                            eventKindView.layoutIfNeeded()
            },  completion: { [self] (_ completed: Bool) -> Void in
                eventKindView.isHidden = true
                eventKindView.frame.size.height = height
            })
        }
    }
    

}
