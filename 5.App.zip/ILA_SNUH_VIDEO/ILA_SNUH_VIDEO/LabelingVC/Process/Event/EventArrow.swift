//
//  EventArrow.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {
    
    func arrowEventFirst() {
        let num = 0
        if (eventArray.count == 0) {
            return
        }
        arrowEvent(num: num)
    }
    
    func arrowEventPrev() {
        let num = selectedEventIndex - 1
        if (num < 0) {
            self.view.showToast(toastMessage: "첫번째 이벤트 입니다.", duration: 0.5)
            return
        }
        arrowEvent(num:num)
    }

    func arrowEventPrevStep() {
        var num = selectedEventIndex - moveEventStepNumber
        if (eventArray.count == 0) {
            return
        }
        if (num < 0) {
            num = 0
        }
        arrowEvent(num: num)
    }

    func arrowEventNext() {
        let num = selectedEventIndex + 1
        if (num > eventArray.count - 1) {
            self.view.showToast(toastMessage: "마지막 이벤트 입니다.", duration: 0.5)
            return
        }
        arrowEvent(num:num)
    }

    func arrowEventNextStep() {
        var num = selectedEventIndex + moveEventStepNumber
        if (eventArray.count == 0) {
            return
        }
        if (num > eventArray.count - 1) {
            num = eventArray.count - 1
        }
        arrowEvent(num:num)
    }
    
    func arrowEventLast() {
        let num = eventArray.count - 1
        if (eventArray.count == 0) {
            return
        }
        arrowEvent(num:num)
    }

    func arrowEvent(num:Int) {
        
        if num < 0 { return }
        
        if (isVideoPlaying) {
            stopPlay()
            DoEvents(f: 0.1)
        }
        selectedEventIndex = num
        let indexPath = IndexPath(item: selectedEventIndex, section: 0)

        DispatchQueue.main.async { [self] in
            eventTV.scrollToRow(at: indexPath, at: .middle, animated: false)
            eventTV.layoutIfNeeded()

            UserDefaults.standard.set(selectedEventIndex, forKey: DefaultKey_EventIndex)
            WorkingEventIndex = selectedEventIndex

            eventSelected(event: eventArray[selectedEventIndex])
        }
    }
 
}
