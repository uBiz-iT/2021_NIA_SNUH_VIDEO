//
//  LabelingVC_Load_Event.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/05/19.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {

    // --------------------------------------------------------------------------
    // 이벤트 로딩
    // --------------------------------------------------------------------------
    func loadEventList() -> Bool? {
        
        eventList.removeAll()
        eventArray.removeAll()
        eventTV.reloadData()

        eventGroupArray.removeAll()
        eventGroupTV.reloadData()

        eventKindArray.removeAll()
        eventKindTV.reloadData()

        WorkingEventIndex = -1
        befFoundFirstIndex = -1

        selectedEventGroupIndex = -1
        selectedEventKindIndex = -1

        DoEvents(f: 0.01)
        
        let (success, code) = getEventList()
        if (success) {
            
            if (eventList.count == 0) {
                self.view.showToast(toastMessage: "이벤트 정보가 등록되어 있지 않습니다.", duration: 0.5)
                return true
            }
            else {
                eventArray = eventList.eventsByGroup(group: "default")
                eventTV.reloadData()

                eventGroupArray = eventList.typeList()
                selectedEventGroupIndex = 0
                eventGroupTV.reloadData()

                eventKindArray = eventList.nameList()
                selectedEventKindIndex = 0
                eventKindTV.reloadData()

                // 테스트를 위하여.. 삭제해야 함. (20210707)
                // ---------------------------------------
                if eventArray.count > 0 {
                    psgArray[currentImageIndex].video_begDT = eventArray[0].begDT
                }
                // --------------------------------------- 여기까지

                setEventResultText()
                
                // 20201110 if 추가
//                if (isReloadTapped) {
//                    WorkingEventIndex = selectedEventIndex
//                }
                
                selectedEventIndex = WorkingEventIndex
                
                if selectedEventIndex >= 0 {
                    eventTV.scrollToRow(at: IndexPath(row: selectedEventIndex, section: 0), at: .middle, animated: false)
                    eventTV.layoutIfNeeded()
                }
                eventTV.reloadData()

                eventCheckType = 9
            }
        }
        else {
            handlingDbError(code: code!, self)
//            if (needToLogin(errno: code!)) {
//                DispatchQueue.main.async() {
//                    isLogin = false
//                    self.performSegue(withIdentifier: "segueLoginOut", sender: nil)
//                }
//            }
//            else {
//                self.view.showToast(toastMessage: "   이벤트 정보를 불러오는 중에 에러가 발생하였습니다.   \n재시도하여 주시기 바랍니다.", duration: 0.6)
//            }
            return false
        }
        return true
    }
}
