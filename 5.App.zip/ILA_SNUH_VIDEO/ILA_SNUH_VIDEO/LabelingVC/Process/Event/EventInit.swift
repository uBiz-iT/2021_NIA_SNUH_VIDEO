//
//  EventInit.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    enum EVENT_ACTION:Int {
        case allok = 0, allng, each, reload, save
    }

    func viewDidLoad_Event() {
        
        setButtonProperty(button: eventMenuButton)
        setButtonProperty(button: eventFirstButton)
        setButtonProperty(button: eventLastButton)
        setButtonProperty(button: eventGoSelectedRowButton)
        setButtonProperty(button: eventUpButton)
        setButtonProperty(button: eventDownButton)

        // ----------------------------
        // 이벤트 테이블 뷰
        // ----------------------------
        initEventTableView()
        eventCheckType = 9
        setEventResultText()

        eventKindView.isHidden = true
        eventKindView.clipsToBounds = true
        eventKindView.frame.size.width = 356
        eventKindView.frame.size.height = 310
        
    }
    
    func initEventTableView() {
        
        eventTV.delegate = self
        eventTV.dataSource = self
        eventTV.tag = 11

        let nibName = UINib(nibName: "LabelingVC_TV_EVENTCELL", bundle: nil)
        let nibNameP = UINib(nibName: "LabelingVC_TV_EVENTCELL_P", bundle: nil)
        eventTV.register(nibName, forCellReuseIdentifier: "EventCellId")
        eventTV.register(nibNameP, forCellReuseIdentifier: "EventCellId_P")
        
        eventGroupTV.delegate = self
        eventGroupTV.dataSource = self
        eventGroupTV.tag = 301

        eventKindTV.delegate = self
        eventKindTV.dataSource = self
        eventKindTV.tag = 302

    }
    
    func clearEvent() {
        eventList.removeAll()

        eventArray.removeAll()
        eventTV.reloadData()

        eventGroupArray.removeAll()
        eventGroupTV.reloadData()

        eventKindArray.removeAll()
        eventKindTV.reloadData()
        
        setEventResultText()
    }
    
}
