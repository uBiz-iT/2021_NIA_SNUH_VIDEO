//
//  PlayerVideoLoad.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/12.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import AVKit
import AVFoundation

extension LabelingVC {

    // --------------------------------------------------------------------------
    // 동영상 파일 다운로드 관련 화면 표시 그리고 동영상 로드
    // --------------------------------------------------------------------------
    func loadVideo(psgIndex:Int) {
        
        if (psgArray[psgIndex].videoDownloadFlag == .completed) {
        
            setPlayerDisplayObjectProperty(psgIndex: psgIndex, isDown: true)
            
            if let url = psgArray[psgIndex].videoFileUrl {
                preparePlayer(fileURL: url as NSURL)
            }
            else {
                p("loadVideo : 비디오 파일 없음, \(psgArray[psgIndex].videoDownloadFlag)")
            }

        }
        else {
            resetPlayer()
            resetAbnormalObject()
            playerView.layoutIfNeeded()

            setPlayerDisplayObjectProperty(psgIndex: psgIndex, isDown: false)
            
            if canDownloadStatus(psgArray[psgIndex].videoDownloadFlag) {
                pushDownloadVideo(index: psgIndex)
                DispatchQueue.main.async { [self] in
                    collectionViewMainImage.reloadItems(at: [IndexPath(item: psgIndex, section: 0)])
                }
            }
        }
        
    }
    
    // --------------------------------------------------------------------------
    // 이미지 tar 파일 다운로드 관련 화면 표시
    // --------------------------------------------------------------------------
    func checkTarFileStatus(psgIndex:Int) {
        if (psgArray[psgIndex].tarDownloadFlag == .completed) {
            downloadingTarIndicator.stopAnimating()
            downloadTarProgress.isHidden = true
            downloadImageProgressLabel.isHidden = true
        }
        else {
            downloadingTarIndicator.startAnimating()
            downloadTarProgress.isHidden = false
            downloadImageProgressLabel.isHidden = false
            downloadTarProgress.progress = psgArray[psgIndex].tarDownloadProgress
            downloadImageProgressLabel.text = "다운로드 대기중"
            downloadImageProgressLabel.layoutIfNeeded()
        }
    }
    
    
    func preparePlayer(videoName:String, videoType:String) {
        if let filePath = Bundle.main.path(forResource: videoName, ofType: videoType) {
            let fileURL = NSURL(fileURLWithPath: filePath)
            preparePlayer(fileURL: fileURL)
        }
    }
    
    
    func preparePlayer(fileURL:NSURL) {

        resetPlayer()
        resetAbnormalObject()

        videoPlayer = VideoPlayer(urlAsset: fileURL, view: playerView, startAutoPlay: false, repeatAfterEnd: false, gravity: videoGravity, timeRangeMultiplier: videoMultiplier)
        if let player = videoPlayer {
            isReadyPlay = false
            player.playerRate = playSpeed
            player.isMuted = !isSoundOn
            player.delegate = self
        }

    }


}
