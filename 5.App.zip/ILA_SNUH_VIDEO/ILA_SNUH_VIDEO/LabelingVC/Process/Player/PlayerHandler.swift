//
//  PlayerHandler.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/12.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    // -----------------------------------------------------------------------------------------------
    // 타임 슬라이더의 특정 위치 Tap할 경우 해당 위치로 이동시키기 위함
    // -----------------------------------------------------------------------------------------------
    @objc func sliderTapped(gestureRecognizer: UIGestureRecognizer) {

        let pointTapped: CGPoint = gestureRecognizer.location(in: self.view)
        //pointTapped.x -= 30  //Subtract left constraint (distance of the slider's origin from "self.view"

        let positionOfSlider: CGPoint = timeSlider.frame.origin
        let widthOfSlider: CGFloat = timeSlider.frame.size.width

        // 탭 위치가 슬라이더 현 위치와 너무 가까우면 무시
        let thumbPosition = CGFloat((timeSlider.value / timeSlider.maximumValue)) * widthOfSlider
        let diff = abs(pointTapped.x - thumbPosition)
        let minDistance: CGFloat = 10                       // 필요하면 조정

        if diff < minDistance {
            print("너무 가까움")
            return
        }

        var newValue: CGFloat
        if pointTapped.x < 10 {
            newValue = 0
        } else {
            newValue = ((pointTapped.x - positionOfSlider.x) * CGFloat(timeSlider.maximumValue) / widthOfSlider)
        }

        setCurrentTime(seconds: Float(newValue), method: .other)
    }
    
    // -----------------------------------------------------------------------------------------------
    // 타임 슬라이더 섬네일을 끄는 동작 캐치(타임 슬라이더 값 변경시 Value Changed 이벤트를 사용하지 않고 이렇게 함)
    // play 중에 값 변경작업을 하면 타임슬라이더 섬네일이 매끄럽지 못하여 이 방식으로 함
    // -----------------------------------------------------------------------------------------------
    @objc func onTimeSliderValChanged(slider: UISlider, event: UIEvent) {
        
        if let touchEvent = event.allTouches?.first {
            switch touchEvent.phase {
            case .began:
                // 오토 스크롤 on하기 위함
                autoScrollTimeCount = autoScrollTimeOut
                autoEventScrollTimeCount = autoEventScrollTimeOut
                isTimeSliderValueChanging = true
                if isVideoPlaying {
                    if let vp = videoPlayer {
                        vp.pause()
                    }
                }
                break
            case .moved:
                setCurrentTime(seconds: slider.value, method: .timeSliderChanged)
                break
            case .ended:
                if isVideoPlaying {
                    if let vp = videoPlayer {
                        vp.play()
                    }
                }
                isTimeSliderValueChanging = false
                break
            default:
                break
            }
        }
    }
    
    // ------------------------------------------------------------------------
    // 자동 정지할 지 체크
    // ------------------------------------------------------------------------
    func checkStopVideo(withTime second:Int) {
        
        if !isVideoPlaying { return }
        
        // 이벤트가 선택되었으면 이벤트 종료지점까지 플레이하고 멈추자..
        if selectedEventIndex >= 0 {
            if let endSec = eventArray[selectedEventIndex].endSecond {
                if second >= Int(endSec) {
                    stopPlay()
                    setCurrentTime(seconds: Int(endSec), method: .autoStop)
                }
            }
        }

        // 이상행동 뷰가 떠 있으면...
        if isShowAbnormalView {
            if second >= Int(abnormalViewEndSecond) {
                stopPlay()
                setCurrentTime(seconds: abnormalViewEndSecond, method: .autoStop)
            }
        }
    }
    
    // -----------------------------------------------------------------------------------------------
    // gravity 설정
    // -----------------------------------------------------------------------------------------------
    func setGravity(_ gravity:AVLayerVideoGravity) {
        videoGravity = gravity
        if let vp = videoPlayer {
            vp.gravity = gravity
        }
    }
    
    // -----------------------------------------------------------------------------------------------
    // 사운드 on/off
    // -----------------------------------------------------------------------------------------------
    func setSoundOn(_ isOn:Bool) {
        isSoundOn = isOn
        if let vp = videoPlayer {
            vp.isMuted = !isOn
        }
    }
    
    // -----------------------------------------------------------------------------------------------
    // play 배속 설정
    // -----------------------------------------------------------------------------------------------
    func setSpeed(_ speed:Float) {
        playSpeed = speed
        if let vp = videoPlayer {
            vp.playerRate = speed
        }
    }
    
    // -----------------------------------------------------------------------------------------------
    // play start/stop toggle
    // -----------------------------------------------------------------------------------------------
    func togglePlay() {
        if (isVideoPlaying) {
            stopPlay()
        }
        else {
            if isShowAbnormalView && currentTime.seconds >= Double(abnormalViewEndSecond) {
                setCurrentTime(seconds: abnormalViewBegSecond, method: .buttonPressed)
            }
            else if selectedEventIndex >= 0 {
                if currentTime.seconds >= Double(eventArray[selectedEventIndex].endSecond!) {
                    setCurrentTime(seconds: eventArray[selectedEventIndex].begSecond!, method: .buttonPressed)
                }
            }
            startPlay()
        }
    }

    // -----------------------------------------------------------------------------------------------
    // play
    // -----------------------------------------------------------------------------------------------
    func startPlay() {
        
        if (eventKindView.isHidden == false) {
            eventKindView.isHidden = true
        }

        if let vp = videoPlayer {
            isVideoPlaying = true
            vp.play()
        }
    }
    
    // -----------------------------------------------------------------------------------------------
    // play stop
    // -----------------------------------------------------------------------------------------------
    func stopPlay() {
        if let vp = videoPlayer {
            isVideoPlaying = false
            vp.removePeriodicalObserver()
            vp.pause()
            vp.addPeriodicalObserver()
        }
    }
    
    // -----------------------------------------------------------------------------------------------
    // 앞으로 이동
    // -----------------------------------------------------------------------------------------------
    func jumpForward() {
        setCurrentTime(seconds: Float(currentTime.seconds) + Float(jumpStep), method: .buttonPressed)
    }
    
    // -----------------------------------------------------------------------------------------------
    // 뒤로 이동
    // -----------------------------------------------------------------------------------------------
    func jumpBackward() {
        setCurrentTime(seconds: Float(currentTime.seconds) - Float(jumpStep), method: .buttonPressed)
    }
    
    // -----------------------------------------------------------------------------------------------
    // 비디오의 해당 위치(시간)로 이동
    // -----------------------------------------------------------------------------------------------
    func seekVideoPosition(seconds value:Float) {
        
        if let vp = videoPlayer {
            vp.removePeriodicalObserver()
            vp.seekToPosition(seconds: Float64(value))
            vp.addPeriodicalObserver()
        }
    }
    
}
