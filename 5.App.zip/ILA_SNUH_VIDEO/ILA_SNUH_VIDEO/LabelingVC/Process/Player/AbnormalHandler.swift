//
//  AbnormalHandler.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/10.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    func blinkAbnormalViewTitle() {
        abnormalViewTitleLabel.backgroundColor = UIColor.lightGray
        var backgroundColorIsRed = false
        Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) {timer in
            backgroundColorIsRed.toggle()
            if self.isAlreadyEvent {
                self.abnormalViewTitleLabel.backgroundColor = .systemBlue
                self.abnormalViewTitleLabel.textColor = .white
            }
            else {
                self.abnormalViewTitleLabel.backgroundColor = backgroundColorIsRed ? .systemPink : UIColor.white
                self.abnormalViewTitleLabel.textColor = backgroundColorIsRed ? .white : UIColor.black
            }
        }
    }

    // -----------------------------------------------------------------------------------------------
    // snapshot/ screenshot collection view 변수 선언부
    // -----------------------------------------------------------------------------------------------
    class SnapShotImageInfo {
        var time:CMTime = .zero {
            didSet {
                seconds = time.seconds
                secondsInt = Int(seconds)
            }
        }
        var seconds:Double = 0.0
        var secondsInt:Int = 0
        var image:UIImage?
        var ciImage:CIImage?
    }
    
    class CreatedAbnormal {
        var begSecond:Int = -1
        var endSecond:Int = -1
        var isInsert:Bool = false
    }

    // 이상행동 처리 뷰가 보이고 안보일때 재생멈춤
    func showAbnormalView(isAlready:Bool, eventName:String, begSec:Int, endSec:Int, seq:Int = -1) {
        isAlreadyEvent = isAlready
        isShowAbnormalView = true
        abnormalView.isHidden = false
        stopPlay()
        abnormalViewBegSecond = Float(begSec)
        abnormalViewEndSecond = Float(endSec)
        if isAlready {
            abnormalViewTitleLabel.text = "이벤트 확인 (\(seq), \(eventName))"
            saveAbnormalBehaviorButton.setTitle(isAlready ? "이벤트 수정" : "이벤트 추가", for: .normal)
        }
        else {
            abnormalViewTitleLabel.text = "이벤트 확인 (\(eventName))"
            saveAbnormalBehaviorButton.setTitle(isAlready ? "이벤트 수정" : "이벤트 추가", for: .normal)
        }
        abnormalMemoText.text = ""
        setCurrentTime(seconds: abnormalViewBegSecond, method: .other)
    }
    
    func hideAbnormalView() {
        if (abnormalMemoText.isFirstResponder) {
            abnormalMemoText.resignFirstResponder()
        }
        isShowAbnormalView = false
        abnormalView.isHidden = true
    }
    

    // 지정된 시간보다 이후이거나 종료시간이 결정되지 않은 것은 삭제 처리
    func removeAllAfterSecond(second:Int) {
        createdAbnormalList.removeAll { $0.begSecond >= second }
        createdAbnormalList.removeAll { $0.endSecond < 0 }
    }
    
    // ------------------------------------------------------------------------
    // 이상행동 여부 체크
    // ------------------------------------------------------------------------
    func checkAbnormalBehavior(withTime time:CMTime) {
        
        if !isAbnormalAutoCreate {
            return
        }

        let diffSeconds =  (playSpeed / Float(videoMultiplier)) <= 10 ? 1.0 : 1.0
        if time.seconds >= (curSnapshot.seconds + Double(diffSeconds)) {

            guard let vp = videoPlayer else { return }

            befSnapshot.time = curSnapshot.time
            befSnapshot.ciImage = curSnapshot.ciImage?.copy() as? CIImage

            curSnapshot.time = CMTime(seconds: Double(Int(time.seconds)), preferredTimescale: CMTimeScale(NSEC_PER_SEC))

            // 스냅샷 이미지를 그레이 스케일로 받아옴
            curSnapshot.ciImage = vp.getScreenshotCIImage(picktime: time)?.blackAndWhite

            if befSnapshot.ciImage == nil || curSnapshot.ciImage == nil {
                p("이미지가 nil임")
                isAbnormalStatus = false
            }
            else {
                let isAbnormal = isDetectMotion()
                
                // 이전 상태와 현재 상태가 다르면(정상->움직임, 움직임->정상)
                if isAbnormalStatus != isAbnormal {
                    if isAbnormal {
                        //p("befSnapshot.seconds : \(befSnapshot.seconds)")
                        abnormalBegSecond = Float(befSnapshot.seconds)
                        if !isTimeSliderValueChanging && !isTimeLineMoving {
                        }
                    }
                    else {
                        abnormalEndSecond = Float(befSnapshot.seconds)

                        // 아래의 경우에는 이상행동 처리 뷰를 보여주지 않음
                        // 타임 슬라이더 조정중, 타임 라인 조정중, 이벤트 선택, 이상행동 처리 뷰가 이미 떠 있는 중
                        if !isTimeSliderValueChanging && !isTimeLineMoving && selectedEventIndex < 0 && !isShowAbnormalView {

                            if let videoBegDate = psgArray[currentImageIndex].video_begDT?.toDate() {
                                // 이벤트존재구간건너뛰기가 true이고 존재하면 Reset하고 그냥 넘어감
                                if (isPassIfExistEvent && eventList.existEvent(begSec: videoBegDate.addingTimeInterval(TimeInterval(abnormalBegSecond)).toYMDHMS(), endSec: videoBegDate.addingTimeInterval(TimeInterval(abnormalEndSecond)).toYMDHMS() )) {
                                    abnormalBegSecond = -1
                                    abnormalEndSecond = -1
                                    isAbnormalStatus = false
                                }
                                else {
                                    showAbnormalView(isAlready: false, eventName: "신규이벤트", begSec: Int(abnormalBegSecond), endSec: Int(abnormalEndSecond))
                                }
                            }

                        }
                    }
                    isAbnormalStatus = isAbnormal
                }
            }
        }
        else if time.seconds < curSnapshot.seconds - 0.2 {
            initSnapshot(time: time)
        }

    }
    
    // ------------------------------------------------------------------------
    // 이상행동 여부 체크
    // ------------------------------------------------------------------------
//    func checkAbnormalBehavior_20210628(withTime time:CMTime) {
//
//        if !isAbnormalAutoCreate {
//            return
//        }
//
//        let diffSeconds =  (playSpeed / Float(videoMultiplier)) <= 10 ? 1.0 : 1.0
//        if time.seconds >= (curSnapshot.seconds + Double(diffSeconds)) {
//
//            guard let vp = videoPlayer else { return }
//
//            befSnapshot.time = curSnapshot.time
//            befSnapshot.image = curSnapshot.image?.copy()
//
//            curSnapshot.time = CMTime(seconds: Double(Int(time.seconds)), preferredTimescale: CMTimeScale(NSEC_PER_SEC))
//
//            // 스냅샷 이미지를 그레이 스케일로 받아옴
//            curSnapshot.image = vp.screenshot(picktime: time)?.blackAndWhite
//
//            if befSnapshot.image == nil || curSnapshot.image == nil {
//                p("이미지가 nil임")
//                isAbnormalStatus = false
//            }
//            else {
//                let isAbnormal = isAbnormalBehavior()
//
//                // 이전 상태와 현재 상태가 다르면(정상->움직임, 움직임->정상)
//                if isAbnormalStatus != isAbnormal {
//                    if isAbnormal {
//                        p("befSnapshot.seconds : \(befSnapshot.seconds)")
//                        abnormalBegSecond = Float(befSnapshot.seconds)
//                        if !isTimeSliderValueChanging && !isTimeLineMoving {
//                        }
//                    }
//                    else {
//                        abnormalEndSecond = Float(befSnapshot.seconds)
////                        abnormalEndSecond = Float(Int(time.seconds))
//
//                        // 아래의 경우에는 이상행동 처리 뷰를 보여주지 않음
//                        // 타임 슬라이더 조정중, 타임 라인 조정중, 이벤트 선택, 이상행동 처리 뷰가 이미 떠 있는 중
//                        if !isTimeSliderValueChanging && !isTimeLineMoving && selectedEventIndex < 0 && !isShowAbnormalView {
//                            showAbnormalView(isAlready: false, eventName: "신규이벤트", begSec: Int(abnormalBegSecond), endSec: Int(abnormalEndSecond))
//                        }
//                    }
//                    isAbnormalStatus = isAbnormal
//                }
//            }
//        }
//        else if time.seconds < curSnapshot.seconds - 0.2 {
//            initSnapshot(time: time)
//        }
//
//    }
    
    // ------------------------------------------------------------------------
    // 2개의 이미지가 동일한지 스레쉬홀드 값을 기준으로 판단
    // ------------------------------------------------------------------------
    func isDetectMotion() -> Bool {
        
        guard let diffCIImage = computeImageDifference(befSnapshot.ciImage, curSnapshot.ciImage) else { return false }

        DiffImage.image = UIImage(ciImage: diffCIImage)
        
        guard let histogramCIImage = diffCIImage.histogramDisplayForPSG else { return false }

        testImageViewOut.image = UIImage(ciImage: histogramCIImage)

        let (redArray, _, _, _) = histogramCIImage.histogramArray()
        
        guard let cg = convertCIImageToCGImage(inputImage: histogramCIImage) else { return false }
        
        let total = Float(cg.width * cg.height)
        let rate = Float(Int(Float(redArray[63])/total*Float(10000))) / Float(100)

        var isAbnormal = false
        isAbnormal =  rate  >= abnormalThresholdSlider.value

        diffRate = rate
        
        // p("rate : \(rate)")

        return isAbnormal
    }
    
//    func isDetectMotion() -> Bool {
//
//        guard let diffImage = computeImageDifference(befSnapshot.image, curSnapshot.image) else { return false }
//
//        DiffImage.image = diffImage
//
//        guard let histogramImage = diffImage.histogramDisplayForPSG else { return false }
//
////        let rect = CGRect(x: 0, y: 0, width: 10 , height: 60)
////        testImageViewOut.image = histogramImage.crop(rect: rect)
//        testImageViewOut.image = histogramImage
//
//        let (redArray, _, _, _) = histogramImage.histogramArray()
//
//        let total = Float(histogramImage.size.width * histogramImage.size.height)
//        let rate = Float(Int(Float(redArray[63])/total*Float(10000))) / Float(100)
//
//        var isAbnormal = false
//        isAbnormal =  rate  >= abnormalThresholdSlider.value
//
//        diffRate = rate
//
//        return isAbnormal
//    }
    
    // ------------------------------------------------------------------------
    // 2개의 이미지의 차이를 새로운 이미지로 생성
    // ------------------------------------------------------------------------
    func computeImageDifference(_ inputImage:UIImage?, _ inputImage2:UIImage?) -> UIImage? {
        
        guard let image1 = inputImage,
              let image2 = inputImage2
        else {
            return nil
        }
        
        let beginImage = CIImage(image: image1)
        let beginImage2 = CIImage(image: image2)
        let context = CIContext()
        let currentFilter = CIFilter.colorAbsoluteDifference()
        currentFilter.inputImage = beginImage
        currentFilter.inputImage2 = beginImage2
        
        guard let outputImage = currentFilter.outputImage
        else {
            return nil
        }
        
        if let cgimg = context.createCGImage(outputImage, from: outputImage.extent) {
            return UIImage(cgImage: cgimg)
        }
        return nil
    }
    
    // ------------------------------------------------------------------------
    // 2개의 이미지의 차이를 새로운 이미지로 생성
    // ------------------------------------------------------------------------
    func computeImageDifference(_ inputImage:CIImage?, _ inputImage2:CIImage?) -> CIImage? {
        
        guard let image1 = inputImage,
              let image2 = inputImage2
        else {
            return nil
        }
        
        let beginImage = image1
        let beginImage2 = image2
        let currentFilter = CIFilter.colorAbsoluteDifference()
        currentFilter.inputImage = beginImage
        currentFilter.inputImage2 = beginImage2
        
        guard let outputImage = currentFilter.outputImage
        else {
            return nil
        }
        
        return outputImage
        
    }
    
    // -----------------------------------------------------------------------------------------------
    // 동영상 파일의 스냅샷을 PSG 이미지의 단위 시간 단위로 가져와서 배열에 담기
    // -----------------------------------------------------------------------------------------------
    func loadSnapShotImages() {
        
        var pickTime = CMTime.zero
        var numberOfShot:Int = 1000
        
        snapShotImageArray.removeAll()
        
        if duration <= CMTime.zero {
            return
        }
        
        numberOfShot = Int(CMTimeGetSeconds(duration) / Float64(snapShotGapTime))
        let remain = CMTimeGetSeconds(duration).truncatingRemainder(dividingBy: Float64(snapShotGapTime))
        if remain > 0 {
            numberOfShot = numberOfShot + 1
        }
        
        var snapshotParsingStarted = true   // snapshot 만들기 시작
        var snapshotCount = numberOfShot    // snapshot 만들 것 남아 있는 양

        for i in 0..<numberOfShot {
            pickTime = CMTimeMakeWithSeconds(Float64(snapShotGapTime) * Double(i), preferredTimescale: 1)
            videoPlayer?.screenshot(picktime:pickTime) { [self] (time, image) in
                DispatchQueue.main.async {
                    let snapShot = SnapShotImageInfo()
                    snapShot.time = time
                    snapShot.image = image
                    snapShotImageArray.append(snapShot)
                    snapshotCount = snapshotCount - 1
                    if snapshotParsingStarted && snapshotCount <= 0 {
                        snapshotParsingStarted = false
                        collectionViewThumbnail.reloadData()
                    }
                }
            }
        }
    }
    
    func calcThresHoldWithArea(videoRect:CGRect, markRect:CGRect) {

        let vw = videoRect.width
        let vh = videoRect.height
        
        let mw = markRect.width
        let mh = markRect.height
        
        // p("view width, height : vw=\(vw), wh=\(vh), mw=\(mw), mh=\(mh)")
        
        let vArea = vw * vh
        let mArea = mw * mh

        if vArea == 0 {
            return
        }
        
        let vSqrt = sqrt(vArea)
        let mSqrt = sqrt(mArea)
        
        let rate = mSqrt / vSqrt
        let thresHold = Float(Int(rate * 4 * 100)) / 10
//        let rate2 = ((rate * 100) * (rate * 100)) / 100
//        let thresHold = Float(Int(rate2 * 40)) / 10

        p("thresHold : \(thresHold)")
        abnormalThresholdSlider.value = thresHold
        abnormalThresholdValue.text = "\(abnormalThresholdSlider.value)"

    }
}
