//
//  PlayerInit.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    // 화면 채우기 옵션
    enum EnumVideoGravity:Int, CaseIterable {
        case x0 = 0, x1, x2
        var value:AVLayerVideoGravity { get {
            switch self {
            case .x0: return .resizeAspect
            case .x1: return .resize
            case .x2: return .resizeAspectFill
            }
        }}
        var title:String { get {
            switch self {
            case .x0: return "기본"
            case .x1: return "늘리기"
            case .x2: return "채우기"
            }
        }}
        init() {
            self = .x0
        }
        var defaultIndex:Int {
            get { return 0 }
        }
    }

    // 재생 속도 설정
    enum EnumSpeed:Int, CaseIterable {
        case x0 = 0, x1, x2, x3, x4, x5
        var value:Float { get {
            switch self {
            case .x0: return 1
            case .x1: return 1.5
            case .x2: return 2
            case .x3: return 5
            case .x4: return 10
            case .x5: return 20
            }
        }}
        var title:String { get {
            switch self {
            case .x0: return "1x"
            case .x1: return "1.5x"
            case .x2: return "2x"
            case .x3: return "5x"
            case .x4: return "10x"
            case .x5: return "20x"
            }
        }}
        init() {
            self = .x0
        }
        var defaultIndex:Int {
            get { return 4 }
        }
    }
    
    // 건너뛰기 시간 설정
    enum EnumJumpStep:Int, CaseIterable {
        case s1 = 0, s2, s3, s4, s5
        var value:Float { get {
            switch self {
            case .s1: return 30
            case .s2: return 60
            case .s3: return 300
            case .s4: return 600
            case .s5: return 1800
            }
        }}
        var title:String { get {
            switch self {
            case .s1: return "30초"
            case .s2: return "1분"
            case .s3: return "5분"
            case .s4: return "10분"
            case .s5: return "30분"
            }
        }}
        var defaultIndex:Int {
            get { return 2 }
        }

    }
    
    func viewDidLoad_Player() {
        
        isAbnormalAutoCreate = false

        // -----------------------------------------------------------
        // 플레이어 스크롤 뷰안의 플레이어 뷰 frame 초기화
        // -----------------------------------------------------------
        playerView.frame.origin.x = 0
        playerView.frame.origin.y = 0
        playerView.frame.size.width = playerScroll.frame.size.width
        playerView.frame.size.height = playerScroll.frame.size.height

        playButton.tintColor = UIColor.white
        lastButton.tintColor = playButton.tintColor
        firstButton.tintColor = playButton.tintColor
        forwardButton.tintColor = playButton.tintColor
        backwardButton.tintColor = playButton.tintColor

        setButtonProperty(button: showAbnormalViewButton)
        setButtonProperty(button: abnormalPlayFirstButton)
        setButtonProperty(button: abnormalPlayLastButton)
        setButtonProperty(button: abnormalPlayButton)
        setButtonProperty(button: saveAbnormalBehaviorButton)
        setButtonProperty(button: closeAbnormalViewButton)
        setButtonProperty(button: abnormalBegChangeButton)
        setButtonProperty(button: abnormalEndChangeButton)

        abnormalPlayFirstButton.setTitle("", for: .normal)
        abnormalPlayLastButton.setTitle("", for: .normal)
        abnormalPlayButton.setTitle("", for: .normal)
        abnormalPlayFirstButton.setImage(backwardImage, for: .normal)
        abnormalPlayLastButton.setImage(forwardImage, for: .normal)
        
        speedSegmented.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.yellow], for: .selected)
        speedSegmented.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.white], for: .normal)

        jumpStepSegmented.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.yellow], for: .selected)
        jumpStepSegmented.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.white], for: .normal)

        gravitySegmented.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.yellow], for: .selected)
        gravitySegmented.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.white], for: .normal)

        if #available(iOS 13.0, *) {
            speedSegmented.selectedSegmentTintColor = .gray
            jumpStepSegmented.selectedSegmentTintColor = .gray
            gravitySegmented.selectedSegmentTintColor = .gray
        } else {
            speedSegmented.tintColor = .gray
            jumpStepSegmented.tintColor = .gray
            gravitySegmented.tintColor = .gray
        }

        // ----------------------------
        // 플레이어 20200320
        // ----------------------------
        initPlayerObjects()

        if #available(iOS 13.0, *) {
            currentTimeLabel.font = .monospacedSystemFont(ofSize: 12, weight: .regular)
            currentTimeLargeLabel.font = .monospacedSystemFont(ofSize: 23, weight: .regular)
            durationLabel.font = .monospacedSystemFont(ofSize: 12, weight: .regular)
            checkResultLabel.font = .monospacedSystemFont(ofSize: 15, weight: .regular)
            downloadVideoProgressLabel.font = .monospacedSystemFont(ofSize: 17, weight: .regular)
            downloadImageProgressLabel.font = .monospacedSystemFont(ofSize: 17, weight: .regular)
        } else {
            currentTimeLabel.font = .monospacedDigitSystemFont(ofSize: 12, weight: .regular)
            currentTimeLargeLabel.font = .monospacedDigitSystemFont(ofSize: 23, weight: .regular)
            durationLabel.font = .monospacedDigitSystemFont(ofSize: 12, weight: .regular)
            checkResultLabel.font = .monospacedDigitSystemFont(ofSize: 15, weight: .regular)
            downloadVideoProgressLabel.font = .monospacedDigitSystemFont(ofSize: 17, weight: .regular)
            downloadImageProgressLabel.font = .monospacedDigitSystemFont(ofSize: 17, weight: .regular)
        }
        checkResultLabel.numberOfLines = 2
        checkResultLabel.lineBreakMode = .byWordWrapping
        
        downloadingIndicator.color = .yellow
        downloadingIndicator.style = .medium

        abnormalThresholdSlider.minimumValue = 1
        abnormalThresholdSlider.maximumValue = 30
        abnormalThresholdSlider.value = 3.5
        abnormalThresholdValue.text = "\(abnormalThresholdSlider.value)"
        
        downloadVideoProgress.tintColor = .white
        
        hideAbnormalView()
        
        abnormalView.center = view.center
        abnormalView.layer.borderWidth = 3
        abnormalView.layer.borderColor = UIColor.lightGray.cgColor
        abnormalView.frame.size.width = 410
        abnormalView.frame.size.height = 216
        
        blinkAbnormalViewTitle()
        blinkPlayTypeLabel()

        drawModeInfo.isHidden = true
        
        setButtonProperty(button: drawModeButton)
        drawModeButton.titleLabel!.lineBreakMode = .byCharWrapping;
        drawModeButton.titleLabel!.textAlignment = .center;
        drawModeButton.setTitle("Threshold\n추천값 설정", for: .normal)
    }
    
    func initPlayerObjects() {
        initPlayerUIControls()
        initPlayerGesture()
        initPlayerScrollView()
    }
    
    func resetPlayer() {
        if isDrawMode {
            drawMode(drawModeButton!)
        }
        if let vp = videoPlayer {
            stopPlay()
            DoEvents(f: 0.1)
            timeSlider.setValue(0, animated: false)
            vp.cleanUp()
        }
        playerView.player = nil
        videoPlayer = nil
        playerScroll.zoomScale = 1.0
    }
    
    func resetAbnormalObject() {
        abnormalBegSecond = -1
        abnormalEndSecond = -1
        hideAbnormalView()
        setCurrentTime(time: .zero, method: .other)
        duration = CMTime.zero
    }
    
    // 비디오 파일 다운로드 여부에 따라 화면에 표시/히든 처리
    func setPlayerDisplayObjectProperty(psgIndex:Int, isDown:Bool) {
        if isDown {
            downloadingIndicator.stopAnimating()
            downloadVideoProgress.isHidden = true
            downloadVideoProgressLabel.isHidden = true
        }
        else {
            downloadingIndicator.startAnimating()
            downloadVideoProgress.isHidden = false
            downloadVideoProgressLabel.isHidden = false
            downloadVideoProgress.progress = psgArray[psgIndex].videoDownloadProgress
            downloadVideoProgressLabel.text = "다운로드 대기중"
            downloadVideoProgressLabel.layoutIfNeeded()
        }
    }
    
    func initPlayerUIControls() {
        
        // -----------------------------------------------------------------------------------------------
        // play 관련 버튼 및 변수 설정
        // -----------------------------------------------------------------------------------------------
        isReadyPlay = false
        isVideoPlaying = false

        playButton.setTitle("", for: .normal)
        backwardButton.setTitle("", for: .normal)
        forwardButton.setTitle("", for: .normal)
        backwardButton.setImage(backwardImage, for: .normal)
        forwardButton.setImage(forwardImage, for: .normal)

        // -----------------------------------------------------------------------------------------------
        // gravity 옵션 설정
        // -----------------------------------------------------------------------------------------------
        gravitySegmented.removeAllSegments()
        for item in EnumVideoGravity.allCases {
            let title = EnumVideoGravity(rawValue: item.rawValue)?.title
            gravitySegmented.insertSegment(withTitle: title, at: gravitySegmented.numberOfSegments, animated: false)
        }
        gravitySegmented.selectedSegmentIndex = EnumVideoGravity(rawValue: 0)!.defaultIndex
        videoGravity = EnumVideoGravity(rawValue: gravitySegmented.selectedSegmentIndex)!.value
        
        // -----------------------------------------------------------------------------------------------
        // speed 옵션 설정
        // -----------------------------------------------------------------------------------------------
        speedSegmented.removeAllSegments()
        for item in EnumSpeed.allCases {
            let title = EnumSpeed(rawValue: item.rawValue)?.title
            speedSegmented.insertSegment(withTitle: title, at: speedSegmented.numberOfSegments, animated: false)
        }
        speedSegmented.selectedSegmentIndex = EnumSpeed(rawValue: 0)!.defaultIndex
        playSpeed = EnumSpeed(rawValue: speedSegmented.selectedSegmentIndex)!.value * Float(videoMultiplier)
        
        // -----------------------------------------------------------------------------------------------
        // 건너뛰기 시간 옵션 설정
        // -----------------------------------------------------------------------------------------------
        jumpStepSegmented.removeAllSegments()
        for item in EnumJumpStep.allCases {
            let title = EnumJumpStep(rawValue: item.rawValue)?.title
            jumpStepSegmented.insertSegment(withTitle: title, at: jumpStepSegmented.numberOfSegments, animated: false)
        }
        jumpStepSegmented.selectedSegmentIndex = EnumJumpStep(rawValue: 0)!.defaultIndex
        jumpStep = EnumJumpStep(rawValue: jumpStepSegmented.selectedSegmentIndex)!.value

        // -----------------------------------------------------------------------------------------------
        // 슬라이더
        // -----------------------------------------------------------------------------------------------
        timeSlider.minimumValue = 0
        timeSlider.maximumValue = 0
        timeSlider.setValue(0, animated: false)
        
        // -----------------------------------------------------------------------------------------------
        // 사운드
        // -----------------------------------------------------------------------------------------------
        soundOnSwitch.isOn = isSoundOn

    }
    
    func initPlayerGesture() {
        // 타임슬라이더 tap gesture 설정
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(sliderTapped(gestureRecognizer:)))
        timeSlider.addGestureRecognizer(tapGestureRecognizer)
        
        timeSlider.addTarget(self, action: #selector(onTimeSliderValChanged(slider:event:)), for: .valueChanged)
    }
    
    func initPlayerScrollView() {
        
        playerScroll.delegate = self
        playerScroll.contentSize = playerView.bounds.size
        playerScroll.autoresizingMask = [UIView.AutoresizingMask.flexibleWidth, UIView.AutoresizingMask.flexibleHeight]
        playerScroll.alwaysBounceVertical = false
        playerScroll.alwaysBounceHorizontal = false
        playerScroll.showsVerticalScrollIndicator = true
        playerScroll.flashScrollIndicators()
        
        playerScroll.panGestureRecognizer.minimumNumberOfTouches = 1
        playerScroll.panGestureRecognizer.maximumNumberOfTouches = 2
        setPlayerZoomScale(playerView, playerScroll)
    }
    
    func setPlayerZoomScale(_ playerView:PlayerView, _ scrollView:UIScrollView) {
        let playerViewSize = playerView.bounds.size
        let scrollViewSize = scrollView.bounds.size
        let widthScale = scrollViewSize.width / playerViewSize.width
        let heightScale = scrollViewSize.height / playerViewSize.height
        
        scrollView.minimumZoomScale = min(widthScale, heightScale)
        scrollView.maximumZoomScale = scrollView.minimumZoomScale * 5.0
        scrollView.decelerationRate = .fast
    }
    
    func initSnapshot(time:CMTime) {
        if let vp = videoPlayer {

            befSnapshot.time = time
            befSnapshot.ciImage = (time == .zero) ? nil : vp.getScreenshotCIImage(picktime: time)?.blackAndWhite
            curSnapshot.time = time
            curSnapshot.ciImage = (time == .zero) ? nil : befSnapshot.ciImage?.copy() as? CIImage
            isAbnormalStatus = false

            abnormalBegSecond = -1
            abnormalEndSecond = -1
            
            testImageViewOut.image = nil

            //p("스냅샷이미지 리셋")
        }
    }
    
//    func initSnapshot_20210628(time:CMTime) {
//        if let vp = videoPlayer {
//
//            befSnapshot.time = time
//            befSnapshot.image = time == .zero ? nil : vp.screenshot(picktime: time)?.blackAndWhite
//            curSnapshot.time = time
//            curSnapshot.image = befSnapshot.image?.copy()
//            isAbnormalStatus = false
//
//            abnormalBegSecond = -1
//            abnormalEndSecond = -1
//            
//            testImageViewOut.image = nil
//
//            //p("스냅샷이미지 리셋")
//        }
//    }
    
    func initSnapshot(seconds:Float) {
        let cmtime = CMTime(seconds: Double(seconds), preferredTimescale: CMTimeScale(NSEC_PER_SEC))
        initSnapshot(time: cmtime)
    }

    func blinkPlayTypeLabel() {
        playTypeLabel.textColor = UIColor.yellow
        var toggle = false
        Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) {timer in
            toggle.toggle()
            UIView.animate(withDuration: 0.5) {
                self.playTypeLabel.textColor = toggle ? .yellow : UIColor.clear
            }
        }
    }
    

}
