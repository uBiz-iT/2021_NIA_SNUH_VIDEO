//
//  LabelingVC_Video.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/03/20.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation
import CoreImage
import CoreImage.CIFilterBuiltins
import Vision

// -----------------------------------------------------------------------------------------------
// Video Player 클래스로부터 받는 이벤트 처리
// -----------------------------------------------------------------------------------------------
extension LabelingVC : VideoPlayerDelegate {
    
    // -----------------------------------------------------------------------------------------------
    // VideoPlayer deligate로부터 이벤트 수신. play 준비
    // -----------------------------------------------------------------------------------------------
    func readyToPlay(duration: CMTime) {

        // background로 가면 동영상이 멈춤,
        // 그리고 foreground로 올때 readyToPlay가 다시 발생함.
        // 그래서 이미지 준비가 되었었던 거라면 stop을 함
        if isReadyPlay {
            if (isVideoPlaying) {
                stopPlay()
                DoEvents(f: 0.1)
            }
        }
        else {
            isReadyPlay = true
            isAbnormalAutoCreate = false
            diffRate = 0
            
            self.duration = duration
            setCurrentTime(time: .zero, method: .readyPlay)
        }
    }
    
    // -----------------------------------------------------------------------------------------------
    // VideoPlayer deligate로부터 이벤트 수신. load 실패
    // -----------------------------------------------------------------------------------------------
    func failedToLoadVideo() {
        p("failedToLoadVideo")
    }
    
    // -----------------------------------------------------------------------------------------------
    // VideoPlayer deligate로부터 이벤트 수신. 필요한 부분 다운로드 완료
    // -----------------------------------------------------------------------------------------------
    func downloadedProgress(progress: Double) {
        // p("downloadedProgress :", progress)
    }
    
    // -----------------------------------------------------------------------------------------------
    // VideoPlayer deligate로부터 이벤트 수신. play되고 있는 시간 및 진행률
    // -----------------------------------------------------------------------------------------------
    func didUpdateProgress(time: CMTime, progress: Float64) {
//        DispatchQueue.main.async { [self] in
            if isVideoPlaying {
                //p("didUpdateProgress : \(time.seconds)")
                setCurrentTime(time: time, method: .auto)
                currentProgress = progress
            }
//        }
    }
    

    // -----------------------------------------------------------------------------------------------
    // VideoPlayer deligate로부터 이벤트 수신. play 완료
    // -----------------------------------------------------------------------------------------------
    func didFinishPlayItem() {
        p("didFinishPlayItem")
        stopPlay()
        DoEvents(f: 0.1)
    }
    
    // -----------------------------------------------------------------------------------------------
    // VideoPlayer deligate로부터 이벤트 수신. play도중 실패
    // -----------------------------------------------------------------------------------------------
    func didFailPlayToEnd() {
        p("didFailPlayToEnd")
    }
}



