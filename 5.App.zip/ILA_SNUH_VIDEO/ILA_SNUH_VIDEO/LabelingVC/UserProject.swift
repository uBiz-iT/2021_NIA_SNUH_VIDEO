//
//  LoginAndProject.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    // ------------------------------------------------------------------------------
    // 로그인/아웃시 체크(최초 로딩시에도 수행)
    // ------------------------------------------------------------------------------
    func checkLoginOutInfo(newLogin new_login:Bool, goLogin:Bool = false) {
        
        if (new_login) {
            signedUserNameLabel.text = LoginName
            clearLabelImage()
            // 라벨링 중인 작업이 있으면 Loading
            if (isWorking) {
                loadData()
            }
            // 라벨링 작업중인 것이 없으면 프로젝트 목록 화면으로 이동
            else {
                DispatchQueue.main.async() {
                    self.performSegue(withIdentifier: "segueProjectList", sender: nil)
                }
            }
        }
        else {
            if (!isLogin) {
                signedUserNameLabel.text = "not logged in"
                clearLabelImage()
                // 맨처음 로딩 했을 경우에만 체크하여 로그인 페이지로 이동
                if (FirstDidBecomeActive || goLogin) {
                    DispatchQueue.main.async() {
                        self.performSegue(withIdentifier: "segueLoginOut", sender: nil)
                    }
                }
            }
        }
        
    }
    
    // ------------------------------------------------------------------------------
    // 프로젝트 및 차수 선택 후 라벨링 시작 및 종료시 체크
    // ------------------------------------------------------------------------------
    func checkWorkingProjectInfo(newProject new_project:Bool) {
        if (new_project) {
            clearLabelImage()
            if (isWorking) {
                loadData()
            }
        }
        else {
            if (!isWorking) {
                clearLabelImage()
            }
        }
    }
    
}
