//
//  ParseResponse.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import Foundation
import UIKit

extension LabelingVC {
    
    // =======================================================================================================
    // JSON 포맷 파싱
    // =======================================================================================================
    func parseJson(parsingType:typeJsonParsing, jsonFormat:Dictionary<String, Any>?) -> AnyObject? {
        
        let returnAnyObject:Bool = false
        
        guard let json = jsonFormat else {
            p("func parseJson:jsonFormat is nil")
            return returnAnyObject as AnyObject
        }
        
        switch parsingType {
        case typeJsonParsing.Success:  // 성공여부 가져오기
            
            do {
                guard let success = json["success"] as? Bool else {
                    throw ResponseDataError.JsonProtocol
                }
                return success as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
                LastURLErrorMessage = error.rawValue
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
                LastURLErrorMessage = error.debugDescription
            }
            
        case typeJsonParsing.ErrorMessage:  //  에러 메시지 가져오기
            
            do {
                guard let errorMessage = json["err_msg"] as? String else {
                    throw ResponseDataError.JsonProtocol
                }
                return errorMessage as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }
            
        case typeJsonParsing.ErrorCode:  //  에러 코드 가져오기
            
            do {
                guard let errorCode = json["err_code"] as? Int else {
                    throw ResponseDataError.JsonProtocol
                }
                return errorCode as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }
            
        case typeJsonParsing.SaveLabelingResult:  //  저장 결과 회신 메시지에서 총건수와 완료건수 가져오기
            
            do {
                
                guard let pass_rate = json["pass_rate"] as? Float,
                      let pass_cnt_rate = json["pass_cnt_rate"] as? Float,
                      let ver = json["ver"] as? String,
                      let build = json["build"] as? String,
                      let ver_content = json["ver_content"] as? String,
                      let ver_date = json["ver_date"] as? String
                else {
                    throw ResponseDataError.JsonProtocol
                }
                PASS_RATE = pass_rate
                PASS_COUNT_RATE = pass_cnt_rate
                APP_VERSION = ver
                APP_BUILD = build
                APP_CONTENT = ver_content
                APP_DIST_DATE = ver_date
                
                guard let psg_chk_res = json["psg_chk_res"] as? Int
                    else {
                        throw ResponseDataError.JsonProtocol
                }
                
                return psg_chk_res as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }
            
        case typeJsonParsing.GetLabelList:  // 라벨 목록
            do {
                
                var labelList:[LabelInfo] = []
                
                // 하부 구조가 또 있으며 여러개가 있을 경우 대비 [[String: Any]], 하나일 경우 [String: Any]
                // ------------------------------------
                if let items = json["label_list"] as? [[String: Any]] {
                    for item in items {
                        //p("item:", item)
                        
                        guard let location:Int = item["target_cd"] as? Int,
                            let value:Int = item["label_cd"] as? Int,
                            let text:String = item["label_desc"] as? String
                            else { throw ResponseDataError.JsonProtocol }
                        
                        let label = LabelInfo()
                        label.location = location
                        label.value = value
                        label.text = text
                        labelList.append(label)
                    }
                }
                else {
                    p("typeJsonParsing.GetLabelList else")
                    throw ResponseDataError.JsonProtocol
                }
                
                return labelList as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }
            
        case typeJsonParsing.GetLabelListWithResult:  // 라벨 목록(라벨링 결과 포함)
            do {
                
                var labelList:[LabelInfo] = []
                
                // 하부 구조가 또 있으며 여러개가 있을 경우 대비 [[String: Any]], 하나일 경우 [String: Any]
                // ------------------------------------
                if let items = json["label_list"] as? [[String: Any]] {
                    for item in items {
                        //p("item:", item)
                        
                        guard let location:Int = item["target_cd"] as? Int,
                            let value:Int = item["label_cd"] as? Int,
                            let text:String = item["label_desc"] as? String
                            else { throw ResponseDataError.JsonProtocol }
                        
                        let label = LabelInfo()
                        label.location = location
                        label.value = value
                        label.text = text
                        labelList.append(label)
                    }
                }
                else {
                    p("typeJsonParsing.GetLabelList else")
                    throw ResponseDataError.JsonProtocol
                }
                
                return labelList as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }
            
        case typeJsonParsing.GetPSGList:  // 이미지 목록
            do {
                
                // 전체 이미지 건수
                guard let count = json["psg_count"] as? Int else {
                    throw ResponseDataError.JsonProtocol
                }
                
                self.image_count = count
                
                guard let image_dir = json["data_dir"] as? String else {
                    throw ResponseDataError.JsonProtocol
                }
                
                var psgList:[PSGInfo] = []
                
                // 하부 구조가 또 있으며 여러개가 있을 경우 대비 [[String: Any]], 하나일 경우 [String: Any]
                // ------------------------------------
                if let items = json["psg_list"] as? [[String: Any]] {
                    for item in items {
                        //p("item:", item)
                        
                        guard let row_num = item["row_num"] as? Int,
                            let id = item["psg_id"] as? String,
                            let file_name = item["file_name"] as? String,
                            let file_path = item["file_path"] as? String,
                            let tar_file_path = item["tar_file_path"] as? String,
                            let video_beg_dt = item["video_beg_dt"] as? String,
                            let labeling_done = item["labeling_done"] as? String,
                            let memo = item["memo"] as? String,
                            let sub_file_name = item["sub_file_name"] as? String,
                            let t0_label_cd = item["t0_label_cd"] as? Int,
                            let gender = item["gender"] as? String,
                            let age = item["age"] as? String,
                            let bmi = item["bmi"] as? String,
                            let sltm = item["sltm"] as? String,
                            let slef = item["slef"] as? String,
                            let slla = item["slla"] as? String,
                            let ahi = item["ahi"] as? String,
                            let rdi = item["rdi"] as? String,
                            let oxavg = item["oxavg"] as? String,
                            let oxmin = item["oxmin"] as? String,
                            let lmi = item["lmi"] as? String,
                            let lmar = item["lmar"] as? String,
                            let ari = item["ari"] as? String,
                            let diag = item["diag"] as? String
                            else { throw ResponseDataError.JsonProtocol }
                        
                        let psg = PSGInfo()
                        psg.row_num = row_num
                        psg.id = id
                        
                        var temp:URL = URL(fileURLWithPath: image_dir)
                        temp.appendPathComponent(file_name)

//                        image.serverLocation = temp.relativePath
                        
                        psg.serverLocation = file_path
                        psg.tarFileServerPath = tar_file_path
                        psg.org_file_path = ""
                        psg.thu_file_path = ""
                            
                        temp = URL(fileURLWithPath: image_dir)
                        temp.appendPathComponent(id)
                        temp.appendPathComponent(sub_file_name)
                        
                        psg.sub_serverLocation = temp.relativePath

                        psg.isLabelingDone = (labeling_done == "Y") ? true : false
                        psg.memo = memo
                        psg.gender = gender
                        psg.age = age
                        psg.bmi = bmi
                        psg.sltm = sltm
                        psg.slef = slef
                        psg.slla = slla
                        psg.ahi = ahi
                        psg.rdi = rdi
                        psg.oxavg = oxavg
                        psg.oxmin = oxmin
                        psg.lmi = lmi
                        psg.lmar = lmar
                        psg.ari = ari
                        psg.diag = diag
                        
                        psg.psg_chk_res = t0_label_cd
                        psg.video_begDT = video_beg_dt
                        
                        let fileManager = FileManager.default

                        // 수면영상 파일 체크  20210731 PATH에 프로젝트코드 추가
                        let videoFileUrl = sourceVideoDirectoryURL!.appendingPathComponent(file_name)

                        //p("Video File check : \(videoFileUrl.absoluteString)")

                        if fileManager.fileExists(atPath: videoFileUrl.path) {
                            p("MP4 File Exist : \(videoFileUrl.lastPathComponent)")
                            psg.videoFileUrl = videoFileUrl
                            psg.videoDownloadProgress = 1.0
                            psg.videoDownloadFlag = .completed
                        }
                        else {
                            psg.videoDownloadFlag = .wait
                            psg.videoDownloadProgress = 0
                            psg.videoFileUrl = videoFileUrl
                        }
                        
                        // 이미지 tar 파일 체크
                        let tarFileName = URL(fileURLWithPath: tar_file_path).lastPathComponent
                        let tarFileUrl = sourceVideoDirectoryURL!.appendingPathComponent(tarFileName)

                        //p("Tar File check : \(tarFileUrl.absoluteString)")

                        if fileManager.fileExists(atPath: tarFileUrl.path) {
                            p("Tar File Exist : \(tarFileUrl.lastPathComponent)")
                            psg.tarFileUrl = tarFileUrl
                            psg.tarDownloadProgress = 1.0
                            psg.tarDownloadFlag = .completed
                        }
                        else {
                            psg.tarDownloadFlag = .wait
                            psg.tarDownloadProgress = 0
                            psg.tarFileUrl = tarFileUrl
                        }

                        psgList.append(psg)
                        
                        image_last_row_num = row_num
                    }
                }
                else {
                    p("typeJsonParsing.GetImageList else")
                    throw ResponseDataError.JsonProtocol
                }
                
                return psgList as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }
            
        case typeJsonParsing.GetSubImageList:  // 하위 이미지 목록
            do {
                
                // 전체 이미지 건수
                guard let count = json["image_count"] as? Int else {
                    throw ResponseDataError.JsonProtocol
                }
                
                self.sub_image_count = count
                
                // 이미지 디렉토리
                guard let image_dir = json["image_dir"] as? String else {
                    throw ResponseDataError.JsonProtocol
                }
                
                LastLabelingSubImageId = ""
                
                // 이미지 목록
                var imageList:[SubImageInfo] = []
                
                // 하부 구조가 또 있으며 여러개가 있을 경우 대비 [[String: Any]], 하나일 경우 [String: Any]
                // ------------------------------------
                if let items = json["image_list"] as? [[String: Any]] {
                    for item in items {
                        
                        guard let row_num:Int = item["row"] as? Int,
                            let image_id:String = item["id"] as? String,
                            let file_path:String = item["path"] as? String,
                            let epo_no:Int = item["epo_no"] as? Int
                            else { throw ResponseDataError.JsonProtocol }
                        
                        let imageInfo = SubImageInfo()
                        imageInfo.row_num = row_num
                        imageInfo.sub_image_id = image_id
                        imageInfo.sub_server_location = file_path   // 20200814
                        imageInfo.org_file_path = ""
                        imageInfo.thu_file_path = ""
                        
                        imageInfo.mark_num = 0
                        imageInfo.group = "default"
                        imageInfo.newMarking = false
                        imageInfo.newMarkedImage = nil
                        imageInfo.isLabelingDone = false
                        
                        var labeling:LabelingLocationResult = LabelingLocationResult()    // 20200820
                        labeling.target_cd = 0
                        labeling.label_cd = -1
                        labeling.memo = ""
                        imageInfo.labelingResult.append(labeling)
                        
                        labeling = LabelingLocationResult()
                        labeling.target_cd = 1
                        labeling.label_cd = -1                                            // 무조건 -1 20200820. 타겟이 하나
                        labeling.memo = ""
                        imageInfo.labelingResult.append(labeling)
                        
                        // 이미지 파일의 디스크 경로 미리 지정
                        let id = psgArray[currentImageIndex].id!
                        let imageDirUrl = sourceVideoDirectoryURL!.appendingPathComponent(id)
                        let fileName = URL(string: file_path)?.lastPathComponent
                        let imageFileUrl = imageDirUrl.appendingPathComponent(fileName!)

                        // p("image path : \(imageFileUrl.path)")
                        imageInfo.fileUrl = imageFileUrl

                        imageList.append(imageInfo)
                        last_row_num = row_num
                    }
                }
                else {
                    p("typeJsonParsing.GetLabelList else")
                    throw ResponseDataError.JsonProtocol
                }
                
                return imageList as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }
            
        case typeJsonParsing.GetEventList:  // 이벤트 목록
            do {
                
                // 이미지 목록
                var eventList:[EventInfo] = []
                
                // 하부 구조가 또 있으며 여러개가 있을 경우 대비 [[String: Any]], 하나일 경우 [String: Any]
                // ------------------------------------
                var count = 0
                if let items = json["event_list"] as? [[String: Any]] {
                    for item in items {
                        count = count + 1
                        guard let eventSeq:Int = item["seq"] as? Int,
                              let eventName:String = item["nm"] as? String,
                              let begDT:String = item["beg_dt"] as? String,
                              let endDT:String = item["end_dt"] as? String,
                              let memo:String = item["memo"] as? String,
                              let begEpoNo:Int = item["beg_no"] as? Int,
                              let endEpoNo:Int = item["end_no"] as? Int,
                              let begSecond:Int = item["beg_sec"] as? Int,
                              let endSecond:Int = item["end_sec"] as? Int,
                              let elapsedSeconds:Double = item["elap"] as? Double,
                              let checkResult:Int = item["res"] as? Int,
                              let note:String = item["note"] as? String,
                              let typeName:String = item["tp_nm"] as? String
                        else {
                            throw ResponseDataError.JsonProtocol
                        }
                        
                        let eventInfo = EventInfo()
                        eventInfo.eventSeq = eventSeq
                        eventInfo.eventName = eventName
                        eventInfo.begDT = begDT
                        eventInfo.endDT = endDT
                        eventInfo.memo = memo
                        eventInfo.begEpoNo = begEpoNo
                        eventInfo.endEpoNo = endEpoNo
                        eventInfo.begSecond = begSecond
                        eventInfo.endSecond = endSecond
                        eventInfo.elapsedSeconds = Int(elapsedSeconds)
                        eventInfo.checkResult = checkResult
                        eventInfo.group = "default"
                        eventInfo.isChecked = checkResult == -1 ? false : true
                        eventInfo.note = note
                        eventInfo.typeName = typeName
//                        eventInfo.orgingResult = checkResult
//                        eventInfo.originMemo = memo
//                        eventInfo.newResult = checkResult
//                        eventInfo.newMemo = memo

                        eventList.append(eventInfo)
                    }
                }
                else {
                    p("typeJsonParsing.GetEventList else")
                    throw ResponseDataError.JsonProtocol
                }
                
                p("eventCount : \(count), \(eventList.count)")
                
                return eventList as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError GetEventList] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError GetEventList] \(error.debugDescription)")
            }
            

        default:
            break
        }
        
        return returnAnyObject as AnyObject
        
    }
    
}
