//
//  Error.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

extension LabelingVC {

    func showNotRegisterdMessage() {
        if (currentImageIndex < 0 || currentImageIndex > psgArray.count) {
            p("Array Index Error : showNotRegisterdMessage() number \(currentImageIndex)")
            return
        }
        guard let imageId = psgArray[currentImageIndex].id else { return }
        // self.view.showToast(toastMessage: "\n" + imageId + "\n\n서버에 이미지가 등록되지 않았습니다.\n", duration: 1.5)
        self.view.showToast(toastMessage: "\n" + imageId + "\n\n이미지 다운로드 중입니다.\n", duration: 1.5)
    }

    

}
