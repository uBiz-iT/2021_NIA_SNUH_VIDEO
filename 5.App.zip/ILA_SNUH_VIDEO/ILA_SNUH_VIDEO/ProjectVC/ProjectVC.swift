//
//  ProjectVC.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 05/11/2018.
//  Copyright © 2018 uBiz Information Technology. All rights reserved.
//

import UIKit

class ProjectVC: UITableViewController {
    
    @IBOutlet var loginNameLabel: UILabel!
    @IBOutlet var tableViewProject: UITableView!
    
    var selectedProjectInfo = ProjectInfo()
    var selectedProjectSection = -1
    var selectedProjectIndex = -1

    // color set
    let workingTextColor = UIColor.black
    let workingBackColor = ColorWithHexString(hexString: "#87CEFA")
    let normalTextColor = UIColor.black
    let normalBackColor = UIColor.white
    let selectedWorkingTextColor = UIColor.blue
    let selectedWorkingBackColor = ColorWithHexString(hexString: "#DCDCDC")
    let selectedNormalTextColor = UIColor.black
    let selectedNormalBackColor = ColorWithHexString(hexString: "#DCDCDC")

    var projectSections = [ProjectSection]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    func setTitle() {
        self.title = "프로젝트 목록 - Free Disk Space : \(DiskStatus.freeDiskSpace)"
    }
    
    override func viewWillAppear(_ animated: Bool) {
        SetOrientation()
        super.viewWillAppear(animated)
    }
    
    var viewDidAppearCount = 0
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        setTitle()

        viewDidAppearCount = viewDidAppearCount + 1
        if (viewDidAppearCount == 1) {
            didTapReloadButton(self)
        }
    }
    
    // ---------------------------------------------------------------------
    // 프로젝트 목록 갱신(서버 요청)
    // ---------------------------------------------------------------------
    @IBAction func didTapReloadButton(_ sender: Any) {
        setTitle()
        loadProjectList()
    }
    
    func loadProjectList() {
        
        if (!isLogin) { return }
        
        // ------------------------------------------------
        // 스피너 시작
        // ------------------------------------------------
        let child = SpinnerViewController()
        child.view.frame = self.view.frame
        self.view.addSubview(child.view)
        child.didMove(toParent: self)

        DoEvents(f: 0.01)     // 20200827

        let rp = RequestProject()
        
        let (success, code) = rp.projectList()
        if (success) {
            
            let ud = MyUserDefaults()
            ud.setWorkingProjectInfo()

            // tableview section처리를 위하여...
            selectedProjectSection = -1
            selectedProjectIndex = -1
            self.projectSections = ProjectSection.group(headlines: ProjectList)
            self.tableView.reloadData()
        }
        else {
            handlingDbError(code: code!, self)
        }

        // ------------------------------------------------
        // 스피너 종료
        // ------------------------------------------------
        child.willMove(toParent: nil)
        child.view.removeFromSuperview()
        child.removeFromParent()

    }
    
    // ---------------------------------------------------------------------
    // 라벨링 시작/종료 이벤트 처리
    // ---------------------------------------------------------------------
    enum enumBeginEndType:String {
        case Begin = "BEGIN", End = "END"
    }
    
    var beginEndType = enumBeginEndType.End
    
    
    @IBAction func projectBeginEndButtonTapped(_ sender: Any) {

        let button = sender as! UIButton
        let tag = button.tag

        if (tag == 1) {
            // 프로젝트 라벨링 시작 처리
            if (selectedProjectIndex < 0) {
                self.view.showToast(toastMessage: "선택된 프로젝트가 없습니다.", duration: 1.5)
                return
            }

            if EXIST_NOTSAVEDDATA {
                let dialogMessage = UIAlertController(title: "확인", message: "저장되지 않은 데이터가 있습니다. \n 계속 하시겠습니까?", preferredStyle: .alert)
                let ok = UIAlertAction(title: "예", style: .destructive, handler: { [self] (action) -> Void in
                    beginEndType = enumBeginEndType.Begin
                    if (processBeginEnd()) {
                        self.performSegue(withIdentifier: "unwindFromNewProject", sender: self)
                        self.dismiss(animated: false, completion: nil)
                    }
                })

                let cancel = UIAlertAction(title: "아니오", style: .cancel) { (action) -> Void in
                }
                dialogMessage.addAction(ok)
                dialogMessage.addAction(cancel)
                self.present(dialogMessage, animated: true, completion: nil)
            }
            else {
                beginEndType = enumBeginEndType.Begin
                if (processBeginEnd()) {
                    self.performSegue(withIdentifier: "unwindFromNewProject", sender: self)
                    self.dismiss(animated: false, completion: nil)
                }
            }

        }
        else if (tag == 0) {
            self.performSegue(withIdentifier: "unwindFromProjectList", sender: self)
            self.dismiss(animated: false, completion: nil)
        }

    }

    func processBeginEnd() -> Bool {
        var success = false
        // ------------------------------------------------
        // 스피너 시작
        // ------------------------------------------------
        let child = SpinnerViewController()
        child.view.frame = self.view.frame
        self.view.addSubview(child.view)
        child.didMove(toParent: self)
        
        DoEvents(f: 0.01)     // 20200827
        
        if (projectBeginEnd()) {
            let rp = RequestProject()
            
            let (isSuccess, _) = rp.projectList()
            if (isSuccess) {

                // tableview section처리를 위하여...
                self.projectSections = ProjectSection.group(headlines: ProjectList)

                let ud = MyUserDefaults()
                ud.setWorkingProjectInfo()
                
                // tableview 반영
                selectedProjectSection = -1
                selectedProjectIndex = -1
                self.tableView.reloadData()
                
                switch beginEndType {
                case enumBeginEndType.Begin:
                    self.view.showToast(toastMessage: "정상적으로 시작되었습니다.", duration: 0.5)
                    break
                case enumBeginEndType.End:
                    selectedProjectSection = -1
                    selectedProjectIndex = -1
                    self.view.showToast(toastMessage: "정상적으로 종료되었습니다.", duration: 0.5)
                    break
                }
                success = true
            }
            else {
                alertSimpleMessage("확인", "\n\(LastURLErrorMessage)\n\n")
//                let alertProgressNoAction = UIAlertController(title: "메세지 확인\n\n\n", message: nil, preferredStyle: .alert)
//                let otherAction = UIAlertAction(title: "OK", style: .default, handler: { action in
//                    //self.dismiss(animated: true, completion: nil)
//                    alertProgressNoAction.dismiss(animated: true, completion: nil)
//                })
//                alertProgressNoAction.addAction(otherAction)
//                self.present(alertProgressNoAction, animated: false, completion: nil)
            }
        }
        else {
            alertSimpleMessage("확인", "\n\(LastURLErrorMessage)\n\n")
//            let alertProgressNoAction = UIAlertController(title: "메세지 확인\n\n\n", message: nil, preferredStyle: .alert)
//            let otherAction = UIAlertAction(title: "OK", style: .default, handler: { action in
//                alertProgressNoAction.dismiss(animated: true, completion: nil)
//            })
//            alertProgressNoAction.addAction(otherAction)
//            self.present(alertProgressNoAction, animated: false, completion: nil)
        }
        
        // ------------------------------------------------
        // 스피너 종료
        // ------------------------------------------------
        child.willMove(toParent: nil)
        child.view.removeFromSuperview()
        child.removeFromParent()
        

        return success
    }
    
}
