//
//  ProjectVC_URL.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 05/11/2018.
//  Copyright © 2018 uBiz Information Technology. All rights reserved.
//

import UIKit


extension ProjectVC {

    enum typeURLRequest:Int {
        case GetProjectList = 0, ProjectBeginEnd, End
    }
    
    enum typeJsonParsing:Int {
        case GetProjectList, ProjectBeginEnd, Success, ErrorMessage, End
    }
    
    // 라벨링 시작/종료 저장
    // ==========================================================================
    func projectBeginEnd() -> Bool {
        // ------------------------------------------------
        let requestURL = makeURLRequestForJsonFromServer(requestType: .ProjectBeginEnd)
        var result = false
        
        LastURLErrorMessage = ""
        
        let (success, error, err_code, err_msg, json ) = SendRequestForJSON(requestURL: requestURL)
        
        do {
            if (!success!) {
                if let e = error {
                    throw e
                }
                else {
                    throw ResponseDataError.RequestURLForJSON
                }
            }

            guard let getSuccess = self.parseJson(parsingType: .Success, jsonFormat: json) as? Bool
                else { throw ResponseDataError.JsonParsing }
            
            if (!getSuccess) {
                guard let msg:String =
                    self.parseJson(parsingType: .ErrorMessage, jsonFormat: json) as? String
                    else { throw ResponseDataError.JsonParsing }
                
                LastURLErrorMessage = msg
                
                throw ResponseDataError.ReturnValue
            }

            result = true

        }
        catch let error as RequestURLError {
            if (error == RequestURLError.URLSession) {
                LastURLErrorMessage = "[\(String(describing: err_code!))]" + err_msg!
            }
            else {
                LastURLErrorMessage = error.rawValue
            }
        }
        catch let error as ResponseDataError {
            if (LastURLErrorMessage == "") {
                LastURLErrorMessage = error.rawValue
            }
            p("[ResponseDataError] \(error.rawValue)")
        }
        catch let error as NSError {
            LastURLErrorMessage = error.debugDescription
            p("[NSError  ] \(error.debugDescription)")
        }
        catch let error {
            LastURLErrorMessage = error.localizedDescription
            p("[Error  ] \(error.localizedDescription)")
        }
        
        return result
    }
    
    // 서버로부터 json 포맷으로 받기 위한 url request 생성하기
    // ==========================================================================
    func makeURLRequestForJsonFromServer(requestType:typeURLRequest) -> URLRequest? {
        
        var request:URLRequest? = nil
        
        switch requestType {
        case typeURLRequest.ProjectBeginEnd:  // 프로젝트 라벨링 시작 종료
            
            struct RequestProjectBeginEnd: Codable {
                var proc_name: String?
                var is_manager: String?
                var project_cd: String?
                var user_id: String?
                var type: String?
            }
            
            var projectBeginEnd = RequestProjectBeginEnd();
            projectBeginEnd.proc_name = "P_CHECK_BEGIN_END"
            projectBeginEnd.is_manager = isManager ? "Y" : "N"
            projectBeginEnd.type = beginEndType.rawValue
            projectBeginEnd.user_id = LoginID
            if (beginEndType == enumBeginEndType.End) {
                projectBeginEnd.project_cd = ""
                TempProjectCode = ""
            }
            else {
                projectBeginEnd.project_cd = selectedProjectInfo.code
                TempProjectCode = selectedProjectInfo.code!
            }
            
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted]
            
            let jsonData = try? encoder.encode(projectBeginEnd);
            
            // 접속 server url 정의
            // -------------------------------------------------
            let endpoint = "\(ILA4ML_URL_PROC)?id=\(LoginID)"
            guard let endpointUrl = URL(string: endpoint) else {
                p("URL Error : \(endpoint)")
                return nil
            }
            
            // 요청할 최종 url 정의
            // -------------------------------------------------
            request = URLRequest(url: endpointUrl)
            request?.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            request!.httpMethod = "POST"
            request!.httpBody = jsonData
            
        default:
            break
        }
        
        return request
        
    }
    
    // JSON 포맷 파싱
    // ==========================================================================
    func parseJson(parsingType:typeJsonParsing, jsonFormat:Dictionary<String, Any>?) -> AnyObject? {
        
        let returnAnyObject:Bool = false
        
        guard let json = jsonFormat else {
            p("func parseJson:jsonFormat is nil")
            return returnAnyObject as AnyObject
        }
        
        switch parsingType {
        case typeJsonParsing.Success:  // 성공여부 가져오기
            do {
                guard let success = json["success"] as? Bool else {
                    throw ResponseDataError.JsonProtocol
                }
                
                return success as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
                LastURLErrorMessage = error.rawValue
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
                LastURLErrorMessage = error.debugDescription
            }
            
        case typeJsonParsing.ErrorMessage:  //  에러 메시지 가져오기
            
            do {
                guard let errorMessage = json["err_msg"] as? String else {
                    throw ResponseDataError.JsonProtocol
                }
                return errorMessage as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }
        default:
            break
        }
        
        return returnAnyObject as AnyObject
        
    }
    
}
