//
//  AppDelegate.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 2020. 08. 10..
//  Copyright © 2020년 uBiz Information Technology. All rights reserved.
//

import UIKit
import BackgroundTasks

@UIApplicationMain

class AppDelegate: UIResponder, UIApplicationDelegate {

    //var window: UIWindow?
    
    // 손가락 터치 포지션을 동그라미로 표시하기 위해서는 위 한줄을 막고 아래를 풀어야 함 mjson
    var window: UIWindow? = FingerTips(frame: UIScreen.main.bounds)
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        Thread.sleep(forTimeInterval: 0.5)

        let ud = MyUserDefaults()
        ud.getUserDefaults()

        Thread.sleep(forTimeInterval: 0.2)
        
        BGTaskScheduler.shared.register(forTaskWithIdentifier: "kr.ubizit.snuh.download", using: nil) { task in
            self.handleAppRefresh(task: task as! BGProcessingTask)
        }
        
        return true
    }

    func scheduleAppRefresh() {

        let request = BGProcessingTaskRequest(identifier: "kr.ubizit.snuh.download")
        request.earliestBeginDate = Date(timeIntervalSinceNow: 5)
        request.requiresNetworkConnectivity = true
        request.requiresExternalPower = false

        do {
            try BGTaskScheduler.shared.submit(request)
        } catch {
            print("Could not schedule app refresh: \(error)")
        }
    }

    func handleAppRefresh(task: BGProcessingTask) {
        scheduleAppRefresh()
        
        task.expirationHandler = {
            task.setTaskCompleted(success: false)
        }
        
        // increment instead of a fixed number
        UserDefaults.standard.set(UserDefaults.standard.integer(forKey: "bgtask")+1, forKey: "bgtask")

        task.setTaskCompleted(success: true)
    }
    
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
        APP_STATE = UIApplication.State.inactive
        p("APP_STATE : applicationWillResignActive")
        
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
        APP_STATE = UIApplication.State.background
        p("APP_STATE : applicationDidEnterBackground")
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
        p("APP_STATE : applicationWillEnterForeground")
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.

        // 이전 상태가 백그라운드이면 세션 체크 필요
        // islogin 조건 추가 20210728
        if  isLogin && APP_STATE == .background {
            let (success, code) = CheckSessionAndDB()
            if !success {
                handlingDbError(code: code!, visibleViewController!)
            }
        }

        APP_STATE = UIApplication.State.active
//        if VideoDownloadTask != nil {
//            VideoDownloadTask?.resume()
//        }
        p("APP_STATE : applicationDidBecomeActive")
        
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
        APP_STATE = UIApplication.State.inactive
        p("APP_STATE : applicationWillTerminate")
        UserDefaults.standard.synchronize()
    }

    var orientationLock = UIInterfaceOrientationMask.all
    
    func application(_ application: UIApplication, supportedInterfaceOrientationsFor window: UIWindow?) -> UIInterfaceOrientationMask {
        return self.orientationLock
    }
    
    struct AppUtility {
        static func lockOrientation(_ orientation: UIInterfaceOrientationMask) {
            if let delegate = UIApplication.shared.delegate as? AppDelegate {
                delegate.orientationLock = orientation
            }
        }
        
        static func lockOrientation(_ orientation: UIInterfaceOrientationMask, andRotateTo rotateOrientation:UIInterfaceOrientation) {
            self.lockOrientation(orientation)
            UIDevice.current.setValue(rotateOrientation.rawValue, forKey: "orientation")
        }
    }
    
    // 백그라운드에서 파일 다운로드 완료시 이벤트 설정
    var backgroundSessionCompletionHandler: (() -> Void)?
    
    func application(_ application: UIApplication, handleEventsForBackgroundURLSession identifier: String, completionHandler: @escaping () -> Void) {
        p("handleEventsForBackgroundURLSession: \(identifier)")
        backgroundSessionCompletionHandler = completionHandler
    }
}

