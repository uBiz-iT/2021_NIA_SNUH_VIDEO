//
//  CheckSessionDatabase.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/19.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

enum CheckSessionParsingType:Int {
    case CheckSession, Success, ErrorMessage, End
}

// ==========================================================================
// 세션 및 db 체크 용
// ==========================================================================
func CheckSessionAndDB() -> (Bool, Int?) {
        
    struct CheckSession: Codable {
        var proc_name: String?
        var user_id: String?
        var is_manager: String?
    }
    
    var checkSession = CheckSession();
    checkSession.proc_name = "P_CHECK_SESSION_DB"
    checkSession.user_id = LoginID
    checkSession.is_manager = isManager ? "Y" : "N"

    let encoder = JSONEncoder()
    encoder.outputFormatting = [.prettyPrinted]
    
    let jsonData = try? encoder.encode(checkSession);
    
    // 접속 server url 정의
    // -------------------------------------------------
    let endpoint = "\(ILA4ML_URL_PROC)?id=\(LoginID)"
    guard let endpointUrl = URL(string: endpoint) else {
        p("URL Error : \(endpoint)")
        return (false, 0)
    }
    
    // 요청할 최종 url 정의
    // -------------------------------------------------
    var requestURL = URLRequest(url: endpointUrl)
    requestURL.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
    requestURL.httpMethod = "POST"
    requestURL.httpBody = jsonData
    
    var result = false
    
    let (success, error, err_code, err_msg, json ) = SendRequestForJSON(requestURL: requestURL)
    
    do {
        
        if (!success!) {
            if let e = error {
                throw e
            }
            else {
                throw ResponseDataError.RequestURLForJSON
            }
        }
        
        guard let getSuccess = ParseCheckSession(parsingType: .Success, jsonFormat: json) as? Bool
            else { throw ResponseDataError.JsonParsing }

        if (!getSuccess) {
            guard let msg:String =
                    ParseCheckSession(parsingType: .ErrorMessage, jsonFormat: json) as? String
            else {
                throw ResponseDataError.JsonParsing
            }

            LastURLErrorMessage = msg

            throw ResponseDataError.ReturnValue
        }

        result = true
         
    }
    catch let error as RequestURLError {
        if (error == RequestURLError.URLSession) {
            LastURLErrorMessage = "[\(String(describing: err_code!))]" + err_msg!
        }
        else {
            LastURLErrorMessage = error.rawValue
        }
    }
    catch let error as ResponseDataError {
        if (LastURLErrorMessage == "") {
            LastURLErrorMessage = error.rawValue
        }
        p("[ResponseDataError] \(error.rawValue)")
    }
    catch let error as NSError {
        LastURLErrorMessage = error.debugDescription
        p("[NSError  ] \(error.debugDescription)")
    }
    catch let error {
        LastURLErrorMessage = error.localizedDescription
        p("[Error  ] \(error.localizedDescription)")
    }
    
    return (result, err_code)
    

}
    
// ==========================================================================
// JSON 포맷 파싱
// ==========================================================================
func ParseCheckSession(parsingType:CheckSessionParsingType, jsonFormat:Dictionary<String, Any>?) -> AnyObject? {
    
    let returnAnyObject:Bool = false
    
    guard let json = jsonFormat else {
        p("func parseJson:jsonFormat is nil")
        return returnAnyObject as AnyObject
    }
    
    switch parsingType {
    case .Success:  // 성공여부 가져오기
        do {
            guard let success = json["success"] as? Bool else {
                throw ResponseDataError.JsonProtocol
            }
            
            return success as AnyObject
            
        }
        catch let error as ResponseDataError {
            p("[ResponseDataError] \(error.rawValue)")
            LastURLErrorMessage = error.rawValue
        }
        catch let error as NSError {
            p("[NSError  ] \(error.debugDescription)")
            LastURLErrorMessage = error.debugDescription
        }
        
    case .ErrorMessage:  //  에러 메시지 가져오기
        
        do {
            guard let errorMessage = json["err_msg"] as? String else {
                throw ResponseDataError.JsonProtocol
            }
            return errorMessage as AnyObject
            
        }
        catch let error as ResponseDataError {
            p("[ResponseDataError] \(error.rawValue)")
        }
        catch let error as NSError {
            p("[NSError  ] \(error.debugDescription)")
        }

    default:
        break
    }
    
    return returnAnyObject as AnyObject
    
}
