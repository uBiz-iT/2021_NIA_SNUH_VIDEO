//
//  Gesture.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/11.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

// 더블 탭 인터벌 세팅, 기본 인터벌 값을 적용할 경우 더블탭 시간 체크로 인하여 싱글 탭 이벤트 발생 시간이 좀 오래걸림
class UIShortTapGestureRecognizer: UITapGestureRecognizer {
    
    //anything below 0.3 may cause doubleTap to be inaccessible by many users
    let tapMaxDelay: Double = 0.26 // 0.26 seconds
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent) {
        super.touchesBegan(touches, with: event)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + tapMaxDelay) { [weak self] in
            if self?.state != UIGestureRecognizer.State.recognized {
                self?.state = UIGestureRecognizer.State.failed
            }
        }
    }
}

