//
//  FingerTipView.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 28/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

class FingerTipView: UIImageView {

    var timestamp: TimeInterval?
    var shouldAutomaticallyRemoveAfterTimeout: Bool?
    var fadingOut: Bool = false
    
}
