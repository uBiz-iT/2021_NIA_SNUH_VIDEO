//
//  FingerTipOverlayWindow.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 28/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

class FingerTipOverlayWindow: UIWindow {

    override var rootViewController: UIViewController? {
        set {
            super.rootViewController = newValue
        }

        get {
            for window in UIApplication.shared.windows {
                if let window = window as? FingerTips {
                    return window.rootViewController
                }
            }

            return super.rootViewController
        }
    }
    
}
