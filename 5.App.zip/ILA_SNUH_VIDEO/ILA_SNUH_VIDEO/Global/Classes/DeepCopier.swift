//
//  DeepCopier.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/16.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

class DeepCopier {

    static func Copy<T:Codable>(of object:T) -> T? {
       do{
           let json = try JSONEncoder().encode(object)
           return try JSONDecoder().decode(T.self, from: json)
       }
       catch let error{
           print(error)
           return nil
       }
    }
    
}
