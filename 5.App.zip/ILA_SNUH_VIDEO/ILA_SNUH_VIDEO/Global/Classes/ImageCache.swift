//
//  ImageCache.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 2020/11/10.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

class ImageCacheInfo {
    var urlString:String?
    var image:UIImage?
}

var myImageCache:ImageCache = ImageCache()

class ImageCache {
    var maxNum:Int = 200
    var images:[ImageCacheInfo] = [ImageCacheInfo]()

    // url에 해당하는 이미지가 있는지 체크하여 이미지를 리턴. 없으면 nil
    // ----------------------------------------------------------------
    func getImage(urlString:String) -> UIImage? {
        for image in images {
            if (image.urlString == urlString) {
                return image.image!
            }
        }
        return nil
    }

    // ----------------------------------------------------------------
    // 제거 : 첫번째것
    // ----------------------------------------------------------------
    func pop() {
        if (images.count > 0) {
            images.remove(at: 0)
        }
    }
    
    // ----------------------------------------------------------------
    // 추가
    // ----------------------------------------------------------------
    func push(_ imageCacheInfo:ImageCacheInfo) {
        if (images.count >= maxNum) {
            pop()
        }
        images.append(imageCacheInfo)
    }
    
    // ----------------------------------------------------------------
    // 추가
    // ----------------------------------------------------------------
    func push(_ urlString:String, _ image:UIImage) {
        let imageCacheInfo = ImageCacheInfo()
        imageCacheInfo.urlString = urlString
        imageCacheInfo.image = image
        push(imageCacheInfo)
        //p("cache images.count = \(images.count)")
    }
    
    func removeAll() {
        images.removeAll()
    }
    
}
