//
//  RequestProject.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 30/11/2018.
//  Copyright © 2018 uBiz Information Technology. All rights reserved.
//

import UIKit

class RequestProject: NSObject {

    enum typeJsonParsing:Int {
        case GetProjectList, Success, ErrorMessage, End
    }
    
    // 서버로부터 프로젝트 목록 가져오기
    // ==========================================================================
    public func projectList() -> (Bool, Int?) {
        
        struct RequestProjectInfo: Codable {
            var proc_name: String?
            var user_id: String?
            var is_manager: String?
        }
        
        var requestProjectInfo = RequestProjectInfo();
        requestProjectInfo.proc_name = "P_GET_PROJECT_LIST"
        requestProjectInfo.user_id = LoginID
        requestProjectInfo.is_manager = isManager ? "Y" : "N"

        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted]
        
        let jsonData = try? encoder.encode(requestProjectInfo);
        
        // 접속 server url 정의
        // -------------------------------------------------
        let endpoint = "\(ILA4ML_URL_PROC)?id=\(LoginID)"
        guard let endpointUrl = URL(string: endpoint) else {
            p("URL Error : \(endpoint)")
            return (false, 0)
        }
        
        // 요청할 최종 url 정의
        // -------------------------------------------------
        var requestURL = URLRequest(url: endpointUrl)
        requestURL.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        requestURL.httpMethod = "POST"
        requestURL.httpBody = jsonData
        
        var result = false
        
        let (success, error, err_code, err_msg, json ) = SendRequestForJSON(requestURL: requestURL)
        
        do {
            
            if (!success!) {
                if let e = error {
                    throw e
                }
                else {
                    throw ResponseDataError.RequestURLForJSON
                }
            }
            
            guard let getSuccess = self.parseJson(parsingType: .Success, jsonFormat: json) as? Bool
                else { throw ResponseDataError.JsonParsing }

            if (!getSuccess) {
                guard let msg:String =
                    self.parseJson(parsingType: .ErrorMessage, jsonFormat: json) as? String
                    else { throw ResponseDataError.JsonParsing }

                LastURLErrorMessage = msg

                throw ResponseDataError.ReturnValue
            }

            guard let pList:[ProjectInfo] =
                self.parseJson(parsingType: .GetProjectList, jsonFormat: json) as? [ProjectInfo]
                else { throw ResponseDataError.JsonParsing }

            ProjectList = pList
            result = true
             
        }
        catch let error as RequestURLError {
            if (error == RequestURLError.URLSession) {
                LastURLErrorMessage = "[\(String(describing: err_code!))]" + err_msg!
            }
            else {
                LastURLErrorMessage = error.rawValue
            }
        }
        catch let error as ResponseDataError {
            if (LastURLErrorMessage == "") {
                LastURLErrorMessage = error.rawValue
            }
            p("[ResponseDataError] \(error.rawValue)")
        }
        catch let error as NSError {
            LastURLErrorMessage = error.debugDescription
            p("[NSError  ] \(error.debugDescription)")
        }
        catch let error {
            LastURLErrorMessage = error.localizedDescription
            p("[Error  ] \(error.localizedDescription)")
        }
        
        return (result, err_code)
        

    }
    
    
    // JSON 포맷 파싱
    // ==========================================================================
    private func parseJson(parsingType:typeJsonParsing, jsonFormat:Dictionary<String, Any>?) -> AnyObject? {
        
        let returnAnyObject:Bool = false
        
        guard let json = jsonFormat else {
            p("func parseJson:jsonFormat is nil")
            return returnAnyObject as AnyObject
        }
        
        switch parsingType {
        case typeJsonParsing.Success:  // 성공여부 가져오기
            do {
                guard let success = json["success"] as? Bool else {
                    throw ResponseDataError.JsonProtocol
                }
                
                return success as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
                LastURLErrorMessage = error.rawValue
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
                LastURLErrorMessage = error.debugDescription
            }
            
        case typeJsonParsing.ErrorMessage:  //  에러 메시지 가져오기
            
            do {
                guard let errorMessage = json["err_msg"] as? String else {
                    throw ResponseDataError.JsonProtocol
                }
                return errorMessage as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }

        case typeJsonParsing.GetProjectList:  // 프로젝트 목록
            do {
                
                guard let pass_rate = json["pass_rate"] as? Float,
                      let pass_cnt_rate = json["pass_cnt_rate"] as? Float,
                      let ver = json["ver"] as? String,
                      let build = json["build"] as? String,
                      let ver_content = json["ver_content"] as? String,
                      let ver_date = json["ver_date"] as? String
                else {
                    throw ResponseDataError.JsonProtocol
                }
                PASS_RATE = pass_rate
                PASS_COUNT_RATE = pass_cnt_rate
                APP_VERSION = ver
                APP_BUILD = build
                APP_CONTENT = ver_content
                APP_DIST_DATE = ver_date
                
                var projectList:[ProjectInfo] = []
                
                // 하부 구조가 또 있으며 여러개가 있을 경우 대비 [[String: Any]], 하나일 경우 [String: Any]
                // ------------------------------------
                if let items = json["project_list"] as? [[String: Any]] {
                    for item in items {
                        //p("item:", item)
                        
                        guard let code:String = item["cd"] as? String,
                            let name:String = item["nm"] as? String,
                            let data_dir:String = item["data_dir"] as? String,
                            let beg_dt:String = item["beg_dt"] as? String,
                            let end_dt:String = item["end_dt"] as? String,
                            let psg_cnt:Int = item["psg_cnt"] as? Int,
                            let work_cnt:Int = item["work_cnt"] as? Int,
                            let last_image_id:String = item["last"] as? String,
                            let working:Bool = item["working"] as? Bool
                            else { throw ResponseDataError.JsonProtocol }
                        
                        let project = ProjectInfo()
                        project.code = code
                        project.name = name
                        project.labeling_times = 1
                        project.image_dir = data_dir
                        project.begin_dt = beg_dt
                        project.end_dt = end_dt
                        project.total_num = psg_cnt
                        project.complete_num = work_cnt
                        project.last_image_id = last_image_id
                        project.cur_image_id = ""
                        project.working = working
                        projectList.append(project)
                    }
                }
                else {
                    p("typeJsonParsing.GetLabelList else")
                    throw ResponseDataError.JsonProtocol
                }
                
                return projectList as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }
            
        default:
            break
        }
        
        return returnAnyObject as AnyObject
        
    }

}
