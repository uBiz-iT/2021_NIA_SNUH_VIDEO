//
//  DownloadThread.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/05/09.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

//class VideoFileInfo {
//    var isWaiting:Bool?             // 중지중이면 true, 다운시작되었으면 true
//    var downloadTask:DownloadTask?  // Task
//    var requestURL:URL?             // 비디오 파일 요청 URL
//    var fileURL:URL?                // 비디오 파일 저장명
//    var isDownloaded:Bool?          // 다운로드 완료 여부
//    var swiftError:Swift.Error?     // 에러
//    var progress:Float?             // 다운로드 진행률
//    var bytes:Int?                  // 다운로드된 파일 크기
//    var isUsing:Bool?               // 사용중인지
//}
//
//var myVideoInfo:VideoInfo = VideoInfo()
//
//class VideoInfo {
//    var maxNum:Int = 5
//    var videos:[VideoFileInfo] = [VideoFileInfo]()
//
//    // url에 해당하는 비디오가 있는지 체크하여 파일 정보를 리턴. 없으면 nil
//    // ----------------------------------------------------------------
//    func getVideoFileInfo(requestURL:URL) -> VideoFileInfo? {
//        for video in videos {
//            if (video.requestURL == requestURL) {
//                return video
//            }
//        }
//        return nil
//    }
//
//    // ----------------------------------------------------------------
//    // 제거 : 첫번째것. 단 사용중이지 않은것
//    // ----------------------------------------------------------------
//    func pop() -> Bool {
//        if (videos.count > 0) {
//            for i in 0..<videos.count {
//                if (videos[i].isUsing == false) {
//
//                    // 여기에서 파일 삭제 후 리스트에서 제거
//
//                    videos.remove(at: i)
//                    
//                    return true
//                }
//            }
//            return false
//        }
//        else {
//            return true
//        }
//    }
//    
//    // ----------------------------------------------------------------
//    // 추가
//    // ----------------------------------------------------------------
//    func push(_ videoFileInfo:VideoFileInfo) -> Bool {
//        if (videos.count >= maxNum) {
//            if (pop()) {
//                videos.append(videoFileInfo)
//                return true
//            }
//            else {
//                return false // push 실패
//            }
//        }
//        else {
//            videos.append(videoFileInfo)
//            return true
//        }
//    }
//    
//    // ----------------------------------------------------------------
//    // 추가
//    // ----------------------------------------------------------------
//    func push(_ requestURL:URL, _ saveDirUrl:URL, _ fileName:String) {
//        
//        let videoFileInfo = VideoFileInfo()
//        
//        // 저장 위치 디렉토리 생성
//        if (!makeDir(fullPath: saveDirUrl.path)) {
//            p("startDownload1() makeDir sourceVideoDirectoryURL error")
//        }
//         
//        videoFileInfo.isWaiting = true
//        videoFileInfo.downloadTask = nil
//        videoFileInfo.requestURL = requestURL
//        videoFileInfo.fileURL = saveDirUrl.appendingPathComponent(fileName)
//        videoFileInfo.isDownloaded = false
//        videoFileInfo.swiftError = nil
//        videoFileInfo.progress = 0
//        videoFileInfo.bytes = 0
//        videoFileInfo.isUsing = false
//        
//        _ = push(videoFileInfo)
//        p("videos.count = \(videos.count)")
//    }
//    
//    func removeAll() {
//        videos.removeAll()
//    }
//    
//}
//
//
//class DownloadThread: NSObject {
//    
//    fileprivate var endless = false
//    fileprivate var running = false
//    
//    fileprivate func runLoop() {
//        
//        self.running = true
//        
//        while (endless) {
//            if (myVideoInfo.videos.count > 0) {
//                for i in 0..<myVideoInfo.videos.count {
//                    // 대기중인 것을 찾아서 다운로드 시작
//                    if (myVideoInfo.videos[i].isWaiting!) {
//                        startDownload(videoFileInfo: myVideoInfo.videos[i])
//                    }
//                }
//                Thread.sleep(forTimeInterval: 1)
//            }
//            else {
//                Thread.sleep(forTimeInterval: 1)
//            }
//            p("download checking : \(myVideoInfo.videos.count)")
//        }
//    }
//    
//    override init() {
//        super.init()
//    }
//    
//    func start() {
//        
//        if (running) {
//            p("이미 비디오 파일 다운로드 프로세스가 동작중입니다.")
//            return
//        }
//        
//        DispatchQueue.global(qos: .background).async {
//            p("DownloadThread Start")
//            self.endless = true
//            self.runLoop()
//            DispatchQueue.main.async {
//                p("DownloadThread Stop")
//                self.running = false
//            }
//        }
//    }
//    
//    func stop() {
//        if (!running) {
//            p("이미 비디오 파일 다운로드 프로세스가 정지 상태입니다.")
//            return
//        }
//        endless = false
//    }
//    
//    fileprivate func startDownload(videoFileInfo:VideoFileInfo) {
//
//        // let url = URL(string: "http://localhost:8001/?imageID=01&tilestamp=\(Date.timeIntervalSinceReferenceDate)")!
//        // let url = URL(string: requestUrlString)!
//        
//        guard let requestUrl = videoFileInfo.requestURL
//        else {
//            p("startDownload : url nil")
//            return
//        }
//        
//        let request = URLRequest(url: requestUrl, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 30)
//        videoFileInfo.downloadTask = DownloadService.shared.download(request: request)
//        videoFileInfo.downloadTask?.completionHandler = { [] in
//            switch $0 {
//            case .failure(let error):
//                p(error)
//                videoFileInfo.swiftError = error
//                
//            case .success(let data):
//
//                p("Downloaded bytes: \(requestUrl.absoluteString)), \(data.count)")
//                videoFileInfo.bytes = data.count
//                
//                do {
//                    try data.write(to: videoFileInfo.fileURL!)
//                } catch {
//                    p(error.localizedDescription)
//                }
//            }
//            
//            videoFileInfo.isDownloaded = true
//            videoFileInfo.downloadTask = nil
//        }
//        
//        videoFileInfo.downloadTask?.progressHandler = { [] in
//            videoFileInfo.progress = Float($0)
//            videoFileInfo.bytes = $1
//            //p("Downloaded progress : \(requestUrl.absoluteString), \($0)")
//        }
//        
//        videoFileInfo.progress = 0
//        videoFileInfo.isWaiting = false
//        videoFileInfo.downloadTask?.resume()
//        
//    }
    
    // ---------------------
    // 아래는 참조 소스
    // ---------------------
//    fileprivate var downloadTask1:  DownloadTask?
//
//    fileprivate func startDownload1(requestUrlString:String) {
//
//        // let url = URL(string: "http://localhost:8001/?imageID=01&tilestamp=\(Date.timeIntervalSinceReferenceDate)")!
//        let url = URL(string: requestUrlString)!
//        let request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 30)
//        downloadTask1 = DownloadService.shared.download(request: request)
//        downloadTask1?.completionHandler = { [weak self] in
//            switch $0 {
//            case .failure(let error):
//                p(error)
//            case .success(let data):
//                p("Downloaded bytes: \(requestUrlString), \(data.count)")
//
//                let f = url.lastPathComponent
//
//                if (!makeDir(fullPath: (self?.sourceVideoDirectoryURL!.path)!)) {
//                    p("startDownload1() makeDir sourceVideoDirectoryURL error")
//                }
//
//                let saveVideoUrl = self?.sourceVideoDirectoryURL!.appendingPathComponent(f)
//                p(saveVideoUrl?.absoluteString as Any)
//
//                do {
//                    try data.write(to: saveVideoUrl!)
//                } catch {
//                    p(error.localizedDescription)
//                }
//
//                self?.preparePlayer(fileURL: saveVideoUrl! as NSURL)
//
//            }
//            self?.downloadTask1 = nil
//            self?.loadVideoButton.isEnabled = true
//        }
//        downloadTask1?.progressHandler = { [weak self] in
//            p("Downloaded progress : \(requestUrlString), \($0)")
//            self?.downloadProgress.progress = Float($0)
//        }
//
//
//        loadVideoButton.isEnabled = false
//        downloadProgress.progress = 0
//        downloadTask1?.resume()
//
//    }
//}
