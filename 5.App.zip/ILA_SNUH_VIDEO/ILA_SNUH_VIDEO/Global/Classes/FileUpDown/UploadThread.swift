//
//  UploadThread.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 24/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

// upload할 이미지 파일 정보
struct FileToUpload {
    var projectCode: String?    // 프로젝트 코드
    var projectName: String?    // 프로젝트 명
    var imageID: String?        // 소스 이미지 id
    var imageSeq: Int?          // 마킹 이미지 순서 0- , 0이면 기존 이미지 삭제 요청 후 진행
    var name: String?           // 저장할 이름
    var location: String?       // 저장할 위치
    var fileUrl: URL?      // 업로드할 이미지 파일 URL
}

var FileListToUpload:[FileToUpload] = []
var ImagesToUploadCheckCount:Int = 0

class UploadThread: NSObject {
    
    fileprivate var endless = false
    fileprivate var running = false
    
    func runLoop() {
        
        self.running = true
        
        while (endless) {
            if (FileListToUpload.count > 0) {
                
                printUploadList(true)
                
                let imageInfoToUpload = FileListToUpload.removeFirst()
                p("Upload, Trying uploadImageFile : ", imageInfoToUpload.name!, imageInfoToUpload.location! )
                
                // 이미지 순번이 0이면 기존 이미지들을 먼저 삭제 요청
                if (imageInfoToUpload.imageSeq == 0) {
                    let (success, _) = removeMarkedImages(imagePath: imageInfoToUpload.location! , imageID: imageInfoToUpload.imageID!)
                    
                    if (success) {
                        //Thread.sleep(forTimeInterval: 0.1)  20200826
                    }
                }
                
                // 이미지 업로드
                let (success, msg) = uploadImageFile(imageFileURL: imageInfoToUpload.fileUrl!, serverLocation: imageInfoToUpload.location!, name: imageInfoToUpload.name!)
                
                if (success) {
                    //printUploadList(true)
                }
                else {
                    p("Upload, uploadImageFile() is failed:", msg)
                    
                    // 재시도하기 위하여 다시 insert
                    FileListToUpload.insert(imageInfoToUpload, at: 0)
                    //printUploadList(true)
                    Thread.sleep(forTimeInterval: 1)
                }
            }
            else {
                Thread.sleep(forTimeInterval: 0.5)
            }
            printUploadList()
        }
    }
    
    override init() {
        super.init()
    }
    
    func start() {
        
        if (running) {
            p("이미 업로드 프로세스가 동작중입니다.")
            return
        }
        
        DispatchQueue.global(qos: .background).async {
            p("UploadThread Start")
            self.endless = true
            self.runLoop()
            DispatchQueue.main.async {
                p("UploadThread Stop")
                self.running = false
            }
        }
    }
    
    func stop() {
        if (!running) {
            p("이미 업로드 프로세스가 정지 상태입니다.")
            return
        }
        p("UploadThread Stop")
        endless = false
    }
    
    func printUploadList(_ prt:Bool = false) {
        
        var print = prt
        
        ImagesToUploadCheckCount += 1
        if ImagesToUploadCheckCount >= 20 {
            print = true
            ImagesToUploadCheckCount = 0
        }
        
        if print {
            p("-------- File Upload Count : \(FileListToUpload.count)      ---------")
            for data in FileListToUpload {
                p("    imageID      : \(data.imageID as Any)")
                p("    imageSeq     : \(data.imageSeq as Any)")
                p("    fileUrl      : \(data.fileUrl as Any)")
                p("    location     : \(data.location as Any)")
                p("    name         : \(data.name as Any)")
                p("--------------------------------------------------")
            }
        }
    }
    

    
}
