////
////  Download.swift
////  ILA_SNUH_VIDEO
////
////  Created by ubizit on 2021/06/01.
////  Copyright © 2021 uBiz Information Technology. All rights reserved.
////
//
//import UIKit
//
//class Download: NSObject {
//    var imageInfo:ImageInfo
//    var fileType:FileType
//    var isDownloading = false
//    var progress: Float = 0.0
//    
//    var task: URLSessionDownloadTask?
//    var resumeData: Data?
//    
//    init(imageInfo:ImageInfo, fileType:FileType) {
//        self.imageInfo = imageInfo
//        self.fileType = fileType
//    }
//}
