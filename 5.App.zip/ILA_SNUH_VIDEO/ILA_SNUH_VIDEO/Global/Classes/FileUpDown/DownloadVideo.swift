//
//  DownloadVideo.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/05/10.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

//// download할 이미지 파일 정보
//class VideoInfoToDownload {
//    var isDownloading = false
//    var requestUrl: URL?                // 요청할 URL
//    var fileUrl: URL?                   // 저장할 파일 URL
//    var resumeData: Data?               // 중간에 멈춘후 재개시 사용할 것.. 지금까지 받은 데이터
//    var progress: Float = 0             // 다운로드 진행률
//    var collectionViewIndex:Int?        // collectionview index 값 저장
//}
//
//var VideosToDownload:[VideoInfoToDownload] = []

//class VideosToDownloadThread: NSObject {
//
//    private lazy var urlSession: URLSession = {
//        let config = URLSessionConfiguration.background(withIdentifier: "\(Bundle.main.bundleIdentifier ?? "").background")
//        config.isDiscretionary = true
//        config.sessionSendsLaunchEvents = true
//        return URLSession(configuration: config, delegate: self, delegateQueue: nil)
//    }()
//
//    fileprivate var endless = false
//    fileprivate var running = false
//
//    fileprivate var downloadingVideo = VideoInfoToDownload()
//    var task:URLSessionDownloadTask?
//
//    func runLoop() {
//
//        self.running = true
//
//        while (endless) {
//
//            if (VideosToDownload.count > 0) {
//
//                // 첫번째 비디오 정보 설정
//                let videoInfoToDownload = VideosToDownload[0]
//
//                // task가 nil이면 다운로드 대상
//                if (videoInfoToDownload.isDownloading == false) {
//                    p("시작")
//                    startDownload(videoInfoToDownload: videoInfoToDownload)
//                }
//                Thread.sleep(forTimeInterval: 1)
//            }
//            else {
//                Thread.sleep(forTimeInterval: 1)
//            }
//            p("VideosToDownload.count : \(VideosToDownload.count)")
//        }
//    }
//
//    override init() {
//        super.init()
//    }
//
//    func start() {
//
//        if (running) {
//            p("이미 비디오 다운로드 프로세스가 동작중입니다.")
//            return
//        }
//
//        DispatchQueue.global(qos: .background).async {
//            p("VideosToDownloadThread Start")
//            self.endless = true
//            self.runLoop()
//            DispatchQueue.main.async {
//                p("VideosToDownloadThread Stop")
//                self.running = false
//            }
//        }
//    }
//
//    func stop() {
//        if (!running) {
//            p("이미 비디오 다운로드 프로세스가 정지 상태입니다.")
//            return
//        }
//        endless = false
//    }
//
//    func cancel() {
//        if let task = self.task {
//            task.cancel()
//        }
//    }
//
//    func startDownload(videoInfoToDownload:VideoInfoToDownload) {
//        downloadingVideo = videoInfoToDownload
//        downloadingVideo.isDownloading = true
//        task = urlSession.downloadTask(with: downloadingVideo.requestUrl!)
//        task!.resume()
//    }
//}
//
//extension VideosToDownloadThread : URLSessionDelegate, URLSessionDownloadDelegate {
//
//    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
//
//        let progress = Double(totalBytesWritten) / Double(totalBytesExpectedToWrite)
//        downloadingVideo.progress = Float(progress)
//        p("Progress : \(downloadingVideo.fileUrl!) \(progress) (\(totalBytesWritten)/\(totalBytesExpectedToWrite))")
//    }
//
//    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didResumeAtOffset fileOffset: Int64, expectedTotalBytes: Int64) {
//        p("didResumeAtOffset: \(fileOffset)")
//    }
//
//    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
//
//        guard let httpResponse = downloadTask.response as? HTTPURLResponse,
//            (200...299).contains(httpResponse.statusCode) else {
//                p("server error")
//
//                // 다운로로 완료한 것이 첫번째이며 완료되었으므로 리스트에서 제거. 에러가 나도 지운다... 무한 대기를 감안해서...
//                VideosToDownload.remove(at: 0)
//
//                return
//        }
//
//        do {
//            p("didFinishDownloadingTo : \(downloadingVideo.fileUrl!.absoluteURL)")
//
//            try FileManager.default.moveItem(at: location, to: downloadingVideo.fileUrl!)
//            //try FileManager.default.copyItem(at: location, to: downloadingVideo.fileUrl!)
//
//        } catch {
//            p("file error: \(error)")
//        }
//
//        // 다운로로 완료한 것이 첫번째이며 완료되었으므로 리스트에서 제거
//        VideosToDownload.remove(at: 0)
//    }
//
//    func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
//
//        DispatchQueue.main.async {
//            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate,
//                let backgroundCompletionHandler =
//                appDelegate.backgroundCompletionHandler else {
//                    return
//            }
//            backgroundCompletionHandler()
//        }
//    }
//
//}
