//
//  LabelInfo.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 26/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

var LabelList:LabelInfoList = LabelInfoList()

class LabelInfoList {
    var arrayLabelInfo: [LabelInfo] = []
    func getLabelCount(location: Int) -> Int {
        var count = 0
        if (arrayLabelInfo.count == 0) {
            return 0
        }
        for labelInfo in arrayLabelInfo {
            if (labelInfo.location == location) {
                count = count + 1
            }
        }
        return count
    }
    func getLabelText(location: Int) -> [String] {
        var arrayLabelText: [String] = []
        for labelInfo in arrayLabelInfo {
            if (labelInfo.location == location) {
                arrayLabelText.append(labelInfo.text!)
            }
        }
        return arrayLabelText
    }
    func getLabelCode(location: Int) -> [Int] {
        var arrayLabelCode: [Int] = []
        for labelInfo in arrayLabelInfo {
            if (labelInfo.location == location) {
                arrayLabelCode.append(labelInfo.value!)
            }
        }
        return arrayLabelCode
    }
    func getIndexOfLabelCode(location: Int, labelCode: Int) -> Int {
        var index = -1
        var exist = false
        for code in getLabelCode(location: location) {
            index = index + 1
            if (code == labelCode) {
                exist = true
                break;
            }
        }
        return exist ? index : -1
    }
    init() {
    }
}

class LabelInfo {
    var location: Int?  // 0:좌측, 1:우측
    var value: Int?        // 0, 1
    var text: String?   // Negative, Positive
}

class LabelingLocationResult {
    var target_cd: Int?
    var label_cd: Int?
    var memo: String?
}

