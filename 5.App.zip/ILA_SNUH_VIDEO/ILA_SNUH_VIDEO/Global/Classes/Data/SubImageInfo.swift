//
//  SubImageInfo.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 18/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

var subImageList:SubImageList = SubImageList()

class SubImageList {
    var images:[SubImageInfo] = [SubImageInfo]()
    var count:Int {
        get {
            return images.count
        }
    }
    
    // index가져오기
    func indexByImageId(imageId:String) -> Int {
        var retval = -1
        for (index, image) in images.enumerated() {
            if (image.sub_image_id == imageId) {
                retval = index
                break
            }
        }
        return retval
    }
    
    // 라벨링 완료한 이미지만 가져오기
    func doneImages() -> [SubImageInfo] {
        var imageInfoList: [SubImageInfo] = []
        for image in images {
            if (image.isLabelingDone!) {
                imageInfoList.append(image)
            }
        }
        return imageInfoList
    }

    var groupList:[String] {
        get {
            var grouplist:[String] = [String]()
            var exist = false
            for image in images {
                exist = false
                for name in grouplist {
                    if (name == image.group) {
                        exist = true
                    }
                }
                if (!exist) {
                    grouplist.append(image.group!)
                }
            }
            return grouplist
        }
    }
    
    // 라벨링 결과 라벨별 카운팅  20200902
    func countByLabel(target_cd:Int, label_cd:Int) -> Int {
        var count = 0
        for image in images {
            for result in image.labelingResult {
                if (result.target_cd == target_cd &&
                    result.label_cd == label_cd) {
                    count = count + 1
                }
            }
        }
        return count
    }

    func imagesByGroup(group:String) -> [SubImageInfo] {
        var subImageList: [SubImageInfo] = []
        for image in images {
            if (image.group == group) {
                subImageList.append(image)
            }
        }
        return subImageList
    }
    
    func append(subImageInfo:SubImageInfo) {
        images.append(subImageInfo)
    }
    
    func append(subImageList:[SubImageInfo]) {
        images.append(contentsOf: subImageList)
    }
    
    func removeAll() {
        images.removeAll()
    }
    
}

class SubImageInfo {
    var row_num:Int?                    // row num
    var sub_image_id:String?            // 하위 이미지 ID
    var sub_server_location:String?     // 서버 파일 위치 및 이름
    var org_file_path:String?           // 원본 이미지 파일 위치 및 이름
    var thu_file_path:String?           // 썸네일 파일 위치 및 이름
    var mark_num:Int?
    var group:String?
    var newMarking:Bool?
    var newMarkedImage:UIImage?
    var screenshotImage:UIImage?
    var standardImage:UIImage?
    var isLabelingDone:Bool?                           // 라벨링 여부
    var labelingResult:[LabelingLocationResult] = []   // 라벨링 결과
    var fileUrl:URL?                    // 디스크에 저장된 이미지 파일명
}

