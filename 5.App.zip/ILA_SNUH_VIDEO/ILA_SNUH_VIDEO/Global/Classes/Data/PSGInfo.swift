//
//  PSGInfo.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 18/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

var psgList:PSGList = PSGList()

class PSGList {
    var images:[PSGInfo] = [PSGInfo]()
    var count:Int {
        get {
            return images.count
        }
    }
    
    // index가져오기
    func indexByImageId(imageId:String) -> Int {
        var retval = -1
        for (index, image) in images.enumerated() {
            if (image.id == imageId) {
                retval = index
                break
            }
        }
        return retval
    }
    
    // 라벨링 완료한 이미지만 가져오기
    func doneImages() -> [PSGInfo] {
        var psgInfoList: [PSGInfo] = []
        for image in images {
            if (image.isLabelingDone!) {
                psgInfoList.append(image)
            }
        }
        return psgInfoList
    }
    
    // 이미지 정보 추가
    func append(psgInfo:PSGInfo) {
        images.append(psgInfo)
    }
    
    // 이미지 정보 목록 추가
    func append(psgList:[PSGInfo]) {
        images.append(contentsOf: psgList)
    }
    
    func removeAll() {
        images.removeAll()
    }
    
}

class PSGInfo {
    var row_num:Int?                                   // row num
    var id:String?                                     // image ID
    var serverLocation:String?                         // 이미지 파일 서버 위치
    var org_file_path:String?                          // 원본 이미지 파일 서버 위치
    var thu_file_path:String?                          // 썸네일 파일 서버 위치
    var sub_serverLocation:String?                     // 이미지 파일 서버 위치
    var name:String?                                   // 이름
    var isLabelingDone:Bool?                           // 라벨링 여부
    var gender:String?                                  // 성별
    var age:String?                                     // 나이
    var bmi:String?                                     // BMI
    var sltm:String?                                    // 총수면시간
    var slef:String?                                    // 수면효율
    var slla:String?                                    // 수면잠복기
    var ahi:String?                                     // AHI
    var rdi:String?                                     // RDI
    var oxavg:String?                                   // 평균산소포화도
    var oxmin:String?                                   // 최저산소포화도
    var lmi:String?                                     // 총 LM index
    var lmar:String?                                    // 총 LM Arousal index
    var ari:String?                                     // 총 Arousal index
    var diag:String?                                    // 최종 진단
//    var videoDownloadFlag:String?                       // 다운로드 구분 W:다운로드 대기, Y:다운로드 완료, N:다운로드 필요, S:다운로드 시작, E:다운로드 에러, P:멈춤
    var videoDownloadFlag:DownloadStatus = .wait
    var videoDownloadProgress:Float = 0.0               // 다운로드 진행률
    var videoFileUrl:URL?                               // 저장된 파일 URL
    var videoUrl:URL?
//    var tarDownloadFlag:String?                         // 다운로드 구분 W:다운로드 대기, Y:다운로드 완료, N:다운로드 필요, S:다운로드 시작, E:다운로드 에러
    var tarDownloadFlag:DownloadStatus = .wait
    var tarDownloadProgress:Float = 0.0                 // 다운로드 진행률
    var tarFileUrl:URL?                                 // 저장된 파일 URL
    var tarFileServerPath:String?                       // 서버에서 tar 파일 위치
    var tarUrl:URL?
    var psg_chk_res:Int = -1                            // Pass/Fail
    var memo:String = ""                                // 메모
    var video_begDT:String?                             // 비디오 시작 일시 yyyymmddhhmiss
//    var timer:Timer?                                    // 타이머
//    var timer2:Timer?                                   // 타이머
}

enum DownloadStatus:Int, CaseIterable {
    case wait       = 0 // 다운로드 대기 상태
    case added      = 1 // 다운로드 리스트에 추가된 상태
    case started    = 2 // 다운로드가 resume된 상태
    case completed  = 3 // 다운로드 완료 상태
    case error      = 4 // 다운로드 중 에러 상태 : 재개 대상
    case paused     = 5 // 사용자가 cancel한 상태 : 재개 대상
    
    var title:String { get {
        switch self {
        case .wait: return "N"
        case .added: return "W"
        case .started: return "S"
        case .completed: return "Y"
        case .error: return "E"
        case .paused: return "P"
        }
    }}
    init() {
        self = .wait
    }
}

func canDownloadStatus(_ status:DownloadStatus) -> Bool {
    // 다운 미완료, 에러, 정지 상태인 경우에 다운로드 대상
    return status == .wait || status == .error || status == .paused
}

