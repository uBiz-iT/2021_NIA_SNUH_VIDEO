//
//  EventInfo.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/05/19.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

var eventList:EventList = EventList()

class EventList {
    var events:[EventInfo] = [EventInfo]()
    var updatedEvents:[EventInfo] = [EventInfo]()
    var backupEvents:[EventInfo] = [EventInfo]()
    var count:Int {
        get {
            return events.count
        }
    }
    var doneCount:Int {
        get {
            var count = 0
            for event in events {
                if (event.isChecked) {
                    count = count + 1
                }
            }
            return count
        }
    }

    // 추가되거나 수정된 것이 있는지
    var isChanged:Bool {
        get {
            if let _ = events.firstIndex(where: { $0.isNeedToSend }) {
                return true
            }
            else {
                return false
            }
        }
    }
    
    // 기존 이벤트중에서 변경된 것이 있는가
    var isOldEventChanged:Bool {
        get {
            if let _ = oldEvents.firstIndex(where: { $0.isNeedToSend }) {
                return true
            }
            else {
                return false
            }
        }
    }
    
    // 신규로 등록된 이벤트만
    var newEvents:[EventInfo] {
        get {
            return events.filter { $0.isCreated }
        }
    }
    
    // 기존 이벤트만
    var oldEvents:[EventInfo] {
        get {
            return events.filter { $0.isCreated == false }
        }
    }
    
    // index가져오기
    func indexByEventSeq(eventSeq:Int) -> Int {
        var retval = -1
        for (index, event) in events.enumerated() {
            if (event.eventSeq == eventSeq) {
                retval = index
                break
            }
        }
        return retval
    }
    
    // seq로 이벤트 가져오기
    func eventInfoByEventSeq(eventSeq:Int) -> EventInfo? {
        var eventInfo:EventInfo?
        for (_, event) in events.enumerated() {
            if (event.eventSeq == eventSeq) {
                eventInfo = event
                break
            }
        }
        return eventInfo
    }
    
    // seq로 이벤트 가져오기
    func updatedEventInfoByEventSeq(eventSeq:Int) -> EventInfo? {
        var updated:EventInfo?
        for (_, event) in updatedEvents.enumerated() {
            if (event.eventSeq == eventSeq) {
                updated = event
                break
            }
        }
        return updated
    }
    
    // seq로 이벤트 가져오기
    func backupEventInfoByEventSeq(eventSeq:Int) -> EventInfo? {
        var updated:EventInfo?
        for (_, event) in backupEvents.enumerated() {
            if (event.eventSeq == eventSeq) {
                updated = event
                break
            }
        }
        return updated
    }
    
    func maxSeqNewEvent() -> Int {
        // "C" 인것만 가져와서...
        let newEventList = events.filter { $0.eventSeq! > 1000 }
        if newEventList.count == 0 {
            return 1000
        }
        else {
            // 가장 큰 번호르 가져옴
            return newEventList.map { $0.eventSeq! }.max()!
        }
    }
    
    func newEventList() -> [EventInfo] {
        return events.filter { $0.isCreated }
    }
    
    func firstIndexWithTime(second:Int) -> Int? {
        return events.firstIndex { second >= $0.begSecond! && second < $0.endSecond! }
    }
    
    func firstIndexWithTime(ymdhms:String) -> Int? {
        return events.firstIndex { ymdhms >= $0.begDT! && ymdhms < $0.endDT! }
    }
    
    // ------------------------------------------------------------------------
    // 주어진 구간에 이미 이벤트가 걸쳐 있는지 체크... 경과 초(second)로 비교
    // ------------------------------------------------------------------------
    func existEvent(begSec:Int, endSec:Int) -> Bool {
        if let _ = events.firstIndex(where: { ($0.begSecond! >= begSec && $0.begSecond! <= endSec) ||
                                              ($0.endSecond! >= begSec && $0.endSecond! <= endSec) ||
                                              ($0.begSecond! < begSec && $0.endSecond! > endSec)       }) {
            return true
        }
        return false
    }
    
    // ------------------------------------------------------------------------
    // 주어진 구간에 이미 이벤트가 걸쳐 있는지 체크... 날짜로 비교
    // "움직임 이벤트"와 "각성 이벤트" 중에서만 찾음...
    // ------------------------------------------------------------------------
    func existEvent(begSec:String, endSec:String) -> Bool {
        if let _ = events.firstIndex(where: { ( ["움직임 이벤트"].contains($0.typeName) ) &&
                                              ( ($0.begDT! >= begSec && $0.begDT! <= endSec) ||
                                                ($0.endDT! >= begSec && $0.endDT! <= endSec) ||
                                                ($0.begDT! <  begSec && $0.endDT! >  endSec))
                                            })
        {
            return true
        }
        return false
    }
    

    // 시작시간으로 정렬
    func sortWithBegTime() {
         events = events.sorted(by: { $0.begSecond! < $1.begSecond! })
    }
    
    // 검수 완료한 이벤트만 가져오기
    func doneEvents() -> [EventInfo] {
        var eventList: [EventInfo] = []
        for event in events {
            if (event.isChecked) {
                eventList.append(event)
            }
        }
        return eventList
    }

    var groupList:[String] {
        get {
            var grouplist:[String] = [String]()
            var exist = false
            for event in events {
                exist = false
                for name in grouplist {
                    if (name == event.group) {
                        exist = true
                    }
                }
                if (!exist) {
                    grouplist.append(event.group!)
                }
            }
            return grouplist
        }
    }
    
    // 이벤트c 검수 결과 라벨별 카운팅
    func countByLabel(checkValue:Int) -> Int {
        var count = 0
        for event in events {
            if event.isChecked && event.checkResult == checkValue {
                count = count + 1
            }
        }
        return count
    }

//    // 원래 불러온 값으로 재설정
//    func restoreOriginResult() {
//        for event in events {
//            if event.checkResult != event.orgingResult || event.memo != event.originMemo {
//                event.checkResult = event.orgingResult
//                event.memo = event.originMemo
//            }
//        }
//    }
    
    func eventsByGroup(group:String) -> [EventInfo] {
        sortWithBegTime()
        var eventList: [EventInfo] = []
        for event in events {
            if (event.group == group) {
                eventList.append(event)
            }
        }
        return eventList
    }
    
    func eventsByType(type:String = "") -> [EventInfo] {
        sortWithBegTime()
        
        if type == "" {
            return events
        }
        
        var eventList: [EventInfo] = []
        for event in events {
            if (event.typeName == type) {
                eventList.append(event)
            }
        }
        return eventList
    }
    
    func eventsByName(name:String) -> [EventInfo] {
        sortWithBegTime()
        var eventList: [EventInfo] = []
        for event in events {
            if (event.eventName == name) {
                eventList.append(event)
            }
        }
        return eventList
    }
    
    // 전체 이벤트 타입 목록 가져오기
    func typeList() -> [String] {
        var uniqueGroupList = [String]()
        for event in events {
            if !uniqueGroupList.contains(where: {$0 == event.typeName }) {
                uniqueGroupList.append(event.typeName!)
            }
        }
        var temp = uniqueGroupList.sorted(by: {$0 < $1})
        temp.insert("전체", at: 0)
        
        return temp
    }
    
    // 전체 이벤트 명 목록
    func nameList() -> [String] {
        var uniqueNameList = [String]()
        for event in events {
            if !uniqueNameList.contains(where: {$0 == event.eventName }) {
                uniqueNameList.append(event.eventName!)
            }
        }
        var temp = uniqueNameList.sorted(by: {$0 < $1})
        temp.insert("전체", at: 0)

        return temp
    }
    
    // 해당 타입에 해당하는 이벤트 목록
    func nameList(typeName:String) -> [String] {
        var uniqueNameList = [String]()
        for event in events {
            if !uniqueNameList.contains(where: {$0 == event.eventName}) {
                if (event.typeName == typeName) {
                    uniqueNameList.append(event.eventName!)
                }
            }
        }
        var temp = uniqueNameList.sorted(by: {$0 < $1})
        temp.insert("전체", at: 0)
        
        return temp
    }
    
    func append(eventInfo:EventInfo) {
        events.append(eventInfo)
    }
    
    func append(eventList:[EventInfo]) {
        events.append(contentsOf: eventList)
    }
    
    func removeAll() {
        events.removeAll()
        backupEvents.removeAll()
    }

    
    func setAllNG() {
        
    }
    
    // 가장 나중에 수정된 내용으로 다시 세팅. 개별 -> 일괄 -> 다시 돌아올 때 사용
    func restoreAllFromUpdated() {
        for updated in updatedEvents {
            // 이벤트 seq가 동일한 놈을 찾아서 변경
            if let index = events.firstIndex(where: { $0.eventSeq == updated.eventSeq }) {
                events[index].set(event: updated)
            }
        }
    }

    // 백업에 있던 놈을 전부 다시 세팅
    func restoreAllFromBackup() {
        for backup in backupEvents {
            // 이벤트 seq가 동일한 놈을 찾아서 변경
            if let index = events.firstIndex(where: { $0.eventSeq == backup.eventSeq }) {
                events[index].set(event: backup)
            }
        }
    }

    // 특정 이벤트만 백업 데이터로 다시 세팅
    func restore(event:EventInfo) {
        guard let index = backupEvents.firstIndex(where: { $0.eventSeq == event.eventSeq }) else { return }
        event.set(event: backupEvents[index])
    }
    
    // 백업과 최종수정 데이터 복사
    func copyAll() {
        backupEvents.removeAll()
        var backup:EventInfo!
        for event in events {
            event.isCreated = false
            event.isUpdated = false
            event.isDeleted = false
            event.isMemoUpdated = false
            event.isDataUpdated = false
            backup = event.copy()
            backupEvents.append(backup)
        }
        
        updatedEvents.removeAll()
        var updated:EventInfo!
        for event in events {
            event.isCreated = false
            event.isUpdated = false
            event.isDeleted = false
            event.isMemoUpdated = false
            event.isDataUpdated = false
            updated = event.copy()
            updatedEvents.append(updated)
        }
    }
    
    func removeDeletedEvent() {
        events.removeAll { $0.isDeleted }
    }
    
    // 신규로 추가된 것을 삭제할 경우에는 3개 모두에서 삭제처리한다.
    func remove(eventSeq:Int) {
        events.removeAll { $0.eventSeq == eventSeq }
        updatedEvents.removeAll { $0.eventSeq == eventSeq }
        backupEvents.removeAll { $0.eventSeq == eventSeq }
    }
    
    func isSameWithBackup(eventSeq:Int) -> Bool {
        guard let event = eventInfoByEventSeq(eventSeq: eventSeq),
              let backupEvent = backupEventInfoByEventSeq(eventSeq: eventSeq)
        else {
            return false
        }

        return event.isSame(event: backupEvent)

    }
    
    func isSameDataWithBackup(eventSeq:Int) -> Bool {
        guard let event = eventInfoByEventSeq(eventSeq: eventSeq),
              let backupEvent = backupEventInfoByEventSeq(eventSeq: eventSeq)
        else {
            return false
        }

        return event.isSameData(event: backupEvent)

    }
    
    func isSameMemoWithBackup(eventSeq:Int) -> Bool {
        guard let event = eventInfoByEventSeq(eventSeq: eventSeq),
              let backupEvent = backupEventInfoByEventSeq(eventSeq: eventSeq)
        else {
            return false
        }

        return event.isSameMemo(event: backupEvent)

    }
    
}

class EventInfo {
    var isChecked:Bool = false          // 검수 여부
    var eventSeq:Int?
    var eventName:String?
    var checkResult:Int = -1            // 0:OK, 1:NG, 2:Hold, -1:No Check
    var memo:String = ""
    var begDT:String?
    var endDT:String?
    var begEpoNo:Int?
    var endEpoNo:Int?
    var begSecond:Int?
    var endSecond:Int?
    var elapsedSeconds:Int?
    var group:String?
    var note:String?
    var typeName:String?
    var isCreated:Bool = false          // 신규 이벤트 생성
    var isUpdated:Bool = false          // 이벤트가 수정이 되었는지
    var isMemoUpdated:Bool = false
    var isDataUpdated:Bool = false      // 시작시간 종료시간이 변경된 경우
    var isDeleted:Bool = false          // 이벤트가 삭제 되었는지
    
    var isNeedToSend: Bool {
        get {
            return isCreated || isUpdated || isDeleted
        }
    }
    
    func copy() -> EventInfo {
        let new = EventInfo()
        new.isChecked = self.isChecked
        new.eventSeq = self.eventSeq
        new.eventName = self.eventName
        new.checkResult = self.checkResult
        new.memo = self.memo
        new.begDT = self.begDT
        new.endDT = self.endDT
        new.begEpoNo = self.begEpoNo
        new.endEpoNo = self.endEpoNo
        new.begSecond = self.begSecond
        new.endSecond = self.endSecond
        new.elapsedSeconds = self.elapsedSeconds
        new.group = self.group
        new.note = self.note
        new.typeName = self.typeName
        new.isCreated = self.isCreated
        new.isUpdated = self.isUpdated
        new.isDeleted = self.isDeleted
        new.isMemoUpdated = self.isMemoUpdated
        new.isDataUpdated = self.isDataUpdated
        return new
    }

    func set(event:EventInfo) {
        self.isChecked = event.isChecked
        self.eventSeq = event.eventSeq
        self.eventName = event.eventName
        self.checkResult = event.checkResult
        self.memo = event.memo
        self.begDT = event.begDT
        self.endDT = event.endDT
        self.begEpoNo = event.begEpoNo
        self.endEpoNo = event.endEpoNo
        self.begSecond = event.begSecond
        self.endSecond = event.endSecond
        self.elapsedSeconds = event.elapsedSeconds
        self.group = event.group
        self.note = event.note
        self.typeName = event.typeName
        self.isCreated = event.isCreated
        self.isUpdated = event.isUpdated
        self.isDeleted = event.isDeleted
        self.isMemoUpdated = event.isMemoUpdated
        self.isDataUpdated = event.isDataUpdated
    }
    
    // 뭐든 변경된 경우
    func isSame(event:EventInfo) -> Bool {
        if (self.isChecked == event.isChecked &&
//            self.eventSeq == event.eventSeq &&
//            self.eventName == event.eventName &&
            self.checkResult == event.checkResult &&
            self.memo == event.memo &&
//            self.begDT == event.begDT &&
//            self.endDT == event.endDT &&
//            self.begEpoNo == event.begEpoNo &&
//            self.endEpoNo == event.endEpoNo &&
            self.begSecond == event.begSecond &&
            self.endSecond == event.endSecond
//            self.elapsedSeconds == event.elapsedSeconds &&
//            self.group == event.group &&
//            self.note == event.note &&
//            self.typeName == event.typeName
           ) {
            return true
        }
        else {
            return false
        }
    }

    // 메모 정보가 변경된 경우
    func isSameMemo(event:EventInfo) -> Bool {
        if (self.memo == event.memo) {
            return true
        }
        else {
            return false
        }
    }

    // 시작 시간 및 종료 시간이 변경된 경우
    func isSameData(event:EventInfo) -> Bool {
        if (self.begSecond == event.begSecond &&
                self.endSecond == event.endSecond) {
            return true
        }
        else {
            return false
        }
    }
}
