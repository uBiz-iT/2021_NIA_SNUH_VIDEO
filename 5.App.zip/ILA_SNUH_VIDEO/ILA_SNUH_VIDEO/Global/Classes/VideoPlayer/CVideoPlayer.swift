//
//  CVideoPlayer.swift
//  videoplayer
//
//  Created by ubizit on 2021/03/03.
//

import AVFoundation
import Foundation
import UIKit

protocol VideoPlayerDelegate {
    func downloadedProgress(progress:Double)
    func readyToPlay(duration:CMTime)
    func didUpdateProgress(time:CMTime, progress:Float64)
    func didFinishPlayItem()
    func didFailPlayToEnd()
    func failedToLoadVideo()
}

let videoContext: UnsafeMutableRawPointer? = nil

class VideoPlayer : NSObject {

    private var assetPlayer:AVPlayer?
    private var playerItem:AVPlayerItem?

    //private var urlAsset:AVURLAsset?
    private var urlAsset:AVAsset?
    private var mixComposition:AVMutableComposition?

    private var videoOutput:AVPlayerItemVideoOutput?

    private var assetDuration:Float64 = 0
    private var playerView:PlayerView?
    private var composition:AVMutableComposition?

    private var timeRangeMultiplier:Float64 = 1.0
    private var observerIntervalTime:Double = 1 / 30
    
    private var autoRepeatPlay:Bool = false
    private var autoPlay:Bool = false
    
    var frameRate:Float = 0.0
    
    var delegate:VideoPlayerDelegate?

    var playerRate:Float = 1.0 {
        didSet {
            if let player = assetPlayer {
                if isPlaying() {
                    player.rate = 0
                    player.rate = playerRate > 0 ? playerRate : 0.0
                    p("playerRate : \(player.rate)")
                }
            }
        }
    }

    var gravity:AVLayerVideoGravity = .resizeAspect {
        didSet {
            if let playView = playerView, let playerLayer = playView.layer as? AVPlayerLayer {
                playerLayer.videoGravity = gravity
            }
        }
    }

    var isMuted:Bool = true {
        didSet {
            if let player = assetPlayer {
                player.isMuted = isMuted
            }
        }
    }

    var volume:Float = 1.0 {
        didSet {
            if let player = assetPlayer {
                player.volume = volume > 0 ? volume : 0.0
            }
        }
    }

    // MARK: - Init

    convenience init(urlAsset:NSURL, view:PlayerView, startAutoPlay:Bool = true, repeatAfterEnd:Bool = true, gravity:AVLayerVideoGravity = .resizeAspect, timeRangeMultiplier:Float64 = 1) {
        self.init()

        playerView = view
        autoPlay = startAutoPlay
        autoRepeatPlay = repeatAfterEnd
        self.timeRangeMultiplier = timeRangeMultiplier

        if let playView = playerView, let playerLayer = playView.layer as? AVPlayerLayer {
            playerLayer.videoGravity = gravity
        }
        initialSetupWithURL(url: urlAsset)
        prepareToPlay()
    }

    override init() {
        super.init()
    }

    // MARK: - Public

    func replaceItem(urlAsset:NSURL) {
        cleanUp()
        initialSetupWithURL(url: urlAsset)
        prepareToPlay()
    }


    func isPlaying() -> Bool {
        if let player = assetPlayer {
            return player.rate > 0 && player.error == nil
        } else {
            return false
        }
    }

    func seekToPosition(seconds:Float64) {

        let sec = seconds * timeRangeMultiplier
        
        //p("seekToPosition : \(sec)")

        let time: CMTime = CMTimeMake(value: Int64(sec*1000), timescale: 1000)

        //p("time.seconds : \(time.seconds)")
        
        seek(time: time)
    }

    private func seek(time:CMTime) {

        if let player = assetPlayer {
            let playing = isPlaying()
            if (playing) {
                player.rate = 0
            }
            
            //player.seek(to: time, toleranceBefore: .zero, toleranceAfter: CMTime(value: 1, timescale: CMTimeScale(10)))
            player.seek(to: time, toleranceBefore: .zero, toleranceAfter: .zero)

            befCurrentTime = time
            
            if (playing) {
                player.rate = playerRate
            }
        }
    }
    
    func seekToLast() {
        if let player = assetPlayer, let item = player.currentItem {
            let time: CMTime = CMTimeMake(value: Int64(item.duration.seconds * 600), timescale: 600)
            seek(time: time)
        }
    }

    func seekToFoward(seconds:Float64) {
        let sec = seconds * timeRangeMultiplier

        if let player = assetPlayer {
            guard let duration = player.currentItem?.duration else { return }
            
            let currentTime = CMTimeGetSeconds(player.currentTime())
            let newTime = currentTime + Float64(sec)

            if newTime < CMTimeGetSeconds(duration) {
                let time: CMTime = CMTimeMake(value: Int64(newTime*600), timescale: 600)
                seek(time: time)
            }
            else {
                seek(time: duration)
            }
        }
    }

    func seekToBackward(seconds:Float64) {
        
        let sec = seconds * timeRangeMultiplier
        
        if let player = assetPlayer {
            
            guard (player.currentItem?.duration) != nil else { return }

            let currentTime = CMTimeGetSeconds(player.currentTime())
            var newTime = currentTime - Float64(sec)
            
            if newTime < 0 {
                newTime = 0
            }

            let time: CMTime = CMTimeMake(value: Int64(newTime*600), timescale: 600)
            seek(time: time)
        }
    }

    func pause() {
        if let player = assetPlayer {
            befCurrentTime = player.currentTime()
            player.pause()
        }
    }

    func play() {
        if let player = assetPlayer {
            if (player.currentItem?.status == .readyToPlay) {
                if player.rate == 0 {
                    player.play()
                    player.rate = playerRate
                    player.isMuted = isMuted
                }
            }
        }
    }

    func cleanUp() {
        if let item = playerItem {
            item.removeObserver(self, forKeyPath: "status")
            item.removeObserver(self, forKeyPath: "loadedTimeRanges")
        }
        NotificationCenter.default.removeObserver(self)
        removePeriodicalObserver()
        assetPlayer = nil
        playerItem = nil
        urlAsset = nil
    }

    // MARK: - Private

    private func prepareToPlay() {
        let keys = ["tracks"]
        if let asset = urlAsset {
            asset.loadValuesAsynchronously(forKeys: keys, completionHandler: {
                DispatchQueue.main.async {
                    self.startLoading()
                }
            })
        }
    }

    private func startLoading(){
        var error:NSError?
        guard let asset = urlAsset else {return}
        let status:AVKeyValueStatus = asset.statusOfValue(forKey: "tracks", error: &error)

        if status == AVKeyValueStatus.loaded {
            //assetDuration = CMTimeGetSeconds(asset.duration)
            assetDuration = CMTimeGetSeconds(mixComposition!.duration)

            let videoOutputOptions = [kCVPixelBufferPixelFormatTypeKey as String : Int(kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange)]
            videoOutput = AVPlayerItemVideoOutput(pixelBufferAttributes: videoOutputOptions)

            //playerItem = AVPlayerItem(asset: asset)
            playerItem = AVPlayerItem(asset: mixComposition!)

            if let item = playerItem {
                item.addObserver(self, forKeyPath: "status", options: .initial, context: videoContext)
                item.addObserver(self, forKeyPath: "loadedTimeRanges", options: [.new, .old], context: videoContext)

                NotificationCenter.default.addObserver(self, selector: #selector(playerItemDidReachEnd), name: NSNotification.Name.AVPlayerItemDidPlayToEndTime, object: nil)
                NotificationCenter.default.addObserver(self, selector: #selector(didFailedToPlayToEnd), name: NSNotification.Name.AVPlayerItemFailedToPlayToEndTime, object: nil)

                if let output = videoOutput {
                    item.add(output)

                    item.audioTimePitchAlgorithm = AVAudioTimePitchAlgorithm.varispeed
                    
                    assetPlayer = AVPlayer(playerItem: item)
                    frameRate = getFrameRate()

                    if let player = assetPlayer {
                        //imageGenerator = AVAssetImageGenerator(asset: player.currentItem!.asset)
                        // mixComposition으로 변경하니 image 생성 속도가 늦어서 asset으로 대체적용.. 이렇게 하니 빠름
                        imageGenerator = AVAssetImageGenerator(asset: asset)
                        if let gen = imageGenerator {
                            gen.appliesPreferredTrackTransform = true
                            gen.requestedTimeToleranceAfter = CMTime.zero
                            gen.requestedTimeToleranceBefore = CMTime.zero
                        }

                        if autoPlay {
                            player.rate = playerRate
                        }
                        else {
                            player.rate = 0.0
                        }
                    }

                    addPeriodicalObserver()
                    
                    if let playView = playerView, let layer = playView.layer as? AVPlayerLayer {
                        layer.player = assetPlayer
                        //print("player created")
                    }
                }
            }
        }
    }

    private func getFrameRate() -> Float {
        var fps:Float = 0.0
        if let player = assetPlayer {
            let asset = player.currentItem?.asset
            let tracks = asset?.tracks(withMediaType: .video)
            fps = (tracks?.first!.nominalFrameRate)!
        }
        // p("fps : \(fps)")
        return fps
    }
    
    private var timeObserver:Any?
    
    func addPeriodicalObserver() {

        if frameRate > 0 {
            
            let timeInterval = CMTime(seconds: Double(1 / (frameRate)), preferredTimescale: CMTimeScale(NSEC_PER_SEC))

            // p("timeInterval : \(timeInterval.seconds)")
            
            if let player = assetPlayer {

//                let progressObserverQueue = DispatchQueue(label: "progressObserverQueue")
//
//                timeObserver = player.addPeriodicTimeObserver(forInterval: timeInterval, queue: progressObserverQueue, using: { (time) in
//                    self.playerDidChangeTime(time: time)
//                })
                timeObserver = player.addPeriodicTimeObserver(forInterval: timeInterval, queue: DispatchQueue.main, using: { (time) in
                    self.playerDidChangeTime(time: time)
                })
            }
            
        }
        
    }
    
    func removePeriodicalObserver() {
        if let player = assetPlayer, let ob = timeObserver {
            player.removeTimeObserver(ob)
            self.timeObserver = nil
            //p("removePeriodicalObserver")
        }
    }

    // seek, pause 시간을 저장하고 playerDidChangeTime 함수에서 사용한다.
    private var befCurrentTime:CMTime = CMTime.zero
    
    private func playerDidChangeTime(time:CMTime) {

        // 설정된 시간보다 작은 경우에는 뒤늦게 발생되는 놈들이므로 바로 return한다.
        if (time.seconds < befCurrentTime.seconds) {
            //p("playerDidChangeTime : \(befCurrentTime.seconds), \(time.seconds) - return")
            return
        }
        
        let progress:Float64 = time.seconds / assetDuration
        // scaleTimeRange 반영
        let multiplierTime = CMTimeMultiplyByFloat64(time, multiplier: 1 / self.timeRangeMultiplier)
        //p(multiplierTime.seconds)
        delegate?.didUpdateProgress(time: multiplierTime, progress: progress)
    }

    @objc private func playerItemDidReachEnd() {
        delegate?.didFinishPlayItem()

        if let player = assetPlayer {
            if autoRepeatPlay == true {
                befCurrentTime = CMTime.zero
                player.seek(to: CMTime.zero)
                play()
            }
        }
    }

    @objc private func didFailedToPlayToEnd() {
        delegate?.didFailPlayToEnd()
    }

    private func playerDidChangeStatus(status:AVPlayer.Status) {
        if status == .failed {
            delegate?.failedToLoadVideo()
        } else if status == .readyToPlay, let player = assetPlayer {
            if let item = player.currentItem {
                //print(item.duration.seconds)
                delegate?.readyToPlay(duration: CMTimeMultiplyByFloat64(item.duration, multiplier: 1 / timeRangeMultiplier))
                //delegate?.readyToPlay(duration: item.duration)
            }
        }
    }

    private func moviePlayerLoadedTimeRangeDidUpdated(ranges:Array<NSValue>) {
        var maximum:TimeInterval = 0
        for value in ranges {
            let range:CMTimeRange = value.timeRangeValue
            let currentLoadedTimeRange = CMTimeGetSeconds(range.start) + CMTimeGetSeconds(range.duration)
            if currentLoadedTimeRange > maximum {
                maximum = currentLoadedTimeRange
            }
        }
        let progress:Double = assetDuration == 0 ? 0.0 : Double(maximum) / assetDuration

        delegate?.downloadedProgress(progress: progress)
    }

    deinit {
        print("VideoPlayer deinit")
        cleanUp()
    }

    private func initialSetupWithURL(url:NSURL) {
        let options = [AVURLAssetPreferPreciseDurationAndTimingKey : true]
        urlAsset = AVURLAsset(url: url as URL, options: options)
//        urlAsset = AVAsset(url: url as URL)

        if let asset = urlAsset {
            
            mixComposition = AVMutableComposition()
            
            let videoTrack = mixComposition!.addMutableTrack(
                withMediaType: .video,
                preferredTrackID: kCMPersistentTrackID_Invalid
            )
            let audioTrack = mixComposition!.addMutableTrack(
                withMediaType: .audio,
                preferredTrackID: kCMPersistentTrackID_Invalid
            )
            let videoDuration = CMTimeRange(start: CMTime.zero, end: asset.duration)
            
            if (asset.tracks(withMediaType: .video).isEmpty == false) {
                try! videoTrack?.insertTimeRange(
                    videoDuration,
                    of: asset.tracks(withMediaType: .video)[0],
                    at: CMTime.zero
                )
            }
            if (asset.tracks(withMediaType: .audio).isEmpty == false) {
                try! audioTrack?.insertTimeRange(
                    videoDuration,
                    of: asset.tracks(withMediaType: .audio)[0],
                    at: CMTime.zero
                )
            }
            mixComposition?.scaleTimeRange(CMTimeRange(start: CMTime.zero, duration: asset.duration), toDuration: CMTimeMultiplyByFloat64(asset.duration, multiplier: timeRangeMultiplier))
        }
    }

    // MARK: - Observations
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {

        if context == videoContext {
            if let key = keyPath {
                if key == "status", let player = assetPlayer {
                    playerDidChangeStatus(status: player.status)
                } else if key == "loadedTimeRanges", let item = playerItem {
                    moviePlayerLoadedTimeRangeDidUpdated(ranges: item.loadedTimeRanges)
                }
            }
        }
    }
    
    var imageGenerator: AVAssetImageGenerator?
    
    func screenshot(handler:@escaping ((CMTime, UIImage)->Void)) {
        guard let player = assetPlayer else { return }

        let currentTime = player.currentTime()
        let times = [NSValue(time:currentTime)]

        if let gen = imageGenerator {
            gen.generateCGImagesAsynchronously(forTimes: times) { _, image, _, _, _ in
                if image != nil {
                    handler(currentTime, UIImage(cgImage: image!))
                }
            }
        }
    }
    
    func screenshot(picktime:CMTime, handler:@escaping ((CMTime, UIImage)->Void)) {

        // mixcomposition scaleTimeRange 관련
        let ptime = CMTimeMultiplyByFloat64(picktime, multiplier: timeRangeMultiplier)
        
        let times = [NSValue(time:ptime)]

        if let gen = imageGenerator {
            gen.generateCGImagesAsynchronously(forTimes: times) { _, image, _, _, _ in
                if image != nil {
                    handler(picktime, UIImage(cgImage: image!))
                }
            }
        }
    }
    
    func screenshot(picktime:CMTime) -> UIImage? {
        
        if let gen = imageGenerator {
            if let thumb: CGImage = try? gen.copyCGImage(at: picktime, actualTime: nil) {
                return UIImage(cgImage: thumb)
            }

        }
        return nil
    }
    
    func getScreenshotCIImage(picktime:CMTime) -> CIImage? {
        
        if let gen = imageGenerator {
            if let thumb: CGImage = try? gen.copyCGImage(at: picktime, actualTime: nil) {

                // 100 * 100 사이즈로 통일
                let scale = CGFloat(100) / CGFloat(thumb.height)
                let aspectRatio = CGFloat(100) / (CGFloat(thumb.width) * scale)

                let ciImage = CIImage(cgImage: thumb)

                let filter = CIFilter(name: "CILanczosScaleTransform")!
                filter.setValue(ciImage, forKey: "inputImage")
                filter.setValue(scale, forKey: "inputScale")
                filter.setValue(aspectRatio, forKey: "inputAspectRatio")
                let outputImage = filter.value(forKey: "outputImage") as! CIImage
                
                return outputImage
            }

        }
        return nil
    }
    
    func screenshot() -> UIImage? {
        
        if let gen = imageGenerator {
            gen.requestedTimeToleranceAfter = CMTime.zero
            gen.requestedTimeToleranceBefore = CMTime.zero

            if let thumb: CGImage = try? gen.copyCGImage(at: (assetPlayer?.currentTime())!, actualTime: nil) {
                //p("video img successful")
                return UIImage(cgImage: thumb)
            }

        }
        return nil
    }
    
}

