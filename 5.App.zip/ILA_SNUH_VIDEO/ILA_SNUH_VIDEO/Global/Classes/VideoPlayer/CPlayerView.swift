//
//  CPlayerView.swift
//  videoplayer
//
//  Created by ubizit on 2021/03/03.
//

import AVFoundation
import UIKit

class PlayerView: UIView {

    var player: AVPlayer? {
        get {
            return playerLayer.player
        }
        set {
            playerLayer.player = newValue
        }
    }

    var playerLayer: AVPlayerLayer {
        return layer as! AVPlayerLayer
    }
    
//    convenience init() {
//        self.init(frame: CGRect.zero)
//        self.layer.addSublayer(pl)
//    }
//
//    var pl = AVPlayerLayer()
//
//    var playerLayer: AVPlayerLayer {
//        return pl
//    }
    
    // Override UIView property
    override static var layerClass: AnyClass {
        return AVPlayerLayer.self
    }
}
