//
//  FileManager.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/07/31.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

extension FileManager {

    func isDirectoryExists(atUrl url: URL) -> Bool {
        var isDirectory: ObjCBool = false
        let exists = self.fileExists(atPath: url.path, isDirectory:&isDirectory)
        return exists && isDirectory.boolValue
    }
}
