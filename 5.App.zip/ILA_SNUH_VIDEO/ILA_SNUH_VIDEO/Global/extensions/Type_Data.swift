//
//  Data.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/30.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

extension Data {
    public var bytes: [UInt8]
    {
        return [UInt8](self)
    }
}
