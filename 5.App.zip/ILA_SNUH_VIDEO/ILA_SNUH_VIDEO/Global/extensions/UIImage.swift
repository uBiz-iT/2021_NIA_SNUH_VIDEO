//
//  UIImage.swift
//  testSaveImage
//
//  Created by Myeong-Joon Son on 11/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit
import Accelerate

extension UIImage {
    
    // ------------------------------------------------------------------
    // UIImage crop
    // ------------------------------------------------------------------
    func crop(rect: CGRect) -> UIImage {
        var rect = rect
        rect.origin.x*=self.scale
        rect.origin.y*=self.scale
        rect.size.width*=self.scale
        rect.size.height*=self.scale
        
        let imageRef = self.cgImage!.cropping(to: rect)
        let image = UIImage(cgImage: imageRef!, scale: self.scale, orientation: self.imageOrientation)
        return image
    }
    
    func copy() -> UIImage? {
        guard let cgimage = self.cgImage,
              let newCgIm = cgimage.copy()
        else { return nil }
        return UIImage(cgImage: newCgIm, scale: self.scale, orientation: self.imageOrientation)
    }
    
    // ------------------------------------------------------------------
    // UIImage resize
    // ------------------------------------------------------------------
    func resize(scale: CGFloat) -> UIImage?
    {
        let transform = CGAffineTransform(scaleX: scale, y: scale)
        let size = self.size.applying(transform)
        UIGraphicsBeginImageContext(size)
        self.draw(in: CGRect(origin: .zero, size: size))
        let resultImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return resultImage
    }
    
    func overlayWith(image: UIImage, posX: CGFloat, posY: CGFloat) -> UIImage {
        UIGraphicsBeginImageContextWithOptions(size, false, 1)
        draw(in: CGRect(origin: CGPoint.zero, size: size))
        image.draw(in: CGRect(origin: CGPoint(x: posX, y: posY), size: image.size))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return newImage
    }
    
    func resizeImage(_ dimension: CGFloat, opaque: Bool, contentMode: UIView.ContentMode = .scaleAspectFit) -> UIImage {
        var width: CGFloat
        var height: CGFloat
        var newImage: UIImage

        let size = self.size
        let aspectRatio =  size.width/size.height

        switch contentMode {
            case .scaleAspectFit:
                if aspectRatio > 1 {                            // Landscape image
                    width = dimension
                    height = dimension / aspectRatio
                } else {                                        // Portrait image
                    height = dimension
                    width = dimension * aspectRatio
                }

        default:
            fatalError("UIIMage.resizeToFit(): FATAL: Unimplemented ContentMode")
        }

        if #available(iOS 10.0, *) {
            let renderFormat = UIGraphicsImageRendererFormat.default()
            renderFormat.opaque = opaque
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: width, height: height), format: renderFormat)
            newImage = renderer.image {
                (context) in
                self.draw(in: CGRect(x: 0, y: 0, width: width, height: height))
            }
        } else {
            UIGraphicsBeginImageContextWithOptions(CGSize(width: width, height: height), opaque, 0)
                self.draw(in: CGRect(x: 0, y: 0, width: width, height: height))
                newImage = UIGraphicsGetImageFromCurrentImageContext()!
            UIGraphicsEndImageContext()
        }

        return newImage
    }
    
    func scaleImage(toSize newSize: CGSize) -> UIImage? {
        var newImage: UIImage?
        let newRect = CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height).integral
        UIGraphicsBeginImageContextWithOptions(newSize, false, 0)
        if let context = UIGraphicsGetCurrentContext(), let cgImage = self.cgImage {
            context.interpolationQuality = .high
            let flipVertical = CGAffineTransform(a: 1, b: 0, c: 0, d: -1, tx: 0, ty: newSize.height)
            context.concatenate(flipVertical)
            context.draw(cgImage, in: newRect)
            if let img = context.makeImage() {
                newImage = UIImage(cgImage: img)
            }
            UIGraphicsEndImageContext()
        }
        return newImage
    }
    
    class func imageWithView(_ view: UIView) -> UIImage {
        UIGraphicsBeginImageContextWithOptions(view.bounds.size, view.isOpaque, 0)
        defer { UIGraphicsEndImageContext() }
        view.drawHierarchy(in: view.bounds, afterScreenUpdates: true)
        return UIGraphicsGetImageFromCurrentImageContext() ?? UIImage()
    }
    
    var blackPixelCount: Int {
        var count = 0
        for x in 0..<Int(size.width) {
            for y in 0..<Int(size.height) {
                count = count + (isPixelBlack(CGPoint(x: CGFloat(x), y: CGFloat(y))) ? 1 : 0)
            }
        }

        return count
    }

    private func isPixelBlack(_ point: CGPoint) -> Bool {
        let pixelData = cgImage?.dataProvider?.data
        let pointerData: UnsafePointer<UInt8> = CFDataGetBytePtr(pixelData)

        let pixelInfo = Int(((size.width * point.y) + point.x)) * 4

        let maxValue: CGFloat = 255.0
        let compare: CGFloat = 0.00

        if (CGFloat(pointerData[pixelInfo]) / maxValue) > compare { return false }
        if (CGFloat(pointerData[pixelInfo + 1]) / maxValue) > compare { return false }
        if (CGFloat(pointerData[pixelInfo + 2]) / maxValue) > compare { return false }

        return true
    }
    
    var averageColor: UIColor? {
        guard let inputImage = CIImage(image: self) else { return nil }
        let extentVector = CIVector(x: inputImage.extent.origin.x, y: inputImage.extent.origin.y, z: inputImage.extent.size.width, w: inputImage.extent.size.height)

        guard let filter = CIFilter(name: "CIAreaAverage", parameters: [kCIInputImageKey: inputImage, kCIInputExtentKey: extentVector]) else { return nil }
        guard let outputImage = filter.outputImage else { return nil }

        var bitmap = [UInt8](repeating: 0, count: 4)
        let context = CIContext(options: [.workingColorSpace: kCFNull!])
        context.render(outputImage, toBitmap: &bitmap, rowBytes: 4, bounds: CGRect(x: 0, y: 0, width: 1, height: 1), format: .RGBA8, colorSpace: nil)

        return UIColor(red: CGFloat(bitmap[0]) / 255, green: CGFloat(bitmap[1]) / 255, blue: CGFloat(bitmap[2]) / 255, alpha: CGFloat(bitmap[3]) / 255)
    }

    var monochrome: UIImage? {
        guard let currentCGImage = self.cgImage else { return nil }
        let currentCIImage = CIImage(cgImage: currentCGImage)

        let filter = CIFilter(name: "CIColorMonochrome")
        filter?.setValue(currentCIImage, forKey: "inputImage")

        // set a gray value for the tint color
        filter?.setValue(CIColor(red: 0.7, green: 0.7, blue: 0.7), forKey: "inputColor")

        filter?.setValue(1.0, forKey: "inputIntensity")
        guard let outputImage = filter?.outputImage else { return nil }

        let context = CIContext()

        if let cgimg = context.createCGImage(outputImage, from: outputImage.extent) {
            return UIImage(cgImage: cgimg)
        }
        return nil
    }

    var blackAndWhite: UIImage? {
        let context = CIContext(options: nil)
        guard let ciImage = CoreImage.CIImage(image: self) else { return nil }

        // Set image color to b/w
        let bwFilter = CIFilter(name: "CIColorControls")!
        bwFilter.setValuesForKeys([kCIInputImageKey:ciImage, kCIInputBrightnessKey:NSNumber(value: 0.0), kCIInputContrastKey:NSNumber(value: 1.1), kCIInputSaturationKey:NSNumber(value: 0.0)])
        let bwFilterOutput = (bwFilter.outputImage)!

        // Adjust exposure
        let exposureFilter = CIFilter(name: "CIExposureAdjust")!
        exposureFilter.setValuesForKeys([kCIInputImageKey:bwFilterOutput, kCIInputEVKey:NSNumber(value: 0.7)])
        let exposureFilterOutput = (exposureFilter.outputImage)!

        // Create UIImage from context
        guard let bwCGIImage = context.createCGImage(exposureFilterOutput, from: ciImage.extent)
        else { return nil }
        
        let resultImage = UIImage(cgImage: bwCGIImage, scale: 1.0, orientation: self.imageOrientation)

        return resultImage
    }
    
    var histogramDisplayForPSG: UIImage? {
        
        guard let currentCGImage = self.cgImage else { return nil }
        let currentCIImage = CIImage(cgImage: currentCGImage)

        let filter = CIFilter(name:"CIAreaHistogram")
        filter?.setValue(currentCIImage, forKey: kCIInputImageKey)
        filter?.setValue(CIVector(cgRect: currentCIImage.extent), forKey: "inputExtent")
        filter?.setValue(80, forKey: "inputCount")
        filter?.setValue(80, forKey: "inputScale")

        guard let histogramImage = filter?.outputImage else { return nil }

        let filter2 = CIFilter(name:"CIHistogramDisplayFilter")
        filter2?.setValue(histogramImage, forKey: kCIInputImageKey)
        filter2?.setValue(60, forKey: "inputHeight")
        filter2?.setValue(1.0, forKey: "inputHighLimit")
        filter2?.setValue(0.0, forKey: "inputLowLimit")
        filter2?.setValue(0.0, forKey: "inputLowLimit")

        guard let outputImage = filter2?.outputImage else { return nil }

        let context = CIContext()
        
        if let cgimg = context.createCGImage(outputImage, from: outputImage.extent) {
            return UIImage(cgImage: cgimg)
        }
        return nil
    }

    func histogramArray() -> (red: [UInt], green: [UInt], blue: [UInt], alpha: [UInt]) {
        
        let img: CGImage = CIImage(image: self)!.cgImage!

        let imgProvider: CGDataProvider = img.dataProvider!
        let imgBitmapData: CFData = imgProvider.data!
        var imgBuffer = vImage_Buffer(
            data: UnsafeMutableRawPointer(mutating: CFDataGetBytePtr(imgBitmapData)),
            height: vImagePixelCount(img.height),
            width: vImagePixelCount(img.width),
            rowBytes: img.bytesPerRow)

        // bins: zero = red, green = one, blue = two, alpha = three
        var binZero = [vImagePixelCount](repeating: 0, count: 256)
        var binOne = [vImagePixelCount](repeating: 0, count: 256)
        var binTwo = [vImagePixelCount](repeating: 0, count: 256)
        var binThree = [vImagePixelCount](repeating: 0, count: 256)
        
        binZero.withUnsafeMutableBufferPointer { zeroPtr in
            binOne.withUnsafeMutableBufferPointer { onePtr in
                binTwo.withUnsafeMutableBufferPointer { twoPtr in
                    binThree.withUnsafeMutableBufferPointer { threePtr in
                        
                        var histogramBins = [zeroPtr.baseAddress, onePtr.baseAddress,
                                             twoPtr.baseAddress, threePtr.baseAddress]
                        
                        histogramBins.withUnsafeMutableBufferPointer {
                            histogramBinsPtr in
                            let error = vImageHistogramCalculation_ARGB8888(
                                &imgBuffer,
                                histogramBinsPtr.baseAddress!,
                                vImage_Flags(kvImageNoFlags))
                            
                            guard error == kvImageNoError else {
                                fatalError("Error calculating histogram: \(error)")
                            }
                        }
                    }
                }
            }
        }
        
        return (binZero, binOne, binTwo, binThree)
    }
    
    

}

extension CIImage {
    
    var histogramDisplayForPSG: CIImage? {
        
        let filter = CIFilter(name:"CIAreaHistogram")
        filter?.setValue(self, forKey: kCIInputImageKey)
        filter?.setValue(CIVector(cgRect: self.extent), forKey: "inputExtent")
        filter?.setValue(80, forKey: "inputCount")
        filter?.setValue(80, forKey: "inputScale")

        guard let histogramImage = filter?.outputImage else { return nil }

        let filter2 = CIFilter(name:"CIHistogramDisplayFilter")
        filter2?.setValue(histogramImage, forKey: kCIInputImageKey)
        filter2?.setValue(60, forKey: "inputHeight")
        filter2?.setValue(1.0, forKey: "inputHighLimit")
        filter2?.setValue(0.0, forKey: "inputLowLimit")
        filter2?.setValue(0.0, forKey: "inputLowLimit")

        guard let outputImage = filter2?.outputImage else { return nil }
        
        return outputImage

    }


    var blackAndWhite: CIImage? {

        let bwFilter = CIFilter(name: "CIColorControls")!
        bwFilter.setValuesForKeys([kCIInputImageKey:self, kCIInputBrightnessKey:NSNumber(value: 0.0), kCIInputContrastKey:NSNumber(value: 1.1), kCIInputSaturationKey:NSNumber(value: 0.0)])
        let bwFilterOutput = (bwFilter.outputImage)!

        let exposureFilter = CIFilter(name: "CIExposureAdjust")!
        exposureFilter.setValuesForKeys([kCIInputImageKey:bwFilterOutput, kCIInputEVKey:NSNumber(value: 0.7)])

        guard let exposureFilterOutput = exposureFilter.outputImage
        else {
            return nil
        }

        return exposureFilterOutput

    }
    
    func histogramArray() -> (red: [UInt], green: [UInt], blue: [UInt], alpha: [UInt]) {
        
        var binZero = [vImagePixelCount](repeating: 0, count: 256)
        var binOne = [vImagePixelCount](repeating: 0, count: 256)
        var binTwo = [vImagePixelCount](repeating: 0, count: 256)
        var binThree = [vImagePixelCount](repeating: 0, count: 256)

        guard let img: CGImage = convertCIImageToCGImage(inputImage: self)
        else {
            return (binZero, binOne, binTwo, binThree)
        }

        let imgProvider: CGDataProvider = img.dataProvider!
        let imgBitmapData: CFData = imgProvider.data!
        var imgBuffer = vImage_Buffer(
            data: UnsafeMutableRawPointer(mutating: CFDataGetBytePtr(imgBitmapData)),
            height: vImagePixelCount(img.height),
            width: vImagePixelCount(img.width),
            rowBytes: img.bytesPerRow)

        // bins: zero = red, green = one, blue = two, alpha = three
        
        binZero.withUnsafeMutableBufferPointer { zeroPtr in
            binOne.withUnsafeMutableBufferPointer { onePtr in
                binTwo.withUnsafeMutableBufferPointer { twoPtr in
                    binThree.withUnsafeMutableBufferPointer { threePtr in
                        
                        var histogramBins = [zeroPtr.baseAddress, onePtr.baseAddress,
                                             twoPtr.baseAddress, threePtr.baseAddress]
                        
                        histogramBins.withUnsafeMutableBufferPointer {
                            histogramBinsPtr in
                            let error = vImageHistogramCalculation_ARGB8888(
                                &imgBuffer,
                                histogramBinsPtr.baseAddress!,
                                vImage_Flags(kvImageNoFlags))
                            
                            guard error == kvImageNoError else {
                                fatalError("Error calculating histogram: \(error)")
                            }
                        }
                    }
                }
            }
        }
        
        return (binZero, binOne, binTwo, binThree)
    }
}

func convertCIImageToCGImage(inputImage: CIImage) -> CGImage? {
    let context = CIContext(options: nil)
    if let cgImage = context.createCGImage(inputImage, from: inputImage.extent) {
        return cgImage
    }
    return nil
}
