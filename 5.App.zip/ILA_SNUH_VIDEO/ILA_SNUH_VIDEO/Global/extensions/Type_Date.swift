//
//  Type_Date.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/07/07.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

extension Date {

    func toYMDHMS() -> String! {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyyMMddHHmmss"

        let dateString = dateFormatter.string(from: self)
        return dateString
    }
    
}
