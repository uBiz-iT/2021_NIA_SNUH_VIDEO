//
//  Int.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/16.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

extension Int {

    func withCommas() -> String {
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = .decimal
        return numberFormatter.string(from: NSNumber(value:self))!
    }

}

extension Int64 {
    func withCommas() -> String {
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = .decimal
        return numberFormatter.string(from: NSNumber(value:self))!
    }
}

