//
//  Cookie.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/05/28.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit


// -------------------------------------------------------------------------------
// 세션 정보를 담고 있는 url 저장용
// -------------------------------------------------------------------------------
var SESSION_URL:URL?


// -------------------------------------------------------------------------------
// 쿠키 관련
// -------------------------------------------------------------------------------
func getCookie(forURL url: URL?) -> [HTTPCookie] {
    if let cookieUrl = url {
        let cookieStorage = HTTPCookieStorage.shared
        let cookies = cookieStorage.cookies(for: cookieUrl) ?? []
        //p("getCookie : \(cookies)")
        return cookies
    }
    else {
        p("getCookie : is null")
        return []
    }
}

func getHeaderFields(forURL url: URL?) -> [String:String] {
    let cookies = getCookie(forURL: url)
    return HTTPCookie.requestHeaderFields(with: cookies)
}

func deleteCookies(forURL url: URL?) {
    if let cookieUrl = url {
        let cookieStorage = HTTPCookieStorage.shared
        for cookie in getCookie(forURL: cookieUrl) {
            p("delete cookie : ", cookie)
            cookieStorage.deleteCookie(cookie)
        }
    }
}

func setCookies(_ cookies: [HTTPCookie], forURL url: URL?) {
    if let cookieUrl = url {
        let cookieStorage = HTTPCookieStorage.shared
        cookieStorage.setCookies(cookies, for: cookieUrl, mainDocumentURL: nil)
        SESSION_URL = cookieUrl
        p("setCookies : \(getCookie(forURL: cookieUrl))")
    }
}

func setCookies(_ fields: [String:String], forURL url: URL?) {
    p("setCookies fields : \(fields)")
    if let cookieUrl = url {
        let cookies = HTTPCookie.cookies(withResponseHeaderFields: fields, for: cookieUrl)
        setCookies(cookies, forURL: url)
    }
}

// -------------------------------------------------------------------------------

