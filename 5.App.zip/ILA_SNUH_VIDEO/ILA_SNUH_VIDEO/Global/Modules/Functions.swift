//
//  Functions.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/23.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

var CurrentAppVersion: String? {
    guard let dictionary = Bundle.main.infoDictionary,
        let version = dictionary["CFBundleShortVersionString"] as? String,
        let build = dictionary["CFBundleVersion"] as? String else {return nil}
    
    let versionAndBuild: String = "version: \(version), build: \(build)"
    return versionAndBuild
}

var IsVersionUp:Bool {
    if APP_VERSION <= "" || APP_BUILD <= "" {
        return false
    }
    let versionAndBuild: String = "version: \(APP_VERSION), build: \(APP_BUILD)"
    return CurrentAppVersion != versionAndBuild
}

var VersionInfo:String {
    var info:String = ""
    
    info = "버전 : \(APP_VERSION)"
    info = "\(info)\n빌드 : \(APP_BUILD)"
    info = "\(info)\n수정내용 : \(APP_CONTENT)"
    info = "\(info)\n수정일시 : \(APP_DIST_DATE)"

    return info
}
