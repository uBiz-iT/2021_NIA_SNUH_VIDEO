//
//  Orientation.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 25/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

let OrientationKey = "Orientation"
var OrientationValue = UIInterfaceOrientationMask.portrait

enum EnumOrientation:Int, CaseIterable {
    case Landscape = 0, Portrait
    var orientation:UIInterfaceOrientationMask { get {
        switch self {
        case .Portrait:
            return .portrait
        case .Landscape:
            return .landscape
        }
        }}
    var title:String { get {
        switch self {
        case .Portrait:
            return "세로모드"
        case .Landscape:
            return "가로모드"
        }
        }}
}

func SetOrientation() {

    switch OrientationValue {
    case .portrait:
        if UIDevice.current.orientation == UIDeviceOrientation.portrait {
            AppDelegate.AppUtility.lockOrientation([.portrait, .portraitUpsideDown])
        }
        else if UIDevice.current.orientation == UIDeviceOrientation.portraitUpsideDown {
            AppDelegate.AppUtility.lockOrientation([.portrait, .portraitUpsideDown])
        }
        else if UIDevice.current.orientation == UIDeviceOrientation.landscapeLeft {
            AppDelegate.AppUtility.lockOrientation([.portrait, .portraitUpsideDown], andRotateTo: .portrait)
        }
        else if UIDevice.current.orientation == UIDeviceOrientation.landscapeRight  {
            AppDelegate.AppUtility.lockOrientation([.portrait, .portraitUpsideDown], andRotateTo: .portrait)
        }
        else if UIDevice.current.orientation == UIDeviceOrientation.faceUp  {
            if UIWindow.isLandscape {
                AppDelegate.AppUtility.lockOrientation([.portrait, .portraitUpsideDown])
            }
            else {
                AppDelegate.AppUtility.lockOrientation([.portrait, .portraitUpsideDown], andRotateTo: .portrait)
            }
//            if UIApplication.shared.statusBarOrientation.isPortrait {
//                AppDelegate.AppUtility.lockOrientation([.portrait, .portraitUpsideDown])
//            }
//            else {
//                AppDelegate.AppUtility.lockOrientation([.portrait, .portraitUpsideDown], andRotateTo: .portrait)
//            }
        }
        else if UIDevice.current.orientation == UIDeviceOrientation.faceDown  {
            if UIWindow.isPortrait {
                AppDelegate.AppUtility.lockOrientation([.portrait, .portraitUpsideDown])
            }
            else {
                AppDelegate.AppUtility.lockOrientation([.portrait, .portraitUpsideDown], andRotateTo: .portrait)
            }
        }
        else {
            AppDelegate.AppUtility.lockOrientation([.portrait, .portraitUpsideDown])
        }

    case .landscape:
        if UIDevice.current.orientation == UIDeviceOrientation.landscapeLeft {
            AppDelegate.AppUtility.lockOrientation([.landscapeLeft, .landscapeRight])
        }
        else if UIDevice.current.orientation == UIDeviceOrientation.landscapeRight {
            AppDelegate.AppUtility.lockOrientation([.landscapeRight, .landscapeLeft])
        }
        else if UIDevice.current.orientation == UIDeviceOrientation.portrait {
            AppDelegate.AppUtility.lockOrientation([.landscapeLeft, .landscapeRight], andRotateTo: .landscapeLeft)
        }
        else if UIDevice.current.orientation == UIDeviceOrientation.portraitUpsideDown {
            AppDelegate.AppUtility.lockOrientation([.landscapeLeft, .landscapeRight], andRotateTo: .landscapeLeft)
        }
        else if UIDevice.current.orientation == UIDeviceOrientation.faceUp {
            if UIWindow.isLandscape {
                AppDelegate.AppUtility.lockOrientation([.landscapeLeft, .landscapeRight])
            }
            else {
                AppDelegate.AppUtility.lockOrientation([.landscapeLeft, .landscapeRight], andRotateTo: .landscapeLeft)
            }
        }
        else if UIDevice.current.orientation == UIDeviceOrientation.faceDown {
            if UIWindow.isLandscape {
                AppDelegate.AppUtility.lockOrientation([.landscapeLeft, .landscapeRight])
            }
            else {
                AppDelegate.AppUtility.lockOrientation([.landscapeLeft, .landscapeRight], andRotateTo: .landscapeLeft)
            }
        }
        else {
            AppDelegate.AppUtility.lockOrientation([.landscapeLeft, .landscapeRight])
        }

    default :
        AppDelegate.AppUtility.lockOrientation([.portrait], andRotateTo: .portraitUpsideDown)
    }
}
