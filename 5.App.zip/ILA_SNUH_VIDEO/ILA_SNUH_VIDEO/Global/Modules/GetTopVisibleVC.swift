//
//  GetTopVisibleVC.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/19.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

var visibleViewController: UIViewController? {

    let keyWindow = UIApplication.shared.windows.filter {$0.isKeyWindow}.first
    guard let rootViewController = keyWindow?.rootViewController else {
        return nil
    }

    return getVisibleViewController(rootViewController)
}

private func getVisibleViewController(_ rootViewController: UIViewController) -> UIViewController? {

    if let presentedViewController = rootViewController.presentedViewController {
        return getVisibleViewController(presentedViewController)
    }

    if let navigationController = rootViewController as? UINavigationController {
        return navigationController.visibleViewController
    }

    if let tabBarController = rootViewController as? UITabBarController {
        return tabBarController.selectedViewController
    }

    return rootViewController
}
