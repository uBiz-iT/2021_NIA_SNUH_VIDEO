//
//  ErrorHandling.swift
//  ILA_SNUH_VIDEO
//
//  Created by ubizit on 2021/06/18.
//  Copyright © 2021 uBiz Information Technology. All rights reserved.
//

import UIKit

func handlingDbError(code:Int, _ myself:UIViewController) {
    
    if (needToLogin(errno: code)) {
        isLogin = false
        LoginName = "Not signed."
        UserDefaults.standard.set(false, forKey: DefaultKey_isLogin)
        UserDefaults.standard.removeObject(forKey: DefaultKey_loginName)
        UserDefaults.standard.removeObject(forKey: DefaultKey_isManager)

        let dialogMessage = UIAlertController(title: "확인", message: "세션이 종료되었습니다.\n다시 로그인해야 합니다.", preferredStyle: .alert)
        let ok = UIAlertAction(title: "확인", style: .destructive, handler: { (action) -> Void in
            // 메인 화면일 경우에는 로그인하러...
            if myself.className == MainClassName {
                myself.performSegue(withIdentifier: "segueLoginOut", sender: nil)
            }
            // 프로젝트 목록 화면일 경우에는 메인화면으로 돌아감... 메인 로직에서 다시 로그인화면으로 감...
            else if myself.className == ProjectClassName {
                myself.performSegue(withIdentifier: "unwindFromProjectList", sender: myself)
            }
        })
        dialogMessage.addAction(ok)
        myself.present(dialogMessage, animated: true, completion: nil)
        
    }
    else {
        if (LastURLErrorMessage.trimmingCharacters(in: [" "]) != "") {
            let alertProgressNoAction = UIAlertController(title: "메시지 확인", message: "\n\(LastURLErrorMessage)\n\n", preferredStyle: .alert)
            let otherAction = UIAlertAction(title: "확인", style: .default, handler: { action in
                alertProgressNoAction.dismiss(animated: true, completion: nil)
            })
            alertProgressNoAction.addAction(otherAction)
            myself.present(alertProgressNoAction, animated: false, completion: nil)
        }
    }
}

func needToLogin(errno: Int) -> Bool {
    if errno == 401 {
        return true
    }
    return false
}

func alertSimpleMessage(_ title:String, _ message:String) {
    DispatchQueue.main.async {
        if let vc = visibleViewController {
            let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
            let confirmAction = UIAlertAction(title: "확인", style: .default, handler: { action in
                alertController.dismiss(animated: true, completion: nil)
            })
            alertController.addAction(confirmAction)
            vc.present(alertController, animated: false, completion: nil)
        }
        else {
            p(message)
        }
    }
}

func alertVersionMessage() {
    DispatchQueue.main.async {
        guard let vc = visibleViewController else { return }
            
        let alertMessage = """
            신규 앱 버전이 배포되었습니다. 재설치한 후 사용하시기 바랍니다
            
            • 버전 : \(APP_VERSION), 빌드 : \(APP_BUILD)
            • 내용 : \(APP_CONTENT)
            • 날짜 : \(APP_DIST_DATE)
            """
            
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = NSTextAlignment.left
        
        let attributedMessageText = NSMutableAttributedString(
            string: alertMessage,
            attributes: [
                NSAttributedString.Key.paragraphStyle: paragraphStyle,
                NSAttributedString.Key.font: UIFont.systemFont(ofSize: 13.0)
            ]
        )
        
        let alertController = UIAlertController.init(title: "앱 버전 확인", message: nil, preferredStyle: UIAlertController.Style.alert)
                
        alertController.setValue(attributedMessageText, forKey: "attributedMessage")

        let confirmAction = UIAlertAction(title: "확인", style: .default, handler: { action in
            alertController.dismiss(animated: true, completion: nil)
        })
        alertController.addAction(confirmAction)
            
        vc.present(alertController, animated: true, completion: nil)

    }

}
