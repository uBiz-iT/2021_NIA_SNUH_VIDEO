//
//  Func_ImageUpload.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 23/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

// 이미지 업로드 하기
// ==========================================================================
func uploadImageFile_OLD(imageFileURL fileURL:URL, serverLocation dirPath:String, name saveName:String) -> (Bool, String) {
    // ------------------------------------------------
    //let requestURL = makeURLRequestForJsonFromServer(requestType: .GetLabelList)

    let encodedSaveName = saveName.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
    let encodedDirPath = dirPath.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
    let url = URL(string: "\(ILA4ML_URL_UPLOADIMAGE)?save_name=\(encodedSaveName!)&save_path=\(encodedDirPath!)")!
    
    // 경로로부터 요청을 생성한다. 이 때 Content-Type 헤더 필드를 변경한다.
    var requestURL = URLRequest(url: url)
    requestURL.httpMethod = "POST"
    requestURL.setValue("multipart/form-data; boundary=\"XXXXX\"", forHTTPHeaderField: "Content-Type")
    
    var isUploaded = false
    var result = false
    var message = ""
    
    if let bodyData = buildBody(with: fileURL) {
        RequestURLForUpload(requestURL: requestURL, bodyData: bodyData) { success, error,  err_code, err_msg, json in
            do {
                if (!success) {
                    if let e = error {
                        throw e
                    }
                    else {
                        throw ResponseDataError.RequestURLForJSON
                    }
                }
                
                guard let getSuccess = parseJsonUploadResult(parsingType: .Success, jsonFormat: json) as? Bool
                    else { throw ResponseDataError.JsonParsing }
                
                if (!getSuccess) {
                    guard let msg =
                        parseJsonUploadResult(parsingType: .ErrorMessage, jsonFormat: json) as? String
                        else { throw ResponseDataError.JsonParsing }
                    message = msg
                    throw ResponseDataError.ReturnValue
                }
                
                result = getSuccess
                
            }
            catch let error as RequestURLError {
                if (error == RequestURLError.URLSession) {
                    message = err_msg!
                }
                else {
                    message = error.rawValue
                }
            }
            catch let error as ResponseDataError {
                if (message == "") {
                    message = error.rawValue
                }
            }
            catch let error as NSError {
                message = error.debugDescription
            }
            catch let error {
                message = error.localizedDescription
            }
            isUploaded = true
        }
        
        // 일정 시간(초)동안 기다림
        for _ in 1...RequestTimeout {
            if (isUploaded) {
                break
            }
            Thread.sleep(forTimeInterval: 0.1)
        }
        
        if (!isUploaded && !result) {
            message = ResponseDataError.Timeout.rawValue
        }
        
        return (result, message)
        
    }
    else {
        return (false, "Upload, buildBody error")
    }
    
}

// ========================================================================================================
// 이미지 업로드 하기
// ========================================================================================================
func uploadImageFile(imageFileURL fileURL:URL, serverLocation dirPath:String, name saveName:String) -> (Bool, String) {
    // ------------------------------------------------
    //let requestURL = makeURLRequestForJsonFromServer(requestType: .GetLabelList)

    let encodedSaveName = saveName.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
    let encodedDirPath = dirPath.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
    let url = URL(string: "\(ILA4ML_URL_UPLOADIMAGE)?save_name=\(encodedSaveName!)&save_path=\(encodedDirPath!)")!
    
    // 경로로부터 요청을 생성한다. 이 때 Content-Type 헤더 필드를 변경한다.
    var requestURL = URLRequest(url: url)
    requestURL.httpMethod = "POST"
    requestURL.setValue("multipart/form-data; boundary=\"XXXXX\"", forHTTPHeaderField: "Content-Type")
    
    var result = false
    var message = ""
    
    if let bodyData = buildBody(with: fileURL) {
        
        let (success, error, err_code, err_msg, json ) = SendRequestForUpload(requestURL: requestURL, bodyData: bodyData)
        
        do {
            if (!success!) {
                if let e = error {
                    throw e
                }
                else {
                    throw ResponseDataError.RequestURLForJSON
                }
            }

            guard let getSuccess = parseJsonUploadResult(parsingType: .Success, jsonFormat: json) as? Bool
                else { throw ResponseDataError.JsonParsing }
            
            if (!getSuccess) {
                guard let msg =
                    parseJsonUploadResult(parsingType: .ErrorMessage, jsonFormat: json) as? String
                    else { throw ResponseDataError.JsonParsing }
                message = msg
                throw ResponseDataError.ReturnValue
            }
            
            result = getSuccess

        }
        catch let error as RequestURLError {
            if (error == RequestURLError.URLSession) {
                message = "[\(String(describing: err_code!))]" + err_msg!
            }
            else {
                message = error.rawValue
            }
        }
        catch let error as ResponseDataError {
            if (message == "") {
                message = error.rawValue
            }
            p("[ResponseDataError] \(error.rawValue)")
        }
        catch let error as NSError {
            message = error.debugDescription
            p("[NSError  ] \(error.debugDescription)")
        }
        catch let error {
            message = error.localizedDescription
            p("[Error  ] \(error.localizedDescription)")
        }
        
        return (result, message)
        
    }
    else {
        return (false, "Upload, buildBody error")
    }
    
}

//func buildBody(with fileURL: URL, fieldName: String) -> Data? {
func buildBody(with fileURL: URL) -> Data? {
    // 파일을 읽을 수 없다면 nil을 리턴
    guard let filedata = try? Data(contentsOf: fileURL)
        else { return nil }
    
    let mimetype = "image/jpeg"
    
    // 바운더리 값을 정하고,
    // 각 파트의 헤더가 될 라인들을 배열로 만든다.
    // 이 배열을 \r\n 으로 조인하여 한 덩어리로 만들어서
    // 데이터로 인코딩한다.
    let boundary = "XXXXX"
    let headerLines = ["--\(boundary)",
        "Content-Disposition: form-data; name=\"file_name\"; filename=\"\(fileURL.lastPathComponent)\"",
        "Content-Type: \(mimetype)",
        "\r\n"]
    var data = headerLines.joined(separator:"\r\n").data(using:.utf8)!
    
    // 그 다음에 파일 데이터를 붙이고
    data.append(contentsOf: filedata)
    // 마지막으로 데이터의 끝임을 알리는 바운더리를 한 번 더 사용한다.
    // 이는 '새로운 개행'이 필요하므로 앞에 \r\n이 있어야 함에 유의 한다.
    data.append(contentsOf: "\r\n--\(boundary)--".data(using:.utf8)!)
    return data
}

enum typeJsonParsingUploadResult:Int {
    case Success, ErrorMessage, End
}

// 업로드 결과 JSON 포맷 파싱
// ==========================================================================
func parseJsonUploadResult(parsingType:typeJsonParsingUploadResult, jsonFormat:Dictionary<String, Any>?) -> AnyObject? {
    
    let returnAnyObject:Bool = false
    
    guard let json = jsonFormat else {
        p("Upload, func parseJsonUploadResult:jsonFormat is nil")
        return returnAnyObject as AnyObject
    }
    
    switch parsingType {
    case typeJsonParsingUploadResult.Success:  // 성공여부 가져오기
        do {
            guard let success = json["success"] as? Bool else {
                throw ResponseDataError.JsonProtocol
            }
            return success as AnyObject
        }
        catch let error as ResponseDataError {
            p("Upload,", error.rawValue)
        }
        catch let error as NSError {
            p("Upload,", error.debugDescription)
        }
        
    case typeJsonParsingUploadResult.ErrorMessage:  //  에러 메시지 가져오기
        
        do {
            guard let errorMessage = json["err_msg"] as? String else {
                throw ResponseDataError.JsonProtocol
            }
            return errorMessage as AnyObject
        }
        catch let error as ResponseDataError {
            p("Upload,", error.rawValue)
        }
        catch let error as NSError {
            p("Upload,", error.debugDescription)
        }
        
    default:
        break
    }
    
    return returnAnyObject as AnyObject
    
}

// 기존 저장된 이미지 삭제
// ==========================================================================
func removeMarkedImages(imagePath:String, imageID:String) -> (Bool, String)  {
    // ------------------------------------------------
    struct RequestRemoveImage: Codable {
        var image_path: String?
        var image_id: String?
    }
    
    var removeImage = RequestRemoveImage();
    removeImage.image_path = imagePath
    removeImage.image_id = imageID
    
    let encoder = JSONEncoder()
    encoder.outputFormatting = [.prettyPrinted]
    
    let jsonData = try? encoder.encode(removeImage);
    
    // 접속 server url 정의
    // -------------------------------------------------
    let endpoint = ILA4ML_URL_REMOVEIMAGE
    guard let endpointUrl = URL(string: endpoint) else {
        p("URL Error : \(endpoint)")
        return (false, "URL Error : \(endpoint)")
    }

    // 요청할 최종 url 정의
    // -------------------------------------------------
    var request = URLRequest(url: endpointUrl)
    request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
    request.httpMethod = "POST"
    request.httpBody = jsonData

    var result = false
    var message = ""
    
    LastURLErrorMessage = ""
    
    let (success, error, err_code, err_msg, json ) = SendRequestForJSON(requestURL: request)
    
    do {
        if (!success!) {
            if let e = error {
                throw e
            }
            else {
                throw ResponseDataError.RequestURLForJSON
            }
        }

        guard let getSuccess = parseJsonUploadResult(parsingType: .Success, jsonFormat: json) as? Bool
            else { throw ResponseDataError.JsonParsing }
        
        if (!getSuccess) {
            guard let msg:String =
                parseJsonUploadResult(parsingType: .ErrorMessage, jsonFormat: json) as? String
                else { throw ResponseDataError.JsonParsing }
            
            message = msg
            
            throw ResponseDataError.ReturnValue
        }
        
        result = true
        
    }
    catch let error as RequestURLError {
        if (error == RequestURLError.URLSession) {
            message = "[\(String(describing: err_code!))]" + err_msg!
        }
        else {
            message = error.rawValue
        }
    }
    catch let error as ResponseDataError {
        if (message == "") {
            message = error.rawValue
        }
        p("[ResponseDataError] \(message)")
    }
    catch let error as NSError {
        message = error.debugDescription
        p("[NSError  ] \(error.debugDescription)")
    }
    catch let error {
        message = error.localizedDescription
        p("[Error  ] \(error.localizedDescription)")
    }
    
    return (result, message)
    
}
