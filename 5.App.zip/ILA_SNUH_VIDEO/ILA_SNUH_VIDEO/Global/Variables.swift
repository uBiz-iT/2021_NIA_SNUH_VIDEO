//
//  Variables.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 30/11/2018.
//  Copyright © 2018 uBiz Information Technology. All rights reserved.
//

import UIKit

var APP_STATE:UIApplication.State = .inactive
var EXIST_NOTSAVEDDATA = false

// -----------------------------------------------------------------------
// 서버 접속 정보 관련 변수 선언
// -----------------------------------------------------------------------
var ServerAddress = "http://211.192.49.71:3002/VIDEO"    // 서울대병원 서버 공인 IP 및 포트
//var ServerAddress = "http://220.69.215.105:3011"       // 건양대병원 서버 공인 IP, 서울대병원 서비스 포트
//var ServerAddress = "http://ubizit.kr:8080/VIDEO"      // 유비즈 개발 서버

var ServerURL = String(format: "%@", ServerAddress)                               // http://220.69.215.105:3001/
var ServerWebView = String(format: "%@", ServerAddress)                         // http://220.69.215.105:3001/
var ILA4ML_URL_PROC = URL(fileURLWithPath: ServerURL).appendingPathComponent("proc").absoluteString                   // http://220.69.215.105:3001/proc
var ILA4ML_URL_LOGIN = URL(fileURLWithPath: ServerURL).appendingPathComponent("login").absoluteString                   // http://220.69.215.105:3001/proc
var ILA4ML_URL_LOGOUT = URL(fileURLWithPath: ServerURL).appendingPathComponent("logout").absoluteString                   // http://220.69.215.105:3001/proc
var ILA4ML_URL_GETIMAGE = URL(fileURLWithPath: ServerURL).appendingPathComponent("getImage").absoluteString           // http://220.69.215.105:3001/getImage
var ILA4ML_URL_UPLOADIMAGE = URL(fileURLWithPath: ServerURL).appendingPathComponent("uploadImage").absoluteString     // http://220.69.215.105:3001/uploadImage
var ILA4ML_URL_REMOVEIMAGE = URL(fileURLWithPath: ServerURL).appendingPathComponent("removeImage").absoluteString     // http://220.69.215.105:3001/removeImage
var ILA4ML_URL_GETVIDEO = URL(fileURLWithPath: ServerURL).appendingPathComponent("getVideo").absoluteString           // http://220.69.215.105:3001/getImage

var MainClassName = "LabelingVC"
var ProjectClassName = "ProjectVC"

// -----------------------------------------------------------------------
// 서버 요청 관련 변수 선언
// -----------------------------------------------------------------------
var LastURLErrorMessage:String = "No Error"                                     // 서버로 요청한 후의 마지막 에러 메시지 저장
var ResponseErrorCode = 0                                                       // 실패일 경우 에러 코드
let RequestTimeout = 100                                                        // 서버 요청 후 최대 응답시간, 0.1초단위(요청 함수 콜하는 곳)
let RequestURLTimeout = 50                                                      // 서버 요청 후 최대 응답시간, 0.1초단위(실제 요청함수 내에서)

// -----------------------------------------------------------------------
// 앱이 최초 실행되었는지 체크용
// -----------------------------------------------------------------------
var FirstDidBecomeActive = true


// -----------------------------------------------------------------------
// login 정보 글로벌 정의
// -----------------------------------------------------------------------
var isLogin = false;
var LoginID = ""
var LoginName = ""
var isManager = false {
    didSet {
    }
}
var PASS_RATE:Float = 80
var PASS_COUNT_RATE:Float = 80
var APP_VERSION = ""
var APP_BUILD = ""
var APP_CONTENT = ""
var APP_DIST_DATE = ""

// -----------------------------------------------------------------------
// project 정보 글로벌 정의
// -----------------------------------------------------------------------
var isWorking = false;
var WorkingProjectCode = ""
var UserDefaultWorkingProjectCode = ""
var WorkingProjectName = ""

// 아래 3개는 관리자 모드에서 프로젝트를 시작할 때 임시 저장하고 시작한 것처럼 하기 위한 용도로 사용함
var TempProjectCode = ""

var WorkingProjectImageDir = ""                 // 20200826
var WorkingImageIndex = 0
var WorkingImageId = ""                         // 풀스캔 모드 마지막 조회
var WorkingSubImageIndex = 0                    // 20200820
var WorkingSubImageId = ""                      // 20200820
var WorkingImageIdOnReviewMode = ""             // 리뷰 모드 마지막 조회
var LastLabelingImageId = ""
var LastLabelingSubImageId = ""                 // 20200819

var WorkingEventIndex = 0

// -----------------------------------------------------------------------
// 어느 화면에서 어떤 동작을 한 후 unwind되었는지 확인용
// -----------------------------------------------------------------------
var isNewLogined = false
var isFromLoginMenu = false
var isNewProjectBegan = false
var isFromProjectMenu = false

