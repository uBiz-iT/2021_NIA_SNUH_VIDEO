//
//  SettingVC.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 25/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

let MoveStepNumberKey = "MoveStepNumberKey"
var moveStepNumber = 50
let MoveEventStepNumberKey = "MoveEventStepNumberKey"
var moveEventStepNumber = 10


class SettingVC: UITableViewController {

    @IBOutlet var tintColorSegmentedControl: UISegmentedControl!
    @IBOutlet var orientationSegmentedControl: UISegmentedControl!
    
    @IBOutlet var openDownloadPageButton: UIButton!
    
    @IBOutlet var lastVersion: UILabel!
    @IBOutlet var currentVersion: UILabel!
    @IBOutlet weak var lastVersionInfo: UILabel!
    
    @IBOutlet weak var moveStepNum: UILabel!
    @IBOutlet weak var moveStepNumStepper: UIStepper!
    
    @IBOutlet weak var moveEventStepNum: UILabel!
    @IBOutlet weak var moveEventStepNumStepper: UIStepper!
    
    
    @IBOutlet weak var currentPW: UITextField!
    @IBOutlet weak var newPW: UITextField!
    @IBOutlet weak var newPWCF: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // 2 touch 2 taps
        let doubleTapGesture = UIShortTapGestureRecognizer(target: self, action: #selector(doubleTapped(_:)))
        doubleTapGesture.numberOfTouchesRequired = 2
        doubleTapGesture.numberOfTapsRequired = 2
        self.view.addGestureRecognizer(doubleTapGesture)

        initVariables()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        SetOrientation()
        
    }
    
    func initVariables() {
        
        //---------------------------------------------------------------------------
        // orientation segmented control
        //---------------------------------------------------------------------------
        orientationSegmentedControl.removeAllSegments()
        for item in EnumOrientation.allCases {
            let title = EnumOrientation(rawValue: item.rawValue)?.title
            orientationSegmentedControl.insertSegment(withTitle: title, at: orientationSegmentedControl.numberOfSegments, animated: false)
        }
        
        //---------------------------------------------------------------------------
        // tint color segmented control
        //---------------------------------------------------------------------------
        tintColorSegmentedControl.removeAllSegments()
        for item in EnumTintColor.allCases {
            let title = EnumTintColor(rawValue: item.rawValue)?.title
            let color = EnumTintColor(rawValue: item.rawValue)?.color
            let index = tintColorSegmentedControl.numberOfSegments
            tintColorSegmentedControl.insertSegment(withTitle: title, at: index, animated: false)
            (tintColorSegmentedControl.subviews[index] as UIView).tintColor = color
        }
        
        //---------------------------------------------------------------------------
        // 저장된 orientation 가져오기. 없으면 nil이 아닌 0을 return 받음
        //---------------------------------------------------------------------------
        let userDefaultOrientation = UserDefaults.standard.integer(forKey: OrientationKey)
        orientationSegmentedControl.selectedSegmentIndex = userDefaultOrientation
        
        //---------------------------------------------------------------------------
        // 저장된 tintColor index값 가져오기. 없으면 nil이 아닌 0을 return 받음
        //---------------------------------------------------------------------------
        let userDefaultTintColor = UserDefaults.standard.integer(forKey: TintColorKey)
        tintColorSegmentedControl.selectedSegmentIndex = userDefaultTintColor

        //---------------------------------------------------------------------------
        // 이미지 이동 개수
        //---------------------------------------------------------------------------
        moveStepNumStepper.value = Double(moveStepNumber)
        moveStepNum.text = "\(moveStepNumber)"

        //---------------------------------------------------------------------------
        // 이벤트 이동 개수
        //---------------------------------------------------------------------------
        moveEventStepNumStepper.value = Double(moveEventStepNumber)
        moveEventStepNum.text = "\(moveEventStepNumber)"

        currentVersion.text = CurrentAppVersion
        lastVersion.text = getLastVersion()
        lastVersionInfo.text = "\(APP_CONTENT)(\(APP_DIST_DATE))"
        if IsVersionUp {
            lastVersion.textColor = UIColor.red
        }
        else {
            openDownloadPageButton.isHidden = true
        }
    }
    
    var lastVersionFromServer: String = ""
    
    func getLastVersion() -> String {
        let success = CheckVersion()
        if (success) {
            return lastVersionFromServer
        }
        else {
            return "Version Check Error"
        }
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        // 20201127 암호변경추가. 로그인한 경우에만 보이게
        if isLogin {
            return 3
        }
        else {
            return 2
        }
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 5
        }
        else if section == 1 {
            return 2
        }
        else if section == 2 {
            return 1
        }
        return 0
    }

    @IBAction func orientationChanged(_ sender: Any) {
        let selectedIndex = orientationSegmentedControl.selectedSegmentIndex
        UserDefaults.standard.set(selectedIndex, forKey: OrientationKey)
        guard let changedOrientation = EnumOrientation(rawValue: selectedIndex)?.orientation else {
            return
        }
        OrientationValue = changedOrientation
    }
    
    @IBAction func tintColorChanged(_ sender: Any) {
        let selectedIndex = tintColorSegmentedControl.selectedSegmentIndex
        UserDefaults.standard.set(selectedIndex, forKey: TintColorKey)
        guard let changedColor = EnumTintColor(rawValue: selectedIndex)?.color else {
            return
        }
        SetTintColor(color: changedColor)
    }
    
    @IBAction func moveStepNumValueDidChange(_ sender: Any) {
        moveStepNumber = Int(moveStepNumStepper.value)
        moveStepNum.text = "\(moveStepNumber)"
        UserDefaults.standard.set(moveStepNumber, forKey: MoveStepNumberKey)
    }
    
    @IBAction func moveEventStepNumValueDidChange(_ sender: Any) {
        moveEventStepNumber = Int(moveEventStepNumStepper.value)
        moveEventStepNum.text = "\(moveEventStepNumber)"
        UserDefaults.standard.set(moveEventStepNumber, forKey: MoveEventStepNumberKey)
    }
    
    
    @IBAction func openDownloadWebPage(_ sender: Any) {
        //사파리로 링크열기
        if let url = URL(string: "https://ubizit.kr/snuhapps/") {
            UIApplication.shared.open(url, options: [:])
        }
    }
    
    @objc func doubleTapped(_ gesture: UITapGestureRecognizer) {
        
        for window in UIApplication.shared.windows {
            if let window = window as? FingerTips {
                window.alwaysShowTouches = !window.alwaysShowTouches
                p("alwaysShowTouches value: ", window.alwaysShowTouches)
                if window.alwaysShowTouches {
                    self.view.showToast(toastMessage: "탭 위치 표시 모드입니다.", duration: 1.0)
                }
                else {
                    self.view.showToast(toastMessage: "탭 위치 표시 모드가 해제되었습니다.", duration: 1.0)
                }
                break
            }
        }

    }
    
    @IBAction func changePWTapped(_ sender: Any) {

        view.endEditing(true)
        
        if currentPW.text?.trimmingCharacters(in: .whitespaces) == "" {
            self.view.showToast(toastMessage: "현재 암호를 입력하세요", duration: 0.6)
            newPW.text = ""
            newPWCF.text = ""
            return
        }
        
        if newPW.text?.trimmingCharacters(in: .whitespaces) == "" {
            self.view.showToast(toastMessage: "신규 암호를 입력하세요", duration: 0.6)
            newPW.text = ""
            newPWCF.text = ""
            return
        }
        
        if newPW.text != newPWCF.text {
            self.view.showToast(toastMessage: "암호 확인이 잘못되었습니다.", duration: 0.6)
            newPWCF.text = ""
            return
        }
        
        // ------------------------------------------------
        // 스피너 시작
        // ------------------------------------------------
        let child = SpinnerViewController()
        child.view.frame = view.frame
        view.addSubview(child.view)
        child.didMove(toParent: self)

        DoEvents(f:0.01)
        
        let success = changePasswd()
        if (success) {
            self.view.showToast(toastMessage: "암호 변경 완료", duration: 0.6)
        }
        else {
            if (LastURLErrorMessage != "") {
                alertSimpleMessage("확인", "\n\(LastURLErrorMessage)\n\n")
            }
        }
        currentPW.text = ""
        newPW.text = ""
        newPWCF.text = ""

        // ------------------------------------------------
        // 스피너 종료
        // ------------------------------------------------
        child.willMove(toParent: nil)
        child.view.removeFromSuperview()
        child.removeFromParent()
        

    }
    
    

}
