//
//  SettingVC_URL.swift
//  ILA_SNUH
//
//  Created by Myeong-Joon Son on 2020/11/04.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//
import UIKit

extension SettingVC {

    enum typeURLRequest:Int {
        case Ver = 0, ChangePW, End
    }
    
    enum typeJsonParsing:Int {
        case Ver, ChangePW, Success, ErrorMessage, End
    }
    
    // 버전 체크
    // ==========================================================================
    func CheckVersion() -> Bool {
        // ------------------------------------------------
        let requestURL = makeURLRequestForJsonFromServer(requestType: .Ver)
        var result = false
        
        LastURLErrorMessage = ""

        let (success, error, err_code, err_msg, json ) = SendRequestForJSON(requestURL: requestURL)
        
        do {
            if (!success!) {
                if let e = error {
                    throw e
                }
                else {
                    throw ResponseDataError.RequestURLForJSON
                }
            }

            guard let getSuccess = self.parseJson(parsingType: .Success, jsonFormat: json) as? Bool
                else {
                    throw ResponseDataError.JsonParsing
            }
            
            if (!getSuccess) {
                guard let msg:String =
                    self.parseJson(parsingType: .ErrorMessage, jsonFormat: json) as? String
                    else { throw ResponseDataError.JsonParsing }
                
                LastURLErrorMessage = msg
                
                throw ResponseDataError.ReturnValue
            }
            
            p("---------------------------------")
            guard let verbuild:String =
                    self.parseJson(parsingType: .Ver, jsonFormat: json) as? String
                else { throw ResponseDataError.JsonParsing }
            
            lastVersionFromServer = verbuild
            
            result = true
            p("Version Check Ok.")

        }
        catch let error as RequestURLError {
            if (error == RequestURLError.URLSession) {
                LastURLErrorMessage = "[\(String(describing: err_code!))]" + err_msg!
            }
            else {
                LastURLErrorMessage = error.rawValue
            }
        }
        catch let error as ResponseDataError {
            if (LastURLErrorMessage == "") {
                LastURLErrorMessage = error.rawValue
            }
            p("[ResponseDataError] \(error.rawValue)")
        }
        catch let error as NSError {
            LastURLErrorMessage = error.debugDescription
            p("[NSError  ] \(error.debugDescription)")
        }
        catch let error {
            LastURLErrorMessage = error.localizedDescription
            p("[Error  ] \(error.localizedDescription)")
        }
        
        return result
    }
    
    // 암호 변경
    // ==========================================================================
    func changePasswd() -> Bool {
        // ------------------------------------------------
        let requestURL = makeURLRequestForJsonFromServer(requestType: .ChangePW)
        var result = false
        
        LastURLErrorMessage = ""

        let (success, error, err_code, err_msg, json ) = SendRequestForJSON(requestURL: requestURL)
        
        do {
            if (!success!) {
                if let e = error {
                    throw e
                }
                else {
                    throw ResponseDataError.RequestURLForJSON
                }
            }

            guard let getSuccess = self.parseJson(parsingType: .Success, jsonFormat: json) as? Bool
                else {
                    throw ResponseDataError.JsonParsing
            }
            
            if (!getSuccess) {
                guard let msg:String =
                    self.parseJson(parsingType: .ErrorMessage, jsonFormat: json) as? String
                    else { throw ResponseDataError.JsonParsing }
                
                LastURLErrorMessage = msg
                
                throw ResponseDataError.ReturnValue
            }
            
            result = true
            p("passwd change ok Ok.")

        }
        catch let error as RequestURLError {
            if (error == RequestURLError.URLSession) {
                LastURLErrorMessage = "[\(String(describing: err_code!))]" + err_msg!
            }
            else {
                LastURLErrorMessage = error.rawValue
            }
        }
        catch let error as ResponseDataError {
            if (LastURLErrorMessage == "") {
                LastURLErrorMessage = error.rawValue
            }
            p("[ResponseDataError] \(error.rawValue)")
        }
        catch let error as NSError {
            LastURLErrorMessage = error.debugDescription
            p("[NSError  ] \(error.debugDescription)")
        }
        catch let error {
            LastURLErrorMessage = error.localizedDescription
            p("[Error  ] \(error.localizedDescription)")
        }
        
        return result
    }
    
    // 서버로부터 json 포맷으로 받기 위한 url request 생성하기
    // ==========================================================================
    func makeURLRequestForJsonFromServer(requestType:typeURLRequest) -> URLRequest? {
        
        var request:URLRequest? = nil
        
        switch requestType {
        case typeURLRequest.Ver:  // 버전체크
            
            struct RequestVersionInfo: Codable {
                var proc_name: String?
            }
            
            var requestVersionInfo = RequestVersionInfo();
            requestVersionInfo.proc_name = "P_GET_APP_VERSION"
            
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted]
            
            let jsonData = try? encoder.encode(requestVersionInfo);
            
            // 접속 server url 정의
            // -------------------------------------------------
            let endpoint = "\(ILA4ML_URL_PROC)?id=\(LoginID)"
            guard let endpointUrl = URL(string: endpoint) else {
                p("URL Error : \(endpoint)")
                return nil
            }
            
            // 요청할 최종 url 정의
            // -------------------------------------------------
            request = URLRequest(url: endpointUrl)
            request?.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            request!.httpMethod = "POST"
            request!.httpBody = jsonData
            
        case typeURLRequest.ChangePW:  // 암호 변경
            
            struct RequestChangePW: Codable {
                var proc_name: String?
                var user_id: String?
                var passwd: String?
                var passwd_new: String?
            }
            
            var requestChangePW = RequestChangePW();
            requestChangePW.proc_name = "P_CHANGE_PW"
            requestChangePW.user_id = LoginID
            requestChangePW.passwd = currentPW.text
            requestChangePW.passwd_new = newPW.text
            
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted]
            
            let jsonData = try? encoder.encode(requestChangePW);
            
            // 접속 server url 정의
            // -------------------------------------------------
            let endpoint = "\(ILA4ML_URL_PROC)?id=\(LoginID)"
            guard let endpointUrl = URL(string: endpoint) else {
                p("URL Error : \(endpoint)")
                return nil
            }
            
            // 요청할 최종 url 정의
            // -------------------------------------------------
            request = URLRequest(url: endpointUrl)
            request?.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            request!.httpMethod = "POST"
            request!.httpBody = jsonData
            
        default:
            break
        }
        
        return request
        
    }
    
    // JSON 포맷 파싱
    // ==========================================================================
    func parseJson(parsingType:typeJsonParsing, jsonFormat:Dictionary<String, Any>?) -> AnyObject? {
        
        let returnAnyObject:Bool = false
        
        guard let json = jsonFormat else {
            p("func parseJson:jsonFormat is nil")
            return returnAnyObject as AnyObject
        }
        
        switch parsingType {
        case typeJsonParsing.Success:  // 성공여부 가져오기
            
            do {
                guard let success = json["success"] as? Bool else {
                    throw ResponseDataError.JsonProtocol
                }
                return success as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }
            
        case typeJsonParsing.ErrorMessage:  //  에러 메시지 가져오기
            
            do {
                guard let errorMessage = json["err_msg"] as? String else {
                    throw ResponseDataError.JsonProtocol
                }
                return errorMessage as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }
        case typeJsonParsing.Ver:  // 버전
            do {
                
                guard let ver = json["ver"] as? String,
                      let build = json["build"] as? String,
                      let ver_content = json["ver_content"] as? String,
                      let ver_date = json["ver_date"] as? String
                else {
                    throw ResponseDataError.JsonProtocol
                }
                APP_VERSION = ver
                APP_BUILD = build
                APP_CONTENT = ver_content
                APP_DIST_DATE = ver_date
                
                let versionAndBuild: String = "version: \(ver), build: \(build)"
                return versionAndBuild as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }
            
        default:
            break
        }
        
        return returnAnyObject as AnyObject
        
    }
}
