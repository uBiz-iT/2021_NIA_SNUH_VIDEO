/**
 * 
 */
package com.ubizit.mla.service.impl;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

/**
 * @Class Name : ImageDAO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
@Repository("imageDAO")
public class ImageDAO extends EgovAbstractDAO{

	private static final Logger LOGGER = LoggerFactory.getLogger(ImageDAO.class);
	
	/**
	 * Method : getImageTitleSearchList
	 * 최초작성일 : 2020. 9. 9.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트 이미지 count 리스트 조회
	 */
	public void getImageTitleSearchList(Map<String, Object> map) throws Exception {
		LOGGER.debug(">>>>>> ImageDAO.getImageTitleSearchList >>>>>>");
		System.out.println(">>>>>> ImageDAO.getImageTitleSearchList >>>>>>");
		
		select("image.title.search", map);
	}

	/**
	 * Method : getImageSearchList
	 * 최초작성일 : 2020. 9. 10.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트별 이미지 리스트 조회
	 */
	public void getImageSearchList(Map<String, Object> map) throws Exception{
		LOGGER.debug(">>>>>> ImageDAO.getImageSearchList >>>>>>");
		System.out.println(">>>>>> ImageDAO.getImageSearchList >>>>>>");
		
		select("image.search", map);
	}

	/**
	 * Method : getImageSubSearchList
	 * 최초작성일 : 2020. 9. 10.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트 이미지별 서브이미지 리스트 조회
	 */
	public void getImageSubSearchList(Map<String, Object> map) throws Exception{
		LOGGER.debug(">>>>>> ImageDAO.getImageSubSearchList >>>>>>");
		System.out.println(">>>>>> ImageDAO.getImageSubSearchList >>>>>>");
		
		select("image.sub.search", map);
	}

	/**
	 * Method : getImageRefSearchList
	 * 최초작성일 : 2020. 9. 10.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트별 참조이미지 리스트 조회
	 */
	public void getImageRefSearchList(Map<String, Object> map) throws Exception{
		LOGGER.debug(">>>>>> ImageDAO.getImageRefSearchList >>>>>>");
		System.out.println(">>>>>> ImageDAO.getImageRefSearchList >>>>>>");
		
		select("image.ref.search", map);
	}

}
