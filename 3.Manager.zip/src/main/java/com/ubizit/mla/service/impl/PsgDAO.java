/**
 * 
 */
package com.ubizit.mla.service.impl;


import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.ubizit.mla.model.PsgDiVO;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

/**
 * 
 * @Class Name : PsgDAO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 6. 15.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 6. 15.
 * @version : 1.0
 *
 */
@Repository("psgDAO")
public class PsgDAO extends EgovAbstractDAO{

	private static final Logger LOGGER = LoggerFactory.getLogger(PsgDAO.class);

	/**
	 * Method : getVideoSearchList
	 * 최초작성일 : 2021. 6. 15.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : psg 검사 현황 목록
	 */
	public void getVideoSearchList(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> PsgDAO.getProjectSearchList >>>>>>");
		System.out.println(">>>>>> PsgDAO.getProjectSearchList >>>>>>");
		
		select("psg.video.search", map);
	}

	/**
	 * Method : getDiSearch
	 * 최초작성일 : 2021. 6. 16.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * @return
	 * Method 설명 : PSG 진단정보
	 */
	public PsgDiVO getDiSearch(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> PsgDAO.getDiSearch >>>>>>");
		System.out.println(">>>>>> PsgDAO.getDiSearch >>>>>>");
		
		return (PsgDiVO) select("psg.di.search", map);
	}

	/**
	 * Method : getEventSearchList
	 * 최초작성일 : 2021. 6. 16.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : psg 이벤트 목록
	 */
	public void getEventSearchList(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> PsgDAO.getEventSearchList >>>>>>");
		System.out.println(">>>>>> PsgDAO.getEventSearchList >>>>>>");
		
		select("psg.event.search", map);
	}

	/**
	 * Method : getEventTpList
	 * 최초작성일 : 2021. 6. 17.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * Method 설명 : 이벤트 타입 목록
	 */
	public List<?> getEventTpList() throws Exception{
		LOGGER.info(">>>>>> PsgDAO.getEventTpList >>>>>>");
		System.out.println(">>>>>> PsgDAO.getEventTpList >>>>>>");
		
		return list("psg.event.list");
	}

	/**
	 * Method : updateEventList
	 * 최초작성일 : 2021. 6. 17.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 :
	 */
	public void updateEventList(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> PsgDAO.updateEventList >>>>>>");
		System.out.println(">>>>>> PsgDAO.updateEventList >>>>>>");
		
		select("psg.event.update", map);
	}

	/**
	 * Method : eventTypeList
	 * 최초작성일 : 2021. 7. 28.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * Method 설명 : 이벤트 타입 목록
	 */
	public List<?> eventTypeList() throws Exception{
		LOGGER.info(">>>>>> PsgDAO.eventTypeList >>>>>>");
		System.out.println(">>>>>> PsgDAO.eventTypeList >>>>>>");
		
		return list("psgDAO.eventTypeList");
	}

	/**
	 * Method : updateEventTypeList
	 * 최초작성일 : 2021. 8. 4.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * Method 설명 : 이벤트 타입(TYPE) 등록 및 수정
	 */
	public void updateEventTypeList(Map<String, Object> map) {
		LOGGER.info(">>>>>> PsgDAO.updateEventTypeList >>>>>>");
		System.out.println(">>>>>> PsgDAO.updateEventTypeList >>>>>>");
		
		select("psg.eventTp.update", map);
	}

	/**
	 * Method : eventExcelDown
	 * 최초작성일 : 2021. 8. 2.
	 * 작성자 : 장두언
	 * 변경이력 :
	 * @return
	 * Method 설명 : 이벤트 코드 현황 엑셀 다운로드
	 */
	public List<Map<String, Object>> eventExcelDown() throws Exception{
		LOGGER.info(">>>>>> PsgDAO.eventExcelDown >>>>>>");
		System.out.println(">>>>>> PsgDAO.eventExcelDown >>>>>>");
		
		return (List<Map<String, Object>>) list("psg.event.excelDown");
	}

	/**
	 * Method : videoExcelDown
	 * 최초작성일 : 2021. 8. 2.
	 * 작성자 : 장두언
	 * 변경이력 :
	 * @return
	 * Method 설명 : 수면 영상 현황 엑셀 다운로드
	 */
	public List<Map<String, Object>> videoExcelDown(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> PsgDAO.videoExcelDown >>>>>>");
		System.out.println(">>>>>> PsgDAO.videoExcelDown >>>>>>");
		
		return (List<Map<String, Object>>) list("psg.video.excelDown", map);
	}
	

}
