package com.ubizit.mla.service.impl;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.mla.service.AnalysisService;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import net.sf.json.JSONObject;

/**
 * @Class Name : AnalysisServiceimpl.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
@Service("analysisService")
public class AnalysisServiceImpl extends EgovAbstractServiceImpl implements AnalysisService {

	private static final Logger LOGGER = LoggerFactory.getLogger(AnalysisServiceImpl.class);
	
	@Resource(name="analysisDAO")
	private AnalysisDAO analysisDAO;
	
	@Override
	public List<?> getProjectList(String project_cd) throws Exception {
		LOGGER.info(">>>>>> AnalysisServiceImpl.getProjectList >>>>>>");
		System.out.println(">>>>>> AnalysisServiceImpl.getProjectList >>>>>>");
		
		return analysisDAO.getProjectList(project_cd);
	}

	@Override
	public void getSelectItemsList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> AnalysisServiceImpl.getSelectItemsList >>>>>>");
		System.out.println(">>>>>> AnalysisServiceImpl.getSelectItemsList >>>>>>");
		
		analysisDAO.getSelectItemsList(map);
	}

	@Override
	public void getStartAnalysis(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> AnalysisServiceImpl.getStartAnalysis >>>>>>");
		System.out.println(">>>>>> AnalysisServiceImpl.getStartAnalysis >>>>>>");
		
		analysisDAO.getStartAnalysis(map);
	}

	@Override
	public void getConsistencyAnalysis(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> AnalysisServiceImpl.getConsistencyAnalysis >>>>>>");
		System.out.println(">>>>>> AnalysisServiceImpl.getConsistencyAnalysis >>>>>>");
		
		analysisDAO.getConsistencyAnalysis(map);
	}

	@Override
	public void getLabelingAnalysis(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> AnalysisServiceImpl.getLabelingAnalysis >>>>>>");
		System.out.println(">>>>>> AnalysisServiceImpl.getLabelingAnalysis >>>>>>");
		
		analysisDAO.getLabelingAnalysis(map);
	}

	@Override
	public void getCrossChkAnalysis(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> AnalysisServiceImpl.getCrossChkAnalysis >>>>>>");
		System.out.println(">>>>>> AnalysisServiceImpl.getCrossChkAnalysis >>>>>>");
		
		analysisDAO.getCrossChkAnalysis(map);
	}

	@Override
	public void getConsistencyCrossChk(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> AnalysisServiceImpl.getConsistencyCrossChk >>>>>>");
		System.out.println(">>>>>> AnalysisServiceImpl.getConsistencyCrossChk >>>>>>");
		
		analysisDAO.getConsistencyCrossChk(map);
	}

	@Override
	public void getLabelingCrossChk(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> AnalysisServiceImpl.getLabelingCrossChk >>>>>>");
		System.out.println(">>>>>> AnalysisServiceImpl.getLabelingCrossChk >>>>>>");
		
		analysisDAO.getLabelingCrossChk(map);
		
	}

	@Override
	public List<Map<String, Object>> selectAnalysisExcelDown(Map<String, Object> map) throws SQLException {
		LOGGER.info(">>>>>> AnalysisServiceImpl.selectAnalysisExcelDown >>>>>>");
		System.out.println(">>>>>> AnalysisServiceImpl.selectAnalysisExcelDown >>>>>>");

		return analysisDAO.selectAnalysisExcelDown(map);
	}

	@Override
	public int selectAnalysisExcelCnt(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> AnalysisServiceImpl.selectAnalysisExcelCnt >>>>>>");
		System.out.println(">>>>>> AnalysisServiceImpl.selectAnalysisExcelCnt >>>>>>");

		return analysisDAO.selectAnalysisExcelCnt(map);
	}

	@Override
	public void crossChkList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> AnalysisServiceImpl.crossChkList >>>>>>");
		System.out.println(">>>>>> AnalysisServiceImpl.crossChkList >>>>>>");

		analysisDAO.crossChkList(map);
		
	}

	@Override
	public List<Map<String, Object>> psgUser(JSONObject jsonObject) throws Exception {
		LOGGER.info(">>>>>> AnalysisServiceImpl.psgUser >>>>>>");
		System.out.println(">>>>>> AnalysisServiceImpl.psgUser >>>>>>");
		
		Map<String, Object> map = new HashMap<>();
		map.put("psg_id", jsonObject.get("PSG_ID"));
		map.put("project_cd", jsonObject.get("PROJECT_CD"));
		
		return analysisDAO.psgUser(map);
	}

	@Override
	public void eventList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> AnalysisServiceImpl.eventList >>>>>>");
		System.out.println(">>>>>> AnalysisServiceImpl.eventList >>>>>>");
		
		analysisDAO.eventList(map);
	}

	@Override
	public List<Map<String, Object>> eventExcelDown(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> AnalysisServiceImpl.eventExcelDown >>>>>>");
		System.out.println(">>>>>> AnalysisServiceImpl.eventExcelDown >>>>>>");
		
		return analysisDAO.eventExcelDown(map);
	}

	@Override
	public Map<String, Object> videoPath(JSONObject jsonObject) throws Exception {
		
		Map<String, Object> map = new HashMap<>();
		map.put("project_cd", jsonObject.get("PROJECT_CD"));
		map.put("psg_id", jsonObject.get("PSG_ID"));
		
		return analysisDAO.videoPath(map);
	}

	
	
	
	
	
	
}
