/**
 * 
 */
package com.ubizit.mla.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.mla.model.TargetVO;
import com.ubizit.mla.service.LabelService;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * @Class Name : LabelServiceImpl.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
@Service("labelService")
public class LabelServiceImpl extends EgovAbstractServiceImpl implements LabelService{

	private static final Logger LOGGER = LoggerFactory.getLogger(LabelServiceImpl.class);
	
	@Resource(name="labelDAO")
	private LabelDAO labelDAO;

	@Override
	public void getLabelSearchList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> LabelServiceImpl.getLabelSearchList >>>>>>");
		System.out.println(">>>>>> LabelServiceImpl.getLabelSearchList >>>>>>");
		
		labelDAO.getLabelSearchList(map);
	}

	@Override
	public List<TargetVO> getTargetInfo(String mission_cd) throws Exception {
		LOGGER.info(">>>>>> LabelServiceImpl.getTargetInfo >>>>>>");
		System.out.println(">>>>>> LabelServiceImpl.getTargetInfo >>>>>>");
		
		return labelDAO.getTargetInfo(mission_cd);
	}

	@Override
	public void saveLabelList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> LabelServiceImpl.saveLabelList >>>>>>");
		System.out.println(">>>>>> LabelServiceImpl.saveLabelList >>>>>>");
		
		labelDAO.saveLabelList(map);
	}
	
	

}
