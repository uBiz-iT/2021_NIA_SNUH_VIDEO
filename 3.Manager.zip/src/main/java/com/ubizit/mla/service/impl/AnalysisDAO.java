/**
 * 
 */
package com.ubizit.mla.service.impl;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.ibatis.sqlmap.client.SqlMapClient;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

/**
 * @Class Name : AnalysisDAO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
@Repository("analysisDAO")
public class AnalysisDAO extends EgovAbstractDAO {

	SqlMapClient sqlMap;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AnalysisDAO.class);
	
	/**
	 * Method : getProjectList
	 * 최초작성일 : 2020. 9. 16.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * Method 설명 : 프로젝트 조회
	 */
	public List<?> getProjectList(String project_cd) throws Exception{
		LOGGER.info(">>>>>> AnalysisDAO.getProjectList >>>>>>");
		System.out.println(">>>>>> AnalysisDAO.getProjectList >>>>>>");
		
		return list("analysisDAO.getProjectList", project_cd);
	}

	/**
	 * Method : getSelectItemsList
	 * 최초작성일 : 2020. 9. 17.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * @return
	 * Method 설명 : 프로젝트, 판독자, 라벨링차수, 타겟 리스트..
	 */
	public void getSelectItemsList(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> AnalysisDAO.getSelectItemsList >>>>>>");
		System.out.println(">>>>>> AnalysisDAO.getSelectItemsList >>>>>>");
		
		select("analysis.select.items", map);
	}

	/**
	 * Method : getStartAnalysis
	 * 최초작성일 : 2020. 9. 22.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 분석 결과
	 */
	public void getStartAnalysis(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> AnalysisDAO.getStartAnalysis >>>>>>");
		System.out.println(">>>>>> AnalysisDAO.getStartAnalysis >>>>>>");
		
		select("analysis.start", map);
	}

	/**
	 * Method : getConsistencyAnalysis
	 * 최초작성일 : 2020. 11. 2.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 일치도 그래프
	 */
	public void getConsistencyAnalysis(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> AnalysisDAO.getConsistencyAnalysis >>>>>>");
		System.out.println(">>>>>> AnalysisDAO.getConsistencyAnalysis >>>>>>");
		
		select("analysis.consistency", map);
	}

	/**
	 * Method : getLabelingAnalysis
	 * 최초작성일 : 2020. 11. 2.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 라벨링 작업량
	 */
	public void getLabelingAnalysis(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> AnalysisDAO.getLabelingAnalysis >>>>>>");
		System.out.println(">>>>>> AnalysisDAO.getLabelingAnalysis >>>>>>");
		
		select("analysis.labeling", map);
	}

	/**
	 * Method : getCrossChkAnalysis
	 * 최초작성일 : 2020. 11. 5.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 이미지 세트별 크로스체크
	 */
	public void getCrossChkAnalysis(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> AnalysisDAO.getStartAnalysis >>>>>>");
		System.out.println(">>>>>> AnalysisDAO.getStartAnalysis >>>>>>");
		
		select("analysis.crosschk", map);
	}

	/**
	 * Method : getConsistencyCrossChk
	 * 최초작성일 : 2020. 11. 5.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 일치도 그래프
	 */
	public void getConsistencyCrossChk(Map<String, Object> map) {
		LOGGER.info(">>>>>> AnalysisDAO.getConsistencyCrossChk >>>>>>");
		System.out.println(">>>>>> AnalysisDAO.getConsistencyCrossChk >>>>>>");
		
		select("analysis.crosschk.consistency", map);
	}

	/**
	 * Method : getLabelingCrossChk
	 * 최초작성일 : 2020. 11. 5.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 라벨링 작업량
	 */
	public void getLabelingCrossChk(Map<String, Object> map) {
		LOGGER.info(">>>>>> AnalysisDAO.getLabelingCrossChk >>>>>>");
		System.out.println(">>>>>> AnalysisDAO.getLabelingCrossChk >>>>>>");
		
		select("analysis.crosschk.labeling", map);
	}

	/**
	 * Method : selectAnalysisExcelDown
	 * 최초작성일 : 2021. 3. 15.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * @return
	 * Method 설명 : 프로젝트별 교차 검증 pass/non-pass 엑셀다운로드
	 */
	public List<Map<String, Object>> selectAnalysisExcelDown(Map<String, Object> map) throws SQLException {
		LOGGER.info(">>>>>> AnalysisDAO.selectAnalysisExcelDown >>>>>>");
		System.out.println(">>>>>> AnalysisDAO.selectAnalysisExcelDown >>>>>>");
		
		return (List<Map<String, Object>>) list("analysis.excelDown", map);
	}

	/**
	 * Method : selectAnalysisExcelCnt
	 * 최초작성일 : 2021. 3. 15.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * @return
	 * Method 설명 : 프로젝트별 교차 검증 pass/non-pass 판독자 수
	 */
	public int selectAnalysisExcelCnt(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> AnalysisDAO.selectAnalysisExcelCnt >>>>>>");
		System.out.println(">>>>>> AnalysisDAO.selectAnalysisExcelCnt >>>>>>");
		
		return (int) select("analysis.excelDown.cnt", map);
	}

	/**
	 * Method : crossChkList
	 * 최초작성일 : 2021. 7. 9.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 검수 결과 크로스 체크
	 */
	public void crossChkList(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> AnalysisDAO.crossChkList >>>>>>");
		System.out.println(">>>>>> AnalysisDAO.crossChkList >>>>>>");
		
		select("analysis.crosschk", map);
	}

	/**
	 * Method : psgUser
	 * 최초작성일 : 2021. 7. 13.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * @return
	 * Method 설명 : 검수자 목록
	 */
	public List<Map<String, Object>> psgUser(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> AnalysisDAO.psgUser >>>>>>");
		System.out.println(">>>>>> AnalysisDAO.psgUser >>>>>>");
		
		return (List<Map<String, Object>>) list("analysis.psgUser", map);
	}

	/**
	 * Method : eventList
	 * 최초작성일 : 2021. 7. 13.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 검수자 이벤트 리스트
	 */
	public void eventList(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> AnalysisDAO.eventList >>>>>>");
		System.out.println(">>>>>> AnalysisDAO.eventList >>>>>>");
		
		select("analysis.eventList", map);
	}

	/**
	 * Method : eventExcelDown
	 * 최초작성일 : 2021. 8. 10.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * @return
	 * Method 설명 : 이벤트 검수 결과 엑셀 다운로드
	 */
	public List<Map<String, Object>> eventExcelDown(Map<String, Object> map) {
		LOGGER.info(">>>>>> AnalysisDAO.eventExcelDown >>>>>>");
		System.out.println(">>>>>> AnalysisDAO.eventExcelDown >>>>>>");
		
		return (List<Map<String, Object>>) list("analysis.event.excelDown", map);
	}

	/**
	 * Method : videoPath
	 * 최초작성일 : 2021. 8. 11.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * @return
	 * Method 설명 : video 경로
	 */
	public Map<String, Object> videoPath(Map<String, Object> map) {
		LOGGER.info(">>>>>> AnalysisDAO.videoPath >>>>>>");
		System.out.println(">>>>>> AnalysisDAO.videoPath >>>>>>");
		
		return (Map<String, Object>) select("analysis.videoPath", map);
	}

}
