/**
 * 
 */
package com.ubizit.mla.service;

import java.util.List;
import java.util.Map;

/**
 * @Class Name : UserService.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
public interface UserService {

	/**
	 * Method : getUserSearchList
	 * 최초작성일 : 2020. 9. 8.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 사용자 리스트 조회
	 */
	void getUserSearchList(Map<String, Object> map) throws Exception;

	/**
	 * Method : saveUserList
	 * 최초작성일 : 2021. 6. 18.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 사용자 저장
	 */
	void saveUserList(Map<String, Object> map) throws Exception;

	/**
	 * Method : userExcelDown
	 * 최초작성일 : 2021. 8. 3.
	 * 작성자 : 장두언
	 * 변경이력 :
	 * @return
	 * @throws Exception
	 * Method 설명 : 검수자 현황 엑셀 다운로드
	 */
	List<Map<String, Object>> userExcelDown(Map<String, Object> map) throws Exception;

}
