/**
 * 
 */
package com.ubizit.mla.service.impl;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

/**
 * @Class Name : MainDAO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
@Repository("mainDAO")
public class MainDAO extends EgovAbstractDAO{

	private static final Logger LOGGER = LoggerFactory.getLogger(MainDAO.class);

	/**
	 * Method : getProgressCounts
	 * 최초작성일 : 2021. 6. 1.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 메인(대시보드) 화면 건 수 데이터들
	 */
	public void getProgressCounts(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> MainServiceImpl.getProgressCounts >>>>>>");
		System.out.println(">>>>>> MainServiceImpl.getProgressCounts >>>>>>");
		
		select("main.total.progress", map);
	}
	
	/**
	 * Method : getWeekMonthCharts
	 * 최초작성일 : 2021. 6. 7.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 주간/월간 실적 그래프
	 */
	public void getWeekMonthCharts(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> MainServiceImpl.getWeekMonthCharts >>>>>>");
		System.out.println(">>>>>> MainServiceImpl.getWeekMonthCharts >>>>>>");
		
		select("main.weekMonth.chart", map);
	}

	/**
	 * Method : getUserCharts
	 * 최초작성일 : 2021. 6. 8.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : PSG 검수자 실적도
	 */
	public void getUserCharts(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> MainServiceImpl.getUserCharts >>>>>>");
		System.out.println(">>>>>> MainServiceImpl.getUserCharts >>>>>>");
		
		select("main.user.chart", map);
	}
	
	/**
	 * Method : getProjectStatusSearchCnt
	 * 최초작성일 : 2020. 9. 14.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 사용자별 프로젝트 to_do, ing, complete count
	 */
	public void getProjectStatusSearchCnt(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> MainServiceImpl.getProjectStatusSearchCnt >>>>>>");
		System.out.println(">>>>>> MainServiceImpl.getProjectStatusSearchCnt >>>>>>");
		
		select("main.status.count.search", map);
	}
	

	/**
	 * Method : getProjectStatusSearchList
	 * 최초작성일 : 2020. 9. 14.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 사용자별 프로젝트 to_do, ing, complete 리스트
	 */
	public void getProjectStatusSearchList(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> MainServiceImpl.getProjectStatusSearchList >>>>>>");
		System.out.println(">>>>>> MainServiceImpl.getProjectStatusSearchList >>>>>>");
		
		select("main.status.search", map);
	}
	
	
	
	
	
	/**
	 * Method : getUserSearchList
	 * 최초작성일 : 2020. 9. 11.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 사용자 월별 진행 현황
	 */
	public void getUserSearchList(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> MainServiceImpl.getUserSearchList >>>>>>");
		System.out.println(">>>>>> MainServiceImpl.getUserSearchList >>>>>>");
		
		select("main.user.search", map);
	}

	/**
	 * Method : getChartSearchList
	 * 최초작성일 : 2020. 9. 11.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트 월별 진행 현황
	 */
	public void getChartSearchList(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> MainServiceImpl.getChartSearchList >>>>>>");
		System.out.println(">>>>>> MainServiceImpl.getChartSearchList >>>>>>");
		
		select("main.chart.search", map);
	}

	/**
	 * Method : getProjectSearchList
	 * 최초작성일 : 2020. 9. 11.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트 월별 진행 현황에 따른 사용자 진행률 조회
	 */
	public void getProjectSearchList(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> MainServiceImpl.getProjectSearchList >>>>>>");
		System.out.println(">>>>>> MainServiceImpl.getProjectSearchList >>>>>>");
		
		select("main.project.search", map);
	}



}
