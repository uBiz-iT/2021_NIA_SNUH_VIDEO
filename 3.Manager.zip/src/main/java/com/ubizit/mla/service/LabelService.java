/**
 * 
 */
package com.ubizit.mla.service;

import java.util.List;
import java.util.Map;

import com.ubizit.mla.model.TargetVO;

/**
 * @Class Name : LabelService.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
public interface LabelService {

	/**
	 * Method : getLabelSearchList
	 * 최초작성일 : 2021. 5. 12.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 타겟별 라벨 목록 데이터 가져오기
	 */
	void getLabelSearchList(Map<String, Object> map) throws Exception;

	/**
	 * Method : getTargetInfo
	 * 최초작성일 : 2021. 5. 12.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param mission_cd
	 * @return
	 * Method 설명 : 미션코드에 해당하는 타겟 정보 가져오기
	 */
	List<TargetVO> getTargetInfo(String mission_cd) throws Exception;

	/**
	 * Method : saveLabelList
	 * 최초작성일 : 2021. 5. 17.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 라벨 등록 현황에서 변경된 라벨 내용 저장하기 위한 기능
	 */
	void saveLabelList(Map<String, Object> map) throws Exception;

	

}
