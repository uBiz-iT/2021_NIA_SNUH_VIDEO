/**
 * 
 */
package com.ubizit.mla.service;

import java.util.Map;

/**
 * @Class Name : ImageService.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
public interface ImageService {

	/**
	 * Method : getImageTitleSearchList
	 * 최초작성일 : 2020. 9. 9.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트 이미지 count 리스트 조회
	 */
	void getImageTitleSearchList(Map<String, Object> map) throws Exception;

	/**
	 * Method : getImageSearchList
	 * 최초작성일 : 2020. 9. 10.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트별 이미지 리스트 조회
	 */
	void getImageSearchList(Map<String, Object> map) throws Exception;

	/**
	 * Method : getImageSubSearchList
	 * 최초작성일 : 2020. 9. 10.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트 이미지별 서브이미지 리스트 조회
	 */
	void getImageSubSearchList(Map<String, Object> map) throws Exception;

	/**
	 * Method : getImageRefSearchList
	 * 최초작성일 : 2020. 9. 10.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param resultMap
	 * Method 설명 : 프로젝트별 참조이미지 리스트 조회
	 */
	void getImageRefSearchList(Map<String, Object> map) throws Exception;

}
