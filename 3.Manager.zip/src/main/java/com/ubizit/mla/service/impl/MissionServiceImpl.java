package com.ubizit.mla.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.mla.service.MissionService;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 
 * @Class Name : MissionServiceImpl.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 7. 14.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 7. 14.
 * @version : 1.0
 *
 */
@Service("missionService")
public class MissionServiceImpl extends EgovAbstractServiceImpl implements MissionService{

	private static final Logger LOGGER = LoggerFactory.getLogger(MissionServiceImpl.class);
	
	@Resource(name="missionDAO")
	private MissionDAO missionDAO;

	@Override
	public void getMissionList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> MissionServiceImpl.getMissionList >>>>>>");
		System.out.println(">>>>>> MissionServiceImpl.getMissionList >>>>>>");
		
		missionDAO.getMissionList(map);
	}

	@Override
	public void getMissionProgress(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> MissionServiceImpl.getMissionProgress >>>>>>");
		System.out.println(">>>>>> MissionServiceImpl.getMissionProgress >>>>>>");
		
		missionDAO.getMissionProgress(map);
		
	}

	@Override
	public List<?> getSumMProgress() throws Exception {
		LOGGER.info(">>>>>> MissionServiceImpl.getSumMProgress >>>>>>");
		System.out.println(">>>>>> MissionServiceImpl.getSumMProgress >>>>>>");
		
		return missionDAO.getSumMProgress();
	}

	@Override
	public void getWmAcmCharts(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> MissionServiceImpl.getWmAcmCharts >>>>>>");
		System.out.println(">>>>>> MissionServiceImpl.getWmAcmCharts >>>>>>");
		
		missionDAO.getWmAcmCharts(map);
	}

	@Override
	public void saveMissionList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> MissionServiceImpl.saveMissionList >>>>>>");
		System.out.println(">>>>>> MissionServiceImpl.saveMissionList >>>>>>");
		
		missionDAO.saveMissionList(map);
	}

	@Override
	public List<Map<String, Object>> missionExcelDown() throws Exception {
		LOGGER.info(">>>>>> MissionServiceImpl.saveMissionList >>>>>>");
		System.out.println(">>>>>> MissionServiceImpl.saveMissionList >>>>>>");
		
		return missionDAO.missionExcelDown();
	}
	
}
