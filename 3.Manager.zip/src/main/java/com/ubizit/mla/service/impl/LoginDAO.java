/**
 * 
 */
package com.ubizit.mla.service.impl;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.ubizit.mla.model.LoginVO;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

/**
 * @Class Name : LoginDAO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
@Repository("loginDAO")
public class LoginDAO extends EgovAbstractDAO{

	private static final Logger LOGGER = LoggerFactory.getLogger(LoginDAO.class);

	/**
	 * 
	 * Method : getLoginUser
	 * 최초작성일 : 2021. 5. 3.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * @return
	 * @throws Exception
	 * Method 설명 : 로그인 정보 조회
	 */
	public void getLoginUser(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> LoginDAO.getLoginUser >>>>>>");
		
		select("login.info", map);
	}
	

}
