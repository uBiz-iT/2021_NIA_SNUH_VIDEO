/**
 * 
 */
package com.ubizit.mla.service;

import java.util.List;
import java.util.Map;

import com.ubizit.mla.model.PsgDiVO;

/**
 * 
 * @Class Name : PsgService.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 6. 15.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 6. 15.
 * @version : 1.0
 *
 */
public interface PsgService {

	/**
	 * Method : getVideoSearchList
	 * 최초작성일 : 2021. 6. 15.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param : map
	 * Method 설명 : psg 검사 현황 목록
	 */
	void getVideoSearchList(Map<String, Object> map) throws Exception;

	/**
	 * Method : getDiSearch
	 * 최초작성일 : 2021. 6. 16.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * @return
	 * Method 설명 : PSG 진단정보
	 */
	PsgDiVO getDiSearch(Map<String, Object> map) throws Exception;

	/**
	 * Method : getEventSearchList
	 * 최초작성일 : 2021. 6. 16.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : psg 이벤트 목록
	 */
	void getEventSearchList(Map<String, Object> map) throws Exception;

	/**
	 * Method : getEventTpList
	 * 최초작성일 : 2021. 6. 17.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * Method 설명 : 이벤트 타입 목록
	 */
	List<?> getEventTpList() throws Exception;

	/**
	 * Method : updateEventList
	 * 최초작성일 : 2021. 6. 17.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 이벤트 사용 여부 변경
	 */
	void updateEventList(Map<String, Object> map) throws Exception;

	/**
	 * Method : eventTypeList
	 * 최초작성일 : 2021. 7. 28.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * Method 설명 : 이벤트 타입 목록
	 */
	List<?> eventTypeList() throws Exception;

	/**
	 * Method : updateEventTypeList
	 * 최초작성일 : 2021. 8. 4.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 이벤트 타입(TYPE) 등록 및 수정
	 */
	void updateEventTypeList(Map<String, Object> map) throws Exception;

	/**
	 * Method : eventExcelDown
	 * 최초작성일 : 2021. 8. 2.
	 * 작성자 : 장두언
	 * 변경이력 :
	 * @return
	 * Method 설명 : 이벤트 코드 현황 엑셀 다운로드
	 */
	List<Map<String, Object>> eventExcelDown() throws Exception;

	/**
	 * Method : videoExcelDown
	 * 최초작성일 : 2021. 8. 4.
	 * 작성자 : 장두언
	 * 변경이력 :
	 * @return
	 * Method 설명 : 수면 영상 현황 엑셀 다운로드
	 */
	List<Map<String, Object>> videoExcelDown(Map<String, Object> map) throws Exception;


}
