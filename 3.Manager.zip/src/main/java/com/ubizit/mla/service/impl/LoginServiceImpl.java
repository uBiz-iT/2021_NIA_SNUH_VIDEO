/**
 * 
 */
package com.ubizit.mla.service.impl;

import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.mla.model.LoginVO;
import com.ubizit.mla.service.LoginService;
import com.ubizit.mla.service.UserService;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * @Class Name : LoginServiceImpl.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 9. 28.
 * @version : 1.0
 * 
 */
@Service("loginService")
public class LoginServiceImpl extends EgovAbstractServiceImpl implements LoginService{

	private static final Logger LOGGER = LoggerFactory.getLogger(LoginServiceImpl.class);
	
	@Resource(name="loginDAO")
	private LoginDAO loginDAO;

	@Override
	public void getLoginUser(Map<String, Object> map) throws Exception {
		LOGGER.debug(">>>>>> LoginServiceImpl.getLoginUser() >>>>>>");
		
		loginDAO.getLoginUser(map);
	}

}
