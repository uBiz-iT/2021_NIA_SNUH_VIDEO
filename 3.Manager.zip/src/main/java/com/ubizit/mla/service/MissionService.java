/**
 * 
 */
package com.ubizit.mla.service;

import java.util.List;
import java.util.Map;

/**
 * @Class Name : MissionService.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 7. 14.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 7. 14.
 * @version : 1.0
 *
 */
public interface MissionService {

	/**
	 * Method : getMissionList
	 * 최초작성일 : 2021. 7. 22.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 기준 정보 가져오기
	 * @throws Exception 
	 */
	void getMissionList(Map<String, Object> map) throws Exception;

	/**
	 * Method : getMissionProgress
	 * 최초작성일 : 2021. 7. 26.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 과제 진행 리스트
	 */
	void getMissionProgress(Map<String, Object> map) throws Exception;

	/**
	 * Method : getSumMProgress
	 * 최초작성일 : 2021. 7. 27.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * Method 설명 : 과제 진행 리스트 합계
	 */
	List<?> getSumMProgress() throws Exception;

	/**
	 * Method : getWmAcmCharts
	 * 최초작성일 : 2021. 7. 27.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 주간/월간 누적 실적 그래프
	 */
	void getWmAcmCharts(Map<String, Object> map) throws Exception;

	/**
	 * Method : saveMissionList
	 * 최초작성일 : 2021. 7. 27.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 과제 기준 정보 저장
	 */
	void saveMissionList(Map<String, Object> map) throws Exception;

	/**
	 * Method : missionExcelDown
	 * 최초작성일 : 2021. 7. 28.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * Method 설명 : 과제 기준일자 등록 및 검수 목록 엑셀 다운로드
	 */
	List<Map<String, Object>> missionExcelDown() throws Exception;



}
