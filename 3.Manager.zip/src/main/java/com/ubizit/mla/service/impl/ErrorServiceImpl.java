/**
 * 
 */
package com.ubizit.mla.service.impl;

import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.mla.service.ErrorService;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * @Class Name : ErrorServiceImpl.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
@Service("errorService")
public class ErrorServiceImpl extends EgovAbstractServiceImpl implements ErrorService{

	private static final Logger LOGGER = LoggerFactory.getLogger(ErrorServiceImpl.class);
	
	@Resource(name="errorDAO")
	private ErrorDAO errorDAO;
	
	@Override
	public void getErrorSearchList(Map<String, Object> map) throws Exception {
		LOGGER.debug(">>>>>> ErrorServiceImpl.getErrorSearchList >>>>>>");
		System.out.println(">>>>>> ErrorServiceImpl.getErrorSearchList >>>>>>");
		
		errorDAO.getErrorSearchList(map);
	}

}
