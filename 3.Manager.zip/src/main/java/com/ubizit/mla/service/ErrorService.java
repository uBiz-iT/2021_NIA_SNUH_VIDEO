/**
 * 
 */
package com.ubizit.mla.service;

import java.util.Map;

/**
 * @Class Name : ErrorService.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
public interface ErrorService {

	/**
	 * Method : getErrorSearchList
	 * 최초작성일 : 2020. 9. 8.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 에러 로그 리스트 조회
	 */
	void getErrorSearchList(Map<String, Object> map) throws Exception;

}
