/**
 * 
 */
package com.ubizit.mla.service;

import java.util.List;
import java.util.Map;

/**
 * @Class Name : ProjectService.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
public interface ProjectService {

	/**
	 * Method : getProjectSearchList
	 * 최초작성일 : 2020. 9. 3.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트 리스트 조회
	 */
	void getProjectSearchList(Map<String, Object> map) throws Exception;

	/**
	 * Method : getProjectDetailView
	 * 최초작성일 : 2020. 9. 14.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param throws
	 * Method 설명 : 프로젝트 상세화면
	 */
	void getProjectDetailView(Map<String, Object> map) throws Exception;

	/**
	 * Method : getProjectReadManager
	 * 최초작성일 : 2020. 9. 14.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param resultMap
	 * Method 설명 : 판독 담당자 조회
	 */
	void getProjectReadManager(Map<String, Object> map) throws Exception;

	/**
	 * Method : getProjectReadUser
	 * 최초작성일 : 2020. 9. 14.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param resultMap
	 * Method 설명 : 일반 판독자 조회
	 */
	void getProjectReadUser(Map<String, Object> map) throws Exception;

	/**
	 * Method : insertProject
	 * 최초작성일 : 2020. 9. 28.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트 등록
	 */
	void insertProject(Map<String, Object> map) throws Exception;

	/**
	 * Method : updateProject
	 * 최초작성일 : 2020. 9. 29.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트 수정
	 */
	void updateProject(Map<String, Object> map) throws Exception;

	/**
	 * Method : getUserSearch
	 * 최초작성일 : 2020. 10. 8.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param userName
	 * @return
	 * Method 설명 : 판독자 조회 (팝업)
	 */
	List<?> getUserSearch(String userName) throws Exception;

	/**
	 * Method : projectExcelDown
	 * 최초작성일 : 2021. 8. 3.
	 * 작성자 : 장두언
	 * 변경이력 :
	 * @return
	 * @throws Exception
	 * Method 설명 : 프로젝트 현황 엑셀 다운로드
	 */
	List<Map<String, Object>> projectExcelDown(Map<String, Object> map) throws Exception;

}
