/**
 * 
 */
package com.ubizit.mla.service.impl;


import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

/**
 * @Class Name : MissionDAO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 7. 14.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 7. 14.
 * @version : 1.0
 *
 */
@Repository("missionDAO")
public class MissionDAO extends EgovAbstractDAO{

	private static final Logger LOGGER = LoggerFactory.getLogger(MissionDAO.class);

	/**
	 * Method : getMissionList
	 * 최초작성일 : 2021. 7. 22.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 :
	 */
	public void getMissionList(Map<String, Object> map) throws Exception{
		LOGGER.debug(">>>>>> MissionDAO.getMissionList >>>>>>");
		System.out.println(">>>>>> MissionDAO.getMissionList >>>>>>");
		
		select("mission.info", map);
	}

	/**
	 * Method : getMissionProgress
	 * 최초작성일 : 2021. 7. 26.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 과제 진행 리스트
	 */
	public void getMissionProgress(Map<String, Object> map) throws Exception{
		LOGGER.debug(">>>>>> MissionDAO.getMissionList >>>>>>");
		System.out.println(">>>>>> MissionDAO.getMissionList >>>>>>");
		
		select("mission.progress", map);
	}

	/**
	 * Method : getSumMProgress
	 * 최초작성일 : 2021. 7. 27.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * Method 설명 : 과제 진행 리스트 합계
	 */
	public List<?> getSumMProgress() throws Exception{
		LOGGER.debug(">>>>>> MissionDAO.getSumMProgress >>>>>>");
		System.out.println(">>>>>> MissionDAO.getSumMProgress >>>>>>");
		
		return list("missionDAO.getSumMProgress");
	}

	/**
	 * Method : getWmAcmCharts
	 * 최초작성일 : 2021. 7. 27.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 주간/월간 누적 실적
	 */
	public void getWmAcmCharts(Map<String, Object> map) {
		LOGGER.debug(">>>>>> MissionDAO.getWmAcmCharts >>>>>>");
		System.out.println(">>>>>> MissionDAO.getWmAcmCharts >>>>>>");
		
		select("mission.wmAcm.chart", map);
	}

	/**
	 * Method : saveMissionList
	 * 최초작성일 : 2021. 7. 27.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 과제 기준 정보 저장
	 */
	public void saveMissionList(Map<String, Object> map) throws Exception{
		LOGGER.debug(">>>>>> MissionDAO.saveMissionList >>>>>>");
		System.out.println(">>>>>> MissionDAO.saveMissionList >>>>>>");
		
		select("mission.save", map);
	}

	/**
	 * Method : missionExcelDown
	 * 최초작성일 : 2021. 7. 28.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * Method 설명 : 과제 기준일자 등록 및 검수 목록 엑셀 다운로드
	 */
	public List<Map<String, Object>> missionExcelDown() throws Exception{
		LOGGER.debug(">>>>>> MissionDAO.missionExcelDown >>>>>>");
		System.out.println(">>>>>> MissionDAO.missionExcelDown >>>>>>");
		
		return (List<Map<String, Object>>) list("mission.excelDown");
	}
}
