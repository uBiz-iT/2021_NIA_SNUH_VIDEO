/**
 * 
 */
package com.ubizit.mla.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ubizit.mla.model.MainChartVO;
import com.ubizit.mla.model.MainCountVO;
import com.ubizit.mla.model.MainProjectVO;
import com.ubizit.mla.model.MainStatusCntVO;
import com.ubizit.mla.model.MainStatusVO;
import com.ubizit.mla.model.MainUserVO;
import com.ubizit.mla.model.MainWMVO;
import com.ubizit.mla.service.MainService;
import com.ubizit.mla.util.StringUtil;

import net.sf.json.JSONObject;

/**
 * @Class Name : MainController.java
 * @Description : 메인(대쉬보드)
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
@Controller
public class MainController {

	/** MainService **/
	@Resource(name="mainService")
	private MainService mainService;
	
	private final static Logger logger = Logger.getLogger(MainController.class);
	
	/**
	 * Method : main
	 * 최초작성일 : 2020. 9. 11.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * @throws Exception
	 * Method 설명 : 메인 화면 (대쉬보드)
	 */
	@RequestMapping(value="/main.do")
	public String main(ModelMap model) throws Exception {
		logger.info(">>>>>> MainController >>>>>>");
		
		System.out.println("메인");
		
		List<MainStatusCntVO> list = getProjectStatusSearchCnt();
		
		if(StringUtil.isNotBlank(list.get(0).getTodo_cnt())){
			model.addAttribute("todo_cnt",list.get(0).getTodo_cnt());
		}
		if(StringUtil.isNotBlank(list.get(0).getIng_cnt())){
			model.addAttribute("ing_cnt",list.get(0).getIng_cnt());
		}
		if(StringUtil.isNotBlank(list.get(0).getEnd_cnt())){
			model.addAttribute("end_cnt",list.get(0).getEnd_cnt());
		}
		
		return "main_list";
	}

	/**
	 * Method : getProgressCounts
	 * 최초작성일 : 2021. 6. 7.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 메인(대시보드) 화면 건 수 데이터들
	 */
	@RequestMapping(value="/main.total.progress.do")
	@ResponseBody
	public Map<String, Object> getProgressCounts(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> MainController.getProgressCounts() >>>>>>");
		System.out.println(">>>>>> MainController.getProgressCounts() >>>>>>");
		
		/** Object 선언 **/
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<MainCountVO> p_ret_json = new ArrayList<>();
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		mainService.getProgressCounts(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<MainCountVO>) resultMap.get("p_ret_json");
		} else {
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
	}
	
	
	/**
	 * Method : getWeekMonthCharts
	 * 최초작성일 : 2021. 6. 7.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 주간/월간 실적 그래프
	 */
	@RequestMapping(value="/main.weekMonth.chart.do")
	@ResponseBody
	public Map<String, Object> getWeekMonthCharts(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> MainController.getWeekMonthCharts() >>>>>>");
		System.out.println(">>>>>> MainController.getWeekMonthCharts() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		
		List<MainWMVO> ret_wm_json = new ArrayList<>();
		
		String wm = ((String[])paramMap.get("wm"))[0];
		String wmVal = ((String[])paramMap.get("wmVal"))[0];
		jsonObject.put("WM", wm);
		jsonObject.put("WM_VALUE", wmVal);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		mainService.getWeekMonthCharts(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			ret_wm_json = (List<MainWMVO>) resultMap.get("p_ret_json");
		}else{
			ret_wm_json = null;
		}
		map.put("rows", ret_wm_json);
		
		return map;
	}
	
	
	/**
	 * Method : getUserCharts
	 * 최초작성일 : 2021. 6. 7.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : PSG 검수자 실적도
	 */
	@RequestMapping(value="/main.user.chart.do")
	@ResponseBody
	public Map<String, Object> getUserCharts(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> MainController.getUserCharts() >>>>>>");
		System.out.println(">>>>>> MainController.getUserCharts() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<MainUserVO> p_ret_json = new ArrayList<>();
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		mainService.getUserCharts(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<MainUserVO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		map.put("rows", p_ret_json);
		
		return map;
	}
	
	
	/**
	 * Method : getProjectStatusSearchCnt
	 * 최초작성일 : 2020. 9. 14.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 사용자별 프로젝트 to_do, ing, complete count
	 */
	public List<MainStatusCntVO> getProjectStatusSearchCnt() throws Exception {
		logger.info(">>>>>> MainController.getProjectStatusSearchCnt() >>>>>>");
		System.out.println(">>>>>> MainController.getProjectStatusSearchCnt() >>>>>>");
		
		/** Object 선언 **/
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<MainStatusCntVO> p_ret_json = new ArrayList<>();
		
		jsonObject.put("USER_ID", "");
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		mainService.getProjectStatusSearchCnt(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<MainStatusCntVO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		
		return p_ret_json;		
		
	}	
	
	
	/**
	 * Method : getProjectStatusSearchList
	 * 최초작성일 : 2020. 9. 14.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 사용자별 프로젝트 to_do, ing, complete 리스트
	 */
	@RequestMapping(value="/main.status.search.do")
	@ResponseBody
	public Map<String, Object> getProjectStatusSearchList(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> MainController.getProjectStatusSearchList() >>>>>>");
		System.out.println(">>>>>> MainController.getProjectStatusSearchList() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<MainStatusVO> p_ret_json = new ArrayList<>();
		
		String tab_id = ((String[])paramMap.get("tab_id"))[0];
		int page_no = Integer.parseInt(((String[])paramMap.get("page_no"))[0]);
		int row_size = Integer.parseInt(((String[])paramMap.get("row_size"))[0]);
		
		jsonObject.put("TAB_ID", tab_id);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		mainService.getProjectStatusSearchList(resultMap);
		
		int originalSize = 1;
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<MainStatusVO>) resultMap.get("p_ret_json");
			
			originalSize = p_ret_json.size();
			
			int start = Math.min(originalSize, Math.abs((page_no-1) * row_size));
			
			if(page_no == 1 && originalSize > row_size){
				p_ret_json.subList(row_size, originalSize).clear();
			
			}else if(page_no == 1 && originalSize <= row_size){
				
			}else if(page_no != 1){
				p_ret_json.subList(0, start).clear();
				
				int size = p_ret_json.size();
				int end = Math.min(row_size, size);
				p_ret_json.subList(end, size).clear();
			}
			
			
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("total", originalSize);
		map.put("rows", p_ret_json);
		
		return map;
	}	
	
	/**
	 * Method : getChartSearchList
	 * 최초작성일 : 2020. 9. 11.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 프로젝트 월별 진행 현황
	 */
	@RequestMapping(value="/main.chart.search.do")
	@ResponseBody
	public Map<String, Object> getChartSearchList(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> MainController.getChartSearchList() >>>>>>");
		System.out.println(">>>>>> MainController.getChartSearchList() >>>>>>");
		
		/** Object 선언 **/
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<MainChartVO> p_ret_json = new ArrayList<>();
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		mainService.getChartSearchList(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<MainChartVO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
	}
	
	
	/**
	 * Method : getProjectSearchList
	 * 최초작성일 : 2020. 9. 11.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 프로젝트 월별 진행 현황에 따른 사용자 진행률 조회
	 */
	@RequestMapping(value="/main.project.search.do")
	@ResponseBody
	public Map<String, Object> getProjectSearchList(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> MainController.getProjectSearchList() >>>>>>");
		System.out.println(">>>>>> MainController.getProjectSearchList() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<MainProjectVO> p_ret_json = new ArrayList<>();
		
		String project_cd = ((String[])paramMap.get("project_cd"))[0];
		jsonObject.put("PROJECT_CD", project_cd);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		mainService.getProjectSearchList(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<MainProjectVO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
	}
	
	
	
	/**
	 * Method : getUserSearchList
	 * 최초작성일 : 2020. 9. 11.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 사용자 월별 진행 현황
	 */
	@RequestMapping(value="/main.user.search.do")
	@ResponseBody
	public Map<String, Object> getUserSearchList(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> MainController.getUserSearchList() >>>>>>");
		System.out.println(">>>>>> MainController.getUserSearchList() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<MainUserVO> p_ret_json = new ArrayList<>();
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
	
		mainService.getUserSearchList(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<MainUserVO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
	}
	

	

	
}
