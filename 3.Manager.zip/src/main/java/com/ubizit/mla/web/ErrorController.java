/**
 * 
 */
package com.ubizit.mla.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ubizit.mla.model.ErrorReqVO;
import com.ubizit.mla.model.ErrorVO;
import com.ubizit.mla.service.ErrorService;
import com.ubizit.mla.util.StringUtil;

import net.sf.json.JSONObject;

/**
 * @Class Name : ErrorController.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
@Controller
public class ErrorController {

	/** ErrorService **/
	@Resource(name="errorService")
	private ErrorService errorService;
	
	private final static Logger logger = Logger.getLogger(ErrorController.class);
	
	/**
	 * Method : errorList
	 * 최초작성일 : 2020. 9. 8.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param errorReqVO
	 * @param model
	 * @return
	 * @throws Exception
	 * Method 설명 : 에러코드 및 로그 관리 메인 화면
	 */
	@RequestMapping(value="/manage.errorList.do")
	public String errorList(ErrorReqVO errorReqVO, ModelMap model, HttpServletRequest request) throws Exception {
		logger.debug(">>>>>> ErrorController >>>>>>");
		System.out.println(">>>>>> ErrorController >>>>>>");
		
		if(StringUtil.isNotBlank(errorReqVO.getFromDate())){
			model.addAttribute("fromDate", errorReqVO.getFromDate());
		}
		if(StringUtil.isNotBlank(errorReqVO.getToDate())){
			model.addAttribute("toDate", errorReqVO.getToDate());
		}
		if(StringUtil.isNotBlank(errorReqVO.getError_code())){
			model.addAttribute("error_code", errorReqVO.getError_code());
		}
		if(StringUtil.isNotBlank(errorReqVO.getError_msg())){
			model.addAttribute("error_msg", errorReqVO.getError_msg());
		}
		if(StringUtil.isNotBlank(request.getParameter("page_cnt"))){
			model.addAttribute("page_cnt", request.getParameter("page_cnt"));
		}else{
			model.addAttribute("page_cnt", 10);
		}		
		return "error_list";
	}
	
	/***
	 * Method : getSearchList
	 * 최초작성일 : 2020. 9. 8.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 검색조건 조회
	 */
	@RequestMapping(value="/manage.error.search.do")
	@ResponseBody
	public Map<String, Object> getSearchList(HttpServletRequest request) throws Exception {
		logger.debug(">>>>>> ErrorController.getSearchList() >>>>>>");
		System.out.println(">>>>>> ErrorController.getSearchList() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<ErrorVO> p_ret_json = new ArrayList<>();
		
		String fromDate      = ((String[])paramMap.get("fromDate"))[0];
		String toDate        = ((String[])paramMap.get("toDate"))[0];
		String error_code    = ((String[])paramMap.get("error_code"))[0];
		String error_msg  	 = ((String[])paramMap.get("error_msg"))[0];
		
		jsonObject.put("FROMDATE", fromDate);
		jsonObject.put("TODATE", toDate);
		jsonObject.put("ERROR_CODE", error_code);
		jsonObject.put("ERROR_MSG", error_msg);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		errorService.getErrorSearchList(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<ErrorVO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
	}
	
}








