/**
 * 
 */
package com.ubizit.mla.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ubizit.mla.model.AnalysisVO;
import com.ubizit.mla.model.ProjectDetailVO;
import com.ubizit.mla.model.ProjectReadVO;
import com.ubizit.mla.model.ProjectReqVO;
import com.ubizit.mla.model.ProjectVO;
import com.ubizit.mla.service.ProjectService;
import com.ubizit.mla.util.ExcelUtil;
import com.ubizit.mla.util.StringUtil;

import net.sf.json.JSONObject;

/**
 * @Class Name : ProjectController.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
@Controller
public class ProjectController {

	/** ProjectService **/
	@Resource(name="projectService")
	private ProjectService projectService;
	
	private final static Logger logger = Logger.getLogger(ProjectController.class);
	
	/**
	 * Method : projectList
	 * 최초작성일 : 2020. 9. 2.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * @throws Exception
	 * Method 설명 : 프로젝트 메인 화면
	 */
	@RequestMapping(value="/project.projectList.do")
	public String projectList(ProjectReqVO projectReqVO, ModelMap model, HttpServletRequest request) throws Exception {
		logger.info(">>>>>> ProjectController >>>>>>");
		System.out.println(">>>>>> ProjectController >>>>>>");

		if(StringUtil.isNotBlank(projectReqVO.getProject_cd())){
			model.addAttribute("project_cd", projectReqVO.getProject_cd());
		}
		if(StringUtil.isNotBlank(projectReqVO.getProject_nm())){
			model.addAttribute("project_nm", projectReqVO.getProject_nm());
		}
		if(StringUtil.isNotBlank(projectReqVO.getComplete_yn())){
			model.addAttribute("complete_yn", projectReqVO.getComplete_yn());
		}
		if(StringUtil.isNotBlank(projectReqVO.getDelete_fg())){
			model.addAttribute("delete_fg", projectReqVO.getDelete_fg());
		}
		if(StringUtil.isNotBlank(request.getParameter("page_cnt"))){
			model.addAttribute("page_cnt", request.getParameter("page_cnt"));
		}else{
			model.addAttribute("page_cnt", 10);
		}
		
		return "project_list";
	}
	
	/**
	 * Method : getSearchList
	 * 최초작성일 : 2020. 9. 7.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 검색조건 조회
	 */
	@RequestMapping(value="/project.search.do")
	@ResponseBody
	public Map<String, Object> getSearchList(HttpServletRequest request, HttpSession session) throws Exception {
		logger.info(">>>>>> ProjectController.getSearchList() >>>>>>");
		System.out.println(">>>>>> ProjectController.getSearchList() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<ProjectVO> p_ret_json = new ArrayList<>();

		String project_cd 		= ((String[])paramMap.get("project_cd"))[0];
		String project_nm 		= ((String[])paramMap.get("project_nm"))[0];
		String complete_yn 		= ((String[])paramMap.get("complete_yn"))[0];
		String delete_fg 		= ((String[])paramMap.get("delete_fg"))[0];
		
		jsonObject.put("PROJECT_CD", project_cd);
		jsonObject.put("PROJECT_NM", project_nm);
		jsonObject.put("COMPLETE_YN", complete_yn);
		jsonObject.put("DELETE_FG", delete_fg);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		projectService.getProjectSearchList(resultMap);
		
		int originalSize = 0;
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<ProjectVO>) resultMap.get("p_ret_json");
			originalSize = p_ret_json.size();
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
	}
	
	
	/**
	 * Method : getProjectDetailView
	 * 최초작성일 : 2020. 9. 14.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 * Method 설명 : 프로젝트 상세보기 화면
	 */
	@RequestMapping(value="/project.view.do")
	public String getProjectDetailView(HttpServletRequest request, HttpSession session, ModelMap model) throws Exception {
		logger.info(">>>>>> ProjectController.getProjectDetailView() >>>>>>");
		System.out.println(">>>>>> ProjectController.getProjectDetailView() >>>>>>");
		
		/** Object 선언 **/
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<ProjectDetailVO> p_ret_json = new ArrayList<>();
		
		String project_cd = (String)request.getParameter("project_cd");
		
		jsonObject.put("PROJECT_CD", project_cd);

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		/** 프로젝트 상세 내용 **/
		projectService.getProjectDetailView(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<ProjectDetailVO>) resultMap.get("p_ret_json");
			
			if(StringUtil.isNotBlank(p_ret_json.get(0).getProject_cd())){
				model.addAttribute("project_cd", p_ret_json.get(0).getProject_cd());
			}
			if(StringUtil.isNotBlank(p_ret_json.get(0).getProject_nm())){
				model.addAttribute("project_nm", p_ret_json.get(0).getProject_nm());
			}
			if(StringUtil.isNotBlank(p_ret_json.get(0).getPsg_cnt())){
				model.addAttribute("psg_cnt", p_ret_json.get(0).getPsg_cnt());
			}
			if(StringUtil.isNotBlank(p_ret_json.get(0).getPsg_reg_date())){
				model.addAttribute("psg_reg_date", p_ret_json.get(0).getPsg_reg_date());
			}
			if(StringUtil.isNotBlank(p_ret_json.get(0).getEvent_cnt())){
				model.addAttribute("event_cnt", p_ret_json.get(0).getEvent_cnt());
			}
			if(StringUtil.isNotBlank(p_ret_json.get(0).getUser_cnt())){
				model.addAttribute("user_cnt", p_ret_json.get(0).getUser_cnt());
			}
			if(StringUtil.isNotBlank(p_ret_json.get(0).getData_dir())){
				model.addAttribute("data_dir", p_ret_json.get(0).getData_dir());
			}
			if(StringUtil.isNotBlank(p_ret_json.get(0).getComplete_yn())){
				model.addAttribute("complete_yn", p_ret_json.get(0).getComplete_yn());
			}
			if(StringUtil.isNotBlank(p_ret_json.get(0).getDelete_fg())){
				model.addAttribute("delete_fg", p_ret_json.get(0).getDelete_fg());
			}
			if(StringUtil.isNotBlank(p_ret_json.get(0).getReg_dt())){
				model.addAttribute("reg_dt", p_ret_json.get(0).getReg_dt());
			}
			if(StringUtil.isNotBlank(p_ret_json.get(0).getReg_user_id())){
				model.addAttribute("reg_user_id", p_ret_json.get(0).getReg_user_id());
			}
			
		}else{
			p_ret_json = null;
		}
		
		return "project_view";
	}
	
	/**
	 * Method : getProjectReadUser
	 * 최초작성일 : 2020. 9. 14.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 일반 판독자 조회
	 */
	@RequestMapping(value="/project.read.user.do")
	@ResponseBody
	public Map<String, Object> getProjectReadUser(HttpServletRequest request, HttpSession session) throws Exception {
		logger.info(">>>>>> ProjectController.getProjectReadUser() >>>>>>");
		System.out.println(">>>>>> ProjectController.getProjectReadUser() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<ProjectReadVO> p_ret_json = new ArrayList<>();
		
		String project_cd = ((String[])paramMap.get("project_cd"))[0];
		
		jsonObject.put("PROJECT_CD", project_cd);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		projectService.getProjectReadUser(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<ProjectReadVO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
		
	}

	
	/**
	 * Method : projectInsertView
	 * 최초작성일 : 2020. 9. 28.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * @throws Exception
	 * Method 설명 : 프로젝트 등록 화면
	 */
	@RequestMapping(value="/project.write.do")
	public String projectInsertView(ModelMap model, HttpSession session,  HttpServletRequest request) throws Exception {
		logger.info(">>>>>> ProjectController.projectInsertView() >>>>>>");
		System.out.println(">>>>>> ProjectController.projectInsertView() >>>>>>");
		
		//등록일자
		String reg_dt = StringUtil.getSimpleDateFormat("yyyy-MM-dd");
		model.addAttribute("reg_dt", reg_dt);
		
		return "project_write";
	}
	
	
	/**
	 * Method : projectUpdateView
	 * 최초작성일 : 2020. 9. 28.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * @throws Exception
	 * Method 설명 : 프로젝트 수정 화면
	 */
	@RequestMapping(value="/project.update.do")
	public String projectUpdateView(ModelMap model, HttpServletRequest request, HttpSession session) throws Exception {
		logger.info(">>>>>> ProjectController.projectUpdateView() >>>>>>");
		System.out.println(">>>>>> ProjectController.projectUpdateView() >>>>>>");
		
		if(StringUtil.isNotBlank((String)request.getParameter("project_cd"))){
			model.addAttribute("project_cd", (String)request.getParameter("project_cd"));
		
			/** Object 선언 **/
			JSONObject jsonObject = new JSONObject();
			Map<String, Object> map = new HashMap<String, Object>();
			List<ProjectDetailVO> p_ret_json = new ArrayList<>();
			List<ProjectReadVO> user_list = new ArrayList<>();
			
			String project_cd = (String)request.getParameter("project_cd");
			
			jsonObject.put("PROJECT_CD", project_cd);
	
			Map<String, Object> resultMap = new HashMap<String, Object>();
			resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
			
			/** 프로젝트 상세 내용 **/
			projectService.getProjectDetailView(resultMap);
			
			if((int)resultMap.get("p_ret_code") == 0){
				p_ret_json = (List<ProjectDetailVO>) resultMap.get("p_ret_json");
				
				if(StringUtil.isNotBlank(p_ret_json.get(0).getProject_cd())){
					model.addAttribute("project_cd", p_ret_json.get(0).getProject_cd());
				}
				if(StringUtil.isNotBlank(p_ret_json.get(0).getProject_nm())){
					model.addAttribute("project_nm", p_ret_json.get(0).getProject_nm());
				}
				if(StringUtil.isNotBlank(p_ret_json.get(0).getPsg_cnt())){
					model.addAttribute("psg_cnt", p_ret_json.get(0).getPsg_cnt());
				}
				if(StringUtil.isNotBlank(p_ret_json.get(0).getPsg_reg_date())){
					model.addAttribute("psg_reg_date", p_ret_json.get(0).getPsg_reg_date());
				}
				if(StringUtil.isNotBlank(p_ret_json.get(0).getEvent_cnt())){
					model.addAttribute("event_cnt", p_ret_json.get(0).getEvent_cnt());
				}
				if(StringUtil.isNotBlank(p_ret_json.get(0).getUser_cnt())){
					model.addAttribute("user_cnt", p_ret_json.get(0).getUser_cnt());
				}
				if(StringUtil.isNotBlank(p_ret_json.get(0).getData_dir())){
					model.addAttribute("data_dir", p_ret_json.get(0).getData_dir());
				}
				if(StringUtil.isNotBlank(p_ret_json.get(0).getComplete_yn())){
					model.addAttribute("complete_yn", p_ret_json.get(0).getComplete_yn());
				}
				if(StringUtil.isNotBlank(p_ret_json.get(0).getDelete_fg())){
					model.addAttribute("delete_fg", p_ret_json.get(0).getDelete_fg());
				}
				if(StringUtil.isNotBlank(p_ret_json.get(0).getReg_dt())){
					model.addAttribute("reg_dt", p_ret_json.get(0).getReg_dt());
				}
				if(StringUtil.isNotBlank(p_ret_json.get(0).getReg_user_id())){
					model.addAttribute("reg_user_id", p_ret_json.get(0).getReg_user_id());
				}
				
			}else{
				p_ret_json = null;
			}
			
			
			/** 판독자 조회 **/
			Map<String, Object> users = new HashMap<String, Object>();
			users.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
			
			projectService.getProjectReadUser(users);
			
			if((int)users.get("p_ret_code") == 0){
				user_list = (List<ProjectReadVO>) users.get("p_ret_json");
			}else{
				user_list = null;
			}
			
			model.addAttribute("user_list", user_list);
		
		}
		
		//등록일자
		String reg_dt = StringUtil.getSimpleDateFormat("yyyy-MM-dd");
		model.addAttribute("reg_dt", reg_dt);		
		
		model.addAttribute("update_yn", "Y");
		
		return "project_write";
	}
	
	/**
	 * Method : insertProject
	 * 최초작성일 : 2020. 9. 28.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 프로젝트 등록
	 */
	@RequestMapping(value="/project.insert.do")
	@ResponseBody
	public Map<String, Object> insertProject(HttpServletRequest request, HttpSession session) throws Exception {
		logger.info(">>>>>> ProjectController.insertProject() >>>>>>");
		System.out.println(">>>>>> ProjectController.insertProject() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		String p_ret_msg = "";
		int p_ret_code = 0;
		
		String project_cd 	= ((String[])paramMap.get("project_cd"))[0];
		String project_nm 	= ((String[])paramMap.get("project_nm"))[0];
		String data_dir 	= ((String[])paramMap.get("data_dir"))[0];
		String user_list	= ((String[])paramMap.get("user"))[0];
		
		jsonObject.put("PROJECT_CD", project_cd);
		jsonObject.put("PROJECT_NM", project_nm);
		jsonObject.put("DATA_DIR", data_dir);
		jsonObject.put("USER_LIST", user_list);
		jsonObject.put("REG_USER_ID", session.getAttribute("user_id"));
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		projectService.insertProject(resultMap);
		
		p_ret_msg = (String) resultMap.get("p_ret_msg");
		p_ret_code = (int) resultMap.get("p_ret_code");
		
		/** return map **/
		map.put("p_ret_msg", p_ret_msg);
		map.put("p_ret_code", p_ret_code);
		
		return map;
	}

	/**
	 * Method : updateProject
	 * 최초작성일 : 2020. 9. 29.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * @throws Exception
	 * Method 설명 : 프로젝트 수정
	 */
	@RequestMapping(value="/project.write.update.do")
	@ResponseBody	
	public Map<String, Object> updateProject(HttpServletRequest request, HttpSession session) throws Exception {
		logger.info(">>>>>> ProjectController.updateProject() >>>>>>");
		System.out.println(">>>>>> ProjectController.updateProject() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		String p_ret_msg = "";
		int p_ret_code = 0;
		
		String project_cd 			= ((String[])paramMap.get("project_cd"))[0];
		String project_nm 			= ((String[])paramMap.get("project_nm"))[0];
		String data_dir 			= ((String[])paramMap.get("data_dir"))[0];
		String complete_yn 			= ((String[])paramMap.get("complete_yn"))[0];
		String delete_fg 			= ((String[])paramMap.get("delete_fg"))[0];
		String user_list			= ((String[])paramMap.get("user"))[0];
		
		jsonObject.put("PROJECT_CD", project_cd);
		jsonObject.put("PROJECT_NM", project_nm);
		jsonObject.put("DATA_DIR", data_dir);
		jsonObject.put("COMPLETE_YN", complete_yn);
		jsonObject.put("DELETE_FG", delete_fg);
		jsonObject.put("USER_LIST", user_list);
		jsonObject.put("REG_USER_ID", session.getAttribute("user_id"));		

		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		projectService.updateProject(resultMap);
		
		p_ret_msg = (String) resultMap.get("p_ret_msg");
		p_ret_code = (int) resultMap.get("p_ret_code");
		
		/** return map **/
		map.put("p_ret_msg", p_ret_msg);
		map.put("p_ret_code", p_ret_code);
		
		return map;
	}
	
	
	/**
	 * Method : userSearch
	 * 최초작성일 : 2020. 9. 29.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param model
	 * @return
	 * @throws Exception
	 * Method 설명 : 판독자 유저 조회
	 */
	@RequestMapping(value="/project.user.popup.do")
	public String userPopup(ModelMap model, HttpServletRequest request,
							@RequestParam(value="userName", defaultValue="") String userName,
							@RequestParam(value="manager", defaultValue="") String manager,
							@RequestParam(value="index", defaultValue="") String index) throws Exception {
		logger.info(">>>>>> ProjectController.userPopup() >>>>>>");
		System.out.println(">>>>>> ProjectController.userPopup() >>>>>>");
		
		if(StringUtil.isNotBlank(userName)){
			model.addAttribute("userName", userName);
		}
		
		if(StringUtil.isNotBlank(manager)){
			model.addAttribute("manager", manager);
		}
		if(StringUtil.isNotBlank(index)){
			model.addAttribute("index", index);
		}
		
		return "project_popup";
	}
	
	/**
	 * Method : getUserList
	 * 최초작성일 : 2020. 10. 8.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 판독자 조회 (팝업)
	 */
	@RequestMapping(value="/project.user.search.do")
	@ResponseBody
	public Map<String, Object> getUserList(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> ProjectController.getUserList() >>>>>>");
		System.out.println(">>>>>> ProjectController.getUserList() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		Map<String, Object> map = new HashMap<String, Object>();
		
		String userName = ((String[])paramMap.get("userName"))[0];
		int page_no = Integer.parseInt(((String[])paramMap.get("page_no"))[0]);
		int row_size = Integer.parseInt(((String[])paramMap.get("row_size"))[0]);
		
		List<?> userList = projectService.getUserSearch(userName);
		
		int originalSize = userList.size();
		
		if(originalSize > 0){
			int start = Math.min(originalSize, Math.abs((page_no-1) * row_size));
			
			if(page_no == 1 && originalSize > row_size){
				userList.subList(row_size, originalSize).clear();
				
			}else if(page_no == 1 && originalSize <= row_size){
				
			}else if(page_no != 1){
				userList.subList(0, start).clear();
				
				int size = userList.size();
				int end = Math.min(row_size, size);
				userList.subList(end, size).clear();
			}
		}else{
			originalSize = 1;
		}
		
		/** return map */
		map.put("total", originalSize);
		map.put("rows", userList);
		
		return map;
	}

	
	/**
	 * Method : projectExcelDown
	 * 최초작성일 : 2021. 8. 3.
	 * 작성자 : 장두언
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 프로젝트 현황 엑셀 다운로드
	 */
	@RequestMapping(value="/project.excelDown.do")
	@ResponseBody
	public Map<String, Object> projectExcelDown(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(">>>>>> ProjectController.projectExcelDown() >>>>>>");
		System.out.println(">>>>>> ProjectController.projectExcelDown() >>>>>>");
		
		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");
		
		/** Object 선언 **/
		Map<String, Object> map = new HashMap<>();
		Map<?, ?> paramMap = request.getParameterMap();	
		
		String project_cd  = ((String[])paramMap.get("project_cd"))[0];
		String project_nm  = ((String[])paramMap.get("project_nm"))[0];
		String complete_yn = ((String[])paramMap.get("complete_yn"))[0];
		String delete_fg   = ((String[])paramMap.get("delete_fg"))[0];
		
		map.put("project_cd", project_cd);
		map.put("project_nm", project_nm);
		map.put("complete_yn", complete_yn);
		map.put("delete_fg", delete_fg);
		
		List<Map<String,Object>> dataList = projectService.projectExcelDown(map);
		
		List<String> logical_list = new ArrayList();
		logical_list.add("프로젝트 코드");
		logical_list.add("프로젝트명");
		logical_list.add("검수 인원");
		logical_list.add("데이터 디렉토리");
		logical_list.add("PSG검사 등록 건 수");
		logical_list.add("이벤트 총 등록 건 수");
		logical_list.add("PSG검사 등록 일자");
		logical_list.add("프로젝트 완료 여부");
		logical_list.add("프로젝트 등록 일자");
		logical_list.add("프로젝트 등록자");
		logical_list.add("삭제 여부");
		
		
		List<String> physical_list = new ArrayList();
		physical_list.add("PROJECT_CD");
		physical_list.add("PROJECT_NM");
		physical_list.add("PROJECT_USER_CNT");
		physical_list.add("DATA_DIR");
		physical_list.add("PSG_CNT");
		physical_list.add("EVENT_CNT");
		physical_list.add("PSG_REG_DATE");
		physical_list.add("COMPLETE_YN");
		physical_list.add("REG_DT");
		physical_list.add("REG_USER_ID");
		physical_list.add("DELETE_FG");
		
		int[] type_int = null;
		int[][] cellRangeAddress = null;
		
		String downFileName = "프로젝트_현황_"+StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] logical_names = logical_list.toArray(new String[logical_list.size()]);
		String[] physical_names = physical_list.toArray(new String[physical_list.size()]);
		
		int[] widths = new int[logical_names.length];
		
		for(int i = 0; i < logical_names.length; i++){
			widths[i] = 25;
		}
		
		ExcelUtil.excelDownload(response, cellRangeAddress, logical_names, physical_names, widths, type_int, downFileName, dataList);
		
		map.put("result", "Y");
		
		return map;
	}	
	
}






