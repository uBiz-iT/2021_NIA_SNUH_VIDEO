/**
 * 
 */
package com.ubizit.mla.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ubizit.mla.model.PsgDiVO;
import com.ubizit.mla.model.PsgEventVO;
import com.ubizit.mla.model.PsgVideoVO;
import com.ubizit.mla.service.PsgService;
import com.ubizit.mla.util.ExcelUtil;
import com.ubizit.mla.util.StringUtil;

import net.sf.json.JSONObject;

/**
 * @Class Name : PsgController.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 6. 15.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 6. 15.
 * @version : 1.0
 *
 */
@Controller
public class PsgController {

	/** psgService **/
	@Resource(name="psgService")
	private PsgService psgService;
	
	private final static Logger logger = Logger.getLogger(PsgController.class);
	
	/**
	 * Method : videoList
	 * 최초작성일 : 2021. 6. 15.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param model
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 영상 및 PSG이미지
	 */
	@RequestMapping(value="/psg.videoList.do")
	public String videoList(PsgVideoVO psgVideoVO, ModelMap model, HttpServletRequest request) throws Exception {
		logger.info(">>>>>> PsgController.videoList >>>>>>");
		System.out.println(">>>>>> PsgController.videoList >>>>>>");

//		if(StringUtil.isNotBlank(psgVideoVO.getProject_cd())){
//			model.addAttribute("project_cd", psgVideoVO.getProject_cd());
//		}
//		if(StringUtil.isNotBlank(psgVideoVO.getPsg_id())){
//			model.addAttribute("psg_id", psgVideoVO.getPsg_id());
//		}
//		if(StringUtil.isNotBlank(request.getParameter("page_cnt"))){
//			model.addAttribute("page_cnt", request.getParameter("page_cnt"));
//		}else{
//			model.addAttribute("page_cnt", 10);
//		}
		if(StringUtil.isNotBlank(request.getParameter("project_code"))){
			model.addAttribute("project_code", request.getParameter("project_code"));
		}
		
		return "psg_video_list";
	}
	
	
	/**
	 * Method : eventList
	 * 최초작성일 : 2021. 6. 15.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param model
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : PSG 이벤트
	 */
	@RequestMapping(value="/psg.eventList.do")
	public String eventList(ModelMap model, HttpServletRequest request) throws Exception {
		logger.info(">>>>>> PsgController.eventList >>>>>>");
		System.out.println(">>>>>> PsgController.eventList >>>>>>");

		if(StringUtil.isNotBlank(request.getParameter("event_tp"))){
			model.addAttribute("event_tp", request.getParameter("event_tp"));
		}
		if(StringUtil.isNotBlank(request.getParameter("event_nm"))){
			model.addAttribute("event_nm", request.getParameter("event_nm"));
		}
		
		if(StringUtil.isNotBlank(request.getParameter("page_cnt"))){
			model.addAttribute("page_cnt", request.getParameter("page_cnt"));
		}else{
			model.addAttribute("page_cnt", 10);
		}
		
		List<?> event_tp_list = new ArrayList<>();
		event_tp_list = psgService.getEventTpList();
		
		model.addAttribute("event_tp_list",event_tp_list);
		
		
		return "psg_event_list";
	}
	
	
	/**
	 * Method : getVideoSearchList
	 * 최초작성일 : 2021. 6. 15.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : psg 검사 현황 목록
	 */
	@RequestMapping(value="/psg.video.search.do")
	@ResponseBody
	public Map<String, Object> getVideoSearchList(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> PsgController.getVideoSearchList >>>>>>");
		System.out.println(">>>>>> PsgController.getVideoSearchList >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<PsgVideoVO> p_ret_json = new ArrayList<>();
		
		String project_cd = ((String[])paramMap.get("project_cd"))[0];
//		String psg_id 	  = ((String[])paramMap.get("psg_id"))[0];
		
		jsonObject.put("PROJECT_CD", project_cd);
//		jsonObject.put("PSG_ID", psg_id);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		psgService.getVideoSearchList(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<PsgVideoVO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
	}
	
	
	/**
	 * Method : getDiSearch
	 * 최초작성일 : 2021. 6. 16.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : psg 진단정보
	 */
	@RequestMapping(value="/psg.di.search.do")
	@ResponseBody
	public PsgDiVO getDiSearch(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> PsgController.getDiSearch >>>>>>");
		System.out.println(">>>>>> PsgController.getDiSearch >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		
		String project_cd = ((String[])paramMap.get("project_cd"))[0];
		String psg_id 	  = ((String[])paramMap.get("psg_id"))[0];
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("project_cd", project_cd);
		map.put("psg_id", psg_id);
		
		PsgDiVO vo = psgService.getDiSearch(map);
		
		return vo;
	}
	
	
	
	/**
	 * Method : getEventSearchList
	 * 최초작성일 : 2021. 6. 16.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : psg 이벤트 목록
	 */
	@RequestMapping(value="/psg.event.search.do")
	@ResponseBody
	public Map<String, Object> getEventSearchList(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> PsgController.getVideoSearchList >>>>>>");
		System.out.println(">>>>>> PsgController.getVideoSearchList >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<PsgEventVO> p_ret_json = new ArrayList<>();
		
		String event_tp = ((String[])paramMap.get("event_tp"))[0];
		String event_nm = ((String[])paramMap.get("event_nm"))[0];
		
		jsonObject.put("EVENT_TP", event_tp);
		jsonObject.put("EVENT_NM", event_nm);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		psgService.getEventSearchList(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<PsgEventVO>) resultMap.get("p_ret_json");
			
			for(int i = 0; i < p_ret_json.size(); i++){
				String useYn = p_ret_json.get(i).getUse_yn();
				String eventNote = p_ret_json.get(i).getEvent_note();
				String chkbox = "";
				
				eventNote = "<input type='text' class='input_text' value='"+eventNote+"'/>";
				
				if(useYn.equals("Y")){
					chkbox = "<input type='checkbox' checked/>";
				}else{
					chkbox = "<input type='checkbox'/>";
				}
				p_ret_json.get(i).setUse_yn(chkbox);
				p_ret_json.get(i).setEvent_note(eventNote);
			}
			
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
	}
	
	
	/**
	 * Method : updateEventList
	 * 최초작성일 : 2021. 6. 17.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 이벤트 사용 여부 변경
	 */
	@RequestMapping(value="/psg.event.update.do")
	@ResponseBody
	public Map<String, Object> updateEventList(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> PsgController.updateEventList >>>>>>");
		System.out.println(">>>>>> PsgController.updateEventList >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		String p_ret_msg = "";
		int p_ret_code = 0;
		
		String event_list = ((String[])paramMap.get("event_list"))[0];
		
		jsonObject.put("EVENT_LIST", event_list);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));		
		
		psgService.updateEventList(resultMap);
		
		p_ret_msg = (String) resultMap.get("p_ret_msg");
		p_ret_code = (int) resultMap.get("p_ret_code");
		
		/** return map **/
		map.put("p_ret_msg", p_ret_msg);
		map.put("p_ret_code", p_ret_code);
		
		return map;
	}
	
	/**
	 * Method : eventTypeList
	 * 최초작성일 : 2021. 7. 27.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 이벤트 타입 목록
	 */
	@RequestMapping(value="/psg.eventTpList.do")
	@ResponseBody
	public Map<String, Object> eventTypeList(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> PsgController.eventTypeList >>>>>>");
		System.out.println(">>>>>> PsgController.eventTypeList >>>>>>");
		
		/** Object 선언 **/
		Map<String, Object> map = new HashMap<String, Object>();
		
		List<?> eventTpList = psgService.eventTypeList();
		
		map.put("rows", eventTpList);
		
		return map;
	}

	/**
	 * Method : eventExcelDown
	 * 최초작성일 : 2021. 8. 2.
	 * 작성자 : 장두언
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 이벤트 코드 현황 엑셀 다운로드
	 */
	@RequestMapping(value="/psg.event.excelDown.do")
	@ResponseBody
	public Map<String, Object> eventExcelDown(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(">>>>>> PsgController.eventExcelDown() >>>>>>");
		System.out.println(">>>>>> PsgController.eventExcelDown() >>>>>>");
		
		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");
		
		/** Object 선언 **/
		Map<String, Object> map = new HashMap<>();
		
		List<Map<String,Object>> dataList = psgService.eventExcelDown();
		
		List<String> logical_list = new ArrayList();
		logical_list.add("이벤트 사용 여부");
		logical_list.add("이벤트 타입(TYPE)");
		logical_list.add("이벤트명(NAME)");
		logical_list.add("이벤트 의미");
		
		List<String> physical_list = new ArrayList();
		physical_list.add("USE_YN");
		physical_list.add("EVENT_TP_NM");
		physical_list.add("EVENT_NM");
		physical_list.add("EVENT_NOTE");
		
		
		int[] type_int = null;
		int[][] cellRangeAddress = null;
		
		String downFileName = "이벤트_코드_현황_"+StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] logical_names = logical_list.toArray(new String[logical_list.size()]);
		String[] physical_names = physical_list.toArray(new String[physical_list.size()]);
		
		int[] widths = new int[logical_names.length];
		
		for(int i = 0; i < logical_names.length; i++){
			widths[i] = 25;
		}
		
		ExcelUtil.excelDownload(response, cellRangeAddress, logical_names, physical_names, widths, type_int, downFileName, dataList);
		
		map.put("result", "Y");
		
		return map;
	}

	/**
	 * Method : videoExcelDown
	 * 최초작성일 : 2021. 8. 4.
	 * 작성자 : 장두언
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 수면 영상 현황 엑셀 다운로드
	 */
	@RequestMapping(value="/psg.video.excelDown.do")
	@ResponseBody
	public Map<String, Object> videoExcelDown(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(">>>>>> PsgController.videoExcelDown() >>>>>>");
		System.out.println(">>>>>> PsgController.videoExcelDown() >>>>>>");
		
		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");
		
		/** Object 선언 **/
		Map<String, Object> map = new HashMap<>();
		Map<?, ?> paramMap = request.getParameterMap();	
		
		String project_cd  = ((String[])paramMap.get("project_cd"))[0];
//		String psg_id  = ((String[])paramMap.get("psg_id"))[0];
		
		map.put("project_cd", project_cd);
//		map.put("psg_id", psg_id);
		
		List<Map<String,Object>> dataList = psgService.videoExcelDown(map);
		
		List<String> logical_list = new ArrayList();
		logical_list.add("프로젝트 코드");
//		logical_list.add("프로젝트명");
		logical_list.add("검사(환자) ID");
		logical_list.add("PSG이미지 등록 건 수");
		logical_list.add("이벤트 건 수");
		logical_list.add("자동 등록");
		logical_list.add("수면영상파일");
		logical_list.add("이미지압축파일");
		
		List<String> physical_list = new ArrayList();
		physical_list.add("PROJECT_CD");
//		physical_list.add("PROJECT_NM");
		physical_list.add("PSG_ID");
		physical_list.add("IMAGE_REG_CNT");
		physical_list.add("EVENT_CNT");
		physical_list.add("AUTO_LOAD_FG");
		physical_list.add("VIDEO_FILE_PATH");
		physical_list.add("TAR_FILE_PATH");
		
		
		int[] type_int = null;
		int[][] cellRangeAddress = null;
		
		String downFileName = "수면_영상_현황_"+project_cd+"_"+StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] logical_names = logical_list.toArray(new String[logical_list.size()]);
		String[] physical_names = physical_list.toArray(new String[physical_list.size()]);
		
		int[] widths = new int[logical_names.length];
		
		for(int i = 0; i < logical_names.length; i++){
			widths[i] = 25;
		}
		
		ExcelUtil.excelDownload(response, cellRangeAddress, logical_names, physical_names, widths, type_int, downFileName, dataList);
		
		map.put("result", "Y");
		
		return map;
	}
	
	/**
	 * Method : eventTypePopup
	 * 최초작성일 : 2021. 8. 04.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 이벤트 타입(TYPE) 생성 팝업
	 */
	@RequestMapping(value="/psg.eventType.do")
	public String eventTypePopup(HttpServletRequest request, ModelMap model) throws Exception {
		logger.info(">>>>>> PsgController.eventTypePopup >>>>>>");
		System.out.println(">>>>>> PsgController.eventTypePopup >>>>>>");
		
		/** Object 선언 **/
		Map<String, Object> map = new HashMap<String, Object>();
		
		List<?> eventTpList = psgService.eventTypeList();
		
		model.addAttribute("event_tp_list", eventTpList);
		
		return "psg_event_popup";
	}
	
	/**
	 * Method : eventTypeUpdate
	 * 최초작성일 : 2021. 8. 04.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 이벤트 타입(TYPE) 등록 및 수정
	 */
	@RequestMapping(value="/psg.eventTp.update.do")
	@ResponseBody
	public Map<String, Object> eventTypeUpdate(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> PsgController.eventTypeUpdate >>>>>>");
		System.out.println(">>>>>> PsgController.eventTypeUpdate >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		String p_ret_msg = "";
		int p_ret_code = 0;
		
		String event_list = ((String[])paramMap.get("event_list"))[0];
		
		jsonObject.put("EVENT_LIST", event_list);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));		
		
		psgService.updateEventTypeList(resultMap);
		
		p_ret_msg = (String) resultMap.get("p_ret_msg");
		p_ret_code = (int) resultMap.get("p_ret_code");
		
		System.out.println("p_ret_msg : " + p_ret_msg);
		
		/** return map **/
		map.put("p_ret_msg", p_ret_msg);
		map.put("p_ret_code", p_ret_code);
		
		return map;
	}
	
}


