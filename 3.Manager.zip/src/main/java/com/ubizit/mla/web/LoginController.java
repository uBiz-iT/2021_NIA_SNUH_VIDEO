/**
 * 
 */
package com.ubizit.mla.web;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ubizit.mla.service.LoginService;
import com.ubizit.mla.util.StringUtil;

import net.sf.json.JSONObject;

/**
 * @Class Name : LoginController.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 9. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 9. 28.
 * @version : 1.0
 * 
 */
@Controller
public class LoginController {

	/** LoginService **/
	@Resource(name="loginService")
	private LoginService loginService;
	
	private final static Logger logger = Logger.getLogger(LoginController.class);
	
	
	/**
	 * Method : login
	 * 최초작성일 : 2020. 9. 28.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param session
	 * @return
	 * @throws Exception
	 * Method 설명 : 로그인 화면
	 */
	@RequestMapping(value="/loginView.do")
	public String loginView() throws Exception {
		logger.info(">>>>>> LoginController.loginView() >>>>>>");
		System.out.println(">>>>>> LoginController.loginView() >>>>>>");
		
		return "login";
	}
	
	
	/**
	 * Method : login
	 * 최초작성일 : 2020. 9. 28.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param model
	 * @param session
	 * @return
	 * @throws Exception
	 * Method 설명 : 로그인 체크 후 성공 시 session 등록, 쿠키는 script에서 실행
	 */
	@RequestMapping(value="/login.do", method=RequestMethod.POST)
	public String login(@RequestParam(value="user_id") String user_id,
						 @RequestParam(value="password") String password,
						 @RequestParam(value="is_manager", defaultValue="N") String is_manager,
						 HttpServletResponse response, HttpSession session) throws Exception {
		logger.info(">>>>>> LoginController.login() >>>>>>");
		
		if(session.getAttribute("user_id") != null){
			session.removeAttribute("user_id");
			session.removeAttribute("user_nm");
			session.removeAttribute("is_manager");
		}
		
		/** 선언부 **/
		ObjectMapper mapper = new ObjectMapper();
		JSONObject jsonObject = new JSONObject();
		String p_ret_json = "";
		
		//IN 변수
		jsonObject.put("USER_ID", user_id);
		jsonObject.put("PASSWD", password);
		jsonObject.put("IS_MANAGER", is_manager);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		//서비스 호출
		loginService.getLoginUser(resultMap);
		
		//p_ret_code 값에 따른 조건
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (String) resultMap.get("p_ret_json");
			
			//String to map
			Map<String, Object> map = mapper.readValue(p_ret_json, Map.class);
			
			session.setAttribute("user_id", map.get("user_id"));
			session.setAttribute("user_nm", map.get("user_nm"));
			session.setAttribute("is_manager", map.get("is_manager"));
			
			logger.info((String)resultMap.get("p_ret_msg"));
			
			return "redirect:/main.do";
			
		}else if((int)resultMap.get("p_ret_code") < 0){
			logger.info((String)resultMap.get("p_ret_msg"));
			
			String ret_msg = (String) resultMap.get("p_ret_msg");
			
			response.setContentType("text/html; charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.println("<script>alert('"+ret_msg+"');</script>");
			out.flush();
			
			return "login";
			
		}else {
			logger.info((String)resultMap.get("p_ret_msg"));
			
			response.setContentType("text/html; charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.println("<script>alert('로그인에 실패했습니다.');</script>");
			out.flush();
			
			return "login";
		}
		
	}
	
	/**
	 * Method : logOut
	 * 최초작성일 : 2020. 9. 28.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param session
	 * @return
	 * @throws Exception
	 * Method 설명 : 로그아웃
	 */
	@RequestMapping(value="/logOut.do", method=RequestMethod.GET)
	public String logOut(HttpSession session) throws Exception {
		logger.info("로그아웃되었습니다.");
		
		session.removeAttribute("user_id");
		session.removeAttribute("user_nm");
		session.removeAttribute("is_manager");
		
		return "login";
	}
	

	/**
	 * Method : errorPage
	 * 최초작성일 : 2020. 12. 14.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param session
	 * @return
	 * @throws Exception
	 * Method 설명 : 세션 종료 안내 페이지
	 */
	@RequestMapping(value="/errorPage.do", method=RequestMethod.GET)
	public String errorPage(HttpSession session) throws Exception {
		logger.info("세션 종료되었습니다.");
		
		return "errorPage";
	}
	
	
	/**
	 * Method : submit
	 * 최초작성일 : 2021. 6. 28.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * @throws Exception
	 * Method 설명 : 추첨하기
	 */
	@RequestMapping(value="/submit.do", method=RequestMethod.POST)
	public String submit(@RequestParam(value="cnt", defaultValue="1") String cnt, ModelMap model) throws Exception {
		
		ArrayList<String> randomList = new ArrayList<String>();
		randomList.add("1동 축구황제맹수");
		randomList.add("1동 도너츨");
		randomList.add("1동 예당합격자");
		randomList.add("1동 유리네");
		randomList.add("1동 디데이2");
		randomList.add("1동 딸2맘");
		randomList.add("1동 전아재");
		randomList.add("1동 로씨");
		randomList.add("1동 딸 소청감");
		randomList.add("1동 사이다");
		randomList.add("1동 딸 양양");
		randomList.add("1동 동동");
		randomList.add("1동 최남매");
		randomList.add("1동펭하");
		randomList.add("2동 치킨치킨");
		randomList.add("2동 동동구리");
		randomList.add("2동 엘라");
		randomList.add("2동 쏭팸");
		randomList.add("2동 두두");
		randomList.add("2동 신짱구네");
		randomList.add("2동 심콩맘");
		randomList.add("2동 마음심");
		randomList.add("2동 칼맨");
		randomList.add("2동 소떡소떡");
		randomList.add("103동 충청도땅부자");
		randomList.add("봉지커피");
		randomList.add("3동 브라운데이");
		randomList.add("3동 핫소스");
		randomList.add("3동 행복한 나");
		randomList.add("3동 달달");
		randomList.add("3동 쿠마");
		randomList.add("3동 보드신화");
		randomList.add("3동 대전홍군");
		randomList.add("3동 아인하사");
		randomList.add("3동 종이학");
		randomList.add("103동 민트초코");
		randomList.add("카오삐약 204");
		randomList.add("4동 아이작");
		randomList.add("4동 보물");
		randomList.add("4동 화이트");
		randomList.add("4동 와동날개");
		randomList.add("4동가온");
		randomList.add("4동 단미");
		randomList.add("4동 초짜");
		randomList.add("4동 고기만두");
		randomList.add("4동 블링남편");
		randomList.add("4동 실마리");
		randomList.add("4동 져니");
		randomList.add("4동 까꿍");
		randomList.add("4동 배우자 두콩이");
		randomList.add("4동 쥬르");
		randomList.add("4동 카페라떼");
		randomList.add("4동 in");
		randomList.add("4동 갈음");
		randomList.add("4동 guardian angel");
		randomList.add("205동 제이");
		randomList.add("5동 대전ㅋㅋㅋ");
		randomList.add("5동 까까");
		randomList.add("6동 모넹");
		randomList.add("6동 맥다날");
		randomList.add("6동 imja");
		randomList.add("6동 홀인원");
		randomList.add("6동 꼬미");
		randomList.add("6동 하늘꿈나무");
		randomList.add("6동 청년");
		randomList.add("6동 광란의하루");
		randomList.add("6동 하늘바라기");
		randomList.add("6동 출퇴근");
		randomList.add("6동 주민입니다");
		randomList.add("6동 수복");
		randomList.add("6동 비행기");
		randomList.add("6동 Yan");
		randomList.add("6동 미니");
		randomList.add("6동 하랑이");
		randomList.add("6동 KK지");
		randomList.add("6동 황새골");
		randomList.add("6동 오요디");
		randomList.add("6동 wkdlaka");
		randomList.add("6동 고생");
		randomList.add("6동 방글이네");
		randomList.add("6동 긍정");
		randomList.add("6동 동북아호랑이");
		randomList.add("6동 햄톨쓰");
		randomList.add("7동 영월");
		randomList.add("7동 람스");
		randomList.add("7동 won");
		randomList.add("7동 새초롬이");
		randomList.add("7동 한울");
		randomList.add("7동 용마");
		randomList.add("7동 하이");
		randomList.add("1동 던키니");
		randomList.add("1동 디데이");
		randomList.add("반짝아범");
		randomList.add("1동 남편");
		randomList.add("1동 로즈");
		randomList.add("1동깡총");
		randomList.add("1동 펭하 배우자");
		randomList.add("2동 배우자 바름동동");
		randomList.add("2동 쁘니뿌니");
		randomList.add("2동 짱구네");
		randomList.add("2동 사파이어");
		randomList.add("2동 K2");
		randomList.add("2동 소떡");
		randomList.add("3동 브라운곰도리");
		randomList.add("3동 초코라떼");
		randomList.add("3동 다크초코");
		randomList.add("204동 쓰맨");
		randomList.add("4동 초코브라운");
		randomList.add("4동 단미는마눌님");
		randomList.add("4동 쩡이");
		randomList.add("4동 쁘미맘");
		randomList.add("4동 만두");
		randomList.add("4동 블링");
		randomList.add("4동 불멍");
		randomList.add("4동 아메");
		randomList.add("6동 세실");
		randomList.add("6동 롯뒐아");
		randomList.add("6동 준마미");
		randomList.add("6동 꼬미남편");
		randomList.add("6동 파랑");
		randomList.add("6동 뀨망");
		randomList.add("6동 강녕");
		randomList.add("6동 미니남편");
		randomList.add("6동 올리브");
		randomList.add("6동 서윗");
		randomList.add("6동 파이프맨");
		randomList.add("6동 햄사모");
		randomList.add("7동 드래곤라자");
		randomList.add("7동큰며늘");
		
		
		ArrayList<String> randomComplete = new ArrayList<String>();    
	     
		int count = Integer.parseInt(cnt);
		
	    for(int i = 0; i < count; i++){
	        
	        int random = (int)(Math.random()*randomList.size());
	        
	        randomComplete.add( randomList.get(random) );
	        
	        randomList.remove(random); //remove 로 인해서 카운터가 변화
	    }
	     
	     
	    model.addAttribute("list", randomComplete);


		return "open";
	}
	
	
	
}
