/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : PgProPuDataVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 1. 6.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 1. 6.
 * @version : 1.0
 * 
 */
public class PgProPuDataVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String row_num;
	private String image_id;
	private String user1_act;
	private String user1_rjt;
	private String user2_act;
	private String user2_rjt;
	private String user3_act;
	private String user3_rjt;
	private String user4_act;
	private String user4_rjt;
	private String user5_act;
	private String user5_rjt;
	private String user6_act;
	private String user6_rjt;
	private String user7_act;
	private String user7_rjt;
	private String user8_act;
	private String user8_rjt;
	private String user9_act;
	private String user9_rjt;
	private String user10_act;
	private String user10_rjt;
	private String act_sum;
	private String rjt_sum;
	private String x_sum;
	private String null_sum;
	
	public String getRow_num() {
		return row_num;
	}
	public void setRow_num(String row_num) {
		this.row_num = row_num;
	}
	public String getImage_id() {
		return image_id;
	}
	public void setImage_id(String image_id) {
		this.image_id = image_id;
	}
	public String getUser1_act() {
		return user1_act;
	}
	public void setUser1_act(String user1_act) {
		this.user1_act = user1_act;
	}
	public String getUser1_rjt() {
		return user1_rjt;
	}
	public void setUser1_rjt(String user1_rjt) {
		this.user1_rjt = user1_rjt;
	}
	public String getUser2_act() {
		return user2_act;
	}
	public void setUser2_act(String user2_act) {
		this.user2_act = user2_act;
	}
	public String getUser2_rjt() {
		return user2_rjt;
	}
	public void setUser2_rjt(String user2_rjt) {
		this.user2_rjt = user2_rjt;
	}
	public String getUser3_act() {
		return user3_act;
	}
	public void setUser3_act(String user3_act) {
		this.user3_act = user3_act;
	}
	public String getUser3_rjt() {
		return user3_rjt;
	}
	public void setUser3_rjt(String user3_rjt) {
		this.user3_rjt = user3_rjt;
	}
	public String getUser4_act() {
		return user4_act;
	}
	public void setUser4_act(String user4_act) {
		this.user4_act = user4_act;
	}
	public String getUser4_rjt() {
		return user4_rjt;
	}
	public void setUser4_rjt(String user4_rjt) {
		this.user4_rjt = user4_rjt;
	}
	public String getUser5_act() {
		return user5_act;
	}
	public void setUser5_act(String user5_act) {
		this.user5_act = user5_act;
	}
	public String getUser5_rjt() {
		return user5_rjt;
	}
	public void setUser5_rjt(String user5_rjt) {
		this.user5_rjt = user5_rjt;
	}
	public String getUser6_act() {
		return user6_act;
	}
	public void setUser6_act(String user6_act) {
		this.user6_act = user6_act;
	}
	public String getUser6_rjt() {
		return user6_rjt;
	}
	public void setUser6_rjt(String user6_rjt) {
		this.user6_rjt = user6_rjt;
	}
	public String getUser7_act() {
		return user7_act;
	}
	public void setUser7_act(String user7_act) {
		this.user7_act = user7_act;
	}
	public String getUser7_rjt() {
		return user7_rjt;
	}
	public void setUser7_rjt(String user7_rjt) {
		this.user7_rjt = user7_rjt;
	}
	public String getUser8_act() {
		return user8_act;
	}
	public void setUser8_act(String user8_act) {
		this.user8_act = user8_act;
	}
	public String getUser8_rjt() {
		return user8_rjt;
	}
	public void setUser8_rjt(String user8_rjt) {
		this.user8_rjt = user8_rjt;
	}
	public String getUser9_act() {
		return user9_act;
	}
	public void setUser9_act(String user9_act) {
		this.user9_act = user9_act;
	}
	public String getUser9_rjt() {
		return user9_rjt;
	}
	public void setUser9_rjt(String user9_rjt) {
		this.user9_rjt = user9_rjt;
	}
	public String getUser10_act() {
		return user10_act;
	}
	public void setUser10_act(String user10_act) {
		this.user10_act = user10_act;
	}
	public String getUser10_rjt() {
		return user10_rjt;
	}
	public void setUser10_rjt(String user10_rjt) {
		this.user10_rjt = user10_rjt;
	}
	public String getAct_sum() {
		return act_sum;
	}
	public void setAct_sum(String act_sum) {
		this.act_sum = act_sum;
	}
	public String getRjt_sum() {
		return rjt_sum;
	}
	public void setRjt_sum(String rjt_sum) {
		this.rjt_sum = rjt_sum;
	}
	public String getX_sum() {
		return x_sum;
	}
	public void setX_sum(String x_sum) {
		this.x_sum = x_sum;
	}
	public String getNull_sum() {
		return null_sum;
	}
	public void setNull_sum(String null_sum) {
		this.null_sum = null_sum;
	}

}
