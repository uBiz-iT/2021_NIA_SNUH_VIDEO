/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : ProgressUserReqVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
public class ProgressUserReqVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String user_info;			//사용자 정보 검색
	private String delete_fg;			//사용자 삭제 여부

	public String getUser_info() {
		return user_info;
	}

	public void setUser_info(String user_info) {
		this.user_info = user_info;
	}

	public String getDelete_fg() {
		return delete_fg;
	}

	public void setDelete_fg(String delete_fg) {
		this.delete_fg = delete_fg;
	}

	
}
