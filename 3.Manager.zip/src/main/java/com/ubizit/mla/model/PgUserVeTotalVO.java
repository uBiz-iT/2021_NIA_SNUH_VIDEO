/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : PgProVeTotalVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 6. 30.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 6. 30.
 * @version : 1.0
 * 
 */
public class PgUserVeTotalVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String assign_cnt;			//검수 할당 건 수
	private String work_cnt;			//검수 완료 건 수
	private float work_ing;			//검수 완료 진행률
	private String event_assign_cnt;	//이벤트 할당 건 수
	private String event_work_cnt;		//이벤트 완료 건 수
	private float event_work_ing;		//이벤트 완료 진행률
	private String event_ok_cnt;		//이벤트 OK 건 수
	private float event_ok_ing;		//이벤트 OK 진행률
	private String event_ng_cnt;		//이벤트 NG 건 수
	private float event_ng_ing;		//이벤트 NG 진행률
	private String project_cnt;		//현재 프로젝트 수
	
	public String getAssign_cnt() {
		return assign_cnt;
	}
	public void setAssign_cnt(String assign_cnt) {
		this.assign_cnt = assign_cnt;
	}
	public String getWork_cnt() {
		return work_cnt;
	}
	public void setWork_cnt(String work_cnt) {
		this.work_cnt = work_cnt;
	}
	public float getWork_ing() {
		return work_ing;
	}
	public void setWork_ing(float work_ing) {
		this.work_ing = work_ing;
	}
	public String getEvent_assign_cnt() {
		return event_assign_cnt;
	}
	public void setEvent_assign_cnt(String event_assign_cnt) {
		this.event_assign_cnt = event_assign_cnt;
	}
	public String getEvent_work_cnt() {
		return event_work_cnt;
	}
	public void setEvent_work_cnt(String event_work_cnt) {
		this.event_work_cnt = event_work_cnt;
	}
	public float getEvent_work_ing() {
		return event_work_ing;
	}
	public void setEvent_work_ing(float event_work_ing) {
		this.event_work_ing = event_work_ing;
	}
	public String getEvent_ok_cnt() {
		return event_ok_cnt;
	}
	public void setEvent_ok_cnt(String event_ok_cnt) {
		this.event_ok_cnt = event_ok_cnt;
	}
	public float getEvent_ok_ing() {
		return event_ok_ing;
	}
	public void setEvent_ok_ing(float event_ok_ing) {
		this.event_ok_ing = event_ok_ing;
	}
	public String getEvent_ng_cnt() {
		return event_ng_cnt;
	}
	public void setEvent_ng_cnt(String event_ng_cnt) {
		this.event_ng_cnt = event_ng_cnt;
	}
	public float getEvent_ng_ing() {
		return event_ng_ing;
	}
	public void setEvent_ng_ing(float event_ng_ing) {
		this.event_ng_ing = event_ng_ing;
	}
	public String getProject_cnt() {
		return project_cnt;
	}
	public void setProject_cnt(String project_cnt) {
		this.project_cnt = project_cnt;
	}

}
