/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : PgProVeCt2VO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 7. 5.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 7. 5.
 * @version : 1.0
 * 
 */
public class PgProVeCt2VO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String pass;				//PASS 건
	private String fail;				//FAIL 건
    private String no_match;			//일치 X 건
	private String no_work;			//작업 X 건
	private String pass_percent;		
	private String fail_percent;
	private String no_match_percent;
	private String no_work_percent;
	
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getFail() {
		return fail;
	}
	public void setFail(String fail) {
		this.fail = fail;
	}
	public String getNo_match() {
		return no_match;
	}
	public void setNo_match(String no_match) {
		this.no_match = no_match;
	}
	public String getNo_work() {
		return no_work;
	}
	public void setNo_work(String no_work) {
		this.no_work = no_work;
	}
	public String getPass_percent() {
		return pass_percent;
	}
	public void setPass_percent(String pass_percent) {
		this.pass_percent = pass_percent;
	}
	public String getFail_percent() {
		return fail_percent;
	}
	public void setFail_percent(String fail_percent) {
		this.fail_percent = fail_percent;
	}
	public String getNo_match_percent() {
		return no_match_percent;
	}
	public void setNo_match_percent(String no_match_percent) {
		this.no_match_percent = no_match_percent;
	}
	public String getNo_work_percent() {
		return no_work_percent;
	}
	public void setNo_work_percent(String no_work_percent) {
		this.no_work_percent = no_work_percent;
	}
	
}
