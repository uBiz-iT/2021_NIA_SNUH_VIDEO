/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : MissionProgressVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 7. 26.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 7. 26.
 * @version : 1.0
 * 
 */
public class MissionProgressVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String base_date;
	private String psg_cnt;
	private String event_cnt;
	private String work_cnt;
    private String same_cnt;
	private String pass_cnt;
	private String event_work_cnt;
	private String event_ok_cnt;
	private String event_ng_cnt;
	
	public String getBase_date() {
		return base_date;
	}
	public void setBase_date(String base_date) {
		this.base_date = base_date;
	}
	public String getPsg_cnt() {
		return psg_cnt;
	}
	public void setPsg_cnt(String psg_cnt) {
		this.psg_cnt = psg_cnt;
	}
	public String getEvent_cnt() {
		return event_cnt;
	}
	public void setEvent_cnt(String event_cnt) {
		this.event_cnt = event_cnt;
	}
	public String getWork_cnt() {
		return work_cnt;
	}
	public void setWork_cnt(String work_cnt) {
		this.work_cnt = work_cnt;
	}
	public String getSame_cnt() {
		return same_cnt;
	}
	public void setSame_cnt(String same_cnt) {
		this.same_cnt = same_cnt;
	}
	public String getPass_cnt() {
		return pass_cnt;
	}
	public void setPass_cnt(String pass_cnt) {
		this.pass_cnt = pass_cnt;
	}
	public String getEvent_work_cnt() {
		return event_work_cnt;
	}
	public void setEvent_work_cnt(String event_work_cnt) {
		this.event_work_cnt = event_work_cnt;
	}
	public String getEvent_ok_cnt() {
		return event_ok_cnt;
	}
	public void setEvent_ok_cnt(String event_ok_cnt) {
		this.event_ok_cnt = event_ok_cnt;
	}
	public String getEvent_ng_cnt() {
		return event_ng_cnt;
	}
	public void setEvent_ng_cnt(String event_ng_cnt) {
		this.event_ng_cnt = event_ng_cnt;
	}
	
}
