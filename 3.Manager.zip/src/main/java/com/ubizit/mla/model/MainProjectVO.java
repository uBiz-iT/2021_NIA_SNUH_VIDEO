/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : MainProjectVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 9. 11.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 9. 11.
 * @version : 1.0
 * 
 */
public class MainProjectVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String user_name;			//사용자명
	private String user_num;			//완료건수/총건수
	private double total_progress;		//진행률
	
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_num() {
		return user_num;
	}
	public void setUser_num(String user_num) {
		this.user_num = user_num;
	}

	public double getTotal_progress() {
		return total_progress;
	}
	public void setTotal_progress(double total_progress) {
		this.total_progress = total_progress;
	}
	

}
