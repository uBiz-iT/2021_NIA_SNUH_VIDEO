/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : MainCountVO.java
 * @Description : 메인(대시보드) 화면 Counts
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 6. 1.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 6. 1.
 * @version : 1.0
 * 
 */
public class MainCountVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String plan_cnt;				//과제목표건수
	private String video_cnt;				//수면 영상 건 수
	private String psg_accord_cnt;			//PSG 검수 일치 건수
	private String psg_event_ok_cnt;		//PSG 이벤트 검수 OK 건 수
	private String psg_complete_cnt;		//PSG 검수 완료 건 수
	private String psg_pass_cnt;			//PSG PASS 건 수
	private String psg_event_ng_cnt;		//PSG 이벤트 검수 NG 건 수
	private float video_percent;			//PSG 영상 목표 건 수 대비 비율
	private float psg_accord_percent;		//PSG 검수 완료 건 수 대비 일치 비율
	private float psg_event_ok_percent;	//이벤트 완료 건 수 대비 OK 비율
	private float psg_complete_percent;	//PSG 검수 건 수 대비 완료 비율
	private float psg_pass_percent;		//PSG 일치 건 수 대비 PASS 비율
	private float psg_event_ng_percent;	//이벤트 완료 건 수 대비 NG 비율
	private float psg_plan_percent;		//과제 목표 달성율
	private String video_plan;				//수면 영상 건 수/수면 영상 목표 건 수
	private String psg_accord;				//PSG 검수 일치 건 수/PSG 검수 완료 건 수
	private String psg_event_ok;			//PSG 이벤트 검수 OK 건 수/PSG 이벤트 검수 완료 건 수
	private String psg_complete;			//PSG 검수 완료 건 수/수면 영상 건 수
	private String psg_pass;				//PSG PASS 건 수/PSG 검수 일치 건 수
	private String psg_event_ng;			//PSG 이벤트 검수 NG 건 수/PSG 이벤트 검수 완료 건 수
	private String psg_plan;				//PSG PASS 일치 건 수 / 과제 목표 건수 
	
	public String getPlan_cnt() {
		return plan_cnt;
	}
	public void setPlan_cnt(String plan_cnt) {
		this.plan_cnt = plan_cnt;
	}
	public String getVideo_cnt() {
		return video_cnt;
	}
	public void setVideo_cnt(String video_cnt) {
		this.video_cnt = video_cnt;
	}
	public String getPsg_accord_cnt() {
		return psg_accord_cnt;
	}
	public void setPsg_accord_cnt(String psg_accord_cnt) {
		this.psg_accord_cnt = psg_accord_cnt;
	}
	public String getPsg_event_ok_cnt() {
		return psg_event_ok_cnt;
	}
	public void setPsg_event_ok_cnt(String psg_event_ok_cnt) {
		this.psg_event_ok_cnt = psg_event_ok_cnt;
	}
	public String getPsg_complete_cnt() {
		return psg_complete_cnt;
	}
	public void setPsg_complete_cnt(String psg_complete_cnt) {
		this.psg_complete_cnt = psg_complete_cnt;
	}
	public String getPsg_pass_cnt() {
		return psg_pass_cnt;
	}
	public void setPsg_pass_cnt(String psg_pass_cnt) {
		this.psg_pass_cnt = psg_pass_cnt;
	}
	public String getPsg_event_ng_cnt() {
		return psg_event_ng_cnt;
	}
	public void setPsg_event_ng_cnt(String psg_event_ng_cnt) {
		this.psg_event_ng_cnt = psg_event_ng_cnt;
	}
	public float getVideo_percent() {
		return video_percent;
	}
	public void setVideo_percent(float video_percent) {
		this.video_percent = video_percent;
	}
	public float getPsg_accord_percent() {
		return psg_accord_percent;
	}
	public void setPsg_accord_percent(float psg_accord_percent) {
		this.psg_accord_percent = psg_accord_percent;
	}
	public float getPsg_event_ok_percent() {
		return psg_event_ok_percent;
	}
	public void setPsg_event_ok_percent(float psg_event_ok_percent) {
		this.psg_event_ok_percent = psg_event_ok_percent;
	}
	public float getPsg_complete_percent() {
		return psg_complete_percent;
	}
	public void setPsg_complete_percent(float psg_complete_percent) {
		this.psg_complete_percent = psg_complete_percent;
	}
	public float getPsg_pass_percent() {
		return psg_pass_percent;
	}
	public void setPsg_pass_percent(float psg_pass_percent) {
		this.psg_pass_percent = psg_pass_percent;
	}
	public float getPsg_event_ng_percent() {
		return psg_event_ng_percent;
	}
	public void setPsg_event_ng_percent(float psg_event_ng_percent) {
		this.psg_event_ng_percent = psg_event_ng_percent;
	}
	public float getPsg_plan_percent() {
		return psg_plan_percent;
	}
	public void setPsg_plan_percent(float psg_plan_percent) {
		this.psg_plan_percent = psg_plan_percent;
	}
	public String getVideo_plan() {
		return video_plan;
	}
	public void setVideo_plan(String video_plan) {
		this.video_plan = video_plan;
	}
	public String getPsg_accord() {
		return psg_accord;
	}
	public void setPsg_accord(String psg_accord) {
		this.psg_accord = psg_accord;
	}
	public String getPsg_event_ok() {
		return psg_event_ok;
	}
	public void setPsg_event_ok(String psg_event_ok) {
		this.psg_event_ok = psg_event_ok;
	}
	public String getPsg_complete() {
		return psg_complete;
	}
	public void setPsg_complete(String psg_complete) {
		this.psg_complete = psg_complete;
	}
	public String getPsg_pass() {
		return psg_pass;
	}
	public void setPsg_pass(String psg_pass) {
		this.psg_pass = psg_pass;
	}
	public String getPsg_event_ng() {
		return psg_event_ng;
	}
	public void setPsg_event_ng(String psg_event_ng) {
		this.psg_event_ng = psg_event_ng;
	}
	public String getPsg_plan() {
		return psg_plan;
	}
	public void setPsg_plan(String psg_plan) {
		this.psg_plan = psg_plan;
	}
	
}
