/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : ErrorReqVO.java
 * @Description : 에러코드 및 로그 관리 메인 화면 검색조건
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 9. 08.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 9. 08.
 * @version : 1.0
 * 
 */
public class ErrorReqVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String fromDate;			//발생기간
	private String toDate;				//발생기간
	private String error_code;			//에러코드명
	private String error_msg;			//에러메세지
	
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getError_code() {
		return error_code;
	}
	public void setError_code(String error_code) {
		this.error_code = error_code;
	}
	public String getError_msg() {
		return error_msg;
	}
	public void setError_msg(String error_msg) {
		this.error_msg = error_msg;
	}
	
}
