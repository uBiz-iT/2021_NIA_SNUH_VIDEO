/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : PsgEventVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 6. 16.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 6. 16.
 * @version : 1.0
 * 
 */
public class PsgEventVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String event_tp;		//이벤트 타입
    private String event_tp_nm;	//이벤트 타입명
	private String event_nm;		//이벤트명
	private String event_note;		//이벤트의미
	private String use_yn;			//사용여부
	
	public String getEvent_tp() {
		return event_tp;
	}
	public void setEvent_tp(String event_tp) {
		this.event_tp = event_tp;
	}
	public String getEvent_tp_nm() {
		return event_tp_nm;
	}
	public void setEvent_tp_nm(String event_tp_nm) {
		this.event_tp_nm = event_tp_nm;
	}
	public String getEvent_nm() {
		return event_nm;
	}
	public void setEvent_nm(String event_nm) {
		this.event_nm = event_nm;
	}
	public String getEvent_note() {
		return event_note;
	}
	public void setEvent_note(String event_note) {
		this.event_note = event_note;
	}
	public String getUse_yn() {
		return use_yn;
	}
	public void setUse_yn(String use_yn) {
		this.use_yn = use_yn;
	}
	
	
}
