/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : PsgVideoVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 6. 15.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 6. 15.
 * @version : 1.0
 * 
 */
public class PsgVideoVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String project_cd;			//프로젝트코드
	private String project_nm;			//프로젝트명
	private String psg_id;				//검사(환자)ID
	private String image_reg_cnt;		//PSG이미지 등록 건 수
	private String event_cnt;			//이벤트 건 수
	private String auto_load_fg;		//자동등록
	private String video_file_path;	//수면영상 파일경로
	private String tar_file_path;		//이미지압축 파일경로
	
	public String getProject_cd() {
		return project_cd;
	}
	public void setProject_cd(String project_cd) {
		this.project_cd = project_cd;
	}
	public String getProject_nm() {
		return project_nm;
	}
	public void setProject_nm(String project_nm) {
		this.project_nm = project_nm;
	}
	public String getPsg_id() {
		return psg_id;
	}
	public void setPsg_id(String psg_id) {
		this.psg_id = psg_id;
	}
	public String getImage_reg_cnt() {
		return image_reg_cnt;
	}
	public void setImage_reg_cnt(String image_reg_cnt) {
		this.image_reg_cnt = image_reg_cnt;
	}
	public String getEvent_cnt() {
		return event_cnt;
	}
	public void setEvent_cnt(String event_cnt) {
		this.event_cnt = event_cnt;
	}
	public String getAuto_load_fg() {
		return auto_load_fg;
	}
	public void setAuto_load_fg(String auto_load_fg) {
		this.auto_load_fg = auto_load_fg;
	}
	public String getVideo_file_path() {
		return video_file_path;
	}
	public void setVideo_file_path(String video_file_path) {
		this.video_file_path = video_file_path;
	}
	public String getTar_file_path() {
		return tar_file_path;
	}
	public void setTar_file_path(String tar_file_path) {
		this.tar_file_path = tar_file_path;
	}
	
	
}
