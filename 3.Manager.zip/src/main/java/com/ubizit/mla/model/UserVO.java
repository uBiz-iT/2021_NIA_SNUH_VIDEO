/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : UserVO.java
 * @Description : 사용자 관리 그리드 리스트
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
public class UserVO implements Serializable{

	private static final long serialVersionUID = 1L;

	private String user_id;		//사용자 ID
	private String user_nm;		//사용자 이름
	private String is_manager;		//관리자 여부
	private String delete_fg;		//삭제여부
	private String reg_user_id;	//등록자
	private String passwd;     //암호
	
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_nm() {
		return user_nm;
	}
	public void setUser_nm(String user_nm) {
		this.user_nm = user_nm;
	}
	public String getIs_manager() {
		return is_manager;
	}
	public void setIs_manager(String is_manager) {
		this.is_manager = is_manager;
	}
	public String getDelete_fg() {
		return delete_fg;
	}
	public void setDelete_fg(String delete_fg) {
		this.delete_fg = delete_fg;
	}
	public String getReg_user_id() {
		return reg_user_id;
	}
	public void setReg_user_id(String reg_user_id) {
		this.reg_user_id = reg_user_id;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	
	
}
