/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : PgUserVeCt1VO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 7. 8.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 7. 8.
 * @version : 1.0
 * 
 */
public class PgUserVeCt2VO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String project_cd;
	private String psg_cnt;
	private String pass_cnt;
	private float pass_progress;
	private String fail_cnt;
	private float fail_progress;
	
	public String getProject_cd() {
		return project_cd;
	}
	public void setProject_cd(String project_cd) {
		this.project_cd = project_cd;
	}
	public String getPsg_cnt() {
		return psg_cnt;
	}
	public void setPsg_cnt(String psg_cnt) {
		this.psg_cnt = psg_cnt;
	}
	public String getPass_cnt() {
		return pass_cnt;
	}
	public void setPass_cnt(String pass_cnt) {
		this.pass_cnt = pass_cnt;
	}
	public float getPass_progress() {
		return pass_progress;
	}
	public void setPass_progress(float pass_progress) {
		this.pass_progress = pass_progress;
	}
	public String getFail_cnt() {
		return fail_cnt;
	}
	public void setFail_cnt(String fail_cnt) {
		this.fail_cnt = fail_cnt;
	}
	public float getFail_progress() {
		return fail_progress;
	}
	public void setFail_progress(float fail_progress) {
		this.fail_progress = fail_progress;
	}
	
	
}
