/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : AnalysisItemVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
public class AnalysisItemVO implements Serializable{

	private static final long serialVersionUID = 1L;

	private String code_name;			//프로젝트코드
	private String project_name;		//프로젝트명
	private String user_name_list;		//사용자 이름(판독자)
	private String user_id_list;		//사용자 아이디(판독자)
	private String labeling_ord_list;	//라벨링차수
	private String target_list;		//타겟
	
	public String getCode_name() {
		return code_name;
	}
	public void setCode_name(String code_name) {
		this.code_name = code_name;
	}
	public String getProject_name() {
		return project_name;
	}
	public void setProject_name(String project_name) {
		this.project_name = project_name;
	}
	public String getUser_name_list() {
		return user_name_list;
	}
	public void setUser_name_list(String user_name_list) {
		this.user_name_list = user_name_list;
	}
	public String getUser_id_list() {
		return user_id_list;
	}
	public void setUser_id_list(String user_id_list) {
		this.user_id_list = user_id_list;
	}
	public String getLabeling_ord_list() {
		return labeling_ord_list;
	}
	public void setLabeling_ord_list(String labeling_ord_list) {
		this.labeling_ord_list = labeling_ord_list;
	}
	public String getTarget_list() {
		return target_list;
	}
	public void setTarget_list(String target_list) {
		this.target_list = target_list;
	}

	
	
}
