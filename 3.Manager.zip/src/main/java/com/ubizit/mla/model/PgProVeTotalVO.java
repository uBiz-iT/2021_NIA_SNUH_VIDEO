/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : PgProVeTotalVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 6. 30.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 6. 30.
 * @version : 1.0
 * 
 */
public class PgProVeTotalVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String psg_cnt;		//검수 건수
	private String work_cnt;		//검수완료 건 수
	private float work_ing;		//검수완료 진행률
	private String pass_cnt;		//검수 PASS 건 수
	private float pass_ing;		//검수 PASS 진행률
	private String fail_cnt;		//검수 FAIL 건 수
	private float fail_ing;		//검수 FAIL 진행률
    private String n_psg_cnt;		//검수 미완료 건 수
	private float n_psg_ing;		//검수 미완료 진행률
	private String user_cnt;		//현재 검수자 인원
	public String getPsg_cnt() {
		return psg_cnt;
	}
	public void setPsg_cnt(String psg_cnt) {
		this.psg_cnt = psg_cnt;
	}
	public String getWork_cnt() {
		return work_cnt;
	}
	public void setWork_cnt(String work_cnt) {
		this.work_cnt = work_cnt;
	}
	public float getWork_ing() {
		return work_ing;
	}
	public void setWork_ing(float work_ing) {
		this.work_ing = work_ing;
	}
	public String getPass_cnt() {
		return pass_cnt;
	}
	public void setPass_cnt(String pass_cnt) {
		this.pass_cnt = pass_cnt;
	}
	public float getPass_ing() {
		return pass_ing;
	}
	public void setPass_ing(float pass_ing) {
		this.pass_ing = pass_ing;
	}
	public String getFail_cnt() {
		return fail_cnt;
	}
	public void setFail_cnt(String fail_cnt) {
		this.fail_cnt = fail_cnt;
	}
	public float getFail_ing() {
		return fail_ing;
	}
	public void setFail_ing(float fail_ing) {
		this.fail_ing = fail_ing;
	}
	public String getN_psg_cnt() {
		return n_psg_cnt;
	}
	public void setN_psg_cnt(String n_psg_cnt) {
		this.n_psg_cnt = n_psg_cnt;
	}
	public float getN_psg_ing() {
		return n_psg_ing;
	}
	public void setN_psg_ing(float n_psg_ing) {
		this.n_psg_ing = n_psg_ing;
	}
	public String getUser_cnt() {
		return user_cnt;
	}
	public void setUser_cnt(String user_cnt) {
		this.user_cnt = user_cnt;
	}

}
