/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : ImageReqVO.java
 * @Description : 프로젝트 이미지 메인 화면 검색조건
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
public class ImageReqVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String fromDate;			//등록기간
	private String toDate;				//등록기간
	private String code_name;			//프로젝트코드명
	private String sub_yn;				//서브이미지 여부
	private String project_name;		//프로젝트명
	private String image_name;			//이미지 파일명
	private String refer_yn;			//참조이미지 여부
	private String search_yn;			//조회여부
	
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getCode_name() {
		return code_name;
	}
	public void setCode_name(String code_name) {
		this.code_name = code_name;
	}
	public String getSub_yn() {
		return sub_yn;
	}
	public void setSub_yn(String sub_yn) {
		this.sub_yn = sub_yn;
	}
	public String getProject_name() {
		return project_name;
	}
	public void setProject_name(String project_name) {
		this.project_name = project_name;
	}
	public String getImage_name() {
		return image_name;
	}
	public void setImage_name(String image_name) {
		this.image_name = image_name;
	}
	public String getRefer_yn() {
		return refer_yn;
	}
	public void setRefer_yn(String refer_yn) {
		this.refer_yn = refer_yn;
	}
	public String getSearch_yn() {
		return search_yn;
	}
	public void setSearch_yn(String search_yn) {
		this.search_yn = search_yn;
	}
	
	
}
