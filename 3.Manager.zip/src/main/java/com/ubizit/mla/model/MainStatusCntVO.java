/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : MainStatusCntVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 9. 14.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 9. 14.
 * @version : 1.0
 * 
 */
public class MainStatusCntVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String todo_cnt;		//to_do
	private String ing_cnt;		//진행중인 프로젝트
	private String end_cnt;		//완료 프로젝트
	
	public String getTodo_cnt() {
		return todo_cnt;
	}
	public void setTodo_cnt(String todo_cnt) {
		this.todo_cnt = todo_cnt;
	}
	public String getIng_cnt() {
		return ing_cnt;
	}
	public void setIng_cnt(String ing_cnt) {
		this.ing_cnt = ing_cnt;
	}
	public String getEnd_cnt() {
		return end_cnt;
	}
	public void setEnd_cnt(String end_cnt) {
		this.end_cnt = end_cnt;
	}


}
