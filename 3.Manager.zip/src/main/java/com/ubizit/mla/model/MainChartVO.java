/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : MainChartVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 9. 11.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 9. 11.
 * @version : 1.0
 * 
 */
public class MainChartVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String project_cd;		//프로젝트 코드
	private String project_name;	//프로젝트명
	private String total_num;		//전체건수
	private String complete_num;	//완료건수
	private double progress;		//진행률
	
	public String getProject_cd() {
		return project_cd;
	}
	public void setProject_cd(String project_cd) {
		this.project_cd = project_cd;
	}
	public String getProject_name() {
		return project_name;
	}
	public void setProject_name(String project_name) {
		this.project_name = project_name;
	}
	
	public String getTotal_num() {
		return total_num;
	}
	public void setTotal_num(String total_num) {
		this.total_num = total_num;
	}
	public String getComplete_num() {
		return complete_num;
	}
	public void setComplete_num(String complete_num) {
		this.complete_num = complete_num;
	}
	public double getProgress() {
		return progress;
	}
	public void setProgress(double progress) {
		this.progress = progress;
	}

}
