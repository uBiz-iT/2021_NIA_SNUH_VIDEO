/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : PgProPuCt2VO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 1. 5.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 1. 5.
 * @version : 1.0
 * 
 */
public class PgProPuCt2VO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String accept;
	private String reject;
	private String no_match;
	private String no_label;
	private String accept_percent;
	private String reject_percent;
	private String no_match_percent;
	private String no_label_percent;
	
	public String getAccept() {
		return accept;
	}
	public void setAccept(String accept) {
		this.accept = accept;
	}
	public String getReject() {
		return reject;
	}
	public void setReject(String reject) {
		this.reject = reject;
	}
	public String getNo_match() {
		return no_match;
	}
	public void setNo_match(String no_match) {
		this.no_match = no_match;
	}
	public String getNo_label() {
		return no_label;
	}
	public void setNo_label(String no_label) {
		this.no_label = no_label;
	}
	public String getAccept_percent() {
		return accept_percent;
	}
	public void setAccept_percent(String accept_percent) {
		this.accept_percent = accept_percent;
	}
	public String getReject_percent() {
		return reject_percent;
	}
	public void setReject_percent(String reject_percent) {
		this.reject_percent = reject_percent;
	}
	public String getNo_match_percent() {
		return no_match_percent;
	}
	public void setNo_match_percent(String no_match_percent) {
		this.no_match_percent = no_match_percent;
	}
	public String getNo_label_percent() {
		return no_label_percent;
	}
	public void setNo_label_percent(String no_label_percent) {
		this.no_label_percent = no_label_percent;
	}
	

}
