/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : PgProVeCt1VO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 7. 5.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 7. 5.
 * @version : 1.0
 * 
 */
public class PgProVeCt1VO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String user_id;			//검수자 아이디
	private String user_nm;			//검수자 이름
	private String pass_progress;		//pass 진행률
	private String fail_progress;		//fail 진행률
	private String pass_cnt;			//pass 건수
	private String fail_cnt;			//fail 건수
	
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_nm() {
		return user_nm;
	}
	public void setUser_nm(String user_nm) {
		this.user_nm = user_nm;
	}
	public String getPass_progress() {
		return pass_progress;
	}
	public void setPass_progress(String pass_progress) {
		this.pass_progress = pass_progress;
	}
	public String getFail_progress() {
		return fail_progress;
	}
	public void setFail_progress(String fail_progress) {
		this.fail_progress = fail_progress;
	}
	public String getPass_cnt() {
		return pass_cnt;
	}
	public void setPass_cnt(String pass_cnt) {
		this.pass_cnt = pass_cnt;
	}
	public String getFail_cnt() {
		return fail_cnt;
	}
	public void setFail_cnt(String fail_cnt) {
		this.fail_cnt = fail_cnt;
	}
	
	
}
