/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : ImageVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
public class ImageSubVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String image_id;			//이미지 ID
	private String image_name;			//이미지 파일명
	private String image_view;			//이미지 보기
	private String ori_image_view;		//원본이미지 보기
//	private String image_name;			//이미지 파일명
//	private String image_sub_id;		//서브이미지 ID
//	private String image_sub_name;		//서브이미지 파일명
//	private String image_view;			//이미지 보기
//	private String reg_dt;				//등록일자
	
	public String getImage_id() {
		return image_id;
	}
	public void setImage_id(String image_id) {
		this.image_id = image_id;
	}
	public String getImage_name() {
		return image_name;
	}
	public void setImage_name(String image_name) {
		this.image_name = image_name;
	}
	public String getImage_view() {
		return image_view;
	}
	public void setImage_view(String image_view) {
		this.image_view = image_view;
	}
	public String getOri_image_view() {
		return ori_image_view;
	}
	public void setOri_image_view(String ori_image_view) {
		this.ori_image_view = ori_image_view;
	}
//	public String getImage_name() {
//		return image_name;
//	}
//	public void setImage_name(String image_name) {
//		this.image_name = image_name;
//	}
//	public String getImage_sub_id() {
//		return image_sub_id;
//	}
//	public void setImage_sub_id(String image_sub_id) {
//		this.image_sub_id = image_sub_id;
//	}
//	public String getImage_sub_name() {
//		return image_sub_name;
//	}
//	public void setImage_sub_name(String image_sub_name) {
//		this.image_sub_name = image_sub_name;
//	}
//	public String getImage_view() {
//		return image_view;
//	}
//	public void setImage_view(String image_view) {
//		this.image_view = image_view;
//	}
//	public String getReg_dt() {
//		return reg_dt;
//	}
//	public void setReg_dt(String reg_dt) {
//		this.reg_dt = reg_dt;
//	}

}
