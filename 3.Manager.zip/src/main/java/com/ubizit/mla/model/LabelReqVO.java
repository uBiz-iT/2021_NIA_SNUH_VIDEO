/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : LabelReqVO.java
 * @Description : 라벨 등록관리 메인 화면 검색조건
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
public class LabelReqVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String fromDate;			//등록기간
	private String toDate;				//등록기간
	private String code_name;			//프로젝트코드명
	private String target_cd;			//타겟코드
	private String project_name;		//프로젝트명
	private String label_name;			//라벨명
	private String del_yn;				//삭제여부
	
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getCode_name() {
		return code_name;
	}
	public void setCode_name(String code_name) {
		this.code_name = code_name;
	}
	public String getTarget_cd() {
		return target_cd;
	}
	public void setTarget_cd(String target_cd) {
		this.target_cd = target_cd;
	}
	public String getProject_name() {
		return project_name;
	}
	public void setProject_name(String project_name) {
		this.project_name = project_name;
	}
	public String getLabel_name() {
		return label_name;
	}
	public void setLabel_name(String label_name) {
		this.label_name = label_name;
	}
	public String getDel_yn() {
		return del_yn;
	}
	public void setDel_yn(String del_yn) {
		this.del_yn = del_yn;
	}
	
	
}
