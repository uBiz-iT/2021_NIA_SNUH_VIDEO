/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : ProjectReadVO.java
 * @Description : 판독자 목록
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 5. 11.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 5. 11.
 * @version : 1.0
 *
 */
public class ProjectReadVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String user_id;        //사용자 ID
	private String user_nm;       	//사용자 이름
	private String assign_date;    //할당 일자
	private String reg_user_id;    //등록자
	
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_nm() {
		return user_nm;
	}
	public void setUser_nm(String user_nm) {
		this.user_nm = user_nm;
	}
	public String getAssign_date() {
		return assign_date;
	}
	public void setAssign_date(String assign_date) {
		this.assign_date = assign_date;
	}
	public String getReg_user_id() {
		return reg_user_id;
	}
	public void setReg_user_id(String reg_user_id) {
		this.reg_user_id = reg_user_id;
	}
	
	
	
}
