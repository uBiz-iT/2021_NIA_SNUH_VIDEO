/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : LabelReadVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 10. 5.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 10. 5.
 * @version : 1.0
 * 
 */
public class LabelReadVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String label_cd;       //라벨값
	private String label_desc;     //라벨 설명
	private String reg_dt;			//등록일자
	private String reg_user_id;	//등록자
	
	public String getLabel_cd() {
		return label_cd;
	}
	public void setLabel_cd(String label_cd) {
		this.label_cd = label_cd;
	}
	public String getLabel_desc() {
		return label_desc;
	}
	public void setLabel_desc(String label_desc) {
		this.label_desc = label_desc;
	}
	public String getReg_dt() {
		return reg_dt;
	}
	public void setReg_dt(String reg_dt) {
		this.reg_dt = reg_dt;
	}
	public String getReg_user_id() {
		return reg_user_id;
	}
	public void setReg_user_id(String reg_user_id) {
		this.reg_user_id = reg_user_id;
	}
	
}
