/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * 
 * @Class Name : LoginVO.java
 * @Description : 로그인VO
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 5. 3.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 5. 3.
 * @version : 1.0
 *
 */
public class LoginVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String mission_cd;		//미션코드(과제코드)
	private String user_id;		//사용자 ID
	private String user_nm;		//사용자 이름
	private String is_manager;		//관리자여부 (시스템/미션관리자 = 'Y', 일반사용자 = 'N')
	
	public String getMission_cd() {
		return mission_cd;
	}
	public void setMission_cd(String mission_cd) {
		this.mission_cd = mission_cd;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_nm() {
		return user_nm;
	}
	public void setUser_nm(String user_nm) {
		this.user_nm = user_nm;
	}
	public String getIs_manager() {
		return is_manager;
	}
	public void setIs_manager(String is_manager) {
		this.is_manager = is_manager;
	}
	
	
}
