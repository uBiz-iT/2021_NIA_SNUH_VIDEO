/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : ProgressProjectVO.java
 * @Description : 진행률 - 프로젝트 현황
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 5. 18.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 5. 18.
 * @version : 1.0
 *
 */
public class ProgressProjectVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String row_num;			//순번
	private String project_cd;       	//프로젝트코드명
	private String project_nm;    		//프로젝트명
	private String user_cnt;	 		//검수인원
	private float total_progress;  	//전체 진행률(%)
	private String work_cnt;    		//검수 완료/대상 개수
	private String pass_cnt;    		//PASS 검수
	private String fail_cnt;   		//FAIL 검수
	private String progress_chk;		//진행률 확인
	private String cross_chk;		 	//크로스체크
	
	public String getRow_num() {
		return row_num;
	}
	public void setRow_num(String row_num) {
		this.row_num = row_num;
	}
	public String getProject_cd() {
		return project_cd;
	}
	public void setProject_cd(String project_cd) {
		this.project_cd = project_cd;
	}
	public String getProject_nm() {
		return project_nm;
	}
	public void setProject_nm(String project_nm) {
		this.project_nm = project_nm;
	}
	public String getUser_cnt() {
		return user_cnt;
	}
	public void setUser_cnt(String user_cnt) {
		this.user_cnt = user_cnt;
	}
	public float getTotal_progress() {
		return total_progress;
	}
	public void setTotal_progress(float total_progress) {
		this.total_progress = total_progress;
	}
	public String getWork_cnt() {
		return work_cnt;
	}
	public void setWork_cnt(String work_cnt) {
		this.work_cnt = work_cnt;
	}
	public String getPass_cnt() {
		return pass_cnt;
	}
	public void setPass_cnt(String pass_cnt) {
		this.pass_cnt = pass_cnt;
	}
	public String getFail_cnt() {
		return fail_cnt;
	}
	public void setFail_cnt(String fail_cnt) {
		this.fail_cnt = fail_cnt;
	}
	public String getProgress_chk() {
		return progress_chk;
	}
	public void setProgress_chk(String progress_chk) {
		this.progress_chk = progress_chk;
	}
	public String getCross_chk() {
		return cross_chk;
	}
	public void setCross_chk(String cross_chk) {
		this.cross_chk = cross_chk;
	}
	
	
}
