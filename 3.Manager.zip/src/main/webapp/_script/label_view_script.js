$(document).ready(function() {
	
});

$(function(){
	
	var code_name = $("#project_cd").val();
	var target_cd = $("#target_cd").val();
	fnReadLabel(code_name, target_cd);
	
})


function fnReadLabel(code_name, target_cd){
	
	var url = "label.read.do";
	var data = new Object();
	data.code_name = code_name;
	data.target_cd = target_cd;
	
	var async = false;
	
	callAjax(url, data, async, function(json){
		createTableRow("labelTable", json);
	});
	
}


function fnUpdateData(){
	
	var project_cd = $("#project_cd").val();
	var target_cd = $("#target_cd").val();
	
	if(project_cd == ""){
		alert("프로젝트 불러오기를 실패하였습니다.");
		return false;
	}
	if(target_cd == ""){
		alert("타겟코드 불러오기를 실패하였습니다.");
		return false;
	}
	
	self.close();
	
	var url = "/MLA_SNUH";
	url += "/label.update.do"
	url += "?code_name="+project_cd
	url += "&target_cd="+target_cd
		
	openPopup(url, "1024", "400", "POPUP_LABEL_WRITE", "yes", "yes", "");
	
}