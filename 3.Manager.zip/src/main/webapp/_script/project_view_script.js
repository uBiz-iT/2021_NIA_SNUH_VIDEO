$(document).ready(function() {
	
});

$(function(){
	
	var project_cd = $("#project_cd").val();
	fnReadUser(project_cd);
	
})


function fnReadUser(project_cd){

	var url = "project.read.user.do";
	var data = new Object();
	data.project_cd = project_cd;
	
	var async = false;
	
	callAjax(url, data, async, function(json){
		createTableRow("projectUserTable", json);
	});
	
}


function fnUpdateData(){
	
	var project_cd = $("#project_cd").val();
	
	if(project_cd == ""){
		alert("프로젝트 불러오기를 실패하였습니다.");
		return false;
	}
	
	self.close();
	
	var url = "/MLA_VIDEO";
	url += "/project.update.do"
	url += "?project_cd="+project_cd;
		
	openPopup(url, "1024", "500", "POPUP_PROJECT_WRITE", "yes", "yes", "");
	
}