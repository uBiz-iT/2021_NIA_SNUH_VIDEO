$(document).ready(function() {
	
});

$(function(){
	
	
})


function popupUser(v, i){
	
	var url = "/MLA_VIDEO";
	url += "/project.user.popup.do"
	if(v == 0){
		url += "?manager=Y&index="+i;
	}else if(v == 1){
		url += "?manager=N&index="+i;
	}
		
	openPopup(url, "700", "500", "POPUP_USER_SEARCH", "yes", "yes", "");
	
}

function addManager(obj){
	
	$(obj).closest("tr").clone(true).appendTo("#projectManagerTableBody");
}

function addUser(obj){
	
	$(obj).closest("tr").clone(true).appendTo("#projectUserTableBody");
}

function remove(obj){
	$(obj).closest("tr").remove();
}

function addManagerRow(){

	var reg_user_nm  = $("#regUserNm").val();
	
	var date = new Date();
	var today = date.getFullYear() + "-" + ("0"+(date.getMonth()+1)).slice(-2) + "-" + ("0"+(date.getDate())).slice(-2);
	
	var trCnt = $("#projectManagerTableBody tr").length;
	
	var html = "";
	
	html += '<tr class="manager_clone" index="'+trCnt+'">';
	html += '<td><button class="add_manager" onclick="addManager(this);"></button></td>';
	html += '<td class="manager_id"><input type="text" class="input_text" onclick="popupUser(0, '+trCnt+')" readOnly/></td>';
	html += '<td class="manager_name"><input type="text" class="input_text" readOnly/></td>';
	html += '<td>'+today+'</td>';
	html += '<td class="reg_user">'+reg_user_nm+'</td>';
	html += '<td class="manager_expt"><select name="is_expt" class="is_expt"><option value="N">N</option><option value="Y">Y</option></select></td>';
	html += '<td><button class="remove_manager" onclick="remove(this);"></button></td>';
	html += '</tr>';

	$("#projectManagerTableBody").append(html);
	
}

function addUserRow(){
	
	var reg_user_nm  = $("#regUserNm").val();
	
	var date = new Date();
	var today = date.getFullYear() + "-" + ("0"+(date.getMonth()+1)).slice(-2) + "-" + ("0"+(date.getDate())).slice(-2);
	
	var trCnt = $("#projectUserTableBody tr").length;
	
	var html = "";
	
	html += '<tr class="user_clone" index="'+trCnt+'">';
	html += '<td><button class="add_user" onclick="addUser(this);"></button></td>';
	html += '<td class="user_id"><input type="text" class="input_text" onclick="popupUser(1, '+trCnt+')" readOnly/></td>';
	html += '<td class="user_nm""><input type="text" class="input_text" readOnly/></td>';
	html += '<td>'+today+'</td>';
	html += '<td class="reg_user">'+reg_user_nm+'</td>';
	html += '<td><button class="remove_user" onclick="remove(this);"></button></td>';
	html += '</tr>';
	
	
	$("#projectUserTableBody").append(html);
	
}

function fnSaveData(){
	
	var bool = validation('');
	if(!bool){
		return false;
	}
	
	var user_array = new Array();
	var JsonObject = new Object();
	
	JsonObject.project_cd = $("#project_cd").val();
	JsonObject.project_nm = $("#project_nm").val();
	JsonObject.data_dir = $("#data_dir").val();
	
	var user_tr = $(".user_clone").length;
	
	var users = [];
	for(var j = 0; j < user_tr; j++){
		if($(".user_clone:eq("+j+")").find(".user_id").find(".input_text").val() == ""){
			alert("입력되지 않은 항목이 있습니다.");
			$(".user_clone:eq("+j+")").find(".user_id").find(".input_text").focus();
			return false;
		}else{
			users.push($(".user_clone:eq("+j+")").find(".user_id").find(".input_text").val());
		}
	}
	
	JsonObject.user = JSON.stringify(users);
	
	$.ajax({
		url : "project.insert.do",
		type :"POST",
		async : false,
		dataType : "json",
		data : JsonObject
	})
	.done(function(data){
		
		var msg = data.p_ret_msg;
		var code = data.p_ret_code;
		
		if(code == 0){
			alert(msg);
		}else{
			alert(msg);
			return false;
		}
		
		self.close();
	})
	.fail(function(jqXHR, textStatus, errorThrown){
		var msg="처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";
		
		alert(msg);
	});
	
}


function fnUpdateData(update_yn){
	
	var msg = confirm("현재 라벨링 작업 중인 판독자를 삭제할 경우\n작업이 중지되오니 반드시 확인 후 변경해주세요!");
	if(msg){
	
		var bool = validation(update_yn);
		if(!bool){
			return false;
		}

		var user_array = new Array();
		var JsonObject = new Object();
		
		JsonObject.project_cd = $("#project_cd").val();
		JsonObject.project_nm = $("#project_nm").val();
		JsonObject.data_dir = $("#data_dir").val();
		JsonObject.complete_yn = $("#complete_yn option:selected").val();
		JsonObject.delete_fg = $("#delete_fg option:selected").val();
		
		var user_tr = $(".user_clone").length;
		
		var users = [];
		for(var j = 0; j < user_tr; j++){
			if($(".user_clone:eq("+j+")").find(".user_id").find(".input_text").val() == ""){
				alert("입력되지 않은 항목이 있습니다.");
				$(".user_clone:eq("+j+")").find(".user_id").find(".input_text").focus();
				return false;
			}else{
				users.push($(".user_clone:eq("+j+")").find(".user_id").find(".input_text").val());
			}
			
		}
		
		JsonObject.user = JSON.stringify(users);
		
		$.ajax({
			url : "project.write.update.do",
			type :"POST",
			async : false,
			dataType : "json",
			data : JsonObject
		})
		.done(function(data){
			var msg="정상적으로 수정되었습니다.";
			
			var msg = data.p_ret_msg;
			var code = data.p_ret_code;
			
			if(code == 0){
				alert(msg);
			}else{
				alert(msg);
				return false;
			}
			
			self.close();
		})
		.fail(function(jqXHR, textStatus, errorThrown){
			var msg="처리에 실패 하였습니다.";
			msg += "\n관리자에게 문의 하세요.";
			
			alert(msg);
		});
	
	}else{
	    return false;
	}
	
	
	
}


function validation(update_yn){
	
	if(update_yn != 'Y'){
		if($("#project_cd").val() == ""){
			alert("프로젝트 코드은 필수 입력 사항입니다.");
			$("#project_cd").focus();
			return false;
		}
	}
	
	if($("#project_nm").val() == ""){
		alert("프로젝트명은 필수 입력 사항입니다.");
		$("#project_nm").focus();
		return false;
	}

	if($("#data_dir").val() == ""){
		alert("이미지 경로는 필수 입력 사항입니다.");
		$("#data_dir").focus();
		return false;
	}
	
	return true;
	
}









