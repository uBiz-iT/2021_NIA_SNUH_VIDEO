$(document).ready(function() {
	
	/** date picker */
	datePicker($("#fromDate"));
	datePicker($("#toDate"));	
	
});

$(function(){
	
	fnSearch();

	$(".ui-pg-selbox").change(function(){
		$("#page_cnt").val($(this).val());
	})
	
})

function fnSearch(){
	
	$("#grid").jqGrid({

		url: 'manage.error.search.do',
	    mtype : "POST",
	    datatype: 'json',
	    jsonReader : {
	    	root : "rows"
//	    	records : "pageCnt"
	    },
		postData : {
			fromDate 		: $('#fromDate').val(),
			toDate 			: $('#toDate').val(),
			error_code 		: $('#error_code').val(),
			error_msg 		: $('#error_msg').val()
		},
	    colNames:['발생일시','실행 프로시저','에러 코드','에러메세지','데이터'],
	    colModel:[
	              {name:'issue_dt'		,index:'issue_dt'		,width:150		,align:"center"},
	              {name:'proc_nm'	 	,index:'proc_nm'	 	,width:200		,align:"left"},
	              {name:'error_code'	,index:'error_code'		,width:90		,align:"center"},
	              {name:'error_msg' 	,index:'error_msg'  	,width:300  	,align:"left"},
	              {name:'error_data' 	,index:'error_data'    	,width:1000  	,align:"left"}
	             ],
	              
	    rowNum: parseInt($("#page_cnt").val()),
	    rowList: [10,20,30],
	    height: 350,
	    loadonce: true,
	    autowidth:true,    	 // jQgrid width 자동100% 채워지게
	    shrinkToFit:false,  // width를 자동설정 해주는 기능
	    gridview: true,
	    cmTemplate: { sortable: false },
	    rownumbers  : true,                     
	    pager: '#pager',
        ondblClickRow : function(rowId, iRow, iCol, e) {
        	
        },
        
        viewrecords: true,
        loadComplete : function(data){

        },
        caption:" "
    	
    });	
	
}


