$(document).ready(function() {
	
});

$(function(){
	
})


function projectChange(obj){
	
	var project_cd = $(obj).val();
	var project_nm = $("#"+project_cd+"").val();
	var title = $("#"+project_cd+"").attr("title");
	
	$("#project_nm").val(project_nm);

//	var html = '<option value="">---선택---</option>';
//	
//	if(title.indexOf("0") == -1){
//		html += '<option value="0">0</option>';
//	}
//	if(title.indexOf("1") == -1){
//		html += '<option value="1">1</option>';
//	}
//	
//	$("#target_cd option").remove();
//	
//	$("#target_cd").append(html);
}

function addLabel(obj){
	
	$(obj).closest("tr").clone(true).appendTo("#labelTableBody");
}

function remove(obj){
	$(obj).closest("tr").remove();
}

function addLabelRow(){

	var reg_user_nm  = $("#regUserNm").val();
	
	var date = new Date();
	var today = date.getFullYear() + "-" + ("0"+(date.getMonth()+1)).slice(-2) + "-" + ("0"+(date.getDate())).slice(-2);
	
	
	var html = "";
	
	html += '<tr class="label_clone">';
	html += '<td><button class="add_label" onclick="addLabel(this);"></button></td>';
	html += '<td class="label_cd"><input type="number" class="input_text"/></td>';
	html += '<td class="label_nm"><input type="text" class="input_text"/></td>';
	html += '<td>'+today+'</td>';
	html += '<td class="reg_user">'+reg_user_nm+'</td>';
	html += '<td><button class="remove_label" onclick="remove(this);"></button></td>';
	html += '</tr>';

	
	$("#labelTableBody").append(html);
	
}

function fnSaveData(){
	
	var bool = validation('');
	if(!bool){
		return false;
	}
	
	var iCnt = 0;
	var label_array = new Array();
	var JsonObject = new Object();
	
	JsonObject.project_cd = $("#project_cd option:selected").val();
//	JsonObject.target_cd = $("#target_cd option:selected").val();
//	JsonObject.target_nm = $("#target_nm").val();
//	JsonObject.screen_loc = $("#screen_loc option:selected").val();
	
	var label_tr = $(".label_clone").length;
	
	var labels = [];
	for(var i = 0; i < label_tr; i++){
		if($(".label_clone:eq("+i+")").find(".label_cd").find(".input_text").val() == ""){
			alert("입력되지 않은 항목이 있습니다.");
			$(".label_clone:eq("+i+")").find(".label_cd").find(".input_text").focus();
			return false;
		}else if($(".label_clone:eq("+i+")").find(".label_nm").find(".input_text").val() == ""){
			alert("입력되지 않은 항목이 있습니다.");
			$(".label_clone:eq("+i+")").find(".label_cd").find(".input_text").focus();
			return false;
		}else{
//			labels.push($(".label_clone:eq("+i+")").find(".label_cd").find(".input_text").val());
			var jsonObj = {};
			
			jsonObj.label_cd = parseInt($(".label_clone:eq("+i+")").find(".label_cd").find(".input_text").val());
			jsonObj.label_nm = $(".label_clone:eq("+i+")").find(".label_nm").find(".input_text").val();
			
			label_array[iCnt] = jsonObj;
			iCnt++;
		}
		
	}
	
	JsonObject.label = JSON.stringify(label_array);
	
	
	$.ajax({
		url : "label.insert.do",
		type :"POST",
		async : false,
		dataType : "json",
		data : JsonObject
	})
	.done(function(){
		var msg="정상적으로 등록되었습니다.";
		
		alert(msg);
		
		self.close();
	})
	.fail(function(jqXHR, textStatus, errorThrown){
		var msg="처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";
		
		alert(msg);
	});
	
}


function fnUpdateData(update_yn){
	
	var msg = confirm("현재 라벨링된 라벨값을 삭제할 경우\n작업에 문제가 발생할 수 있습니다. 반드시 확인 후 변경해주세요!");
	if(msg){
	
		var bool = validation(update_yn);
		if(!bool){
			return false;
		}
	
		var iCnt = 0;
		var label_array = new Array();
		var JsonObject = new Object();
		
		JsonObject.project_cd = $("#project_cd").val();
//		JsonObject.target_cd = $("#target_cd option:selected").val();
//		JsonObject.target_nm = $("#target_nm").val();
//		JsonObject.screen_loc = $("#screen_loc option:selected").val();
		
		var label_tr = $(".label_clone").length;
		
		var labels = [];
		for(var i = 0; i < label_tr; i++){
			if($(".label_clone:eq("+i+")").find(".label_cd").find(".input_text").val() == ""){
				alert("입력되지 않은 항목이 있습니다.");
				$(".label_clone:eq("+i+")").find(".label_cd").find(".input_text").focus();
				return false;
			}else if($(".label_clone:eq("+i+")").find(".label_nm").find(".input_text").val() == ""){
				alert("입력되지 않은 항목이 있습니다.");
				$(".label_clone:eq("+i+")").find(".label_cd").find(".input_text").focus();
				return false;
			}else{
//				labels.push($(".label_clone:eq("+i+")").find(".label_cd").find(".input_text").val());
				var jsonObj = {};
				
				jsonObj.label_cd = parseInt($(".label_clone:eq("+i+")").find(".label_cd").find(".input_text").val());
				jsonObj.label_nm = $(".label_clone:eq("+i+")").find(".label_nm").find(".input_text").val();
				
				label_array[iCnt] = jsonObj;
				iCnt++;
			}
			
		}
		
		JsonObject.label = JSON.stringify(label_array);
		
		
		$.ajax({
			url : "label.write.update.do",
			type :"POST",
			async : false,
			dataType : "json",
			data : JsonObject
		})
		.done(function(data){
			
			var msg = data.p_ret_msg;
			var code = data.p_ret_code;
			
			if(code == -1){
				alert(msg);
				return false;
			}else{
				alert(msg);
			}
			
			self.close();
		})
		.fail(function(jqXHR, textStatus, errorThrown){
			var msg="처리에 실패 하였습니다.";
			msg += "\n관리자에게 문의 하세요.";
			
			alert(msg);
		});
	
	}else{
	    return false;
	}
}


function validation(update_yn){
	
	if(update_yn == 'Y'){
		
	}else{
		if($("#project_cd option:selected").val() == ""){
			alert("프로젝트 코드명은 필수 선택 사항입니다.");
			$("#project_cd").focus();
			return false;
		}
		
		if($("#target_cd option:selected").val() == ""){
			alert("타켓 코드는 필수 선택 사항입니다.");
			$("#target_cd").focus();
			return false;
		}
	}
	
	if($("#target_cd option:selected").val() == ""){
		alert("타켓 코드는 필수 선택 사항입니다.");
		$("#target_cd").focus();
		return false;
	}
	
	if($("#target_nm").val() == ""){
		alert("타겟명은 필수 입력 사항입니다.");
		$("#target_nm").focus();
		return false;
	}
	
	if($("#screen_loc option:selected").val() == ""){
		alert("화면상 위치는 필수 선택 사항입니다.");
		$("#screen_loc").focus();
		return false;
	}	
	
	return true;
	
}









