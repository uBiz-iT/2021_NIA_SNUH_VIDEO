$(document).ready(function() {
	
	$(".input_text").keydown(function(key) {
	    if (key.keyCode == 13) {
	    	$("#search").click();
	    }
	});
	
	$(document).on("click","ul.tabs li",function(){
		var tab_id = $(this).attr('data-tab');
		
		$('ul.tabs li').removeClass('current');
	    
	    $(this).addClass('current');
	    $("#"+tab_id).addClass('current');
		
	    /** 이벤트 검수 결과 tab **/
	    var psg_id = $("#psg_id").val();
	    var project_cd = $("#project_cd").val();
	    
    	var obj = new Object();
    	obj.psg_id = psg_id;
    	obj.project_cd = project_cd;

    	if($(".tabs").find(".tab-link").hasClass('current')){
    		obj.user_id = $(".tabs").find(".current").find("span").text();
    	}else{
    		obj.user_id = '';
    	}
    	
	    createEvent(obj);
	})
	
	
	projectSearch();
	
});

$(function(){
	
	if($("#projectCd").val() != ''){
		var project_cd = $("#projectCd").val();
		
		auto_data(project_cd);
	}
	
})

/** 숫자 0 및 배열, 객체의 빈값 전부 체크 **/
function isEmpty(val){
	if(val === "" || val === null || val === undefined || (val !== null && typeof val === "object" && !Object.keys(val).length)){
		return true
	}else{
		return false
	}
}


/** 엑셀 다운로드 **/
function excelDownload(){
   
	var url = "analysis.excelDown.do";
   
   	var data = new Object();
   	data.psg_id = $("#psg_id").val();
   	data.project_cd = $("#project_cd").val();
   
   	if($(".tabs").find(".tab-link").hasClass('current')){
   		data.user_id = $(".tabs").find(".current").find("span").text();
	}else{
		data.user_id = '';
	}
   
   	$(".loading-image").show();
   
   	$.fileDownload(url,{
   		httpMethod:"POST",
   		data: data,
   		successCallback: function (url) {
   			$(".loading-image").hide();
   		},
   		failCallback: function (responseHtml, url, error) {
   			$(".loading-image").hide();
   		}

   	});
   
}


/** 프로젝트 리스트 조회 **/
function projectSearch(){
	var project_cd = $("#project_code").val();
	
	var data = new Object();
	data.project_cd = project_cd;
	
	var url = "analysis.search.do";
	var async = false;
	
	callAjax(url, data, async, function(json){
		
		var rows = json.rows;
		
		$("#tb_project").find("tr").remove();
		
		for(var i = 0; i < rows.length; i++){
			var html = "";
			
			html += "<tr>";
			html += "<td id='"+rows[i].projectCd+"' style='font-size:14px;border:none;font-weight:bold;border-bottom:1px dashed #cccccc;'>" +
					"<span style='cursor:pointer;padding-left:10px;' onclick='selectProject(this)'>"+rows[i].projectCd+"</span></td>";
			html += "</tr>";
			
			$("#tb_project").append(html);
		}
		
	});
	
}

/** 크로스 체크 재조회 **/
function reSearch(){
	var project_cd = $("#project_cd").val();
	
	var url = "analysis.crossChk.do";
	var async = false;
	var data = new Object();
	
	data.project_cd = project_cd;
	if($("#same_yn").is(':checked')){
		data.same_yn = 'Y';
	}else{
		data.same_yn = 'N';
	}
	
	$(".tabs").find(".tab-link").remove();
	$(".div_subject").css('display', 'none');
	
	createGrid(data);
}


function selectProject(obj){

	$("#tb_project").find("tr").css("background", "white");
	$(".div_video").find(".buttonList").css("display", "none");
	
	var project_cd = $(obj).text();
	$("#project_cd").val(project_cd);
	$(obj).closest('tr').css("background", "#eaf0fa");
	
	$(".list_num").css("display", "block");
	
	var data = new Object();
	
	data.project_cd = project_cd;
	if($("#same_yn").is(':checked')){
		data.same_yn = 'Y';
	}else{
		data.same_yn = 'N';
	}
	
	$("video").remove();
	$(".tabs").find(".tab-link").remove();
	$(".div_subject").css('display', 'none');
	
	createGrid(data);
	
	$("#div_cross_chk").slideDown("slow");
	
}


/** 진행률 화면에서 크로스체크 넘어왔을 때 데이터 자동 출력 **/
function auto_data(project_cd){
	
	var data = new Object();
	data.project_cd = project_cd;
	data.same_yn = 'N';
	
	$("#tb_project").find("tr").css("background", "white");
	var obj = $("#tb_project").find("tr").find("#"+project_cd+"");
	
	var project_cd = $(obj).text();
	$("#project_cd").val(project_cd);
	$(obj).closest('tr').css("background", "#eaf0fa");
	
	$(".list_num").css("display", "block");
	
	var data = new Object();
	
	data.project_cd = project_cd;
	if($("#same_yn").is(':checked')){
		data.same_yn = 'Y';
	}else{
		data.same_yn = 'N';
	}
	
	createGrid(data);
	
	$("#div_cross_chk").slideDown("slow");
	
}

/** 그리드 생성 **/
function createGrid(data){
	
	var colNames = [];
	var colModels = [];
	var rows;
	var row_size;
	var keys;
	
	$.ajax({
		url : "analysis.crossChk.do",
		async : false,
		dataType : "json",
		type : "POST",
		data : data
	})
	.done(function(jsonData){
		if(jsonData.rows != ''){
			rows = jsonData.rows;
			keys = Object.keys(jsonData.rows[0]);
			row_size = jsonData.total;
			
			for(var i = 0; i < keys.length; i++){
				var model = {name:keys[i],index:keys[i],width:170, align:"center"};
				if(keys[i] == "검사(환자) ID"){
					model.width = 170;
				}else if(keys[i] == "검수완료여부" || keys[i] == "검수일치여부" || keys[i] == "검수일치결과"){
					model.width = 100;
				}
				colModels.push(model);
				colNames.push(keys[i]);
				
			}
		}else{
			alert("조회된 데이터가 없습니다.");
			
			colModels.push({name:"검사(환자) ID",index:"검사(환자) ID",width:170, align:"center"},{name:"검수완료여부",index:"검수완료여부",width:100, align:"center"},
						   {name:"검수일치결과",index:"검수일치결과",width:100, align:"center"},{name:"검수일치여부",index:"검수일치여부",width:100, align:"center"});
		}
		
		
	})
	.fail(function(jqXHR, textStatus, errorThrown){
		var msg="처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";
		
		alert(msg);
	});
	
	$.jgrid.gridUnload("grid");
	
	$("#grid").jqGrid({
		data : rows,
		datatype: "local",
		colNames : colNames,
		colModel : colModels,
		rowNum: row_size,	
//	    rowNum: parseInt($("#page_cnt1").val()),
//	    rowList: [50,100,150, 200],
	    height: 500,
	    loadonce: true,
	    autowidth:true,    	 // jQgrid width 자동100% 채워지게
	    shrinkToFit:false,  // width를 자동설정 해주는 기능
	    gridview: true,
	    cmTemplate: { sortable: false },
	    rownumbers  : true,                     
	    pager: '#pager',
	    onCellSelect: function(rowId, iCol, cellcontent, e){
        
	    },
	    onSelectRow: function(rowId, status, e) {
	    	var psg_id = $("#grid").getCell(rowId, "검사(환자) ID");
	    	var project_cd = $("#project_cd").val();
	    	
	    	$("#psg_id").val(psg_id);
	    	
	    	var obj = new Object();
	    	obj.psg_id = psg_id;
	    	obj.project_cd = project_cd;
	    	
	    	if($(".tabs").find(".tab-link").hasClass('current')){
	    		obj.user_id = $(".tabs").find(".current").find("span").text();
	    	}else{
	    		obj.user_id = '';
	    	}
	    	
	    	createEvent(obj);
	    	
	    },        
//	    ondbClickRow : function(rowId, iRow, iCol, e) {},        
        viewrecords: true,
        loadComplete : function(data){
        	var ids = $("#grid").getDataIDs();
        	var total = $("#grid").getGridParam("records");
        	$("#list_num").text(total);
        	
        	$.each(ids, function(idx, rowId){
        		rowData = $("#grid").getRowData(rowId);
        		
        		if(rowData.검수일치여부 == 'X'){
//        			$("#grid").setRowData(rowId, false, {background:"#1191d033"});
        			$("#grid").jqGrid('setCell', rowId, '검수일치여부', '', {'background':"#1191d033"});
        		}
        		if(rowData.검수일치결과 == 'Fail'){
        			$("#grid").jqGrid('setCell', rowId, '검수일치결과', '', {'color':"#ff0505",'font-weight':'bold'});
        		}
        	})
        	
        },
        caption:" "
	})
	
	$("#event_chk_list").css("display", "none");
	
}


function createEvent(data){

	$("#span_video").addClass('on_view');
	videoDownload();
	
	var colNames = [];
	var colModels = [];	
	var rows;
	var user_id;
	var user_nm;
	var users;
	var row_size;
	
	$.ajax({
		url : "analysis.eventList.do",
		async : false,
		dataType : "json",
		type : "POST",
		data : data
	})
	.done(function(jsonData){
		
		if(jsonData.row != ''){
			rows = jsonData.row;
			user_id = jsonData.user;
			users = jsonData.user_list;
			row_size = jsonData.total;
			
			colModels.push({name:"이벤트 순번",index:"이벤트 순번",width:90, align:"center"},{name:"이벤트명",index:"이벤트명",width:150, align:"center"},
						   {name:"이벤트 타입",index:"이벤트 타입",width:130, align:"center"},{name:"이벤트 의미",index:"이벤트 의미",width:130, align:"center"},
						   {name:"시작초",index:"시작초",width:100, align:"center"},{name:"종료초",index:"종료초",width:100, align:"center"},
						   {name:"시작일시",index:"시작일시",width:100, align:"center"},{name:"종료일시",index:"종료일시",width:100, align:"center"},
						   {name:"시작일시_TS",index:"시작일시_TS",width:100, align:"center"},{name:"종료일시_TS",index:"종료일시_TS",width:100, align:"center"},
						   {name:"경과시간",index:"경과시간",width:100, align:"center"},{name:"시작 EPOCH 번호",index:"시작 EPOCH 번호",width:120, align:"center"},
						   {name:"종료 EPOCH 번호",index:"종료 EPOCH 번호",width:120, align:"center"},{name:"검수결과",index:"검수결과",width:150, align:"center"},
						   {name:"메모",index:"메모",width:200, align:"center"},{name:"검수일자",index:"검수일자",width:150, align:"center"}
			);
		}
		
	})
	.fail(function(jqXHR, textStatus, errorThrown){
		var msg="처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";
		
		alert(msg);
	});
	
	$(".div_subject").css("display", "block");
	$(".wrap_content_grid").css("height", "650px");
	
	/** 탭 **/
	if(!$(".tabs").find(".tab-link").hasClass('current')){
		for(var i = 1; i <= users.length; i++){
			var tab = 'tab-'+ i;
		
			if(i == 1){
				$(".tabs").append('<li class="tab-link current" data-tab="'+tab+'" style="border:1px solid #ededed;width:160px;">'+users[0].userNm + ' ( <span>' + users[0].userId + '</span> ) '+'</li>');
			}else{
				$(".tabs").append('<li class="tab-link" data-tab="'+tab+'" style="border:1px solid #ededed;width:160px;">'+users[i-1].userNm + ' ( <span>' + users[i-1].userId + '</span> ) '+'</li>');
			}
			
			if(user_id == users[i-1].userId){
				user_nm = users[i-1].userNm;
			}
		}
		
	}else{
		for(var i = 1; i <= users.length; i++){
			
			if(user_id == users[i-1].userId){
				user_nm = users[i-1].userNm;
			}
		}
	}
	
	
	if(users.length < 1){
		alert("검수자가 없어 이벤트 목록을 확인할 수 없습니다");
	}else{
		
		$.jgrid.gridUnload("grid_event");
		
		$("#grid_event").jqGrid({
			data : rows,
			datatype: "local",
			colNames : colNames,
			colModel : colModels,
		    rowNum: row_size,		
		    height: 500,
		    loadonce: true,
		    autowidth:true,    	 // jQgrid width 자동100% 채워지게
		    shrinkToFit:false,  // width를 자동설정 해주는 기능
		    gridview: true,
		    cmTemplate: { sortable: false },
		    rownumbers  : false,                     
		    pager: '#pager',
		    onCellSelect: function(rowId, iCol, cellcontent, e){
	        
		    },
		    ondblClickRow : function(rowId, iRow, iCol, e) {
	        	
	        },        
	        viewrecords: true,
	        loadComplete : function(data){
	        	$(".loading-image").show();
	        	
	        	$("#grid_event").jqGrid("hideCol", "시작초");
	        	$("#grid_event").jqGrid("hideCol", "종료초");
	        	$("#grid_event").jqGrid("hideCol", "시작일시_TS");
	        	$("#grid_event").jqGrid("hideCol", "종료일시_TS");
	        	
	        	var ids = $("#grid_event").getDataIDs();
	        	var total = $("#grid_event").getGridParam("records");
	        	$("#event_list_num").text(total);
	        	
	        	$.each(ids, function(idx, rowId){
	        		rowData = $("#grid_event").getRowData(rowId);
	        		
	        		if(rowData.검수결과 == 'NG'){
	        			$("#grid_event").jqGrid('setCell', rowId, '검수결과', '', {'background':"#1191d033"});
	        		}else if(rowData.검수결과 == 'OK'){
	        			$("#grid_event").jqGrid('setCell', rowId, '검수결과', '', {'background':"#ff000033"});
	        		}
	        	})
	        	
	        },
	        caption:" "
		})
		
		$("#str_user").text(user_nm + " (" + user_id + ") ");
		
	}
	
	$("#event_chk_list").slideDown("fast");
	$('body, html').animate({ scrollTop: $("#event_chk_list").offset().top }, 1000);
	
	$(".loading-image").hide();
	
	
}


function videoDownload(){
	
	$("video").remove();
	
	var data = new Object();
	data.project_cd = $("#project_cd").val();
	data.psg_id = $("#psg_id").val();
	
	var videoPath = '';
	
	$.ajax({
		url : "analysis.video.do",
		async : false,
		dataType : "json",
		type : "POST",
		data : data
	})
	.done(function(json){
		if(json.videoFilePath != ''){
			videoPath = json.videoFilePath;
		}else{
			alert('동영상 파일이 없습니다.');
		}

	})
	.fail(function(jqXHR, textStatus, errorThrown){
		var msg="처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";
		
		alert(msg);
	});
	
	if($("#span_video").hasClass('on_view')){
		
		$("#span_video").find("a").text('동영상확인');
		$("#event_chk_list").css("width", "100%");
		$(".div_video").find(".buttonList").css("display", "none");
		
		$("#span_video").removeClass('on_view');
		
	}else{
		
		$("#span_video").find("a").text('동영상닫기');
		$(".div_video").find(".buttonList").css("display", "block");
		
		var html = '';
		html += '<video id="myVideo" width="750" height="540" style="margin-left:20px;" controls controlsList="nodownload">';
//		html += '<source src="A2020-NX-01-0787_video.mp4" type="video/mp4">';
		html += '<source src="/'+videoPath+'" type="video/mp4">';
		html += '</video>';
		
		$("#event_chk_list").css("width", "50%");
		$(".div_video").append(html);
		
		$("#span_video").addClass('on_view');
		
	}
		
}

function playbackRate(rate){
	var vid = document.getElementById("myVideo");
	vid.playbackRate = rate;
}

function second(time){
	var vid = document.getElementById("myVideo");
	vid.currentTime = time;
}


/** 이벤트 그리드 생성 **/
//function createEvent1(data){
//	
//	var colNames = [];
//	var colModels = [];
//	var rows0;
//	var rows1;
//	var users;
//	var row_size;
//	var keys;
//	
//	$.ajax({
//		url : "analysis.eventList.do",
//		async : false,
//		dataType : "json",
//		type : "POST",
//		data : data
//	})
//	.done(function(jsonData){
//		if(jsonData.row0 != '' && jsonData.row1 != ''){
//			rows0 = jsonData.row0;
//			rows1 = jsonData.row1;
//			users = jsonData.user_list;
//			row_size = jsonData.total;
//			
//			colModels.push({name:"이벤트 순번",index:"이벤트 순번",width:90, align:"center"},{name:"이벤트명",index:"이벤트명",width:150, align:"center"},
//						   {name:"이벤트 타입",index:"이벤트 타입",width:130, align:"center"},{name:"이벤트 의미",index:"이벤트 의미",width:130, align:"center"},
//						   {name:"시작초",index:"시작초",width:100, align:"center"},{name:"종료초",index:"종료초",width:100, align:"center"},
//						   {name:"경과시간",index:"경과시간",width:100, align:"center"},{name:"시작 EPOCH 번호",index:"시작 EPOCH 번호",width:120, align:"center"},
//						   {name:"종료 EPOCH 번호",index:"종료 EPOCH 번호",width:120, align:"center"},{name:"검수결과",index:"검수결과",width:150, align:"center"},
//						   {name:"메모",index:"메모",width:200, align:"center"},{name:"검수일자",index:"검수일자",width:150, align:"center"}
//			);
//		}
//		
//	})
//	.fail(function(jqXHR, textStatus, errorThrown){
//		var msg="처리에 실패 하였습니다.";
//		msg += "\n관리자에게 문의 하세요.";
//		
//		alert(msg);
//	});
//	
//	$(".tabs").find(".tab-link").remove();
//	
//	/** 탭 **/
//	for(var i = 1; i <= users.length; i++){
//		var tab = 'tab-'+ i;
//		
//		if(i == 1){
//			$(".tabs").append('<li class="tab-link current" data-tab="'+tab+'" style="border:1px solid #ededed;width:160px;">'+users[0].userNm + ' ( <span>' + users[0].userId + '</span> ) '+'</li>');
//		}else{
//			$(".tabs").append('<li class="tab-link" data-tab="'+tab+'" style="border:1px solid #ededed;width:160px;">'+users[i-1].userNm + ' ( <span>' + users[i-1].userId + '</span> ) '+'</li>');
//		}
//		
//	}
//	
//	if(users.length < 1){
//		alert("검수자가 없어 이벤트 목록을 확인할 수 없습니다");
//	}else if(users.length == 1){
//		
//		$.jgrid.gridUnload("grid0");
//		
//		$("#grid0").jqGrid({
//			data : rows0,
//			datatype: "local",
//			colNames : colNames,
//			colModel : colModels,
//		    rowNum: row_size,		
//		    height: 500,
//		    loadonce: true,
//		    autowidth:true,    	 // jQgrid width 자동100% 채워지게
//		    shrinkToFit:false,  // width를 자동설정 해주는 기능
//		    gridview: true,
//		    cmTemplate: { sortable: false },
//		    rownumbers  : false,                     
//		    pager: '#pager',
//		    onCellSelect: function(rowId, iCol, cellcontent, e){
//	        
//		    },
//		    ondblClickRow : function(rowId, iRow, iCol, e) {
//	        	
//	        },        
//	        viewrecords: true,
//	        loadComplete : function(data){
//	        	$(".loading-image").show();
//	        	
//	        	var ids = $("#grid0").getDataIDs();
//	        	var total = $("#grid0").getGridParam("records");
//	        	$("#event_list_num0").text(total);
//	        	
//	        	$.each(ids, function(idx, rowId){
//	        		rowData = $("#grid0").getRowData(rowId);
//	        		
//	        		if(rowData.검수결과 == 'NG'){
//	        			$("#grid0").jqGrid('setCell', rowId, '검수결과', '', {'background':"#1191d033"});
//	        		}else if(rowData.검수결과 == 'OK'){
//	        			$("#grid0").jqGrid('setCell', rowId, '검수결과', '', {'background':"#ff000033"});
//	        		}
//	        	})
//	        	
//	        },
//	        caption:" "
//		})
//		
//		$("#str_user1").text(users[0].userNm + " (" + users[0].userId + ") ");
//		
//	}else {
//	
//		$.jgrid.gridUnload("grid0");
//		$.jgrid.gridUnload("grid1");
//		
//		$("#grid0").jqGrid({
//			data : rows0,
//			datatype: "local",
//			colNames : colNames,
//			colModel : colModels,
//		    rowNum: row_size,		
//		    height: 500,
//		    loadonce: true,
//		    autowidth:true,    	 // jQgrid width 자동100% 채워지게
//		    shrinkToFit:false,  // width를 자동설정 해주는 기능
//		    gridview: true,
//		    cmTemplate: { sortable: false },
//		    rownumbers  : false,                     
//		    pager: '#pager',
//		    onCellSelect: function(rowId, iCol, cellcontent, e){
//	        
//		    },
//		    ondblClickRow : function(rowId, iRow, iCol, e) {
//	        	
//	        },        
//	        viewrecords: true,
//	        loadComplete : function(data){
//	        	var ids = $("#grid0").getDataIDs();
//	        	var total = $("#grid0").getGridParam("records");
//	        	$("#event_list_num0").text(total);
//	        	
//	        	$.each(ids, function(idx, rowId){
//	        		rowData = $("#grid0").getRowData(rowId);
//	        		
//	        		if(rowData.검수결과 == 'NG'){
//	        			$("#grid0").jqGrid('setCell', rowId, '검수결과', '', {'background':"#1191d033"});
//	        		}else if(rowData.검수결과 == 'OK'){
//	        			$("#grid0").jqGrid('setCell', rowId, '검수결과', '', {'background':"#ff000033"});
//	        		}
//	        	})
//	        	
//	        },
//	        caption:" "
//		})	
//		
//		$("#grid1").jqGrid({
//			data : rows1,
//			datatype: "local",
//			colNames : colNames,
//			colModel : colModels,
//			rowNum: row_size,	
//			height: 500,
//			loadonce: true,
//			autowidth:true,    	 // jQgrid width 자동100% 채워지게
//			shrinkToFit:false,  // width를 자동설정 해주는 기능
//			gridview: true,
//			cmTemplate: { sortable: false },
//			rownumbers  : false,                     
//			pager: '#pager',
//			onCellSelect: function(rowId, iCol, cellcontent, e){
//				
//			},
//			ondblClickRow : function(rowId, iRow, iCol, e) {
//				
//			},        
//			viewrecords: true,
//			loadComplete : function(data){
//				var ids = $("#grid1").getDataIDs();
//	        	var total = $("#grid1").getGridParam("records");
//	        	$("#event_list_num1").text(total);
//	        	
//	        	$.each(ids, function(idx, rowId){
//	        		rowData = $("#grid1").getRowData(rowId);
//	        		
//	        		if(rowData.검수결과 == 'NG'){
//	        			$("#grid1").jqGrid('setCell', rowId, '검수결과', '', {'background':"#1191d033"});
//	        		}else if(rowData.검수결과 == 'OK'){
//	        			$("#grid1").jqGrid('setCell', rowId, '검수결과', '', {'background':"#ff000033"});
//	        		}
//	        	})
//				
//			},
//			caption:" "
//		})	
//		
//		$("#str_user1").text(users[0].userNm + " (" + users[0].userId + ") ");
//		$("#str_user2").text(users[1].userNm + " (" + users[1].userId + ") ");
//		
//	}
//	
//	$("#event_chk_list").slideDown("fast");
//	$('body, html').animate({ scrollTop: $("#event_chk_list").offset().top }, 1000);
//	
//	$(".loading-image").hide();
//}


function del(obj){
	var code = $(obj).closest('td').find('.checkbox').val();
	
	$(obj).closest('tr').css("display", "none");
	$("#userListTable tbody tr").find("."+code+"").css("display", "none");
	$("#labelListTable tbody tr").find("."+code+"").css("display", "none");
	$("#targetListTable tbody tr").find("."+code+"").css("display", "none");
}

/** 프로젝트 선택했을 때 이벤트 **/
function getUserItem(obj){
//	$("#projectListTable tbody tr td").find('.checkbox').prop('checked', false);
//	$(obj).find('.checkbox').prop('checked', true);
	
	if($("#projectListTable tbody tr td").find('.checkbox').is(":checked")){
		$("#projectListTable tbody tr td").find('.checkbox').prop('checked', false);
		
		$("#userListTable tbody tr").find("td").css("display", "none");
		$("#labelListTable tbody tr").find("td").css("display", "none");
		$("#targetListTable tbody tr").find("td").css("display", "none");
		
		$("#userListTable tbody tr").find("td").find('.checkbox').prop('checked', false);
		$("#labelListTable tbody tr").find("td").find('.checkbox').prop('checked', false);
		$("#targetListTable tbody tr").find("td").find('.checkbox').prop('checked', false);
		
		$(obj).find('.checkbox').prop('checked', true);
	}
	
	var code = $(obj).find('.checkbox').val();

	if($(obj).find('.checkbox').is(":checked")){
		$("#userListTable tbody tr").find("."+code+"").css("display", "block");
		
		/** 2020.10.29 추가 **/
		$("#labelListTable tbody tr").find("."+code+"").css("display", "block");
		$("#targetListTable tbody tr").find("."+code+"").css("display", "block");
		
		$("#userListTable tbody tr").find("."+code+"").find('.checkbox').prop('checked', true);
		$("#labelListTable tbody tr").find("."+code+"").find('.checkbox').prop('checked', true);
		$("#targetListTable tbody tr").find("."+code+"").find('.checkbox').prop('checked', true);
		
	}else{
		$("#userListTable tbody tr").find("."+code+"").css("display", "none");
		$("#labelListTable tbody tr").find("."+code+"").css("display", "none");
		$("#targetListTable tbody tr").find("."+code+"").css("display", "none");
		
		$("#userListTable tbody tr").find("."+code+"").find('.checkbox').prop('checked', false);
		$("#labelListTable tbody tr").find("."+code+"").find('.checkbox').prop('checked', false);
		$("#targetListTable tbody tr").find("."+code+"").find('.checkbox').prop('checked', false);
	}
	
}

/** 판독자 선택했을 때 이벤트 **/
function getLabelingItem(obj){
//	var code = $(obj).parents().attr('class');
	
//	$("#labelListTable tbody tr").find("."+code+"").css("display", "block");
}

/** 라벨링 선택했을 때 이벤트 **/
function getTargetItem(obj){
//	var code = $(obj).parents().attr('class');
	
//	$("#targetListTable tbody tr").find("."+code+"").css("display", "block");
}

function analysisCheck(){
	
	var project = "";
	var userList = new Array();
	var labelingList = new Array();
	var targetList = new Array();
	
	$("#projectListTable tbody tr").each(function(){
		if($(this).find("td").find('.checkbox').is(':checked')){
			project = $(this).find("td").find('.checkbox').val().trim();
		}
	})
	
	$("#userListTable tbody tr").each(function(){
		if($(this).find("td").find('.checkbox').is(':checked')){
			userList.push($(this).find("td").find('.checkbox').val());
		}
	})
	
	$("#labelListTable tbody tr").each(function(){
		if($(this).find("td").find('.checkbox').is(':checked')){
			labelingList.push($(this).find("td").find('.checkbox').val());
		}
	})
	
	$("#targetListTable tbody tr").each(function(){
		if($(this).find("td").find('.checkbox').is(':checked')){
			targetList.push($(this).find("td").find('.checkbox').val());
		}
	})
	
	if(project == ""){
		alert("프로젝트 선택은 필수 사항입니다.");
		return '';
	}
	if(isEmpty(userList)){
		alert("판독자 선택은 하나 이상 선택이 필수입니다.")
		return '';
	}
	if(isEmpty(labelingList)){
		alert("라벨링 차수 선택은 하나 이상 선택이 필수입니다.")
		return '';
	}
	if(isEmpty(targetList)){
		alert("타겟 선택은 하나 이상 선택이 필수입니다.")
		return '';
	}
	
	var data = new Object();
	data.project_cd = project;
	data.user_list = userList;
	data.order_list = labelingList;
	data.target_list = targetList;
	data.except_null = $("#except_null").val();
	
	return data
	
}

/** 분석 START 이벤트 (단일 프로젝트) **/
function startAnalysis(){
	
	var data = analysisCheck();
	
	if(data == ''){
		return false;
	}
	
	//Reject 건 조회 체크박스 리셋
	$("#grid1_reject_yn").prop('checked', false);
	$("#grid2_reject_yn").prop('checked', false);
	$("#grid1_reject_yn").val('false'); 
	$("#grid2_reject_yn").val('false');
	
	createChart1(data);
	createChart2(data);
	
	$("#grid").jqGrid('clearGridData', true);
	$("#grid2").jqGrid('clearGridData', true); $("#image_id").val("");
	
	gridView();
	
	/*$("#grid_btn span").remove();
	$("#grid_btn").append('<span class="btn_span"><i class="btn btn-download" onclick="gridView();"><a href="javascript:void(0);">크로스체크 리스트 보기</a></i></span>')
	*/
}

/** 그리드 호출 **/
function gridView(){
	
	var data = analysisCheck();
	
	if(data == ''){
		return false;
	}
	
	data.reject_yn = $("#grid1_reject_yn").val();
	
	createGrid(data);
}

/** Reject 건 조회 여부 **/
function reject_view(grid){
	
	var data = analysisCheck();

	if(data == ''){
		return false;
	}
	
	if(grid == 'grid1'){
		data.reject_yn = $("#grid1_reject_yn").val();
		
		createGrid(data);
		
	}else if(grid == 'grid2'){
		data.reject_yn = $("#grid2_reject_yn").val();
		data.image_id = $("#image_id").val();
		
		createGrid2(data);
	}
	
	
}


function exceldown(){
	
	if($("#list_grid1").css("display") == "block"){
		excelDown('Analysis_1', 'grid');
	}else{
		alert("크로스체크 리스트 조회가 되지 않았습니다.");
	}
	
	if($("#list_grid2").css("display") == "block"){
		excelDown('Analysis_2', 'grid2');
	}
	
}

/** grid 2개 이상일 경우**/
/** 다음에 사용 할때에는 hide, show할 컬럼들의 id값을 배열로 받아 처리하자**/
function excelDown(title, grid){
	
	options = {
			  includeLabels : true,
			  includeGroupHeader : true,
			  includeFooter: true,
			  includeHeader: true,
			  fileName : ""+title+".xlsx",
			  mimetype : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
			  maxlength : 40,
			  onBeforeExport : null,
			  replaceStr : null,
			  loadIndicator : true,
			  treeindent : ' '
			}

	if(grid == 'grid'){
		
		$("#"+grid+"").jqGrid("exportToExcel",options);
		
	}else if(grid == 'grid2'){
		
		$("#"+grid+"").jqGrid("hideCol", "이미지보기");
		$("#"+grid+"").jqGrid("hideCol", "원본이미지보기");
		
		$("#"+grid+"").jqGrid("exportToExcel",options);
		
		$("#"+grid+"").jqGrid("showCol", "이미지보기");
		$("#"+grid+"").jqGrid("showCol", "원본이미지보기");
	}
}

function crossChkPopup(image_id){
	var url = "/MLA_VIDEO";
	url += "/analysis.view.do";
	utl += "?image_id="+image_id;
	
	openPopup(url, "800", "600", "POPUP_ANALYSIS_VIEW", "yes", "yes", "");
}



/** 그리드 생성2 **/
function createGrid2(data){
	
	var colNames = [];
	var colModels = [];
	var rows;
	var keys;
	
	$.ajax({
		url : "analysis.crosschk.do",
		async : false,
		dataType : "json",
		type : "POST",
		data : data
	})
	.done(function(jsonData){
		if(jsonData.rows != ''){
			rows = jsonData.rows;
			keys = Object.keys(jsonData.rows[0]);
			
			for(var i = 0; i < keys.length; i++){
				var model = {name:keys[i],index:keys[i],width:150, align:"center"};
				if(keys[i] == "이미지"){
					model.width = 200;
				}else if(/*keys[i] == "이미지보기" || keys[i] == "원본이미지보기" || keys[i] == "라벨링 차수" || */keys[i] == "타겟" || keys[i] == "일치도"){
					model.width = 100;
				}else{
					model.width = 100;
				}
				colModels.push(model);
				colNames.push(keys[i]);
			}
		}else{
			alert("라벨링 작업 데이터가 없습니다.");
			
			colModels.push({name:"이미지",index:"이미지",width:150, align:"center"},{name:"이미지보기",index:"이미지보기",width:150, align:"center"},
						   {name:"라벨링차수",index:"라벨링차수",width:150, align:"center"},{name:"타겟",index:"타겟",width:150, align:"center"},
						   {name:"일치도",index:"일치도",width:150, align:"center"});
		}
		
		
	})
	.fail(function(jqXHR, textStatus, errorThrown){
		var msg="처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";
		
		alert(msg);
	});
	
	$.jgrid.gridUnload("grid2");
	
	$("#grid2").jqGrid({
		data : rows,
		datatype: "local",
		colNames : colNames,
		colModel : colModels,
		rowNum: parseInt($("#page_cnt2").val()),
		rowList: [100,200,300,400,500],
		height: 350,
		loadonce: true,
		autowidth:true,    	 // jQgrid width 자동100% 채워지게
		shrinkToFit:false,  // width를 자동설정 해주는 기능
		gridview: true,
		cmTemplate: { sortable: false, title: false },
		rownumbers  : true,                     
		pager: '#pager2',
		onCellSelect: function(rowId, iCol, cellcontent, e){
			
		},
		ondblClickRow : function(rowId, iRow, iCol, e) {
		},        
		viewrecords: true,
		loadComplete : function(data){
//			$("#grid2").jqGrid("hideCol", "mark");
			$("#grid2").jqGrid("hideCol", "원본이미지보기");
			
			var ids = $("#grid2").getDataIDs();
			
			$.each(ids, function(idx, rowId){
				rowData = $("#grid2").getRowData(rowId);
				
				if(rowData.일치도 == 'X'){
					$("#grid2").setRowData(rowId, false, {background:"#ffc10733"});
				}
			})
			
			$("#list_grid2 .ui-pg-selbox").change(function(){
        		$("#page_cnt2").val($(this).val());
        	})
			
		},
		caption:" "
	})
	
	
	$("#list_grid2").css("display", "block");
	$("#pager2").css("display", "block");
	
//	closeLoadingMask();
	
	delete data.reject_yn;
	
	createChart3(data);
	createChart4(data);
	
}

/** 일치도 차트 생성 **/
function createChart1(data){
	
	var datas = [];
	
	$.ajax({
		url : "analysis.consistency.do",
		async : false,
//		global : false,
		dataType : "json",
		type : "POST",
		data : data
	})
	.done(function(json){
		var rows = json;
		rows = json.rows;
		
		for(var i = 0; i < rows.length; i++){
			datas.push(rows[i].result);
		}
		
	})
	.fail(function(jqXHR, textStatus, errorThrown){
		var msg="처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";
		
		alert(msg);
	});
	
	$("#doughChart1").remove();
	$("#chart1").append('<canvas id="doughChart1"></canvas>');
	
	var canvas = document.getElementById('doughChart1');
	var doughChart = new Chart(canvas, {
		type: 'doughnut',
		data: {
			datasets: [{
				data: datas,
				backgroundColor: [
					'rgba(1, 53, 139, 1)',
					'rgba(17, 145, 208, 1)'
					],
			}],
			labels: [
				'일치('+datas[0]+')',
				'불일치('+datas[1]+')'
				]
		},
		options: {
			legend: {
				position: 'top'
			},
			hover: {
				animationDuration: 0
			},
			title : {
				display : true,
				text : '크로스체크 일치도 수'
			}
//			animation: {
//				onComplete: function () {
//					var ctx = this.chart.ctx;
//					ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontFamily, 'normal', Chart.defaults.global.defaultFontFamily);
//					ctx.textAlign = 'center';
//					ctx.textBaseline = 'bottom';
//					
//					this.data.datasets.forEach(function (dataset) {
//						
//						for (var i = 0; i < dataset.data.length; i++) {
//							var model = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._model,
//							total = dataset._meta[Object.keys(dataset._meta)[0]].total,
//							mid_radius = model.innerRadius + (model.outerRadius - model.innerRadius)/2,
//							start_angle = model.startAngle,
//							end_angle = model.endAngle,
//							mid_angle = start_angle + (end_angle - start_angle)/2;
//							
//							var x = mid_radius * Math.cos(mid_angle);
//							var y = mid_radius * Math.sin(mid_angle);
//							
//							ctx.fillStyle = '#212529';
//							if (i == 3){
//								ctx.fillStyle = '#444';
//							}
//							if(dataset.data[i] != 0 && dataset._meta[0].data[i].hidden != true) {
//								ctx.fillText(dataset.data[i], model.x + x, model.y + y);
//							}
//						}
//					}); 		    
//					
//				}
			
//			}
			
		},
		
		
	});

}

/** 라벨링 작업량 차트 **/
function createChart2(data){
	
	var datas = [];
	
	$.ajax({
		url : "analysis.labeling.do",
		async : false,
		global : false,
		dataType : "json",
		type : "POST",
		data : data
	})
	.done(function(json){
		var rows = json;
		rows = json.rows;
		
		for(var i = 0; i < rows.length; i++){
			datas.push(rows[i].result);
		}
		
	})
	.fail(function(jqXHR, textStatus, errorThrown){
		var msg="처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";
		
		alert(msg);
	});
	
	$("#doughChart2").remove();
	$("#chart2").append('<canvas id="doughChart2"></canvas>');
	
	var canvas = document.getElementById('doughChart2');
	var doughChart = new Chart(canvas, {
		type: 'doughnut',
		data: {
			datasets: [{
				data: datas,
				backgroundColor: [
					'rgba(1, 53, 139, 1)',
					'rgba(17, 145, 208, 1)'
					],
			}],
			labels: [
				'라벨링 완료('+datas[0]+')',
				'라벨링 미완료('+datas[1]+')'
				]
		},
		options: {
			legend: {
				position: 'top'
			},
			hover: {
				animationDuration: 0
			},
			title : {
				display : true,
				text : '현재 라벨링 작업 수'
			}
//			animation: {
//				onComplete: function () {
//					var ctx = this.chart.ctx;
//					ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontFamily, 'normal', Chart.defaults.global.defaultFontFamily);
//					ctx.textAlign = 'center';
//					ctx.textBaseline = 'bottom';
//					
//					this.data.datasets.forEach(function (dataset) {
//						
//						for (var i = 0; i < dataset.data.length; i++) {
//							var model = dataset._meta[Object.keys(dataset._meta)[0]].data[i]._model,
//							total = dataset._meta[Object.keys(dataset._meta)[0]].total,
//							mid_radius = model.innerRadius + (model.outerRadius - model.innerRadius)/2,
//							start_angle = model.startAngle,
//							end_angle = model.endAngle,
//							mid_angle = start_angle + (end_angle - start_angle)/2;
//							
//							var x = mid_radius * Math.cos(mid_angle);
//							var y = mid_radius * Math.sin(mid_angle);
//							
//							ctx.fillStyle = '#212529';
//							if (i == 3){
//								ctx.fillStyle = '#444';
//							}
//							if(dataset.data[i] != 0 && dataset._meta[0].data[i].hidden != true) {
//								ctx.fillText(dataset.data[i], model.x + x, model.y + y);
//							}
//						}
//					}); 		    
//					
//				}
			
//			}
			
		},
		
		
	});
	
}


/** 일치도 차트 생성 **/
function createChart3(data){
	
	var datas = [];
	
	$.ajax({
		url : "analysis.crosschk.consistency.do",
		async : false,
		dataType : "json",
		type : "POST",
		data : data
	})
	.done(function(json){
		var rows = json;
		rows = json.rows;
		
		for(var i = 0; i < rows.length; i++){
			datas.push(rows[i].result);
		}
		
	})
	.fail(function(jqXHR, textStatus, errorThrown){
		var msg="처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";
		
		alert(msg);
	});
	
	$("#doughChart3").remove();
	$("#chart3").append('<canvas id="doughChart3"></canvas>');
	
	var canvas = document.getElementById('doughChart3');
	var doughChart = new Chart(canvas, {
		type: 'doughnut',
		data: {
			datasets: [{
				data: datas,
				backgroundColor: [
					'rgba(1, 53, 139, 1)',
					'rgba(255, 193, 7, 1)'
					],
			}],
			labels: [
				'일치('+datas[0]+')',
				'불일치('+datas[1]+')'
				]
		},
		options: {
			legend: {
				position: 'top'
			},
			hover: {
				animationDuration: 0
			},
			title : {
				display : true,
				text : '크로스체크 일치도 수'
			}
			
		},
		
		
	});

}


/** 라벨링 작업량 차트 **/
function createChart4(data){
	
	var datas = [];
	
	$.ajax({
		url : "analysis.crosschk.labeling.do",
		async : false,
		dataType : "json",
		type : "POST",
		data : data
	})
	.done(function(json){
		var rows = json;
		rows = json.rows;
		
		for(var i = 0; i < rows.length; i++){
			datas.push(rows[i].result);
		}
		
	})
	.fail(function(jqXHR, textStatus, errorThrown){
		var msg="처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";
		
		alert(msg);
	});
	
	$("#doughChart4").remove();
	$("#chart4").append('<canvas id="doughChart4"></canvas>');
	
	var canvas = document.getElementById('doughChart4');
	var doughChart = new Chart(canvas, {
		type: 'doughnut',
		data: {
			datasets: [{
				data: datas,
				backgroundColor: [
					'rgba(1, 53, 139, 1)',
					'rgba(255, 193, 7, 1)'
					],
			}],
			labels: [
				'라벨링 완료('+datas[0]+')',
				'라벨링 미완료('+datas[1]+')'
				]
		},
		options: {
			legend: {
				position: 'top'
			},
			hover: {
				animationDuration: 0
			},
			title : {
				display : true,
				text : '현재 라벨링 작업 수'
			}
			
		},
		
		
	});
	
}


/** 이미지 팝업 **/
function imageView(image_dir, image_org_dir){
	
	var url = "/MLA_VIDEO";
	url += "/image.imageView.do"
	url += "?image_dir="+image_dir;
	url += "&image_org_dir="+image_org_dir;
	
	openPopup(url, "840", "900", "POPUP_IMAGE_VIEW", "yes", "yes", "");
	
}



