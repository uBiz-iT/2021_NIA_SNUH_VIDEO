$(document).ready(function() {
	

	
});

$(function(){

	if($("#image_id").val() != ''){
		var image_id = $("#image_id").val();
		
		createChart1(image_id);
		createChart2(image_id);
		createGrid(image_id);
	}
	
})


function createChart1(image_id){
	
}

function createChart2(image_id){
	
}

function createGrid(image_id){
	
}










