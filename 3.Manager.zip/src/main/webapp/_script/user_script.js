$(document).ready(function() {
	
	$(".input_text").keydown(function(key) {
	    if (key.keyCode == 13) {
	    	$("#search").click();
	    }
	});
	
});

$(function(){
	
	fnSearch();

	$(".ui-pg-selbox").change(function(){
		$("#page_cnt").val($(this).val());
	})
	
})


function userAdd(){
	var rowId = $("#grid").getGridParam("reccount");
	
	var id_text = "<input type='text' class='input_text add_userId' value=''/>";
	var nm_text = "<input type='text' class='input_text add_userNm' value=''/>";
	var pass_text = "<input type='text' class='input_text add_passwd' value=''/>";
	var check = "<input type='checkbox' />"; 
	var rowDel = "<span class='btn_span'><i class='btn btn-minus' onclick='cancer(this);'><a href='javascript:void(0);'>취소</a></i></span>";
	var rowData = {"user_id":id_text, "user_nm":nm_text, "passwd":pass_text, "is_manager":check, "reg_user_id":$("#user_nm").val(), "delete_fg":rowDel};
	
	$("#grid").jqGrid("addRowData", rowId+1, rowData, 'first');
	
}

function cancer(obj){
	$(obj).closest("tr").remove();
}


function userSave(){
	
	var list = [];
	var JsonObject = new Object();
	var grid = $("#grid");
	var rows = grid.jqGrid('getDataIDs');
	
	//신규추가(insert)
	$('#grid .ui-row-ltr').each(function(index, result){
		if($(this).find('td:eq(1)').find('input').hasClass('add_userId')){
			var users = {};
			users.status = 'S';
			users.user_id = $(this).find('td:eq(1)').find('.add_userId').val();
			users.user_nm = $(this).find('td:eq(2)').find('.add_userNm').val();
			users.passwd = $(this).find('td:eq(3)').find('.add_passwd').val();
			if($(this).find('td:eq(4)').find('[type=checkbox]').is(":checked")){
				users.is_manager = 'Y'
			}else{
				users.is_manager = 'N'
			}
			users.delete_fg = 'N';
			
			
			list.push(users);
		
		//기존사용자(update)		
		}else{
			var rowData = grid.jqGrid('getRowData', rows[index]);
			var users = {};
			users.status = 'U';
			users.user_id = rowData['user_id'];
			users.user_nm = $(this).find('td:eq(2)').find('[type=text]').val();
			users.passwd = $(this).find('td:eq(3)').find('[type=text]').val();
			
			if($(this).find('td:eq(4)').find('[type=checkbox]').is(":checked")){
				users.is_manager = 'Y'
			}else{
				users.is_manager = 'N'
			}
			
			if($(this).find('td:eq(6)').find('[type=checkbox]').is(":checked")){
				users.delete_fg = 'Y'
			}else{
				users.delete_fg = 'N'
			}
			
			
			list.push(users);
		}
	})
	
	
	JsonObject.user_list = JSON.stringify(list);
	
	
	$.ajax({
		url : "manage.user.save.do",
		type :"POST",
		async : false,
		dataType : "json",
		data : JsonObject
	})
	.done(function(data){
		
		var msg = data.p_ret_msg;
		var code = data.p_ret_code;
		
		if(code == 0){
			alert('저장 완료 되었습니다.');
			
		}else{
			alert(msg);
			return false;
		}
		
		document.location.reload();
		
	})
	.fail(function(jqXHR, textStatus, errorThrown){
		var msg="처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";
		
		alert(msg);
	});
	
	
}


function fnSearch(){
	
	$("#userId_hid").val($("#userId").val());
	$("#userNm_hid").val($("#userNm").val());
	
	$("#grid").jqGrid({

		url: 'manage.user.search.do',
	    mtype : "POST",
	    datatype: 'json',
	    jsonReader : {
	    	root : "rows"
//	    	records : "pageCnt"
	    },
		postData : {
			userId 	: $('#userId').val(),
			userNm 	: $('#userNm').val()
		},
	    colNames:['검수자 ID','검수자 이름','검수자 비밀번호' ,'관리자 여부' ,'등 록 자','삭제 여부'],
	    colModel:[
	              {name:'user_id'		,index:'user_id'		,width:255		,align:"center"},
	              {name:'user_nm' 		,index:'user_nm'  		,width:255  	,align:"center"},
	              {name:'passwd'		,index:'passwd'			,width:254		,align:"center"},
	              {name:'is_manager' 	,index:'is_manager'    	,width:255  	,align:"center"},
	              {name:'reg_user_id'  	,index:'reg_user_id'  	,width:255  	,align:"center"},
	              {name:'delete_fg' 	,index:'delete_fg'    	,width:255  	,align:"center"}
	             ],
	              
	    rowNum: parseInt($("#page_cnt").val()),
	    rowList: [10,20,30],
	    height: 450,
	    loadonce: true,
	    autowidth:true,    	 // jQgrid width 자동100% 채워지게
	    shrinkToFit:false,  // width를 자동설정 해주는 기능
	    gridview: true,
	    cmTemplate: { sortable: false },
	    rownumbers  : true,                     
	    pager: '#pager',
	    onCellSelect: function(rowid, icol, cellcontent, e){
        	
        },
        viewrecords: true,
        loadComplete : function(data){
        	var total = $("#grid").getGridParam("records");
        	$("#list_num").text(total);
        },
        caption:" "
    	
    });	
	
}


function excelDown(){
	   
   var url = "manage.user.excelDown.do";
   
   var data = new Object();
   data.userId =  $("#userId_hid").val();
   data.userNm =  $("#userNm_hid").val();
   
   $(".loading-image").show();
   
   $.fileDownload(url,{
      httpMethod:"POST",
      data: data,
      successCallback: function (url) {
         $(".loading-image").hide();
      },
      failCallback: function (responseHtml, url, error) {
         $(".loading-image").hide();
      }

   });
   
}