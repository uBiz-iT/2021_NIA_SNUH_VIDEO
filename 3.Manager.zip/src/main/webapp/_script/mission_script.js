$(document).ready(function() {
   
   /** date picker */
   datePicker($("#beg_date"));
   datePicker($("#end_date"));
   
});


$(function(){
   
   fnMissionList();
   fnSearch();
//   weekOnChange();
   monthOnChange();
   changeWeek();
   changeMonth();
   slide();
   
})

/** 엑셀 다운로드 **/
function excelDown(){
   
   var url = "mission.excelDown.do";
   
   var data = new Object();
   
   $(".loading-image").show();
   
   $.fileDownload(url,{
      httpMethod:"POST",
      data: data,
      successCallback: function (url) {
         $(".loading-image").hide();
      },
      failCallback: function (responseHtml, url, error) {
         $(".loading-image").hide();
      }

   });
   
}

function missionSave(){
   
   var params = Object();
   
   params.plan_cnt = $("#plan_cnt").val();
   params.week_base = $('#week_base option:selected').val();
   params.pass_rate = $("#pass_rate").val();
   params.pass_cnt_rate = $("#pass_cnt_rate").val();
   params.beg_date = $("#beg_date").val();
   params.end_date = $("#end_date").val();
   
   $.ajax({
      url : "manage.mission.save.do",
      type :"POST",
      async : false,
      dataType : "json",
      data : params
   })
   .done(function(data){
      
      var msg = data.p_ret_msg;
      var code = data.p_ret_code;
      
      if(code == 0){
         alert('저장 완료 되었습니다.');
         
      }else{
         alert(msg);
         return false;
      }
      
      document.location.reload();
      
   })
   .fail(function(jqXHR, textStatus, errorThrown){
      var msg="처리에 실패 하였습니다.";
      msg += "\n관리자에게 문의 하세요.";
      
      alert(msg);
   });
}

function fnMissionList(){
   
   var url = "manage.missionList.do";
   
   var data = new Object();
   
   var async = false;
   
   callAjax(url, data, async, function(json){
      var row = json.rows;
      var sum = json.sums;
      
      $("#week_base").val(row[0].week_base).prop("selected", true);
      $("#pass_rate").val(row[0].pass_rate);
      $("#pass_cnt_rate").val(row[0].pass_cnt_rate);
      $("#beg_date").val(row[0].beg_date);
      $("#end_date").val(row[0].end_date);
      $("#plan_cnt").val(row[0].plan_cnt);
      
      $("#psg_sum").text(sum[0].psgSum);
      $("#work_sum").text(sum[0].workSum);
      $("#same_sum").text(sum[0].sameSum);
      $("#pass_sum").text(sum[0].passSum);
      $("#event_sum").text(sum[0].eventSum);
      $("#event_work_sum").text(sum[0].eventWorkSum);
      $("#event_ok_sum").text(sum[0].eventOkSum);
      $("#event_ng_sum").text(sum[0].eventNgSum);
   });
   
}

function fnSearch(){
   
   $("#grid").jqGrid({

      url: 'manage.mission.progress.do',
       mtype : "POST",
       datatype: 'json',
       jsonReader : {
          root : "rows",
       },
      postData : {
      },
       colNames:['기준 일자','PSG 등록 수량','PSG 검수 완료 수량','PSG 검수 일치 수량','일치 건 중 PASS 수량','이벤트 등록 수량','이벤트 검수 완료 수량','이벤트 완료 건 중 OK 수량 ','이벤트 완료 건 중 NG 수량'],
       colModel:[
                 {name:'base_date'       ,index:'base_date'           ,width:170      ,align:"center"},
                 {name:'psg_cnt'       ,index:'psg_cnt'          ,width:168      ,align:"center"},
                 {name:'work_cnt'     ,index:'work_cnt'           ,width:168       ,align:"center"},
                 {name:'same_cnt'       ,index:'same_cnt'          ,width:168     ,align:"center"},
                 {name:'pass_cnt'     ,index:'pass_cnt'         ,width:168     ,align:"center"},
                 {name:'event_cnt'     ,index:'event_cnt'        ,width:168       ,align:"center"},
                 {name:'event_work_cnt',index:'event_work_cnt'      ,width:168      ,align:"center"},
                 {name:'event_ok_cnt'  ,index:'event_ok_cnt'         ,width:168       ,align:"center"},
                 {name:'event_ng_cnt'   ,index:'event_ng_cnt'      ,width:168      ,align:"center"},
                ],
                 
       rowNum: parseInt($("#page_cnt").val()),
       rowList: [10,20,30],
//       height: 300,
       loadonce: true,
       autowidth:true,        // jQgrid width 자동100% 채워지게
       shrinkToFit:false,  // width를 자동설정 해주는 기능
       gridview: true,
       cmTemplate: { sortable: false },
       rownumbers  : true,                     
       pager: '#pager',
       onCellSelect: function(rowid, icol, cellcontent, e){
           
        },
        
        viewrecords: true,
        loadComplete : function(data){
           var total = $("#grid").getGridParam("records");
           $("#list_num").text(total);
           
           if(total < 10){
        	   $(".ui-jqgrid-bdiv").css("height", "200px");
        	   $(".ui-jqgrid-bdiv").css("margin-bottom", "20px");
           }else{
        	   $(".ui-jqgrid-bdiv").css("height", "400px");
           }
        },
        caption:" "
       
    });   

}


function weekOnChange(){
   
   if($("#select1").length > 0){
      $("#select1").remove();
   }
   
   var html = '';
   html += "<select class='selectbox' id='select1' onchange='changeWeek()' style='width:100px'>";
   
   var date = new Date();
   var today = date.getMonth() + 1;
   
   for(var i = 1; i <= 12; i++ ){
      if(i == today){
         html += "<option value='0"+i+"' selected>"+i+" 월</option>";
      }else if(i < 10){
         html += "<option value='0"+i+"'>"+i+" 월</option>";
      }else{
         html += "<option value='"+i+"'>"+i+" 월</option>";
      }
   }
   
   html += "</select>";
   
   $("#select_span").append(html);

   changeWeek();
   
}

function monthOnChange(){
   
   if($("#select2").length > 0){
      $("#select2").remove();
   }
   
   var html = '';
   html += "<select class='selectbox' id='select2' onchange='changeMonth()' style='width:100px'>";
   
   var date = new Date();
   var year = date.getFullYear();
   var month = date.getMonth();
   
   for (i = 2021; i <= year; i++) {
      html += "<option value='" + i + "' ";
      if (i == year-1 && month <2 ) {
         html += "selected";
      }else if(i == year && month>=2){
         html += "selected";
      }
      html += ">" + i + "년도</option>";
   }
   
//   html += "<option value='2021'>2021 년도</option>";
   
   html += "</select>";
   
   $("#select_span2").append(html);

   changeMonth();
   
}

function fnWeekChart(jsondata){
   
   var labels = [];
   var psg_cnt = [];
   var work_cnt = [];
   var pass_cnt = [];
   
   
   $.ajax({
      url : "main.weekMonth.chart.do",
      type : "post",
      dataType : "json",
      data : jsondata,
      async : false
   })
   .done(function(json){
      var rows = json;
      rows = json.rows;
      
      for(var i = 0; i < rows.length; i++){
         if(rows[i].wm == 'W'){
            labels.push(rows[i].week_of_month + '주차(' + rows[i].week_start + '~' + rows[i].week_end + ')');
         }else{
            labels.push(rows[i].month + '월');
         }
         
         psg_cnt.push(rows[i].psg_cnt);
         work_cnt.push(rows[i].work_cnt);
         pass_cnt.push(rows[i].pass_cnt);
      }
      
   })
   
   
   $("#chart1").remove();
   $("#div_chart1").append('<canvas id="chart1"></canvas>');
   
   var ctx = document.getElementById("chart1").getContext("2d");
   
   var gradientStroke = ctx.createLinearGradient(100, 0, 800, 0);
   gradientStroke.addColorStop(0, '#80b6f4');
   gradientStroke.addColorStop(0.5, '#f7e28f');
   gradientStroke.addColorStop(1, '#e27a6e');
   
   const data = {
      labels: labels,
      datasets: [
         {
            label: 'PSG 등록 수량',
            data: psg_cnt,
            borderColor: "rgba(251,217,79,1)",
            backgroundColor: "rgba(251,217,79,0.4)",
            fill: false,
            borderWidth: 2,
            tension: 0
         },
         {
            label: 'PSG 검수 완료 수량',
            data: work_cnt,
            borderColor: "rgba(35,84,131,1)",
            backgroundColor: "rgba(35,84,131,0.4)",
            fill: false,
            borderWidth: 2,
            tension: 0
         },
         {
            label: '일치 건 중 PASS 수량',
            data: pass_cnt,
            borderColor: "rgba(156,41,150,1)",
            backgroundColor: "rgba(156,41,150,0.4)",
            fill: false,
            borderWidth: 2,
            tension: 0
         }
         
      ]
   }
   
   const config = {
      type: 'bar',
      data: data,
      options: {
         legend: {
            labels: {
               fontFamily : 'NanumGothic',
               fontColor: '#000',
               fontStyle: 'bold'
            }
         },
         scales: {
            yAxes: [{
               ticks:{
                  max: 100,
                  min: 0,
                  stepSize: 20
               }
            }]
         },
           tooltips:{
              titleFontFamily: 'NanumGothic',
              callbacks:{
                 label : function(tooltipItem, data){
                    var label = data.datasets[tooltipItem.datasetIndex].label || '';
                    
                    if (label) {
                           label += ' : ';
                       }
                    
                    label += data.datasets[tooltipItem.datasetIndex]['data'][tooltipItem['index']] + " 건";
                    
                    return label;
                 }
              }
           }
      }
   }
   
   var chart = new Chart(ctx, config);
   
}

function fnMonthChart(jsondata){
   
   var labels = [];
   var psg_cnt = [];
   var work_cnt = [];
   var pass_cnt = [];
   
   
   $.ajax({
      url : "main.weekMonth.chart.do",
      type : "post",
      dataType : "json",
      data : jsondata,
      async : false
   })
   .done(function(json){
      var rows = json;
      rows = json.rows;
      
      for(var i = 0; i < rows.length; i++){
         if(rows[i].wm == 'W'){
            labels.push(rows[i].week_of_month + '주차(' + rows[i].week_start + '~' + rows[i].week_end + ')');
         }else{
            labels.push(rows[i].month + '월');
         }
         
         psg_cnt.push(rows[i].psg_cnt);
         work_cnt.push(rows[i].work_cnt);
         pass_cnt.push(rows[i].pass_cnt);
      }
      
   })
   
   
   $("#chart2").remove();
   $("#div_chart2").append('<canvas id="chart2"></canvas>');
   
   var ctx = document.getElementById("chart2").getContext("2d");
   
   var gradientStroke = ctx.createLinearGradient(100, 0, 800, 0);
   gradientStroke.addColorStop(0, '#80b6f4');
   gradientStroke.addColorStop(0.5, '#f7e28f');
   gradientStroke.addColorStop(1, '#e27a6e');
   
   const data = {
         labels: labels,
         datasets: [
            {
               label: 'PSG 등록 수량',
               data: psg_cnt,
               borderColor: "rgba(251,217,79,1)",
               backgroundColor: "rgba(251,217,79,0.4)",
               fill: false,
               borderWidth: 2,
               tension: 0
            },
            {
               label: 'PSG 검수 완료 수량',
               data: work_cnt,
               borderColor: "rgba(35,84,131,1)",
               backgroundColor: "rgba(35,84,131,0.4)",
               fill: false,
               borderWidth: 2,
               tension: 0
            },
            {
               label: '일치 건 중 PASS 수량',
               data: pass_cnt,
               borderColor: "rgba(156,41,150,1)",
               backgroundColor: "rgba(156,41,150,0.4)",
               fill: false,
               borderWidth: 2,
               tension: 0
            }
            
            ]
   }
   
   const config = {
         type: 'bar',
         data: data,
         options: {
            legend: {
               labels: {
                  fontFamily : 'NanumGothic',
                  fontColor: '#000',
                  fontStyle: 'bold'
               }
            },
            scales: {
               yAxes: [{
                  ticks:{
                     max: 100,
                     min: 0,
                     stepSize: 20
                  }
               }]
            },
            tooltips:{
               titleFontFamily: 'NanumGothic',
               callbacks:{
                  label : function(tooltipItem, data){
                     var label = data.datasets[tooltipItem.datasetIndex].label || '';
                     
                     if (label) {
                        label += ' : ';
                     }
                     
                     label += data.datasets[tooltipItem.datasetIndex]['data'][tooltipItem['index']] + " 건";
                     
                     return label;
                  }
               }
            }
         }
   }
   
   var chart = new Chart(ctx, config);
   
}

function fnWeekAcmChart(jsondata){
   
   var labels = [];
   var psg_cnt = [];
   var work_cnt = [];
   var pass_cnt = [];
   
   
   $.ajax({
      url : "mission.wmAcm.chart.do",
      type : "post",
      dataType : "json",
      data : jsondata,
      async : false
   })
   .done(function(json){
      var rows = json;
      rows = json.rows;
      
      for(var i = 0; i < rows.length; i++){
         if(rows[i].wm == 'W'){
            labels.push(rows[i].week_of_month + '주차(' + rows[i].week_start + '~' + rows[i].week_end + ')');
         }else{
            labels.push(rows[i].month + '월');
         }
         
         psg_cnt.push(rows[i].psg_cnt);
         work_cnt.push(rows[i].work_cnt);
         pass_cnt.push(rows[i].pass_cnt);
      }
      
   })
   
   
   $("#chart3").remove();
   $("#div_chart3").append('<canvas id="chart3"></canvas>');
   
   var ctx = document.getElementById("chart3").getContext("2d");
   
   var gradientStroke = ctx.createLinearGradient(100, 0, 800, 0);
   gradientStroke.addColorStop(0, '#80b6f4');
   gradientStroke.addColorStop(0.5, '#f7e28f');
   gradientStroke.addColorStop(1, '#e27a6e');
   
   const data = {
      labels: labels,
      datasets: [
         {
            label: 'PSG 등록 수량',
            data: psg_cnt,
            borderColor: "rgba(251,217,79,1)",
            backgroundColor: "rgba(251,217,79,0.4)",
            fill: false,
            borderWidth: 2,
            tension: 0
         },
         {
            label: 'PSG 검수 완료 수량',
            data: work_cnt,
            borderColor: "rgba(35,84,131,1)",
            backgroundColor: "rgba(35,84,131,0.4)",
            fill: false,
            borderWidth: 2,
            tension: 0
         },
         {
            label: '일치 건 중 PASS 수량',
            data: pass_cnt,
            borderColor: "rgba(156,41,150,1)",
            backgroundColor: "rgba(156,41,150,0.4)",
            fill: false,
            borderWidth: 2,
            tension: 0
         }
         
      ]
   }
   
   const config = {
      type: 'line',
      data: data,
      options: {
         legend: {
            labels: {
               fontFamily : 'NanumGothic',
               fontColor: '#000',
               fontStyle: 'bold'
            }
         },
         scales: {
            yAxes: [{
               ticks:{
                  max: 100,
                  min: 0,
                  stepSize: 20
               }
            }]
         },
           tooltips:{
              titleFontFamily: 'NanumGothic',
              callbacks:{
                 label : function(tooltipItem, data){
                    var label = data.datasets[tooltipItem.datasetIndex].label || '';
                    
                    if (label) {
                           label += ' : ';
                       }
                    
                    label += data.datasets[tooltipItem.datasetIndex]['data'][tooltipItem['index']] + " 건";
                    
                    return label;
                 }
              }
           }
      }
   }
   
   var chart = new Chart(ctx, config);
   
}

function fnMonthAcmChart(jsondata){
   
   var labels = [];
   var psg_cnt = [];
   var work_cnt = [];
   var pass_cnt = [];
   
   
   $.ajax({
      url : "mission.wmAcm.chart.do",
      type : "post",
      dataType : "json",
      data : jsondata,
      async : false
   })
   .done(function(json){
      var rows = json;
      rows = json.rows;
      
      for(var i = 0; i < rows.length; i++){
         if(rows[i].wm == 'W'){
            labels.push(rows[i].week_of_month + '주차(' + rows[i].week_start + '~' + rows[i].week_end + ')');
         }else{
            labels.push(rows[i].month + '월');
         }
         
         psg_cnt.push(rows[i].psg_cnt);
         work_cnt.push(rows[i].work_cnt);
         pass_cnt.push(rows[i].pass_cnt);
      }
      
   })
   
   
   $("#chart4").remove();
   $("#div_chart4").append('<canvas id="chart4"></canvas>');
   
   var ctx = document.getElementById("chart4").getContext("2d");
   
   var gradientStroke = ctx.createLinearGradient(100, 0, 800, 0);
   gradientStroke.addColorStop(0, '#80b6f4');
   gradientStroke.addColorStop(0.5, '#f7e28f');
   gradientStroke.addColorStop(1, '#e27a6e');
   
   const data = {
         labels: labels,
         datasets: [
            {
               label: 'PSG 등록 수량',
               data: psg_cnt,
               borderColor: "rgba(251,217,79,1)",
               backgroundColor: "rgba(251,217,79,0.4)",
               fill: false,
               borderWidth: 2,
               tension: 0
            },
            {
               label: 'PSG 검수 완료 수량',
               data: work_cnt,
               borderColor: "rgba(35,84,131,1)",
               backgroundColor: "rgba(35,84,131,0.4)",
               fill: false,
               borderWidth: 2,
               tension: 0
            },
            {
               label: '일치 건 중 PASS 수량',
               data: pass_cnt,
               borderColor: "rgba(156,41,150,1)",
               backgroundColor: "rgba(156,41,150,0.4)",
               fill: false,
               borderWidth: 2,
               tension: 0
            }
            
            ]
   }
   
   const config = {
         type: 'line',
         data: data,
         options: {
            legend: {
               labels: {
                  fontFamily : 'NanumGothic',
                  fontColor: '#000',
                  fontStyle: 'bold'
               }
            },
            scales: {
               yAxes: [{
                  ticks:{
                     max: 100,
                     min: 0,
                     stepSize: 20
                  }
               }]
            },
            tooltips:{
               titleFontFamily: 'NanumGothic',
               callbacks:{
                  label : function(tooltipItem, data){
                     var label = data.datasets[tooltipItem.datasetIndex].label || '';
                     
                     if (label) {
                        label += ' : ';
                     }
                     
                     label += data.datasets[tooltipItem.datasetIndex]['data'][tooltipItem['index']] + " 건";
                     
                     return label;
                  }
               }
            }
         }
   }
   
   var chart = new Chart(ctx, config);
   
}


function changeWeek(i){
   var jsondata = new Object();
   
   jsondata.wm = 'W';
   jsondata.wmVal = i;
   
   fnWeekChart(jsondata);
   fnWeekAcmChart(jsondata);
}

function changeMonth(){
   var jsondata = new Object();   
   
   jsondata.wm = 'M';
   jsondata.wmVal = $('#select2 option:selected').val();
   
   fnMonthChart(jsondata);
   fnMonthAcmChart(jsondata);
}


function slide() {
    const slideList = document.querySelector(".slide_list"); // Slide parent dom
    
    const slideBtnNext = document.querySelector(".slide_btn_next"); // next button
    const slideBtnPrev = document.querySelector(".slide_btn_prev"); // prev button
//    const pagination = document.querySelector(".slide_pagination"); 
    const slideWidth = 50; // slide width
    const slideSpeed = 300; // slide speed
    
    var date = new Date();
   var today = date.getMonth();
   
    

    // Add slides
       let slideChild = "";
       for (var i = 1; i < 13; i++) {
           slideChild += '<div class="slide_content';
           
//           slideChild += i === today+1 ? " slide_active" : "";
           slideChild += '" value="';
           if(i<10){
              slideChild += "0"+ i ; 
           }else{
              slideChild += ""+ i ; 
           }        
           slideChild += '"><p>'+i+'월</p></div>';
       }
       slideList.innerHTML = slideChild;
    const slideContents = document.querySelectorAll(".slide_content"); // each slide dom    
   const slideLen = slideContents.length; // slide length
    slideList.style.width = slideWidth * (slideLen + 2) + "px";

    // Copy first and last slide
    let firstChild = slideList.firstElementChild;
    let lastChild = slideList.lastElementChild;
    let clonedFirst = firstChild.cloneNode(true);
    let clonedLast = lastChild.cloneNode(true);

    // Add copied Slides
    slideList.appendChild(clonedFirst);
    slideList.insertBefore(clonedLast, slideList.firstElementChild);

    
//    const pageDots = document.querySelectorAll(".dot"); // each dot from pagination

    slideList.style.transform =
        "translate3d(-" + slideWidth * (today + 1) + "px, 0px, 0px)";

    let curIndex = today; // current slide index (except copied slide)
    let curSlide = slideContents[curIndex]; // current slide dom
    curSlide.classList.add("slide_active");
    changeWeek($('.slide_active').attr("value"));
    
    /** Next Button Event */
    slideBtnNext.addEventListener("click", function () {
        if (curIndex <= slideLen - 1) {
            slideList.style.transition = slideSpeed + "ms";
            slideList.style.transform =
                "translate3d(-" + slideWidth * (curIndex + 2) + "px, 0px, 0px)";
        }
        if (curIndex === slideLen - 1) {
            setTimeout(function () {
                slideList.style.transition = "0ms";
                slideList.style.transform =
                    "translate3d(-" + slideWidth + "px, 0px, 0px)";
            }, slideSpeed);
            curIndex = -1;
        }
        curSlide.classList.remove("slide_active");
        curSlide = slideContents[++curIndex];
        curSlide.classList.add("slide_active");
        changeWeek($('.slide_active').attr("value"));
    });

    /** Prev Button Event */
    slideBtnPrev.addEventListener("click", function () {
        if (curIndex >= 0) {
            slideList.style.transition = slideSpeed + "ms";
            slideList.style.transform =
                "translate3d(-" + slideWidth * curIndex + "px, 0px, 0px)";
        }
        if (curIndex === 0) {
            setTimeout(function () {
                slideList.style.transition = "0ms";
                slideList.style.transform =
                    "translate3d(-" + slideWidth * slideLen + "px, 0px, 0px)";
            }, slideSpeed);
            curIndex = slideLen;
        }
        curSlide.classList.remove("slide_active");
        curSlide = slideContents[--curIndex];
        curSlide.classList.add("slide_active");
        
//        console.log($('.slide_active').attr("value"));
        changeWeek($('.slide_active').attr("value"));
       
       

    });

    
    
    
    
}



