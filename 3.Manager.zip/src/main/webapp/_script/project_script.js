$(document).ready(function() {
	
	$(".input_text").keydown(function(key) {
	    if (key.keyCode == 13) {
	    	$("#search").click();
	    }
	});
	
});

$(function(){
	
	fnSearch();

	$(".ui-pg-selbox").change(function(){
		$("#page_cnt").val($(this).val());
	})
	
})

function popupView(val){
	
	var url = "/MLA_VIDEO";
	url += "/project.view.do"
	url += "?project_cd="+val;
	
	openPopup(url, "1024", "500", "POPUP_PROJECT_VIEW", "yes", "yes", "");
	
}


function projectAdd(){
	
	var url = "/MLA_VIDEO";
	url += "/project.write.do";
		
	openPopup(url, "1024", "500", "POPUP_PROJECT_WRITE", "yes", "yes", "");
}


function fnSearch(){
	
	$("#project_cd_hid").val($('#project_cd').val());
	$("#project_nm_hid").val($('#project_nm').val());
	$("#complete_yn_hid").val($('#complete_yn option:selected').val());
	$("#delete_fg_hid").val($('#delete_fg option:selected').val());	
	
	$("#grid").jqGrid({

		url: 'project.search.do',
	    mtype : "POST",
	    datatype: 'json',
	    jsonReader : {
	    	root : "rows",
	    },
		postData : {
			project_cd 		: $('#project_cd').val(),
			project_nm 		: $('#project_nm').val(),
			complete_yn 	: $('#complete_yn option:selected').val(),
			delete_fg 		: $('#delete_fg option:selected').val(),
		},
	    colNames:['프로젝트 코드','프로젝트명','검수 인원','데이터 디렉토리','PSG검사 등록 건 수','이벤트 총 등록 건 수','PSG검사 등록 일자','프로젝트 완료 여부','프로젝트 등록 일자','프로젝트 등록자','삭제 여부'],
	    colModel:[
	              {name:'project_cd'	 	,index:'project_cd'	 	 	,width:120		,align:"center"},
	              {name:'project_nm'	 	,index:'project_nm'	 		,width:265		,align:"left"},
	              {name:'project_user_cnt'  ,index:'project_user_cnt'  	,width:90 		,align:"center"},
	              {name:'data_dir'  		,index:'data_dir'  			,width:150 		,align:"left"},
	              {name:'psg_cnt' 			,index:'psg_cnt'    		,width:130  	,align:"center"},
	              {name:'event_cnt'  		,index:'event_cnt'   		,width:130  	,align:"center"},
	              {name:'psg_reg_date'		,index:'psg_reg_date'		,width:130		,align:"center"},
	              {name:'complete_yn'  	 	,index:'complete_yn'  	 	,width:130 		,align:"center"},
	              {name:'reg_dt'		 	,index:'reg_dt'		 	 	,width:130		,align:"center"},
	              {name:'reg_user_id'  	 	,index:'reg_user_id'  	 	,width:130  	,align:"center"},
	              {name:'delete_fg'  	 	,index:'delete_fg'  	 	,width:100  	,align:"center"}
	             ],
	              
	    rowNum: parseInt($("#page_cnt").val()),
	    rowList: [10,20,30],
	    height: 400,
	    loadonce: true,
	    autowidth:true,    	 // jQgrid width 자동100% 채워지게
	    shrinkToFit:false,  // width를 자동설정 해주는 기능
	    gridview: true,
	    cmTemplate: { sortable: false },
	    rownumbers  : true,                     
	    pager: '#pager',
	    onCellSelect: function(rowid, icol, cellcontent, e){
        	var rowData = $(this).jqGrid("getRowData", rowid);
        	
        	popupView(rowData.project_cd);
        },
        
        viewrecords: true,
        loadComplete : function(data){
        	var total = $("#grid").getGridParam("records");
        	$("#list_num").text(total);
        },
        caption:" "
    	
    });	

}

function excelDown(){
	   
   var url = "project.excelDown.do";
   
   var data = new Object();
   data.project_cd 	= $('#project_cd_hid').val();
   data.project_nm 	= $('#project_nm_hid').val();
   data.complete_yn = $('#complete_yn_hid').val();
   data.delete_fg 	= $('#delete_fg_hid').val();
   
   $(".loading-image").show();
   
   $.fileDownload(url,{
      httpMethod:"POST",
      data: data,
      successCallback: function (url) {
         $(".loading-image").hide();
      },
      failCallback: function (responseHtml, url, error) {
         $(".loading-image").hide();
      }

   });
   
}


