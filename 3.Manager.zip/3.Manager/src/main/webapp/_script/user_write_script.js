$(document).ready(function() {
	
});

$(function(){
	
})

function fnSaveData(){
	
	var bool = validation('');
	if(!bool){
		return false;
	}

	var JsonObject = new Object();
	
	JsonObject.userId = $("#userId").val();
	JsonObject.userName = $("#userName").val();
	JsonObject.deleteYn = $("#deleteYn option:selected").val();
	JsonObject.isManager = $("#isManager option:selected").val();
	
	
	$.ajax({
		url : "user.write.insert.do",
		type :"POST",
		async : false,
		dataType : "json",
		data : JsonObject
	})
	.done(function(data){
		
		var msg = data.p_ret_msg;
		var code = data.p_ret_code;
		
		if(code == -1){
			alert(msg);
			return false;
		}else{
			alert(msg);
		}
		
		self.close();
	})
	.fail(function(jqXHR, textStatus, errorThrown){
		var msg="처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";
		
		alert(msg);
	});
	
}


function fnUpdateData(update_yn){
	
	var msg = confirm("현재 작업중인 사용자를 변경할 경우\n작업에 문제가 발생할 수 있습니다. 반드시 확인 후 변경해주세요!");
	if(msg){
	
		var bool = validation(update_yn);
		if(!bool){
			return false;
		}

		if($("#password").val() == ''){
			alert("비밀번호 입력은 필수입니다.");
			$("#password").focus();
			return false;
		}
		
		var JsonObject = new Object();
		
		JsonObject.userId = $("#userId").val();
		JsonObject.userName = $("#userName").val();
		JsonObject.deleteYn = $("#deleteYn option:selected").val();
		JsonObject.isManager = $("#isManager option:selected").val();
		JsonObject.password = $("#password").val();
		
		
		$.ajax({
			url : "user.write.update.do",
			type :"POST",
			async : false,
			dataType : "json",
			data : JsonObject
		})
		.done(function(data){
			var msg = data.p_ret_msg;
			var code = data.p_ret_code;
			
			if(code == -1){
				alert(msg);
				return false;
			}else{
				alert(msg);
			}
			
			self.close();
		})
		.fail(function(jqXHR, textStatus, errorThrown){
			var msg="처리에 실패 하였습니다.";
			msg += "\n관리자에게 문의 하세요.";
			
			alert(msg);
		});
	
	}else{
	    return false;
	}
}


function validation(update_yn){
	
	if(update_yn == 'Y'){
		
	}else{
		if($("#userId").val() == ""){
			alert("사용자 아이디는 필수 입력 사항입니다.");
			$("#userId").focus();
			return false;
		}
		
	}
	
	if($("#userName").val() == ""){
		alert("사용자 이름은 필수 입력 사항입니다.");
		$("#userName").focus();
		return false;
	}
	
	return true;
	
}









