$(document).ready(function() {
	
});

$(function(){
	
	fnSearch();

	$(".ui-pg-selbox").change(function(){
		$("#page_cnt").val($(this).val());
	})
	
})

function eventType(){
		
	var url = "/MLA_VIDEO";
	url += "/psg.eventType.do";
	
	openPopup(url, "600", "500", "POPUP_PSG_EVENT", "yes", "yes", "");
		
}


/** 이벤트 추가 **/
function eventAdd(){
	
	var select = "<select class='select'>";
	
	$.ajax({
		url : "psg.eventTpList.do",
		type :"POST",
		async : false,
		dataType : "json"
	})
	.done(function(json){
		var row = json.rows;
		
		for(var i = 0; i < row.length; i++){
			select += "<option value='"+row[i].eventTp+"'>"+row[i].eventTpNm+"</option>";
		}
		
	})
	.fail(function(jqXHR, textStatus, errorThrown){
		var msg="처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";
		
		alert(msg);
	});
	
	select += "</select>";
	
	var rowId = $("#grid").getGridParam("reccount");
	
	var text = "<input type='text' class='input_text add_event' value=''/>";
	var rowDel = "<span class='btn_span'><i class='btn btn-minus' onclick='cancer(this);'><a href='javascript:void(0);'>취소</a></i></span>";
	var rowData = {"event_tp":text, "use_yn":rowDel, "event_tp_nm":select, "event_nm":text, "event_note":text};
	
	$("#grid").jqGrid("addRowData", rowId+1, rowData, 'first');
	
}

/** 취소 이벤트 **/
function cancer(obj){
	$(obj).closest("tr").remove();
}

/** 이벤트 사용 여부 변경 저장 **/
function eventSave(){
	
	var list = [];
	var JsonObject = new Object();
	var grid = $("#grid");
	var rows = grid.jqGrid('getDataIDs');
	
	//신규추가(insert)
	$('#grid .ui-row-ltr').each(function(index, result){
		if($(this).find('td:eq(1)').find('input').hasClass('add_event')){
			var events = {};
			events.status = 'S';
			events.event_tp = $(this).find('td:eq(3)').find('select option:selected').val();
			events.use_yn = 'Y';
			events.event_nm = $(this).find('td:eq(4)').find('.add_event').val();
			events.event_note = $(this).find('td:eq(5)').find('.add_event').val();
				
			list.push(events);
			
		//기존사용자(update)
		}else{
			var rowData = grid.jqGrid('getRowData', rows[index]);
			var events = {};
			events.status = 'U';
			events.event_tp = rowData['event_tp'];
			if($(this).find('td:eq(2)').find('[type=checkbox]').is(":checked")){
				events.use_yn = 'Y'
			}else{
				events.use_yn = 'N'
			}
			events.event_nm = rowData['event_nm'];
			events.event_note = $(this).find('td:eq(5)').find('[type=text]').val();
			
			list.push(events);
		}
	})
	
//	$('[type=checkbox]').each(function(index, result){
//		if(!result.checked){
//			var rowData = grid.jqGrid('getRowData', rows[index]);
//			list.push(rowData['event_nm']);
//		}
//	});
	
	JsonObject.event_list = JSON.stringify(list);
	
	
	$.ajax({
		url : "psg.event.update.do",
		type :"POST",
		async : false,
		dataType : "json",
		data : JsonObject
	})
	.done(function(data){
		
		var msg = data.p_ret_msg;
		var code = data.p_ret_code;
		
		if(code == 0){
			alert('저장 완료 되었습니다.');
			
		}else{
			alert(msg);
			return false;
		}
		
		document.location.reload();
		
	})
	.fail(function(jqXHR, textStatus, errorThrown){
		var msg="처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";
		
		alert(msg);
	});
}


function fnSearch(){
	
	$("#grid").jqGrid({

		url: 'psg.event.search.do',
	    mtype : "POST",
	    datatype: 'json',
	    jsonReader : {
	    	root : "rows",
	    },
		postData : {
			event_tp : $('#event_tp').val(),
			event_nm : $('#event_nm').val()
		},
	    colNames:['이벤트 타입', '이벤트 사용 여부', '이벤트 타입(TYPE)', '이벤트명(NAME)', '이벤트 의미'],
	    colModel:[
	              {name:'event_tp'	 		,index:'event_tp'	 		,width:100		,align:"center"},
	              {name:'use_yn' 			,index:'use_yn'    			,width:385  	,align:"center"},
	              {name:'event_tp_nm'	 	,index:'event_tp_nm'	 	,width:385		,align:"center"},
	              {name:'event_nm'  		,index:'event_nm'  			,width:385 		,align:"center"},
	              {name:'event_note'  		,index:'event_note'  		,width:385 		,align:"center"},
	             ],
	              
	    rowNum: 100,
	    rowList: [30,50,100],
	    height: 600,
	    loadonce: true,
	    autowidth:true,    	 // jQgrid width 자동100% 채워지게
	    shrinkToFit:false,  // width를 자동설정 해주는 기능
	    gridview: true,
	    cmTemplate: { sortable: false },
	    rownumbers  : true,                     
	    pager: '#pager',
//	    multiselect:true,
	    onCellSelect: function(rowid, icol, cellcontent, e){

	    },
        
        viewrecords: true,
        loadComplete : function(data){
        	$("#grid").jqGrid("hideCol", "event_tp");
        	
        	var total = $("#grid").getGridParam("records");
        	$("#list_num").text(total);
        },
        caption:" "
    	
    });	

}

/** 엑셀 다운로드 **/
function excelDown(){
   
   var url = "psg.event.excelDown.do";
   
   var data = new Object();
   
   $(".loading-image").show();
   
   $.fileDownload(url,{
      httpMethod:"POST",
      data: data,
      successCallback: function (url) {
         $(".loading-image").hide();
      },
      failCallback: function (responseHtml, url, error) {
         $(".loading-image").hide();
      }

   });
   
}


