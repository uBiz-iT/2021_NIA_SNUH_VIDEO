$(document).ready(function() {
   
   
});

$(function(){
   
   fnTotalSearch();   //psg, work, pass, fail
   fnSubSearch();
   
})

/** 엑셀 다운로드 **/
function excelDown(project_cd){
   
   var url = "progress.project.excelDown.do";
   
   var data = new Object();
   data.project_cd = project_cd;
   
   $(".loading-image").show();
   
   $.fileDownload(url,{
      httpMethod:"POST",
      data: data,
      successCallback: function (url) {
         $(".loading-image").hide();
      },
      failCallback: function (responseHtml, url, error) {
         $(".loading-image").hide();
      }

   });
   
}

/** 프로젝트 단위 진행률에서 쓰는 엑셀 다운로드 **/
function exDownSelect(){
   
   var exDownVal = $("#exDownSelect").val();
   
   var data = new Object();
   data.project_cd  = $('#project_cd_hid').val();
   data.complete_yn = $('#complete_yn_hid').val();
   
   if(exDownVal == '1'){
      
	  var url = "progress.project.list.excelDown.do";
      
      $(".loading-image").show();
      
      $.fileDownload(url,{
         httpMethod:"POST",
         data: data,
         successCallback: function (url) {
            $(".loading-image").hide();
         },
         failCallback: function (responseHtml, url, error) {
            $(".loading-image").hide();
         }

      });
      
   }else if(exDownVal == '2'){
      
      var url = "progress.project.pass.exDownSelect.do";
      
      $(".loading-image").show();
      
      $.fileDownload(url,{
         httpMethod:"POST",
         successCallback: function (url) {
            $(".loading-image").hide();
         },
         failCallback: function (responseHtml, url, error) {
            $(".loading-image").hide();
         }

      });
      
   }else if(exDownVal == '3'){
      
      var url = "progress.project.nonPass.exDownSelect.do";
      
      $(".loading-image").show();
      
      $.fileDownload(url,{
         httpMethod:"POST",
         successCallback: function (url) {
            $(".loading-image").hide();
         },
         failCallback: function (responseHtml, url, error) {
            $(".loading-image").hide();
         }

      });      
   }else if(exDownVal == '4'){
      
      var url = "progress.project.pn.exDownSelect.do";
      
      $(".loading-image").show();
      
      $.fileDownload(url,{
         httpMethod:"POST",
         successCallback: function (url) {
            $(".loading-image").hide();
         },
         failCallback: function (responseHtml, url, error) {
            $(".loading-image").hide();
         }

      });   
   }
   
}


/** 페이징 리스트**/
var subPage = function(pageNo){
   if(pageNo == undefined || pageNo == "") pageNo = 1;
   
   var url = "progress.project.search.do";
   
   var data = new Object();
   data.fromDate      = $('#fromDate').val(),
   data.toDate      = $('#toDate').val(),
   data.code_name      = $('#code_name').val(),
   data.complete_yn  = $('#complete_yn option:selected').val(),
   data.project_name = $('#project_name').val(),
   data.del_yn        = $('#del_yn option:selected').val(),
   data.search_yn     = $('#search_yn').val()
   data.page_no = pageNo;
   data.row_size = 10;
   
   var async = false;
   
   callAjax(url, data, async, function(json){
      createTableRowPage("progressTitleTable", json, pageNo, 10, "subPage");
      $("#list_num").text(json.total);
   });
   
}

/** PSG등록건수 / 검수완료건수 / 검수PASS건수 / 검수FAIL건수 **/
function fnTotalSearch(){
   
   var url = "progress.project.total.search.do";
   
   var data = new Object();
   
   var async = false;
   
   callAjax(url, data, async, function(json){
      var row = json.rows;
      
      $("#psg_cnt").text(row[0].psg_cnt);
      $("#work_cnt").text(row[0].work_cnt);
      $("#pass_cnt").text(row[0].pass_cnt);
      $("#fail_cnt").text(row[0].fail_cnt);
      $("#n_psg_cnt").text(row[0].n_psg_cnt);
      
   });
   
}

/** 진행률 리스트 조회 **/
function fnSubSearch(){
   
   var url = "progress.project.search.do";
   
   var data = new Object();
   data.project_cd   = $('#project_cd').val();
   data.complete_yn  = $('#complete_yn option:selected').val();
   
   var async = false;
   
   callAjax(url, data, async, function(json){
      createTableRow("progressTitleTable", json);
      $("#list_num").text(json.total);
      if(json.total<10){
         $(".list_title").css('height', 'auto');
      }
   });
   
   
}


/** 프로젝트 진행률 확인 **/
function progress_chk(project_cd){

//   $("#project_code").val(project_cd);
//   
//   $("#form").attr("action", "/MLA_VIDEO/progress.project.view.do");
//   $("#form").submit();
   
   $(".div_title").find(".project_title").text('프로젝트 : ' + project_cd);
 
   projectProgress(project_cd);
   graph1(project_cd);
   graph2(project_cd);
   
   $("#panel").css('height','630px');
   $(".div_title").slideDown('slow');
   $('html, body').stop().animate({ scrollTop :  $("#panel").offset().top }, 1200);

   
}


/** 크로스체크 **/
function cross_chk(project_cd){
   
   $("#project_code").val(project_cd);
   
   $("#form").attr("action", "/MLA_VIDEO/analysis.analysisProgress.do");
   $("#form").submit();
   
}


function getTotalProgress(obj){
   
//   if($("#myChart").length > 0){
//      $("#myChart").remove();
//   }
   
//   var html = "";
//   html += "<canvas id='myChart'></canvas>";
//   $(".chartDiv").append(html);
   
   var project_code = $(obj).closest("tr").find("td:eq(1)").text();
   
   $("#progressTitleTableBody tr").css("background-color", "white");
   $(obj).closest("tr").css("background-color", "#1091ce42");

   graphPopup(project_code);
   
}

function graphPopup(project_cd){

   var url = "/MLA_VIDEO";
   url += "/progress.project.popup.do"
   url += "?code_name="+project_cd;
   
//   openPopup(url, "800", "600", "POPUP_PROGRESS_PROJECT", "yes", "yes", "");
   openPopup(url, "1200", "1000", "POPUP_PROGRESS_PROJECT", "yes", "yes", "");
    
//   var labels = [];
//   var dataLabels = [];
//   
//   var backgroundColors = [];
//   var borderColors = [];
//   
//   $.ajax({
//      url : "progress.project.chart.do",
//      type : "POST",
//      dataType : "json",
//      data : {"code_name" : project_cd},
//      async : false
//   })
//   .done(function(json){
//      var rows = json;
//      rows = json.rows;
//      
//      for(var i = 0; i < rows.length; i++){
//         labels.push(rows[i].user_name + " (" + rows[i].labeling_ord + "차)");
//         dataLabels.push(rows[i].progress);
//         if(rows[i].labeling_ord == '1'){
//            backgroundColors.push('rgba(15, 102, 174, 0.2)');
//            borderColors.push('rgba(15, 102, 174, 1)');
//         }else{
//            backgroundColors.push('rgba(251, 216, 80, 0.2)');
//            borderColors.push('rgba(251, 216, 80, 1)');
//         }
//         
//      }
//      
////      names = labels.reduce(( a, b ) => {
////         if( a.indexOf(b) < 0 ) a.push(b) ;
////         return a ;
////      }, []) ;
//      
//   })
//   
//   var canvas = document.getElementById("myChart");   
//   var myChart = new Chart(canvas, {
//      type : 'bar',
//      data : {
//         labels : labels,
//         datasets : [{
//                  label : '판독자 진행률(%)',
//                  fill : false,
//                  data : dataLabels,
//                  backgroundColor : backgroundColors,
//                  borderColor : borderColors,
//                  borderWidth : 1
//                  }]
//      },
//       options: {
//          legend: {
//              display: false
//           },
//          scales: {
//               xAxes: [{
//                    stacked: true
//                }],
//                yAxes: [{
//                   stacked: true,
//                   ticks: {
//                        beginAtZero: true,
//                        responsive: false,
//                        maintainAspectRatio: true,
//                        steps: 10,
//                        max: 100
//                    }
//                }]
//            },
//       },
//        tooltips: {
//        },
//        animation:false,
//        showValue:{
//           fontStyle: 'Helvetica',
//           fontSize: 13
//        }
//        
//   })
   
}


/** 검수완료 건 수 / 검수 PASS 건 수 / 검수 FAIL 건 수 / 검수 미완료 건 수 **/
function projectProgress(project_cd){
   
   var data = new Object();
   data.project_cd = project_cd;
   
   var async = false;
   $.ajax({
      url : "progress.pro.view.total.do",
      type : "POST",
      dataType : "json",
      global: true,
      data : {"project_cd" : project_cd},
      async : false
   })
   .done(function(json){
      var row = json.rows;
      
      $(".div_title").find("#work_cnt").text(row[0].work_cnt);
      $(".div_title").find("#work_cnt_ing").text(row[0].work_ing);
      $(".div_title").find("#work_cnt_ani").val(row[0].work_cnt);
      $(".div_title").find("#work_cnt_ani").attr('max', row[0].psg_cnt);
      $(".div_title").find("#work_part").text("( " + row[0].work_cnt + " / " + row[0].psg_cnt + " )")
      
      $(".div_title").find("#pass_cnt").text(row[0].pass_cnt);
      $(".div_title").find("#pass_cnt_ing").text(row[0].pass_ing);
      $(".div_title").find("#pass_cnt_ani").val(row[0].pass_cnt);
      $(".div_title").find("#pass_cnt_ani").attr('max', row[0].psg_cnt);
      $(".div_title").find("#pass_part").text("( " + row[0].pass_cnt + " / " + row[0].psg_cnt + " )")
      
      $(".div_title").find("#fail_cnt").text(row[0].fail_cnt);
      $(".div_title").find("#fail_cnt_ing").text(row[0].fail_ing);
      $(".div_title").find("#fail_cnt_ani").val(row[0].fail_cnt);
      $(".div_title").find("#fail_cnt_ani").attr('max', row[0].psg_cnt);
      $(".div_title").find("#fail_part").text("( " + row[0].fail_cnt + " / " + row[0].psg_cnt + " )")
      
      $(".div_title").find("#n_psg_cnt").text(row[0].n_psg_cnt);
      $(".div_title").find("#n_psg_cnt_ing").text(row[0].n_psg_ing);
      $(".div_title").find("#n_psg_cnt_ani").val(row[0].n_psg_cnt);
      $(".div_title").find("#n_psg_cnt_ani").attr('max', row[0].psg_cnt);
      $(".div_title").find("#n_psg_part").text("( " + row[0].n_psg_cnt + " / " + row[0].psg_cnt + " )")
      
      $(".div_title").find("#user_cnt").text(row[0].user_cnt);
      
   })
      
}

/** 검수자 PASS, FAIL **/
function graph1(project_cd){
   
   $("#chart1").html("");
   var html = "";
   html += "<canvas id='myChart1'></canvas>";
   $("#chart1").append(html);
   
   var label = [];
   var labels = [];
   var datasets = [];
   
   $.ajax({
      url : "progress.pro.view.chart1.do",
      type : "POST",
      dataType : "json",
      data : {"project_cd" : project_cd},
      async : false
   })
   .done(function(json){
      
      var rows = json;
      rows = json.rows;
      
      for(var i = 0; i < rows.length; i++){
         label.push(rows[i].user_nm);
      }

      labels = label.reduce(( a, b ) => {
      if( a.indexOf(b) < 0 ) a.push(b) ;
      return a ;
      }, []) ;
      
      var pass_data = [];
      var fail_data = [];
      var pass_cnt = [];
      var fail_cnt = [];
      for(var i = 0; i < rows.length; i++){
         if(labels[i] = rows[i].user_nm){
            pass_data.push(rows[i].pass_progress);
            fail_data.push(rows[i].fail_progress);
            pass_cnt.push(rows[i].pass_cnt);
            fail_cnt.push(rows[i].fail_cnt);
         }
      }
      
      var pass_dataset = {};
      pass_dataset.label = 'PASS 건 수(진행률%)';
      pass_dataset.backgroundColor = 'rgba(216, 43, 24, 0.2)';
      pass_dataset.borderColor = 'rgba(216, 43, 24, 1)';
      pass_dataset.borderWidth = 1;
      pass_dataset.data = pass_data;
      pass_dataset.count = pass_cnt;
      
      var fail_dataset = {};
      fail_dataset.label = 'FAIL 건 수(진행률%)';
      fail_dataset.backgroundColor = 'rgba(35, 84, 131, 0.2)';
      fail_dataset.borderColor = 'rgba(35, 84, 131, 1)';
      fail_dataset.borderWidth = 1;
      fail_dataset.data = fail_data;
      fail_dataset.count = fail_cnt;
      
      datasets.push(pass_dataset);
      datasets.push(fail_dataset);
      
   })

   var barCharData = {
       labels: labels,
       datasets : datasets
   };
   
   var canvas = document.getElementById("myChart1");   
   var myChart = new Chart(canvas, {
      type : 'bar',
      data : barCharData,
       options: {
//           events: false,
           tooltips: {
               enabled: false
           },
          legend: {
              display: true,
              labels : {fontSize:13,fontFamily:'NanumGothic',fontColor:'#000',fontStyle:'bold'}
           },
          scales: {
                yAxes: [{
                   position : 'left',
                   ticks: {
                        beginAtZero: true,
                        responsive: false,
                        maintainAspectRatio: true,
                        steps: 10,
                        max: 100
                    }
                }]
            },
//            tooltips:{
//               callbacks:{
//                  label : function(tooptipItem, data){
//                     return  "총 진행률% (건수) : " + data['datasets'][0]['data'][tooptipItem['index']]+"%\n"+data['datasets'][0]['datas'][tooptipItem['index']];
//                  }
//               }
//            },
          hover: {
               animationDuration: 0
           },
          animation : {
//             duration : 1,
             onComplete : function(){

                  var chartInstance  = this.chart;
                  ctx = chartInstance .ctx;
                  ctx.font = "bold 13px NanumGothic";
//                  ctx.font = Chart.helpers.fontString('13', Chart.defaults.global.defaultFontStyle, 'NanumGothic');
//                  ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
                  ctx.textAlign = "center";
                  ctx.textBaseline = "bottom";

                   this.data.datasets.forEach(function (dataset, i) {
                       var meta = chartInstance.controller.getDatasetMeta(i);
                       meta.data.forEach(function (bar, index) {
                           var data = dataset.count[index] + '건';
                           var data2 = dataset.data[index] + '%';
                           ctx.fillText(data + " (" + data2 + ")", bar._model.x, bar._model.y - 5);
                           
//                           if(dataset.data[index] == 0){
//                              
//                           }else{
//                              ctx.fillText(data2, bar._model.x, bar._model.y + 17);
//                           }
                       });
                   });
                
                
             }
          }
           
           
           
       }        
   })
   
   
}

function graph2(project_cd){

   $("#chart2").html("");
   var html = "";
   html += "<canvas id='myChart2'></canvas>";
   $("#chart2").append(html);
   
   var labels = ['PASS 일치', 'FAIL 일치', '일치 X', '미완료 건수'];
   var data = [];         
   var datas = [];         
   
   var backgroundColors = ['rgba(121, 120, 120, 0.2)', 'rgba(121, 120, 120, 0.2)', 'rgba(121, 120, 120, 0.2)', 'rgba(121, 120, 120, 0.2)'];
   var borderColors = ['rgba(121, 120, 120, 1)','rgba(121, 120, 120, 1)', 'rgba(121, 120, 120, 1)', 'rgba(121, 120, 120, 1)'];
   
   $.ajax({
      url : "progress.pro.view.chart2.do",
      type : "POST",
      dataType : "json",
      data : {"project_cd" : project_cd},
      async : false
   })
   .done(function(json){
      var rows = json;
      rows = json.rows;
      
      //건수
      datas.push(rows[0].pass);
      datas.push(rows[0].fail);
      datas.push(rows[0].no_match);
      datas.push(rows[0].no_work);
      
      
      //백분율
      data.push(rows[0].pass_percent);
      data.push(rows[0].fail_percent);
      data.push(rows[0].no_match_percent);
      data.push(rows[0].no_work_percent);
      
   })
   
   var canvas = document.getElementById("myChart2");   
   var myChart = new Chart(canvas, {
      type : 'bar',
      data : {
         labels : labels,
         datasets : [{
                  label : 'PASS / FAIL 일치 비율',
                  fill : false,
                  data : data,
                  datas : datas,
                  backgroundColor : backgroundColors,
                  borderColor : borderColors,
                  borderWidth : 1
                  }]
      },
       options: {
//           events: true,
           tooltips: {
               enabled: false
           },
          legend: {
              display: true,
              labels : {fontSize:13,fontFamily:'NanumGothic',fontColor:'#000',fontStyle:'bold'}
           },
          scales: {
                yAxes: [{
                   position : 'left',
                   ticks: {
                        beginAtZero: true,
                        responsive: false,
                        maintainAspectRatio: true,
                        steps: 10,
                        max: 100
                    }
                }]
            },
//            tooltips:{
//               callbacks:{
//                  label : function(tooptipItem, data){
//                     return  "총 진행률% (건수) : " + data['datasets'][0]['data'][tooptipItem['index']]+"%\n"+data['datasets'][0]['datas'][tooptipItem['index']];
//                  }
//               }
//            },
          hover: {
               animationDuration: 0
           },
          animation : {
//             duration : 1,
             onComplete : function(){

                  var chartInstance  = this.chart;
                  ctx = chartInstance .ctx;
                  ctx.font = "bold 13px NanumGothic";
//                  ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
                  ctx.textAlign = "center";
                  ctx.textBaseline = "bottom";

                   this.data.datasets.forEach(function (dataset, i) {
                       var meta = chartInstance.controller.getDatasetMeta(i);
                       meta.data.forEach(function (bar, index) {
                           var data = dataset.datas[index] + '건';
                           var data2 = dataset.data[index] + '%';
//                           ctx.fillText(data, bar._model.x, bar._model.y - 5);
                           ctx.fillText(data + " (" + data2 + ")", bar._model.x, bar._model.y - 5);
                           
//                           if(dataset.data[index] == 0){
//                              
//                           }else{
//                              ctx.fillText(data2, bar._model.x, bar._model.y + 18);
//                           }
                       });
                   });
                
                
             }
          }

       }
        
   })
   
}

