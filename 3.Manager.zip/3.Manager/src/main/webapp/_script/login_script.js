$(document).ready(function() {
	
	/** 로그인 버튼 이벤트 **/
	$("#submit_btn").click(function(){
		
		var user_id = $("#user_id").val();
		var password = $("#password").val();
		
		if(user_id == ''){
			alert("아이디를 입력해주세요.");
			return false;
			
		}else if(password == ''){
			alert("패스워드를 입력해주세요.");
			return false;
		
		}else{
			save();
			$("#form").submit();
		}
		
	});
	
	/** 과제코드/아이디저장 체크박스 이벤트 **/
	$("#cd_id_yn").click(function(){
		if($(this).val() == 'N'){
			$(this).val('Y');
		}else{
			$(this).val('N');
		}
	})
	
	/** 과제코드/아이디저장 label 이벤트 **/
	$("#cd_label").click(function(){
		if($("#cd_id_yn").val() == 'N'){
			$("#cd_id_yn").val('Y');
			$("#cd_id_yn").prop('checked', true);
		}else{
			$("#cd_id_yn").val('N');
			$("#cd_id_yn").prop('checked', false);
		}
	})
	
	
	/** 관리자 여부 체크박스 이벤트 **/
	$("#is_manager").click(function(){
		if($(this).val() == 'N'){
			$(this).val('Y');
		}else{
			$(this).val('N');
		}
	})

	/** 관리자 여부 label 이벤트 **/
	$("#ma_label").click(function(){
		if($("#is_manager").val() == 'N'){
			$("#is_manager").val('Y');
			$("#is_manager").prop('checked', true);
		}else{
			$("#is_manager").val('N');
			$("#is_manager").prop('checked', false);
		}
	})
	
	
});


$(function(){
	getMissonAndId();
})


/** 아이디저장 **/
function save(){
	var expdate = new Date();
	
	//30일동안 기억하게 함
	if($("#cd_id_yn").prop("checked")){
		expdate.setTime(expdate.getTime() + 1000 * 3600 * 24 * 30); // 30일
		
		setCookie("save_id", $("#user_id").val(), expdate);
		
	}else{
		deleteCookie("save_id");
		
	}
	
	
}

/** 아이디 쿠키 가져오기 **/
function getMissonAndId(){
	
	var save_id = getCookie("save_id");
	
	if(save_id != ''){
		$("#user_id").val(save_id);
		
		$("#cd_id_yn").prop('checked', true);
		$("#cd_id_yn").val('Y');
	}
//	if(save_ms != ''){
//		$("#cd_id_yn").prop('checked', true);
//		$("#cd_id_yn").val('Y');
//	}
	
}





