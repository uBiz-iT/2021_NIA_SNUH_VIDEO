$(document).ready(function() {
	
	/** 탭 메뉴 **/
	$(".gnb ul li").click(function(){
		if($(this).find('p').hasClass('on')){
			$(this).find('p').removeClass('on');
		}else{
			$(this).find('p').addClass('on');
		}
	})
	
});


