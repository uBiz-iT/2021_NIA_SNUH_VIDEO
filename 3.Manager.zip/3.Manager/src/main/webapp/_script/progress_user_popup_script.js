$(document).ready(function() {
	
	
});

$(function(){
	
})

function graph(user_id){

	var html = "";
	html += "<canvas id='myChart'></canvas>";
	$(".chartDiv").append(html);
	
	var labels = [];
	var dataLabels = [];	//진행률(완료건수/총건수)
	var datas = [];			//완료건수/총건수
	
	var backgroundColors = [];
	var borderColors = [];
	
	$.ajax({
		url : "progress.user.chart.do",
		type : "POST",
		dataType : "json",
		data : {"user_id" : user_id},
		async : false
	})
	.done(function(json){
		var rows = json;
		rows = json.rows;
		
		for(var i = 0; i < rows.length; i++){
			labels.push(rows[i].project_cd + " (" + rows[i].labeling_ord + "차)");
			dataLabels.push(rows[i].progress);
			datas.push("("+rows[i].project_num+" 건)");
			if(rows[i].labeling_ord == '1'){
				backgroundColors.push('rgba(27, 148, 208, 0.2)');
				borderColors.push('rgba(27, 148, 208, 1)');
			}else{
				backgroundColors.push('rgba(27, 148, 208, 0.2)');
				borderColors.push('rgba(27, 148, 208, 1)');
			}
			
		}
		
//		names = labels.reduce(( a, b ) => {
//			if( a.indexOf(b) < 0 ) a.push(b) ;
//			return a ;
//		}, []) ;
		
	})
	
	var canvas = document.getElementById("myChart");	
	var myChart = new Chart(canvas, {
		type : 'bar',
		data : {
			labels : labels,
			datasets : [{
						label : '프로젝트 진행률(%)',
						fill : false,
						data : dataLabels,
						datas: datas,
						backgroundColor : backgroundColors,
						borderColor : borderColors,
						borderWidth : 1
						}]
		},
	    options: {
	    	legend: {
	        	display: false
	        },
	    	scales: {
            	xAxes: [{
                    stacked: true
                }],
                yAxes: [{
                	stacked: true,
                	ticks: {
                        beginAtZero: true,
                        responsive: false,
                        maintainAspectRatio: true,
                        steps: 10,
                        max: 100
                    }
                }]
            },
            tooltips:{
            	callbacks:{
            		label : function(tooptipItem, data){
            			return  "총 진행률% (건수) : " + data['datasets'][0]['data'][tooptipItem['index']]+"%\n"+data['datasets'][0]['datas'][tooptipItem['index']];
            		}
            	}
            }
	    },
        tooltips: {
        },
        animation:false,
        showValue:{
	        fontStyle: 'Helvetica',
	        fontSize: 13
        }
        
	})
	
}




