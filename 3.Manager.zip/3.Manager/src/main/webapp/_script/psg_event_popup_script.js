$(document).ready(function() {
	
});

$(function(){
	
	
})


/** 이벤트 추가 **/
function eventAdd(){
	
	var rowDel = "<span class='btn_span'><i class='btn btn-minus' onclick='cancer(this);'><a href='javascript:void(0);'>취소</a></i></span>";
	
	var html;
	html += '<tr>';
	html += '<td style="text-align:center;">'+rowDel+'</td>';
	html += '<td style="text-align:center;"><input type="text" class="input_text add_event" value=""/></td>';
	html += '<td style="text-align:left;"><input type="text" class="input_text add_event" value=""/></td>';
	
	html += '</tr>';
	
	$('.popup_table').append(html);
	
}

/** 취소 이벤트 **/
function cancer(obj){
	$(obj).closest("tr").remove();
}

/** 이벤트 사용 여부 변경 저장 **/
function eventSave(){
	
	var list = [];
	var JsonObject = new Object();
	var tr = $(".popup_table tr");
	
	//신규추가(insert)
	$.each(tr, function(index, result){
		if($(this).find('td:eq(1)').find('input').hasClass('add_event')){
			
			if($(this).find('td:eq(1)').find('.add_event').val() == ''){
				return false;
			}
			
			var events = {};
			events.status = 'S';
			events.event_tp = $(this).find('td:eq(1)').find('.add_event').val();
			events.event_tp_nm = $(this).find('td:eq(2)').find('.add_event').val();
				
			list.push(events);
			
		//기존사용자(update)
		}else{
			var events = {};
			events.status = 'U';
			events.event_tp = $(this).find('td:eq(1)').text();
			events.event_tp_nm = $(this).find('td:eq(2)').find('[type=text]').val();
			
			list.push(events);
		}
	})
	
	JsonObject.event_list = JSON.stringify(list);
	
	$.ajax({
		url : "psg.eventTp.update.do",
		type :"POST",
		async : false,
		dataType : "json",
		data : JsonObject
	})
	.done(function(data){
		
		var msg = data.p_ret_msg;
		var code = data.p_ret_code;
		
		if(code == 0){
			alert('저장 완료 되었습니다.');
			
		}else if(code == -1){
			alert('동일한 이벤트 타입이 있습니다.');
			return false;
			
		}else{
			alert(msg);
			return false;
		}
		
		document.location.reload();
		
	})
	.fail(function(jqXHR, textStatus, errorThrown){
		var msg="처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";
		
		alert(msg);
	});
}


function fnSearch(){
	
	$("#grid").jqGrid({

		url: 'psg.event.search.do',
	    mtype : "POST",
	    datatype: 'json',
	    jsonReader : {
	    	root : "rows",
	    },
		postData : {
			event_tp : $('#event_tp').val(),
			event_nm : $('#event_nm').val()
		},
	    colNames:['이벤트 타입', '이벤트 사용 여부', '이벤트 타입(TYPE)', '이벤트명(NAME)', '이벤트 의미'],
	    colModel:[
	              {name:'event_tp'	 		,index:'event_tp'	 		,width:100		,align:"center"},
	              {name:'use_yn' 			,index:'use_yn'    			,width:385  	,align:"center"},
	              {name:'event_tp_nm'	 	,index:'event_tp_nm'	 	,width:385		,align:"center"},
	              {name:'event_nm'  		,index:'event_nm'  			,width:385 		,align:"center"},
	              {name:'event_note'  		,index:'event_note'  		,width:385 		,align:"center"},
	             ],
	              
	    rowNum: 100,
	    rowList: [30,50,100],
	    height: 600,
	    loadonce: true,
	    autowidth:true,    	 // jQgrid width 자동100% 채워지게
	    shrinkToFit:false,  // width를 자동설정 해주는 기능
	    gridview: true,
	    cmTemplate: { sortable: false },
	    rownumbers  : true,                     
	    pager: '#pager',
//	    multiselect:true,
	    onCellSelect: function(rowid, icol, cellcontent, e){

	    },
        
        viewrecords: true,
        loadComplete : function(data){
        	$("#grid").jqGrid("hideCol", "event_tp");
        	
        	var total = $("#grid").getGridParam("records");
        	$("#list_num").text(total);
        },
        caption:" "
    	
    });	

}




