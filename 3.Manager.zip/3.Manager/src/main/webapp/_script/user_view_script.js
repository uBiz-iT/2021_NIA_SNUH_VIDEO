$(document).ready(function() {
	
});

$(function(){
	
})


function fnUpdateData(){
	
	var userId = $("#userId").val();
	
	if(userId == ""){
		alert("사용자 정보 불러오기를 실패하였습니다.");
		return false;
	}
	
	self.close();
	
	var url = "/MLA_SNUH";
	url += "/user.update.do"
	url += "?userId="+userId
		
	openPopup(url, "1024", "300", "POPUP_USER_WRITE", "yes", "yes", "");
	
}