$(document).ready(function() {
	
});

$(function(){
	
	fnSearch();

	$(".ui-pg-selbox").change(function(){
		$("#page_cnt").val($(this).val());
	})
	
})

function popupView(code_name/*, target_cd*/){
	
	var url = "/MLA_COM";
	url += "/label.view.do"
	url += "?code_name="+code_name;
//	url += "&target_cd="+target_cd
	
	openPopup(url, "1024", "400", "POPUP_LABEL_VIEW", "yes", "yes", "");
	
}


function labelAdd(){

	var url = "/MLA_COM";
	url += "/label.write.do";
		
	openPopup(url, "1024", "400", "POPUP_LABEL_WRITE", "yes", "yes", "");
	
}


function fnSearch(){
	
	$("#grid").jqGrid({

		url: 'label.search.do',
	    mtype : "POST",
	    datatype: 'json',
	    jsonReader : {
	    	root : "rows"
//	    	records : "pageCnt"
	    },
		postData : {
			fromDate 		: $('#fromDate').val(),
			toDate 			: $('#toDate').val(),
			code_name 		: $('#code_name').val(),
			target_cd 		: $('#target_cd option:selected').val(),
			project_name 	: $('#project_name').val(),
			label_name 		: $('#label_name').val(),
			del_yn 			: $('#del_yn option:selected').val()
		},
	    colNames:[/*'등록일자',*/'프로젝트 코드','프로젝트명'/*,'타겟 코드'*/,'라벨 코드','라벨명','등록자'],
	    colModel:[
//	              {name:'reg_dt'		,index:'reg_dt'		 	,width:100		,align:"center"},
	              {name:'code_name'	 	,index:'code_name'	 	,width:100		,align:"center"  ,cellattr:jsFormatterCell},
	              {name:'project_name'	,index:'project_name'	,width:300		,align:"left"	 ,cellattr:jsFormatterCell2},
//	              {name:'target_cd' 	,index:'target_cd'  	,width:100  	,align:"center"  /*,cellattr:jsFormatterCell3*/},
	              {name:'label_cd' 	 	,index:'label_cd'    	,width:100  	,align:"center"},
	              {name:'label_name' 	,index:'label_name'    	,width:150  	,align:"center"},
	              {name:'reg_user_id'  	,index:'reg_user_id'  	,width:150  	,align:"center"}
	              
	             ],
	              
	    rowNum: parseInt($("#page_cnt").val()),
	    rowList: [10,20,30],
	    height: 350,
	    loadonce: true,
	    autowidth:true,    	 // jQgrid width 자동100% 채워지게
	    shrinkToFit:false,  // width를 자동설정 해주는 기능
	    gridview: true,
	    cmTemplate: { sortable: false },
	    rownumbers  : true,                     
	    pager: '#pager',
	    onCellSelect : function(rowid, icol, cellcontent, e) {
        	var rowData = $(this).jqGrid("getRowData", rowid);
        	
        	popupView(rowData.code_name, rowData.target_cd);
        },
        
        viewrecords: true,
        loadComplete : function(data){
        	var grid = this;
            
        	chkcell1 = {cellId:undefined, chkval:undefined};
            chkcell2 = {cellId:undefined, chkval:undefined};
//            chkcell3 = {cellId:undefined, chkval:undefined};
        	
            $('td[name="cellRowspan1"]', grid).each(function() {
                var spans = $('td[rowspanid="'+this.id+'"]',grid).length+1;
                if(spans>1){
                 $(this).attr('rowspan',spans);
                }
                
            });
            
            $('td[name="cellRowspan2"]', grid).each(function() {
                var spans = $('td[rowspanid="'+this.id+'"]',grid).length+1;
                if(spans>1){
                 $(this).attr('rowspan',spans);
                }
            });
            
//            $('td[name="cellRowspan3"]', grid).each(function() {
//            	var spans = $('td[rowspanid="'+this.id+'"]',grid).length+1;
//            	if(spans>1){
//            		$(this).attr('rowspan',spans);
//            	}
//            });
            
        },
        caption:" "
    	
    });	
	
}

var chkcell1 = {cellId:undefined, chkval:undefined}; //cell rowspan 중복 체크
var chkcell2 = {cellId:undefined, chkval:undefined};
//var chkcell3 = {cellId:undefined, chkval:undefined};

function jsFormatterCell(rowid, val, rowObject, cm, rdata){
	var result = "";
	
	if(chkcell1.chkval != val){ //check 값이랑 비교값이 다른 경우
		var cellId = this.id + '_row_'+rowid+'-'+cm.name;
		result = ' rowspan="1" id ="'+cellId+'" + name="cellRowspan1"';
		chkcell1 = {cellId:cellId, chkval:val, rowid:rowid};
	}else{
		result = 'style="display:none"  rowspanid="'+chkcell1.cellId+'"'; //같을 경우 display none 처리
	}
	
	return result;
}

function jsFormatterCell2(rowid, val, rowObject, cm, rdata){
	var result = "";
	
	if(chkcell2.chkval != val){ //check 값이랑 비교값이 다른 경우
		var cellId = this.id + '_row_'+rowid+'-'+cm.name;
		result = ' rowspan="1" id ="'+cellId+'" + name="cellRowspan2"';
		chkcell2 = {cellId:cellId, chkval:val, rowid:rowid};
	}else{
		result = 'style="display:none"  rowspanid="'+chkcell2.cellId+'"'; //같을 경우 display none 처리
	}
	
	return result;
}

//function jsFormatterCell3(rowid, val, rowObject, cm, rdata){
//	var result = "";
//	
//	if(chkcell3.chkval != val){ //check 값이랑 비교값이 다른 경우
//		var cellId = this.id + '_row_'+rowid+'-'+cm.name;
//		result = ' rowspan="1" id ="'+cellId+'" + name="cellRowspan3"';
//		chkcell3 = {cellId:cellId, chkval:val, rowid:rowid};
//	}else{
//		result = 'style="display:none"  rowspanid="'+chkcell3.cellId+'"'; //같을 경우 display none 처리
//	}
//	
//	return result;
//}

