$(document).ready(function() {
	
	projectSearch();
	
});

$(function(){
	
	
//	fnPsgSearch();

	$(".ui-pg-selbox").change(function(){
		$("#page_cnt").val($(this).val());
	})
	
})

/** 프로젝트 리스트 조회 **/
function projectSearch(){
	var project_cd = $("#project_code").val();
	
	var data = new Object();
	data.project_cd = project_cd;
	
	var url = "analysis.search.do";
	var async = false;
	
	callAjax(url, data, async, function(json){
		
		var rows = json.rows;
		
		$("#tb_project").find("tr").remove();
		
		for(var i = 0; i < rows.length; i++){
			var html = "";
			
			html += "<tr>";
			html += "<td id='"+rows[i].projectCd+"' style='font-size:14px;border:none;font-weight:bold;border-bottom:1px dashed #cccccc;'>" +
					"<span style='cursor:pointer;padding-left:10px;' onclick='selectProject(this)'>"+rows[i].projectCd+"</span></td>";
			html += "</tr>";
			
			$("#tb_project").append(html);
		}
		
	});
	
}

function selectProject(obj){

	$("#tb_project").find("tr").css("background", "white");
	
	var project_cd = $(obj).text();
	$("#project_cd").val(project_cd);
	$("#excel_btn").css("display","block");
	
	$(obj).closest('tr').css("background", "#eaf0fa");
	
    $("#tb_project").find("td").removeClass("on_class");
    $("#tb_project").find("#"+project_cd).addClass("on_class");
	
	$(".list_num").css("display", "block");
	
	fnPsgSearch();
	
	$("#div_cross_chk").slideDown("slow");
	
}

function popupView(project_cd, psg_id){
	
	var url = "/MLA_VIDEO";
	url += "/psg.video.view.do"
	url += "?project_cd="+val;
	
	openPopup(url, "1024", "500", "POPUP_PSG_VIEW", "yes", "yes", "");
	
}


function videoAdd(){
	
	var url = "/MLA_VIDEO";
	url += "/psg.video.write.do";
		
	openPopup(url, "1024", "500", "POPUP_PSG_WRITE", "yes", "yes", "");
}


function fnPsgSearch(){
	
	$.jgrid.gridUnload("grid");
	
	$("#grid").jqGrid({

		url: 'psg.video.search.do',
	    mtype : "POST",
	    datatype: 'json',
	    jsonReader : {
	    	root : "rows",
	    },
		postData : {
			project_cd 	: $("#project_cd").val(),
//			psg_id 		: $('#psg_id').val()
		},
	    colNames:['프로젝트 코드', '프로젝트명', '검사(환자) ID', 'PSG이미지 등록 건 수', '이벤트 건 수', '자동 등록', '수면영상파일', '이미지압축파일'],
	    colModel:[
	              {name:'project_cd'	 	,index:'project_cd'	 	 	,width:120		,align:"center"},
	              {name:'project_nm'	 	,index:'project_nm'	 		,width:180		,align:"left"},
	              {name:'psg_id'  			,index:'psg_id'  			,width:150 		,align:"center"},
	              {name:'image_reg_cnt'  	,index:'image_reg_cnt'  	,width:140 		,align:"center"},
	              {name:'event_cnt' 		,index:'event_cnt'    		,width:120  	,align:"center"},
	              {name:'auto_load_fg'  	,index:'auto_load_fg'  	 	,width:80 		,align:"center"},
	              {name:'video_file_path'	,index:'video_file_path'	,width:330		,align:"left"},
	              {name:'tar_file_path'  	,index:'tar_file_path'  	,width:330  	,align:"left"},
	             ],
	              
	    rowNum: parseInt($("#list_num").text()),
	    rowList: [10,25,50, 100],
	    height: 500,
	    loadonce: true,
	    autowidth:true,    	 // jQgrid width 자동100% 채워지게
	    shrinkToFit:false,  // width를 자동설정 해주는 기능
	    gridview: true,
	    cmTemplate: { sortable: false },
	    rownumbers  : true,                     
	    pager: '#pager',
	    onCellSelect: function(rowid, icol, cellcontent, e){
        	var rowData = $(this).jqGrid("getRowData", rowid);
        	fnDiSearch(rowData.project_cd, rowData.psg_id);
        	
//        	popupView(rowData.project_cd, rowData.psg_id);
        },
        
        viewrecords: true,
        loadComplete : function(data){
//        	var total = $("#grid").getGridParam("reccount");
        	var total = $("#grid").getGridParam("records");
        	$("#list_num").text(total);
        	
        	var html;
        	
        	if(total == 0){
        		html += "<tr style='height:30px;'>";
        		html += "<td class='td_blank' colspan='9'>조회된 데이터가 없습니다.</td>";
        		html += "</tr>";
        		
        		$("#grid").append(html);
        	}
        	
        	$("#grid").jqGrid("hideCol", "project_cd");
        	$("#grid").jqGrid("hideCol", "project_nm");
        },
        caption:" "
    	
    });	

}


function fnDiSearch(project_cd, psg_id){
	
	$("#span_project").text(' : ' + project_cd + ' > ');
	$("#span_psg").text(psg_id);

	$("#panel").slideDown("slow");
	$( 'html,  body' ).stop().animate({ scrollTop :  $("#panel").offset().top });
	
	// reset
	$("#panel").find("table tr").find("span").text('');
	
	var url = "psg.di.search.do";
	var async = false;
	var data = new Object();
	
	data.project_cd = project_cd;
	data.psg_id = psg_id;
	
	callAjax(url, data, async, function(json){
		
		$("#s_project_cd").text(json.project_cd);
		$("#s_psg_id").text(json.psg_id);
		$("#di_gender").text(json.di_gender);
		$("#di_age").text(json.di_age);
		$("#di_bmi").text(json.di_bmi);
		$("#di_tot_sleep_time").text(json.di_tot_sleep_time);
		$("#di_sleep_effi").text(json.di_sleep_effi);
		$("#di_sleep_latency").text(json.di_sleep_latency);
		$("#di_ahi").text(json.di_ahi);
		$("#di_tot_lm_index").text(json.di_tot_lm_index);
		$("#di_tot_lm_arou").text(json.di_tot_lm_arou);
		$("#di_arou_index").text(json.di_arou_index);
		$("#di_rdi").text(json.di_rdi);
		$("#di_oxy_satu_avg").text(json.di_oxy_satu_avg);
		$("#di_oxy_satu_min").text(json.di_oxy_satu_min);
	});
	
	
}


/** 엑셀 다운로드 **/
function excelDown(){
   
   var url = "psg.video.excelDown.do";
   
   var data = new Object();
   data.project_cd = $(".on_class").attr("id");
   
   $(".loading-image").show();
   
   $.fileDownload(url,{
      httpMethod:"POST",
      data: data,
      successCallback: function (url) {
         $(".loading-image").hide();
      },
      failCallback: function (responseHtml, url, error) {
         $(".loading-image").hide();
      }

   });
   
}
