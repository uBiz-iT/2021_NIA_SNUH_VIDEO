$(document).ready(function() {
	
	$(".loading-image").hide();
	
})

$(function(){
	
	//기존 팝업 화면은 맨 아래 코드 작성되어있음
	
	if($("#project_cd").val() != ''){
		projectProgress($("#project_cd").val());
		
		graph1($("#project_cd").val());
		graph2($("#project_cd").val());
		
		dataSet($("#project_cd").val());
	}
	
})

/** 팝업창 상단 진행률/라벨링완료건수/라벨링미완료건수 **/
function projectProgress(project_cd){
	
	var data = new Object();
	data.project_cd = project_cd;
	
	var async = false;
	$.ajax({
		url : "progress.pro.popup.total.do",
		type : "POST",
		dataType : "json",
		global: true,
		data : {"project_cd" : project_cd},
		async : false
	})
	.done(function(json){
		var row = json.rows;
		
		$("#total_progress").text(row[0].progress);
		$("#total_progress_ani").val(row[0].progress);
		
		$("#complete_labeling").text(row[0].complete_labeling);
		$("#complete_label_ing").text(row[0].complete_percent);
		$("#complete_labeling_ani").val(row[0].complete_labeling);
		$("#complete_labeling_ani").attr('max', row[0].total_num);
		
		
		$("#incomplete_labeling").text(row[0].incomplete_labeling);
		$("#incomplete_label_ing").text(row[0].incomplete_percent);
		$("#incomplete_labeling_ani").val(row[0].complete_labeling);
		$("#incomplete_labeling_ani").attr('max', row[0].total_num);		
		
	})
		
}

/** 판독자 Accept, Reject 건 수 **/
function graph1(project_cd){

	var html = "";
	html += "<canvas id='myChart1' style='max-height: 250px;'></canvas>";
	$("#chart1").append(html);
	
	var label = [];
	var labels = [];
	var datasets = [];
	
	$.ajax({
		url : "progress.pro.popup.chart1.do",
		type : "POST",
		dataType : "json",
		data : {"project_cd" : project_cd},
		async : false
	})
	.done(function(json){
		
		var rows = json;
		rows = json.rows;
		
		for(var i = 0; i < rows.length; i++){
			label.push(rows[i].user_nm);
		}

		labels = label.reduce(( a, b ) => {
		if( a.indexOf(b) < 0 ) a.push(b) ;
		return a ;
		}, []) ;
		
		var acc_data = [];
		var rej_data = [];
		var acc_cnt = [];
		var rej_cnt = [];
		for(var i = 0; i < rows.length; i++){
			if(labels[i] = rows[i].user_nm){
				acc_data.push(rows[i].accept_progress);
				rej_data.push(rows[i].reject_progress);
				acc_cnt.push(rows[i].accept_cnt);
				rej_cnt.push(rows[i].reject_cnt);
			}
		}
		
		var acc_dataset = {};
		acc_dataset.label = 'Pass';
		acc_dataset.backgroundColor = 'rgba(216, 43, 24, 0.2)';
		acc_dataset.borderColor = 'rgba(216, 43, 24, 1)';
		acc_dataset.borderWidth = 1;
		acc_dataset.data = acc_data;
		acc_dataset.count = acc_cnt;
		
		var rej_dataset = {};
		rej_dataset.label = 'Non-pass';
		rej_dataset.backgroundColor = 'rgba(35, 84, 131, 0.2)';
		rej_dataset.borderColor = 'rgba(35, 84, 131, 1)';
		rej_dataset.borderWidth = 1;
		rej_dataset.data = rej_data;
		rej_dataset.count = rej_cnt;
		
		datasets.push(acc_dataset);
		datasets.push(rej_dataset);
		
	})

	var barCharData = {
	    labels: labels,
	    datasets : datasets
	};
	
	var canvas = document.getElementById("myChart1");	
	var myChart = new Chart(canvas, {
		type : 'bar',
		data : barCharData,
	    options: {
//	        events: false,
	        tooltips: {
	            enabled: false
	        },
	    	legend: {
	        	display: true
	        },
	    	scales: {
                yAxes: [{
                	position : 'left',
                	ticks: {
                        beginAtZero: true,
                        responsive: false,
                        maintainAspectRatio: true,
                        steps: 10,
                        max: 100
                    }
                }]
            },
//            tooltips:{
//            	callbacks:{
//            		label : function(tooptipItem, data){
//            			return  "총 진행률% (건수) : " + data['datasets'][0]['data'][tooptipItem['index']]+"%\n"+data['datasets'][0]['datas'][tooptipItem['index']];
//            		}
//            	}
//            },
	    	hover: {
	            animationDuration: 0
	        },
	    	animation : {
//	    		duration : 1,
	    		onComplete : function(){

	    	        var chartInstance  = this.chart;
	    	        ctx = chartInstance .ctx;
	    	        ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
	    	        ctx.textAlign = "center";
	    	        ctx.textBaseline = "bottom";

	                this.data.datasets.forEach(function (dataset, i) {
	                    var meta = chartInstance.controller.getDatasetMeta(i);
	                    meta.data.forEach(function (bar, index) {
	                        var data = dataset.count[index] + '건';
	                        var data2 = dataset.data[index] + '%';
                        	ctx.fillText(data + " (" + data2 + ")", bar._model.x, bar._model.y - 5);
	                        
//	                        if(dataset.data[index] == 0){
//	                        	
//	                        }else{
//	                        	ctx.fillText(data2, bar._model.x, bar._model.y + 17);
//	                        }
	                    });
	                });
	    			
	    			
	    		}
	    	}
	        
	        
	        
	    }        
	})
	
	
}

function graph2(project_cd){

	var html = "";
	html += "<canvas id='myChart2' style='max-height: 250px;'></canvas>";
	$("#chart2").append(html);
	
	var labels = ['Pass 일치', 'Non-pass 일치', '일치 X', '미완료 건수'];
	var data = [];			
	var datas = [];			
	
//	var backgroundColors = ['rgba(8, 146, 209, 0.2)', 'rgba(251, 217, 79, 0.2)', 'rgba(0, 179, 130, 0.2)', 'rgba(30, 83, 132, 0.2)'];
//	var borderColors = ['rgba(8, 146, 209, 1)', 'rgba(251, 217, 79, 1)', 'rgba(0, 179, 130, 1)', 'rgba(30, 83, 132, 1)'];
//	var backgroundColors = ['rgba(35, 84, 131, 0.2)', 'rgba(35, 84, 131, 0.2)', 'rgba(35, 84, 131, 0.2)', 'rgba(35, 84, 131, 0.2)'];
//	var borderColors = ['rgba(35, 84, 131, 1)', 'rgba(35, 84, 131, 1)', 'rgba(35, 84, 131, 1)', 'rgba(35, 84, 131, 1)'];
	var backgroundColors = ['rgba(121, 120, 120, 0.2)', 'rgba(121, 120, 120, 0.2)', 'rgba(121, 120, 120, 0.2)', 'rgba(121, 120, 120, 0.2)'];
	var borderColors = ['rgba(121, 120, 120, 1)','rgba(121, 120, 120, 1)', 'rgba(121, 120, 120, 1)', 'rgba(121, 120, 120, 1)'];
	
	$.ajax({
		url : "progress.pro.popup.chart2.do",
		type : "POST",
		dataType : "json",
		data : {"project_cd" : project_cd},
		async : false
	})
	.done(function(json){
		var rows = json;
		rows = json.rows;
		
		//건수
		datas.push(rows[0].accept);
		datas.push(rows[0].reject);
		datas.push(rows[0].no_match);
		datas.push(rows[0].no_label);
		
		
		//백분율
		data.push(rows[0].accept_percent);
		data.push(rows[0].reject_percent);
		data.push(rows[0].no_match_percent);
		data.push(rows[0].no_label_percent);
		
	})
	
	var canvas = document.getElementById("myChart2");	
	var myChart = new Chart(canvas, {
		type : 'bar',
		data : {
			labels : labels,
			datasets : [{
						label : '일치 비율',
						fill : false,
						data : data,
						datas : datas,
						backgroundColor : backgroundColors,
						borderColor : borderColors,
						borderWidth : 1
						}]
		},
	    options: {
//	        events: true,
	        tooltips: {
	            enabled: false
	        },
	    	legend: {
	        	display: true
	        },
	    	scales: {
                yAxes: [{
                	position : 'left',
                	ticks: {
                        beginAtZero: true,
                        responsive: false,
                        maintainAspectRatio: true,
                        steps: 10,
                        max: 100
                    }
                }]
            },
//            tooltips:{
//            	callbacks:{
//            		label : function(tooptipItem, data){
//            			return  "총 진행률% (건수) : " + data['datasets'][0]['data'][tooptipItem['index']]+"%\n"+data['datasets'][0]['datas'][tooptipItem['index']];
//            		}
//            	}
//            },
	    	hover: {
	            animationDuration: 0
	        },
	    	animation : {
//	    		duration : 1,
	    		onComplete : function(){

	    	        var chartInstance  = this.chart;
	    	        ctx = chartInstance .ctx;
	    	        ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
	    	        ctx.textAlign = "center";
	    	        ctx.textBaseline = "bottom";

	                this.data.datasets.forEach(function (dataset, i) {
	                    var meta = chartInstance.controller.getDatasetMeta(i);
	                    meta.data.forEach(function (bar, index) {
	                        var data = dataset.datas[index] + '건';
	                        var data2 = dataset.data[index] + '%';
//                        	ctx.fillText(data, bar._model.x, bar._model.y - 5);
                        	ctx.fillText(data + " (" + data2 + ")", bar._model.x, bar._model.y - 5);
	                        
//	                        if(dataset.data[index] == 0){
//	                        	
//	                        }else{
//	                        	ctx.fillText(data2, bar._model.x, bar._model.y + 18);
//	                        }
	                    });
	                });
	    			
	    			
	    		}
	    	}

	    }
        
	})
	
}


/** 데이터셋 **/
function dataSet(project_cd){
	
	var url = "progress.pro.popup.data.do";
	
	var data = new Object();
	data.project_cd = project_cd;

	var async = false;
	
	callAjax(url, data, async, function(json){
		createTableRow("progressDatasetTitleTable", json);
	});
	
	
}

/** 데이터셋 tr 선택 **/
function select_tr(obj){
	
	$("#progressDatasetTitleTableBody tr").css("background-color", "white");
	$(obj).closest("tr").css("background-color", "#79787833");
	
}

/** 기존 팝업 **/
//function graph1(project_cd){
//
//	var html = "";
//	html += "<canvas id='myChart'></canvas>";
//	$(".chartDiv").append(html);
//	
//	var labels = [];
//	var dataLabels = [];	//진행률(완료건수/총건수)
//	var datas = [];			//완료건수/총건수
//	
//	var backgroundColors = [];
//	var borderColors = [];
//	
//	$.ajax({
//		url : "progress.project.chart.do",
//		type : "POST",
//		dataType : "json",
//		data : {"code_name" : project_cd},
//		async : false
//	})
//	.done(function(json){
//		var rows = json;
//		rows = json.rows;
//		
//		for(var i = 0; i < rows.length; i++){
//			labels.push(rows[i].user_name + " (" + rows[i].labeling_ord + "차)");
//			dataLabels.push(rows[i].progress);
//			datas.push("("+rows[i].user_num+" 건)");
//			if(rows[i].labeling_ord == '1'){
//				backgroundColors.push('rgba(27, 148, 208, 0.2)');
//				borderColors.push('rgba(27, 148, 208, 1)');
//			}else{
//				backgroundColors.push('rgba(27, 148, 208, 0.2)');
//				borderColors.push('rgba(27, 148, 208, 1)');
//			}
//			
//		}
//		
//	})
//	
//	var canvas = document.getElementById("myChart");	
//	var myChart = new Chart(canvas, {
//		type : 'bar',
//		data : {
//			labels : labels,
//			datasets : [{
//						label : '프로젝트 진행률(%)',
//						fill : false,
//						data : dataLabels,
//						datas: datas,
//						backgroundColor : backgroundColors,
//						borderColor : borderColors,
//						borderWidth : 1
//						}]
//		},
//	    options: {
//	    	legend: {
////	        	display: false
//	        	display: true
//	        },
//	    	scales: {
//          	xAxes: [{
//                  stacked: true
//              }],
//              yAxes: [{
//              	stacked: true,
//              	position : 'left',
//              	ticks: {
//                      beginAtZero: true,
//                      responsive: false,
//                      maintainAspectRatio: true,
//                      steps: 10,
//                      max: 100
//                  }
//              }]
//          },
//          tooltips:{
//          	callbacks:{
//          		label : function(tooptipItem, data){
//          			return  "총 진행률% (건수) : " + data['datasets'][0]['data'][tooptipItem['index']]+"%\n"+data['datasets'][0]['datas'][tooptipItem['index']];
//          		}
//          	}
//          }
//	    },
//      tooltips: {
//      },
//      animation:false,
//      showValue:{
//	        fontStyle: 'Helvetica',
//	        fontSize: 13
//      }
//      
//	})
//	
//}

