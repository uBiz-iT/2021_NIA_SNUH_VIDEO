$(document).ready(function() {
	
	/** 메인 탭(TO-DO/진행중인 프로젝트/완료 프로젝트) **/
	$('ul.tabs li').click(function(){
	    var tab_id = $(this).attr('data-tab');
	    
	    $('ul.tabs li').removeClass('current');
	    $('.tab-content').removeClass('current');
	    
	    $(this).addClass('current');
	    $("#"+tab_id).addClass('current');
	    
	    fnTabSearch(tab_id);
	    
	})
	
	/** h 태그 클릭 이벤트 **/
	$(".main_h5").click(function(){
		$(this).prev("a").get(0).click();
	})
	
	/** 프로젝트 현황 더보기 버튼 이벤트 **/
	$("#project_span").click(function(){
		$("#project_progress").get(0).click();
	})
	
	/** 사용자 현황 더보기 버튼 이벤트 **/
	$("#user_span").click(function(){
		$("#user_progress").get(0).click();
	})
	

	
	
});

$(function(){
	
	fnChartSearch();
	fnUserSearch();
	
	if($("ul.tabs li").hasClass('current') == true){
		var tab_id = $("ul.tabs li").attr('data-tab');
		fnTabSearch(tab_id);
	}
	
})

/** 차트 그리기 **/
function fnChartSearch(){
	
	var labels = [];
	var dataLabels = [];	//진행률(완료건수/총건수)
	var datas = [];			//완료건수/총건수
	
	$.ajax({
		url : "main.chart.search.do",
		type : "POST",
		dataType: "json",
		async : false
	})
	.done(function(json){
		var rows = json;
		rows = json.rows;
		
		for(var i = 0; i < rows.length; i++){
			labels.push(rows[i].project_cd);
			dataLabels.push(rows[i].progress);
			datas.push("("+rows[i].complete_num+"/"+rows[i].total_num+" 건)");

		}
	})
	
	var ctx = document.getElementById("myChart");
	var myChart = new Chart(ctx, {
	    type: 'bar',
	    data: {
	        labels: labels,
	        datasets: [{
			        	label: '총 진행률(%)',
			            fill: false,
			            data: dataLabels,
			            datas: datas,
			            backgroundColor: [
			            	'rgba(15, 102, 174, 0.2)',
			            	'rgba(15, 102, 174, 0.2)',
			            	'rgba(15, 102, 174, 0.2)',
			            	'rgba(15, 102, 174, 0.2)',
			            	'rgba(15, 102, 174, 0.2)',
			            	'rgba(15, 102, 174, 0.2)',
			            	'rgba(15, 102, 174, 0.2)',
			            	'rgba(15, 102, 174, 0.2)',
			            	'rgba(15, 102, 174, 0.2)',
			            	'rgba(15, 102, 174, 0.2)'
			            ],
			            borderColor: [
			            	'rgba(15, 102, 174, 1)',
			            	'rgba(15, 102, 174, 1)',
			            	'rgba(15, 102, 174, 1)',
			            	'rgba(15, 102, 174, 1)',
			            	'rgba(15, 102, 174, 1)',
			            	'rgba(15, 102, 174, 1)',
			            	'rgba(15, 102, 174, 1)',
			            	'rgba(15, 102, 174, 1)',
			            	'rgba(15, 102, 174, 1)',
			            	'rgba(15, 102, 174, 1)'
			            ],
			            borderWidth: 1
			           }
//			           {
//		        	    type: 'line',
//		        	    label: '진행률(%)',
//			            fill: false,
//			            data: dataLabels,
//			            backgroundColor: [
//			            	'rgba(75, 192, 192, 0.2)',
//			            	'rgba(75, 192, 192, 0.2)',
//			            	'rgba(75, 192, 192, 0.2)',
//			            	'rgba(75, 192, 192, 0.2)',
//			            	'rgba(75, 192, 192, 0.2)',
//			            	'rgba(75, 192, 192, 0.2)'
//			            ],
//			            borderColor: [
//			            	'rgba(75, 192, 192, 1)',
//			            	'rgba(75, 192, 192, 1)',
//			            	'rgba(75, 192, 192, 1)',
//			            	'rgba(75, 192, 192, 1)',
//			            	'rgba(75, 192, 192, 1)',
//			            	'rgba(75, 192, 192, 1)'
//			            ],
//			            borderWidth: 1
//			           },	       
	        
			        ]
	    },
	    options: {
	    	scales: {
            	xAxes: [{
                    stacked: true
                }],
                yAxes: [{
                	stacked: true,
                	ticks: {
                        beginAtZero: true,
                        responsive: false,
                        maintainAspectRatio: true,
                        steps: 10,
                        max: 100
                    }
                }]
            },
            tooltips:{
            	callbacks:{
            		label : function(tooptipItem, data){
            			return  "총 진행률% (건수) : " + data['datasets'][0]['data'][tooptipItem['index']]+"%\n"+data['datasets'][0]['datas'][tooptipItem['index']];
            		}
            	}
            }
	    },
	    legend: {
        	display: false
        },
        tooltips: {
        	
        },
        animation:false,
        showValue:{
	        fontStyle: 'Helvetica',
	        fontSize: 13
        }
	});
	
	document.getElementById("myChart").onclick = function(evt){
		var activePoints = myChart.getElementAtEvent(event);
		if (activePoints.length > 0) {
	       var clickedDatasetIndex = activePoints[0]._datasetIndex;
	       var clickedElementindex = activePoints[0]._index;
	       var label = myChart.data.labels[clickedElementindex];
	       var value = myChart.data.datasets[clickedDatasetIndex].data[clickedElementindex];     
//	       alert("Clicked: " + label + " - " + value);
	       
	       $("#project_nm").text("프로젝트 : " + label);
	       fnProjectSearch(label);
	       
	     }
	}
	
}

/** 프로젝트별 사용자 진행률 **/
function fnProjectSearch(project_cd){
	
	var url = "main.project.search.do";
	var data = new Object();
	data.project_cd = project_cd;
	
	var async = false;
	
	callAjax(url, data, async, function(json){
		createTableRow("projectProgressTable", json);
	});
}

/** 월별 사용자 진행률 **/
function fnUserSearch(){
	
	var url = "main.user.search.do";
	var data = new Object();
	var async = false;
	
	callAjax(url, data, async, function(json){
		createTableRow("userProgressTable", json);
	});
	
}

/** 프로젝트 TO-DO **/
var toDoPage = function(pageNo){
	if(pageNo == undefined || pageNo == "") pageNo = 1;
	
	var url = "main.status.search.do";
	
	var data = new Object();
	data.tab_id = "tab-1";
	data.page_no = pageNo;
	data.row_size = "5";
	
	var async = false;
	
	callAjax(url, data, async, function(json){
		createTableRowPage("projectStatusTable", json, pageNo, 5, "toDoPage");
	});	
	
}

/** 프로젝트 ING **/
var ingPage = function(pageNo){
	if(pageNo == undefined || pageNo == "") pageNo = 1;
	
	var url = "main.status.search.do";
	
	var data = new Object();
	data.tab_id = "tab-2";
	data.page_no = pageNo;
	data.row_size = 5;
	
	var async = false;
	
	callAjax(url, data, async, function(json){
		createTableRowPage("projectStatusTable", json, pageNo, 5, "ingPage");
	});	
	
}

/** 프로젝트 COMPLETE **/
var endPage = function(pageNo){
	if(pageNo == undefined || pageNo == "") pageNo = 1;
	
	var url = "main.status.search.do";
	
	var data = new Object();
	data.tab_id = "tab-3";
	data.page_no = pageNo;
	data.row_size = 5;
	
	var async = false;
	
	callAjax(url, data, async, function(json){
		createTableRowPage("projectStatusTable", json, pageNo, 5, "endPage");
	});	
	
}


/** 프로젝트 TO-DO / ING / COMPLETE **/
function fnTabSearch(tab_id){
	
	if(tab_id == "tab-1"){
		toDoPage(1);
	}else if(tab_id == "tab-2"){
		ingPage(1);
	}else if(tab_id == "tab-3"){
		endPage(1);
	}
	
}

/** 프로젝트 TO-DO / ING / COMPLETE 팝업창 **/
function popupProject(obj){
	
	var project_cd = $(obj).find("td:eq(0)").text();

	var url = "/MLA_SNUH";
	url += "/project.view.do"
	url += "?code_name="+project_cd;
	
	openPopup(url, "1024", "500", "POPUP_PROJECT_VIEW", "yes", "yes", "");
}










