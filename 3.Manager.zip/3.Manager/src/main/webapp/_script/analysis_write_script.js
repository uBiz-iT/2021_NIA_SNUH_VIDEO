$(document).ready(function() {
	
});

$(function(){
	
	fnSearch();
	
})

/** 선택한 요소의 결과를 부모창에 전달 **/
var saveItem = function(){
	
	var data = new Object();
	var array = new Array();
	
	if($(".selectBox span").length < 1){
		alert("선택된 정보가 없습니다. \n최소 하나 이상 선택해주세요.");
		return false;
	}
	
	$(".selectBox span.selectedBox").each(function(i){
		var id = $(this).attr("id").trim();
		array[i] = id;
	})
	
	data.items = array;
	
	var rows;
	$.ajax({
		url : "analysis.select.items.do",
		async : false,
		dataType : "json",
		type : "POST",
		data : data
	})
	.done(function(json){
		rows = json.rows;
		
		$("#projectListTable tbody tr", parent.opener.document).remove();
		$("#userListTable tbody tr", parent.opener.document).remove();
		$("#labelListTable tbody tr", parent.opener.document).remove();
		$("#targetListTable tbody tr", parent.opener.document).remove();
		
		//프로젝트 선택
		for(var i = 0; i< rows.length; i++){
			var html = "";
			
			html += "<tr><td title='"+rows[i].project_name+"' style='font-size:13px;'><a href='javascript:void(0);' onclick='getUserItem(this)' style='text-decoration: none;'>" +
					"<span class='checkboxVal'><input type='checkbox' class='checkbox' id='"+rows[i].code_name+"' value='"+rows[i].code_name+"'/>";
			html += "<label for='"+rows[i].code_name+"' style='cursor:pointer;'>"+rows[i].code_name+"</label></a>";
			html += "<span class='btn_span' style='border:1px solid #fff;cursor:pointer;'><i class='btn btn-del' onclick='del(this)'>&nbsp;&nbsp;&nbsp;&nbsp;</i></span>";
			html += "</span></td></tr>";
			
			$("#projectListTable tbody", parent.opener.document).append(html);
		}
		
		//판독자 선택
		for(var i = 0; i < rows.length; i++){
			if(rows[i].user_id_list == "" || rows[i].user_id_list == null){
				
			}else{
				var nm_list = rows[i].user_name_list.split(',');
				var id_list = rows[i].user_id_list.split(',');
				
				for(var j = 0; j < nm_list.length; j++){
					var html = "";
					
					var id_array = id_list[j].split('/');
					
					html += "<tr><td class='"+rows[i].code_name+"' style='font-size:13px;display:none;'><a href='javascript:void(0);' onclick='getLabelingItem(this)'>" +
					"<span class='checkboxVal'><input type='checkbox' class='checkbox' value='"+id_array[0].trim()+"'/></a>";
					html += nm_list[j];
					html += "</span></td></tr>";
					
					$("#userListTable tbody", parent.opener.document).append(html);
				}
				
			}
			
		}
		
		//라벨링차수 선택
		for(var i = 0; i < rows.length; i++){
			var ord = rows[i].labeling_ord_list;
			
			for(var j = 1; j <= ord; j++){
				var html = "";
				
				html += "<tr><td class='"+rows[i].code_name+"' style='font-size:13px;display:none;'><a href='javascript:void(0);' onclick='getTargetItem(this)'><span class='checkboxVal'><input type='checkbox' class='checkbox' value='"+j+"' /></a>"+j+"</span></td></tr>";
				
				$("#labelListTable tbody", parent.opener.document).append(html);
			}
			
		}
		
		//타겟 선택
		for(var i = 0; i < rows.length; i++){
			if(rows[i].target_list == "" || rows[i].target_list == null){
				
			}else{
				var list = rows[i].target_list.split(',');
				
				for(var j in list){
					var html = "";
					
					html += "<tr><td class='"+rows[i].code_name+"' style='font-size:13px;display:none;'><span class='checkboxVal'><input type='checkbox' class='checkbox' value='"+list[j]+"' />"+list[j]+"</span></td></tr>";
					
					$("#targetListTable tbody", parent.opener.document).append(html);
				}
				
			}
		}
		
	})
	.fail(function(jqXHR, textStatus, errorThrown){
		var msg="처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";
		
		alert(msg);
	});
	
	
	self.close();
	
}


var listPage = function(pageNo){
	var url = "analysis.search.do";
	
	var data = new Object();
	data.project_cd = $("#project_cd").val();
	data.page_no = pageNo;
	data.row_size = 10;
	
	var async = false;
	
	callAjax(url, data, async, function(json){
		createTableRowPage("projectTable", json, pageNo, 10, "listPage");
	});
	
	var ids = new Array();
	$(".selectBox span.selectedBox").each(function(){
		var id = $(this).attr("id").trim();
		$("#projectTableBody tr").each(function(){
			var text = $(this).find("td:eq(1)").text().trim();
			if(text == id){
				$(this).find("td:eq(0) .checkbox").prop("checked", true);
			}
		})
	})
	
	$("#all_check").prop("checked", false);
	
}

function fnSearch(){
	listPage(1);
}

/** 전체선택 이벤트 **/
function allItem(obj){
	var attr = $(obj).is(":checked");
	if(attr){
		if(checkItem("rows") == "excess"){
			$(obj).prop("checked", false);
			return false;
		}else{
			$(".checkbox").prop("checked", true);
		}
		
		$("#projectTableBody tr").each(function(){
			var text = $(this).find("td:eq(1)").text().trim();
			if($("#"+text+"").length == 0){
				$(".selectBox").append("<span id="+text+" class='selectedBox'>"+text+"</span>");
				$(".selectBox").append("<span id='del_"+text+"' class='del_icon'><i class='btn btn-del' onclick='delItem(this)'>&nbsp;&nbsp;&nbsp;&nbsp;</i></span>");
			}
		})
		
	}else{
		$(".checkbox").prop("checked", false);
		
		$("#projectTableBody tr").each(function(){
			var text = $(this).find("td:eq(1)").text().trim();
			
			$(".selectBox").find("#"+text+"").remove();
			$(".selectBox").find("#del_"+text+"").remove();
		})
	}
	
}

/** row checkbox 선택 이벤트 **/
function addItem(obj){
	var attr = $(obj).find(".checkbox").is(":checked");
	var project_cd = $(obj).parents("td").next().text().trim();
	
	if(attr){
		if($("#"+project_cd+"").length == 0){
			//10개 초과시 선택 못하게 하기 위함
			if(checkItem("row") == "excess"){
				$(".selectBox").find("#"+project_cd+"").remove();
				$(".selectBox").find("#del_"+project_cd+"").remove();
				$(obj).find(".checkbox").prop("checked", false);
				return false;
			}else{
				$(".selectBox").append("<span id="+project_cd+" class='selectedBox'>"+project_cd+"</span>");
				$(".selectBox").append("<span id='del_"+project_cd+"' class='del_icon'><i class='btn btn-del' onclick='delItem(this)'>&nbsp;&nbsp;&nbsp;&nbsp;</i></span>");
				
			}
			
		}
		
	}else{
		$(".selectBox").find("#"+project_cd+"").remove();
		$(".selectBox").find("#del_"+project_cd+"").remove();
	}
	
}

/** 선택 개수 제한하기 위함 **/
function checkItem(row){
	if(row == "row"){
		if($(".selectBox span").length >= 20){
			alert("10개까지만 선택 가능합니다.");
			return "excess";
		}
	}else if(row == "rows"){
		var spanLength = $(".selectBox span").length;
		var trLength = $(".checkbox:checked").length;
		
		if(spanLength != trLength*2){
			if($(".selectBox span").length != 0){
				alert("10개까지만 선택 가능합니다.");
				return "excess";
			}
		}
		
	}
	
}

/** selectedBox에서 지우기 **/
function delItem(obj){
	var id = $(obj).parents("span").attr("id");
	id = id.replace("del_", "");
	
	$(".selectBox").find("#"+id+"").remove();
	$(".selectBox").find("#del_"+id+"").remove();
	
	$("#projectTableBody tr").each(function(){
		var text = $(this).find("td:eq(1)").text().trim();
		if(text == id){
			$(this).find("td:eq(0) .checkbox").prop("checked", false);
		}
	})
	
}




