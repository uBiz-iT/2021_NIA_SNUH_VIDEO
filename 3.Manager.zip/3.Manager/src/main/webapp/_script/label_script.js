$(document).ready(function() {
	
	/** 타겟 탭 **/
	$('ul.tabs li').click(function(){
	    var tab_id = $(this).attr('data-tab');
	    
	    $('ul.tabs li').removeClass('current');
	    $('.tab-content').removeClass('current');
	    
	    $(this).addClass('current');
	    $("#"+tab_id).addClass('current');
	    
	    $(".table_area").removeClass('tb_current');
	    $(".table_area[data-table="+tab_id+"]").addClass('tb_current');
	    $(".target_span").removeClass('tg_current');
	    $(".target_span[data-table="+tab_id+"]").addClass('tg_current');
	    
//	    fnTabSearch(tab_id);
	    
	})
	
	
});

$(function(){
	
	target0();
	target1();
	
	if($("ul.tabs li").hasClass('current') == true){
		var tab_id = $("ul.tabs li").attr('data-tab');
		
		if(tab_id == "tab-1"){
			$("#target_nm0").val($(".targetNm[target_cd='0']").val());
		}else if(tab_id == "tab-2"){
			$("#target_nm1").val($(".targetNm[target_cd='1']").val());
		}
	}
	
})


var target0 = function(){
	var url = "label.target.search.do";
	
	var data = new Object();
	data.target_cd = 0;
	
	var async = false;
	
	callAjax(url, data, async, function(json){
		createTableRow("labelTable1", json);

		if(json.rows.length == 0){
			var html = '';
			html += "<tr><td colspan='6'>라벨 데이터가 없습니다.</td></tr>";
			
			$("#labelTable1Body tr").remove();
			$("#labelTable1Body").append(html);
		}
		
	});
	
}

var target1 = function(){
	
	var url = "label.target.search.do";
	
	var data = new Object();
	data.target_cd = 1;
	
	var async = false;
	
	callAjax(url, data, async, function(json){
		createTableRow("labelTable2", json);
		
		if(json.rows.length == 0){
			var html = '';
			html += "<tr><td colspan='6'>라벨 데이터가 없습니다.</td></tr>";
			
			$("#labelTable2Body tr").remove();
			$("#labelTable2Body").append(html);
		}
	});
	
}


/** TARGET 0 / TARGET 1 **/
function fnTabSearch(tab_id){

	if(tab_id == "tab-1"){
		target0();
	}else if(tab_id == "tab-2"){
		target1();
	}
	
}


function labelAdd(){
	
	var label_cd = $(".tb_current").find("tbody tr:last").find('td:first-child').text();
	var tbody_id = $(".tb_current").find("tbody").attr('id');
	
	if(isNaN(label_cd)){
		label_cd = 0;
		$(".tb_current").find("tbody tr").remove();
	}
	else {
		label_cd = Number(label_cd)+1; 
	}
	
	var now = new Date();
	var todayInfo = now.getFullYear()+'-'+("0"+(now.getMonth()+1)).slice(-2)+'-'+now.getDate();
	
	var html = '';
	html += "<tr class='add_label'>";
	html += "<td>"+label_cd+"</td>";
	html += "<td><input type='text' value=''/></td>";
	html += "<td>"+todayInfo+"</td>";
	html += "<td>"+$("#user_nm").val()+"</td>";
	html += "<td><span class='btn_span'><i class='btn btn-minus' onclick='cancelLabel(this)'><a href='javascript:void(0);'>삭제</a></i></span></td>";
	html += "</tr>";
	
	
	$("#"+tbody_id).append(html);
}

/** 저장 버튼 클릭 이벤트 **/
function saveLabel(){

	var label = {};
	var labels = [];
	var jsonObject = new Object();
	
	var label_tr1 = $("#labelTable1Body").find(".add_label").length;
	var label_tr2 = $("#labelTable2Body").find(".add_label").length;
	
	for(var i = 0; i < label_tr1; i++){
		var label_cd = $("#labelTable1Body").find(".add_label:eq("+i+")").find("td:first-child").text();
		var label_nm = $("#labelTable1Body").find(".add_label:eq("+i+")").find("td:nth-child(2)").find("input[type=text]").val();
		
		if(label_nm == ''){
			alert("입력되지 않은 항목이 있습니다.");
			$("#labelTable1Body").find(".add_label:eq("+i+")").find("td:nth-child(2)").find("input[type=text]").focus();
			return false;
		}else{
			label.target_cd = '0';
			label.target_nm = $("#target_nm0").val();
			label.label_cd = label_cd;
			label.label_nm = label_nm;
			
			labels.push(label);
		}
	}
	
	for(var i = 0; i < label_tr2; i++){
		var label_cd = $("#labelTable2Body").find(".add_label:eq("+i+")").find("td:first-child").text();
		var label_nm = $("#labelTable2Body").find(".add_label:eq("+i+")").find("td:nth-child(2)").find("input[type=text]").val();
		if(label_nm == ''){
			alert("입력되지 않은 항목이 있습니다.");
			$("#labelTable2Body").find(".add_label:eq("+i+")").find("td:nth-child(2)").find("input[type=text]").focus();
			return false;
		}else{
			label.target_cd = '1';
			label.target_nm = $("#target_nm1").val();
			label.label_cd = label_cd;
			label.label_nm = label_nm;
			
			labels.push(label);
		}
	}

	jsonObject.label = JSON.stringify(labels);
	
	
	$.ajax({
		url : "label.save.do",
		type : "POST",
		async : false,
		dataType : "json",
		data : jsonObject

	}).done(function(data){
		var msg="정상적으로 저장되었습니다.";
		
		var msg = data.p_ret_msg;
		var code = data.p_ret_code;
		
		if(code == 0){
			alert(msg);
		}else{
			alert(msg);
			return false;
		}
		
	}).fail(function(jqXHR, textStatus, errorThrown){
		var msg="처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";
		
		alert(msg);
		
	})
	
}

/** 수정 버튼 클릭 이벤트 **/
function updateLabel(obj){

	var label_nm = $(obj).closest("tr").find("td:nth-child(2)").text();
	$(obj).closest("tr").find("td:nth-child(2)").text('');
	$(obj).closest("tr").addClass('add_label');
	$(obj).closest("tr").find("td:nth-child(2)").append("<input type='text' value='"+label_nm+"'/>");
	$(obj).closest("td").find("i").removeClass('btn-edit');
	$(obj).closest("td").find("i").addClass('btn-del');
	$(obj).closest("td").find("i").attr('onclick', 'resetLabel(this)');
	$(obj).closest("td").find("a").text('취소');
	
	
}

/** 취소(원복) 버튼 클릭 이벤트 **/
function resetLabel(obj){
	var label_nm = $(obj).closest("tr").find("td:nth-child(2)").find("input").val();
	$(obj).closest("tr").removeClass("add_label");
	$(obj).closest("tr").find("td:nth-child(2)").find("input").remove();
	$(obj).closest("tr").find("td:nth-child(2)").text(label_nm);
	$(obj).closest("td").find("i").removeClass('btn-del');
	$(obj).closest("td").find("i").addClass('btn-edit');
	$(obj).closest("td").find("i").attr('onclick', 'updateLabel(this)');
	$(obj).closest("td").find("a").text('수정');
}

/** 취소(삭제) 버튼 클릭 이벤트 **/
function cancelLabel(obj){
	$(obj).closest("tr").remove();
}


