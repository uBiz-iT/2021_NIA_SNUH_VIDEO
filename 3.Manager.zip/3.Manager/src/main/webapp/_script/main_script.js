$(document).ready(function() {

	/** 메인 탭(TO-DO/진행중인 프로젝트/완료 프로젝트) **/
	$('ul.tabs li').click(function(){
	    var tab_id = $(this).attr('data-tab');
	    
	    $('ul.tabs li').removeClass('current');
	    $('.tab-content').removeClass('current');
	    
	    $(this).addClass('current');
	    $("#"+tab_id).addClass('current');
	    
	    fnTabSearch(tab_id);
	    
	})
	
	wmOnChange();
	fnTotalProgress();
	fnLineChart();
	fnBarChart();
});

$(function(){
	
	if($("ul.tabs li").hasClass('current') == true){
		var tab_id = $("ul.tabs li").attr('data-tab');
		fnTabSearch(tab_id);
	}
	
})

function fnTotalProgress(){

	var url = "main.total.progress.do";
	
	var data = new Object();
	
	var async = false;
	
	callAjax(url, data, async, function(json){
		var row = json.rows;

		/** 과제 목표 건 수 **/
		$("#plan_cnt").text(row[0].plan_cnt);
		
		/** 수면 영상 건 수 **/
		$("#video_cnt").text(row[0].video_cnt);
		$("#video_percent").text(row[0].video_percent);
		$("#video_ani").val(row[0].video_percent);
		$("#video_plan").text('(' + row[0].video_plan + ')');

		/** PSG 검수 일치 건 수 **/
		$("#psg_accord_cnt").text(row[0].psg_accord_cnt);
		$("#psg_accord_percent").text(row[0].psg_accord_percent);
		$("#psg_accord_ani").val(row[0].psg_accord_percent);
		$("#psg_accord").text('(' + row[0].psg_accord + ')');
		
		/** PSG 이벤트 검수 OK 건 수 **/
//		$("#psg_event_ok_cnt").text(row[0].psg_event_ok_cnt);
//		$("#psg_event_ok_percent").text(row[0].psg_event_ok_percent);
//		$("#psg_event_ok_ani").val(row[0].psg_event_ok_percent);
//		$("#psg_event_ok").text('(' + row[0].psg_event_ok + ')');
		
		/** 과제 목표 달성율 **/
		$("#psg_plan_cnt").text(row[0].psg_pass_cnt);
		$("#psg_plan_percent").text(row[0].psg_plan_percent);
//		$("#psg_plan_ani").val(row[0].psg_plan_percent);
//		$("#psg_plan").text('(' + row[0].psg_plan + ')');
		
		/** PSG 검수 완료 건 수 **/
		$("#psg_complete_cnt").text(row[0].psg_complete_cnt);
		$("#psg_complete_percent").text(row[0].psg_complete_percent);
		$("#psg_complete_ani").val(row[0].psg_complete_percent);
		$("#psg_complete").text('(' + row[0].psg_complete + ')');
		
		/** PSG PASS 건 수 **/
		$("#psg_pass_cnt").text(row[0].psg_pass_cnt);
		$("#psg_pass_percent").text(row[0].psg_pass_percent);
		$("#psg_pass_ani").val(row[0].psg_pass_percent);
		$("#psg_pass").text('(' + row[0].psg_pass + ')');
		
		/** PSG 이벤트 검수 NG 건 수 **/
//		$("#psg_event_ng_cnt").text(row[0].psg_event_ng_cnt);
//		$("#psg_event_ng_percent").text(row[0].psg_event_ng_percent);
//		$("#psg_event_ng_ani").val(row[0].psg_event_ng_percent);
//		$("#psg_event_ng").text('(' +row[0].psg_event_ng + ')');
		
	});
	
}


/** 주간/월간 선택 이벤트 **/
function wmOnChange(){
	
	if($("#select2").length > 0){
		$("#select2").remove();
	}
	
	var select = $('#select1 option:selected').val();
	var html = '';
	html += "<select class='selectbox' id='select2' onchange='weekOnChange()' style='width:100px'>";
	
	if(select == 'week'){
		var date = new Date();
		var today = date.getMonth() + 1;
		
		for(var i = 1; i <= 12; i++ ){
			if(i == today){
				html += "<option value='0"+i+"' selected>"+i+" 월</option>";
			}else if(i < 10){
				html += "<option value='0"+i+"'>"+i+" 월</option>";
			}else{
				html += "<option value='"+i+"'>"+i+" 월</option>";
			}
		}
		
	}else if(select == 'month'){
		html += "<option value='2021'>2021 년도</option>";
	}
	
	html += "</select>";
	
	$("#select_span").append(html);

	if(select == ''){
		$("#select2").remove();
	}
	
	fnLineChart();
	
}

/** 주간 월별 및 월간 년도별 선택 이벤트 **/
function weekOnChange(){
	fnLineChart();
}

/** 주간/월간 실적 그래프 **/
function fnLineChart(){
	
	var labels = [];
	var psg_cnt = [];
	var work_cnt = [];
	var pass_cnt = [];
	var max = 0;
	var jsondata = new Object();
	
	var select = $('#select1 option:selected').val();
	
	if(select == 'week'){ jsondata.wm = 'W'; }
	else if(select == 'month'){ jsondata.wm = 'M'; }
	
	jsondata.wmVal = $('#select2 option:selected').val();
	
	$.ajax({
		url : "main.weekMonth.chart.do",
		type : "post",
		dataType : "json",
		data : jsondata,
		async : false
	})
	.done(function(json){
		var rows = json;
		rows = json.rows;
		
		for(var i = 0; i < rows.length; i++){
			if(rows[i].wm == 'W'){
				labels.push(rows[i].week_of_month + '주차(' + rows[i].week_start + '~' + rows[i].week_end + ')');
			}else{
				labels.push(rows[i].month + '월');
			}
			
			psg_cnt.push(rows[i].psg_cnt);
			work_cnt.push(rows[i].work_cnt);
			pass_cnt.push(rows[i].pass_cnt);
		}
		
		max = Math.max.apply(null, work_cnt.map(Number));
		if(max < 100){
			max = 100;
		}
		
	})
	
	
	$("#chart1").remove();
	$("#div_chart1").append('<canvas id="chart1"></canvas>');
	
	var ctx = document.getElementById("chart1").getContext("2d");
	
	var gradientStroke = ctx.createLinearGradient(100, 0, 800, 0);
	gradientStroke.addColorStop(0, '#80b6f4');
	gradientStroke.addColorStop(0.5, '#f7e28f');
	gradientStroke.addColorStop(1, '#e27a6e');
	
	const data = {
		labels: labels,
		datasets: [
			{
				label: '수면 영상 등록 건 수',
				data: psg_cnt,
				borderColor: "rgba(251,217,79,1)",
				backgroundColor: "rgba(251,217,79,0.4)",
//				borderColor: gradientStroke,
//				pointBorderColor: gradientStroke,
//				pointBackgroundColor: gradientStroke,
//				pointHoverBackgroundColor: gradientStroke,
//				pointHoverBorderColor: gradientStroke,
//				pointBorcderWidth: 3,
//				pointHoverRadius: 5,
//				pointHoverBorderWidth: 1,
//				pointRadius: 3,
				fill: false,
				borderWidth: 2,
				tension: 0
			},
			{
				label: 'PSG 검수 완료 건 수',
				data: work_cnt,
				borderColor: "rgba(35,84,131,1)",
				backgroundColor: "rgba(35,84,131,0.4)",
				fill: false,
				borderWidth: 2,
				tension: 0
			},
			{
				label: '일치 건 중 PASS 건 수',
				data: pass_cnt,
				borderColor: "rgba(156,41,150,1)",
				backgroundColor: "rgba(156,41,150,0.4)",
				fill: false,
				borderWidth: 2,
				tension: 0
			}			
			
		]
	}
	
	const config = {
		type: 'bar',
		data: data,
		options: {
			legend: {
				labels: {
					fontFamily : 'NanumGothic',
					fontColor: '#000',
					fontStyle: 'bold'
				}
			},
			scales: {
				yAxes: [{
					ticks:{
                        beginAtZero: true,
                        responsive: false,
                        maintainAspectRatio: true,
//                        steps: 5,
                        max: max
					}
				}]
			},
	        tooltips:{
	        	titleFontFamily: 'NanumGothic',
	        	callbacks:{
	        		label : function(tooltipItem, data){
	        			var label = data.datasets[tooltipItem.datasetIndex].label || '';
	        			
	        			if (label) {
	                        label += ' : ';
	                    }
	        			
	        			label += data.datasets[tooltipItem.datasetIndex]['data'][tooltipItem['index']] + " 건";
	        			
	        			return label;
	        		}
	        	}
	        }
		}
	}
	
	var chart = new Chart(ctx, config);
	
}


/** PSG 검수자 실적도 **/
function fnBarChart(){
	
	var labels = [];
	var assign_cnt = [];
	var work_cnt = [];
	var max = 0;
	var jsondata = new Object();
	
	$.ajax({
		url : "main.user.chart.do",
		type : "post",
		dataType : "json",
		data : jsondata,
		async : false
	})
	.done(function(json){
		var rows = json;
		rows = json.rows;
		
		for(var i = 0; i < rows.length; i++){
			labels.push(rows[i].user_nm);
			assign_cnt.push(rows[i].assign_cnt);
			work_cnt.push(rows[i].work_cnt);
		}
		
		max = Math.max.apply(null, assign_cnt.map(Number));
		if(max < 10){
			max = 10;
		}		
		
	})
	
	
	$("#chart2").remove();
	$("#div_chart2").append('<canvas id="chart2"></canvas>');
	
	var ctx = document.getElementById("chart2").getContext("2d");
	
	const data = {
		labels: labels,
		datasets: [
			{
				label: '할당건 수',
				data: assign_cnt,
				borderColor: "rgba(221,63,45,1)",
				backgroundColor: "rgba(221,63,45,0.4)",
				borderWidth: 2,
				tension: 0
			},
			{
				label: '완료건 수',
				data: work_cnt,
				borderColor: "rgba(30,83,132,1)",
				backgroundColor: "rgba(30,83,132,0.4)",
				borderWidth: 2,
				tension: 0
			}
			
		]
	}
	
	const config = {
		type: 'bar',
		data: data,
		options: {
			legend: {
				labels: {
					fontFamily : 'NanumGothic',
					fontColor: '#000',
					fontStyle: 'bold'
				}
			},
			scales: {
				yAxes: [{
					ticks:{
                        beginAtZero: true,
                        responsive: false,
                        maintainAspectRatio: true,
//                        steps: 5,
                        max: max
					}
				}]
			},
	        tooltips:{
	        	titleFontFamily: 'NanumGothic',
	        	callbacks:{
	        		label : function(tooltipItem, data){
	        			var label = data.datasets[tooltipItem.datasetIndex].label || '';
	        			
	        			if (label) {
	                        label += ' : ';
	                    }
	        			
	        			label += data.datasets[tooltipItem.datasetIndex]['data'][tooltipItem['index']] + " 건";
	        			
	        			return label;
	        		}
	        	}
	        }
		}
	}
	
	var chart = new Chart(ctx, config);
	
}


/** 프로젝트 TO-DO **/
var toDoPage = function(pageNo){
	if(pageNo == undefined || pageNo == "") pageNo = 1;
	
	var url = "main.status.search.do";
	
	var data = new Object();
	data.tab_id = "tab-1";
	data.page_no = pageNo;
	data.row_size = "5";
	
	var async = false;
	
	callAjax(url, data, async, function(json){
		createTableRowPage("projectStatusTable", json, pageNo, 5, "toDoPage");
		
		if($("#projectStatusTableBody tr td").length == 0){
			html = '<tr>';
			html += '<td colspan="6">데이터가 없습니다.</td>';	
			html += '</tr>';
			
			$("#projectStatusTableBody").append(html);
			$("#projectStatusTablePage").empty();
		}
	});	
	
}

/** 프로젝트 ING **/
var ingPage = function(pageNo){
	if(pageNo == undefined || pageNo == "") pageNo = 1;
	
	var url = "main.status.search.do";
	
	var data = new Object();
	data.tab_id = "tab-2";
	data.page_no = pageNo;
	data.row_size = 5;
	
	var async = false;
	
	callAjax(url, data, async, function(json){
		createTableRowPage("projectStatusTable", json, pageNo, 5, "ingPage");
		
		if($("#projectStatusTableBody tr td").length == 0){
			html = '<tr>';
			html += '<td colspan="6">데이터가 없습니다.</td>';	
			html += '</tr>';
			
			$("#projectStatusTableBody").append(html);
			$("#projectStatusTablePage").empty();
		}
	});	
	
}

/** 프로젝트 COMPLETE **/
var endPage = function(pageNo){
	if(pageNo == undefined || pageNo == "") pageNo = 1;
	
	var url = "main.status.search.do";
	
	var data = new Object();
	data.tab_id = "tab-3";
	data.page_no = pageNo;
	data.row_size = 5;
	
	var async = false;
	
	callAjax(url, data, async, function(json){
		createTableRowPage("projectStatusTable", json, pageNo, 5, "endPage");
		
		if($("#projectStatusTableBody tr td").length == 0){
			html = '<tr>';
			html += '<td colspan="6">데이터가 없습니다.</td>';	
			html += '</tr>';
			
			$("#projectStatusTableBody").append(html);
			$("#projectStatusTablePage").empty();
		}
	});	
	
}


/** 프로젝트 TO-DO / ING / COMPLETE **/
function fnTabSearch(tab_id){
	
	if(tab_id == "tab-1"){
		toDoPage(1);
	}else if(tab_id == "tab-2"){
		ingPage(1);
	}else if(tab_id == "tab-3"){
		endPage(1);
	}
	
}

/** 프로젝트 TO-DO / ING / COMPLETE 팝업창 **/
function popupProject(obj){
	
	var project_cd = $(obj).find("td:eq(0)").text();

	var url = "/MLA_VIDEO";
	url += "/project.view.do"
	url += "?project_cd="+project_cd;
	
	openPopup(url, "1024", "500", "POPUP_PROJECT_VIEW", "yes", "yes", "");
}










