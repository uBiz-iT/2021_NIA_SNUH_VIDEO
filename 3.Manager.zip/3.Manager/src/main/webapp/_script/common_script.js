
/** keyup function : numberOnly input 속성일때 숫자만 입력 가능하게 하기 위함 */
$("input:text[numberOnly]").on("keyup", function(){
	$(this).val($(this).val().replace(/[^0-9]/g, ""));
});

//$(".input_text").keydown(function(key) {
//    if (key.keyCode == 13) {
//        $(".btn-search").click();
//    }
//});

/** 검색조건 리셋 **/
var doReset = function(form){
	var em = form.elements;
	form.reset();

	for (var i = 0; i < em.length; i++) {
        if (em[i].type == 'text') em[i].value = '';
        if (em[i].type == 'checkbox') em[i].checked = false;
        if (em[i].type == 'radio') em[i].checked = false;
        if (em[i].type == 'select-one') em[i].options[0].selected = true;
        if (em[i].type == 'textarea') em[i].value = '';
    }
	
    return;
	
}

/** 검색조건 조회 **/
var doSearch = function(form){
	if(form.search_yn){
		form.search_yn.value = 'Y'
	}
	form.submit();
}

/** 창 닫기 **/
var doClose = function(){
	self.close();
}

/**
 * @param url(mapping), data(json), async(비동기여부), callback(function)
 * @return <tbody>
 * @throws Exception
 * 용도 : 공통 Ajax
 */
var callAjax = function(url, data, async, callback){
	
	async = (async == undefined || async == null ? false : async);
	
	$.ajax({
		url : url,
		async : async,
		dataType : "json",
		type : "POST",
		data : data
	})
	.done(function(json){
		callback(json);
	})
	.fail(function(jqXHR, textStatus, errorThrown){
		var msg="처리에 실패 하였습니다.";
		msg += "\n관리자에게 문의 하세요.";
		
		alert(msg);
	});
	
}


/**
 * @param id(table id값), jsonData
 * @return <tbody>
 * @throws 
 * 용도 : 서브/타이틀 테이블 생성
 */
var createTableRow = function(id, jsonData){
	var total = jsonData.total;
	var rows = jsonData;
//	var keys;
	
	if(jsonData.rows != undefined){
		rows = jsonData.rows;
//		keys = Object.keys(jsonData.rows[0]);
	}
	
	var tr = $("tr","#"+id);
	var $th = $("th","#"+id);
	var $tbody = $("<tbody id='"+id+"Body'>");
	
	if(rows != ""){
//		console.log(JSON.stringify(rows));
		
		$("#"+id+"Body").remove();
		$(rows).each(function(i, d){
			var $tr = $("<tr>");
			var trOpt = $(tr).data("opt");
			
			if(trOpt && trOpt["onClick"]){
				var func = trOpt["onClick"];
				
				$tr.attr("onClick", func);
				$tr.css("cursor", "pointer");
			}
			
			$th.each(function(j, e){
				var $td = $("<td>");
				var opt = $(e).data("opt");
				
				if(opt["align"]){
					$td.css("text-align", opt["align"]);
				}
				
				if(opt["margin"]){
					$td.css("margin", opt["margin"]);
				}
				
				if(opt["padding"]){
					$td.css("padding", opt["padding"]);
				}
				
				if(opt["line-height"]){
					$td.css("line-height", opt["line-height"]);
				}
				
				if(opt["onClick"]){
					var href = opt["onClick"];
					$td.append("<a href='javascript:void(0);' onclick='"+ href +"'>"+d[opt["col"]]+"</a>");
				}else{
					$td.append(d[opt["col"]]);
				}

				if(opt["checkNclick"]){
					var href = opt["checkNclick"];
					$td.append("<a href='javascript:void(0);' onclick='"+ href +"'><input type='checkbox' class='checkbox'/></a>");
				}
				
				if(opt["checkbox"]){
					$td.append("<input type='checkbox' class='checkbox'/>");
				}
				
				if(opt["btn_update"]){
					var fnc = opt["btn_update"];
					$td.append("<span class='btn_span'><i class='btn btn-edit' onclick='"+ fnc +"'><a href='javascript:void(0);'>수정</a></i></span>");
				}
				
//				$td.append(d[keys[j]])
				$td.append("</td>");
				$tr.append($td);
			})
			
			$tr.append("</tr>");
			$tbody.append($tr);
		})
		
		$("#"+id).append($tbody);

	}else{
		$("#"+id+"Body").html("");
		var $tr = $("<tr>");
		$("#"+id+"Body").html($tr);
	}
	
}


/**
 * @param id(table id값), pageNo(현재 페이지 번호), rowSize(row개수), func(페이지함수명)
 * @param jsonData  : {"total":n,"rows":[{},{},{}....]} 형식 유지 필요 / total : 게시물 총개수 / rows : 실 게시물 데이터
 * @return <tbody>
 * @throws 
 * 용도 : 서브/타이틀 테이블 생성 (페이지네이션 포함)
 */
var createTableRowPage = function(id, jsonData, pageNo, rowSize, func){
	var total = jsonData.total;
	var rows = jsonData;
//	var keys;
	
	if(jsonData.rows != undefined){
		rows = jsonData.rows;
//		keys = Object.keys(jsonData.rows[0]);
	}
	
	var tr = $("tr","#"+id);
	var $th = $("th","#"+id);
	var $tbody = $("<tbody id='"+id+"Body'>");
	
	if(rows != ""){
//		console.log(JSON.stringify(rows));
		
		if(pageNo != "undefined" && pageNo > 0){
			this.createPage(id, total, pageNo, rowSize, func);
		}
		
		
		$("#"+id+"Body").remove();
		$(rows).each(function(i, d){
			var $tr = $("<tr>");
			var trOpt = $(tr).data("opt");
			
			if(trOpt && trOpt["onClick"]){
				var func = trOpt["onClick"];
				
				$tr.attr("onClick", func);
				$tr.css("cursor", "pointer");
			}
			
			$th.each(function(j, e){
				var $td = $("<td>");
				var opt = $(e).data("opt");
				
				if(opt["align"]){
					$td.css("text-align", opt["align"]);
				}
				
				if(opt["margin"]){
					$td.css("margin", opt["margin"]);
				}
				
				if(opt["padding"]){
					$td.css("padding", opt["padding"]);
				}
				
				if(opt["line-height"]){
					$td.css("line-height", opt["line-height"]);
				}

				if(opt["onClick"]){
					var href = opt["onClick"];
					$td.append("<a href='javascript:void(0);' onclick='"+ href +"'>"+d[opt["col"]]+"</a>");
				}else{
					$td.append(d[opt["col"]]);
				}
				
				if(opt["checkNclick"]){
					var href = opt["checkNclick"];
					$td.append("<a href='javascript:void(0);' onclick='"+ href +"'><input type='checkbox' class='checkbox'/></a>");
				}
				
				if(opt["checkbox"]){
					$td.append("<input type='checkbox' class='checkbox'/>");
				}
				
				if(opt["btn_update"]){
					var fnc = opt["btn_update"];
					$td.append("<span class='btn_span'><i class='btn btn-edit' onclick='"+ fnc +"'><a href='javascript:void(0);'>수정</a></i></span>");
				}
				
//				$td.append(d[keys[j]])
				$td.append("</td>");
				$tr.append($td);
			})
			
			$tr.append("</tr>");
			$tbody.append($tr);
		})
		
		$("#"+id).append($tbody);
		
	}else{
		$("#"+id+"Body").html("");
		var $tr = $("<tr>");
		$("#"+id+"Body").html($tr);
	}
	
}


/**
 * @param id, totalCount, pageNo, rowSize, func
 * @return pageDiv
 * @throws 
 * 용도 : 페이지네이션
 */
var createPage = function(id, totalCount, pageNo, rowSize, func){
	
	var $pageDiv = $("#"+id+"Page");
	$pageDiv.html("");
	
	if(pageNo <= 0) pageNo = 1;
	if(rowSize <= 0) rowSize = 1;
	
	var pageListSize = 10;
	var lastPageNo = 1;
	
	var totalPage = Math.ceil(totalCount/rowSize);
	if(pageListSize > totalPage) pageListSize = totalPage;
	
	var pageGroup = Math.ceil(pageNo/pageListSize);
	
	var last = pageGroup * pageListSize;    // 화면에 보여질 마지막 페이지 번호
	if(last > totalPage) last = totalPage;
	
	var first = last - (pageListSize-1);    // 화면에 보여질 첫번째 페이지 번호
	var next = last+1;
	var prev = first-1;
	
	//first
	$pageDiv.append($("<a href=\"javascript:void(0);\">").attr("onClick", func+"(1)").append($("<span class=\"go_first\">")));
	if(prev < 1){
		prev = pageNo-1;
		if(prev < 1) prev = 1;
	}

	//prev
	$pageDiv.append($("<a href=\"javascript:void(0);\">").attr("onClick", func+"("+prev+")").append($("<span class=\"go_prev\">")));
	for(var i=first; i<=last; i++){
		if(i > first){
			$pageDiv.append($("<span class=\"page_separ\">").text("|"));
		}
		
		if(i == pageNo){
			$pageDiv.append($("<span class=\"page_no\">").text(i));
		}else{
			$pageDiv.append($("<a href=\"javascript:void(0);\">").attr("onClick", func+"("+i+")").text(i));
		}
		
	}
	
	
	if(next > totalPage){
		next = pageNo+1;
		if(next > totalPage) next = totalPage;
	}
	
	//next
	$pageDiv.append($("<a href=\"javascript:void(0);\">").attr("onClick", func+"("+next+")").append($("<span class=\"go_next\">")));
	$pageDiv.append($("<a href=\"javascript:void(0);\">").attr("onClick", func+"("+totalPage+")").append($("<span class=\"go_last\">")));
	
}



/**
 * @param url, width, height, name, scrollbar, resizable, etc
 * @return window.open
 * @throws 
 * 용도 : popup창
 */
var openPopup = function(url, width, height, name, scrollbar, resizable, etc){
	
	var left = 0;
	var top = 0;
	
	if (url == undefined || url == ""){
		url = "about:blank";
	}
	
	if (String(width) == "100%") {
		width = window.screen.availWidth-20;
    }else {
	    left = (window.screen.availWidth / 2) - (width / 2);
    }

    if (String(height) == "100%") {
	    height = window.screen.availHeight;
    }else {
	    top = (window.screen.availHeight / 2) - (height / 2);
    }
    
    if (name == undefined){
    	name = "";
    }

    if (scrollbars == "yes" || scrollbars == "1") {
        scrollbars = "yes";
    }else {
        scrollbars = "no";
    }

    if (resizable == "yes" || resizable == "1") {
        resizable = "yes";
    }else {
        resizable = "no";
    }

    if (etc == undefined) {
  	    etc = "";
    }else {
  	    etc = ","+ etc;
    }
	
    var a = window.open(encodeURI(url), name, "left=" + left + ",top=" + top + ",width=" + width + ",height=" + height + ",scrollbars=" + scrollbars + ",resizable=" + resizable + ",toolbar=no,location=no,directories=no,status=no,menubar=no"+ etc);

    $(a).focus();

    return a;
    
    
}

/** 엑셀 다운로드 기본 table 버전 **/
var fnExcelExport = function(id, title){
	var tab_text = '<html xmlns:x="urn:schemas-microsoft-com:office:excel">';
	tab_text = tab_text + '<head><meta http-equiv="content-type" content="application/vnd.ms-excel; charset=UTF-8">';
	tab_text = tab_text + '<xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet>'
	tab_text = tab_text + '<x:Name>Test Sheet</x:Name>';
	tab_text = tab_text + '<x:WorksheetOptions><x:Panes></x:Panes></x:WorksheetOptions></x:ExcelWorksheet>';
	tab_text = tab_text + '</x:ExcelWorksheets></x:ExcelWorkbook></xml></head><body>';
	tab_text = tab_text + "<table border='1px'>";
	
	var exportTable = $('#' + id).clone();
	exportTable.find('input').each(function (index, elem) { $(elem).remove(); });
	
	tab_text = tab_text + exportTable.html();
	tab_text = tab_text + '</table></body></html>';
	
	var data_type = 'data:application/vnd.ms-excel';
	var ua = window.navigator.userAgent;
	var msie = ua.indexOf("MSIE ");
	var fileName = title + '.xls';
	
	//Explorer 환경에서 다운로드
	if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
		if (window.navigator.msSaveBlob) {
			var blob = new Blob([tab_text], {
				type: "application/csv;charset=utf-8;"
			});
			navigator.msSaveBlob(blob, fileName);
		}
	} else {
		var blob2 = new Blob([tab_text], {
			type: "application/csv;charset=utf-8;"
		});
		var filename = fileName;
		var elem = window.document.createElement('a');
		elem.href = window.URL.createObjectURL(blob2);
		elem.download = filename;
		document.body.appendChild(elem);
		elem.click();
		document.body.removeChild(elem);
	}
	
}

/** 엑셀 다운로드 jqgrid 버전 **/
/** 다음에 사용 할때에는 hide, show할 컬럼들의 id값을 배열로 받아 처리하자**/
var excelExport = function(title){
	
	options = {
			  includeLabels : true,
			  includeGroupHeader : true,
			  includeFooter: true,
			  includeHeader: true,
			  fileName : ""+title+".xlsx",
			  mimetype : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
			  maxlength : 40,
			  onBeforeExport : null,
			  replaceStr : null,
			  loadIndicator : true,
			  treeindent : ' '
			}

	$("#grid").jqGrid("hideCol", "complete_yn");
	$("#grid").jqGrid("hideCol", "image_view");
	$("#grid").jqGrid("hideCol", "이미지보기");
	
	$("#grid").jqGrid("exportToExcel",options);
	
	$("#grid").jqGrid("showCol", "complete_yn");
	$("#grid").jqGrid("showCol", "image_view");
	$("#grid").jqGrid("showCol", "이미지보기");
}

/** datepicker options*/
var datePicker = function(obj){
	$(obj).datepicker({
		  buttonImageOnly: true, // 버튼에 있는 이미지만 표시한다.
		  changeMonth: true, // 월을 바꿀수 있는 셀렉트 박스를 표시한다.
		  changeYear: true, // 년을 바꿀 수 있는 셀렉트 박스를 표시한다.
		  minDate: '-100y', // 현재날짜로부터 100년이전까지 년을 표시한다.
		  nextText: '다음 달', // next 아이콘의 툴팁.
		  prevText: '이전 달', // prev 아이콘의 툴팁.
		  numberOfMonths: [1,1], // 한번에 얼마나 많은 월을 표시할것인가. [2,3] 일 경우, 2(행) x 3(열) = 6개의 월을 표시한다.
		  stepMonths: 1, // next, prev 버튼을 클릭했을때 얼마나 많은 월을 이동하여 표시하는가. 
		  yearRange: 'c-10:c+10', // 년도 선택 셀렉트박스를 현재 년도에서 이전, 이후로 얼마의 범위를 표시할것인가.
		  //showButtonPanel: true, // 캘린더 하단에 버튼 패널을 표시한다. 
		  //currentText: '오늘 날짜' , // 오늘 날짜로 이동하는 버튼 패널
		  //closeText: '닫기',  // 닫기 버튼 패널
		  dateFormat: "yy-mm-dd", // 텍스트 필드에 입력되는 날짜 형식.
		  showMonthAfterYear: true , // 월, 년순의 셀렉트 박스를 년,월 순으로 바꿔준다. 
		  dayNamesMin: ['월', '화', '수', '목', '금', '토', '일'], // 요일의 한글 형식.
		  monthNamesShort: ['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'] // 월의 한글 형식.
	})
}


/** 로딩 시작 **/
var loadingWithMask = function() {
    //로딩중 이미지 표시
    $('#loadingImg').show();
}

/** 로딩 종료 **/
var closeLoadingMask = function(){
	$("#loadingImg").hide();
	$("#loadingImg").empty();
}

/** 쿠키 세팅 **/
function setCookie(cookieName, value, exdays){
	var exdate = new Date();
	exdate.setDate(exdate.getDate() + exdays);
	var cookieValue = escape(value) + ((exdays==null) ? "" : "; expires=" + exdate.toGMTString());
	document.cookie = cookieName + "=" + cookieValue;
}

/** 쿠키 삭제 **/
function deleteCookie(cookieName){
	var expireDate = new Date();
	expireDate.setDate(expireDate.getDate() - 1);
	document.cookie = cookieName + "= " + "; expires=" + expireDate.toGMTString();
}

/** 쿠키 가져오기 **/
function getCookie(cookieName) {
	cookieName = cookieName + '=';
	var cookieData = document.cookie;
	var start = cookieData.indexOf(cookieName);
	var cookieValue = '';
	if(start != -1){
		start += cookieName.length;
		var end = cookieData.indexOf(';', start);
		if(end == -1)end = cookieData.length;
		cookieValue = cookieData.substring(start, end);
	}
	return unescape(cookieValue);
}

/** 스크롤 위치 저장 **/
function getScrollPoint(){
 	//스크롤 위치 저장
 	var scrollPoint = (document.documentElement && document.documentElement.scrollTop) || document.body.scrollTop;

	setCookie("category", "mainScrollPoint"); // 쿠키에서 사용할 category에 사용자 정의 카테고리명 세팅
	setCookie("scrollPoint", scrollPoint); // 쿠키에 스크롤 위치 세팅
}

/** 스크롤 위치 리셋 **/
function setScrollPoint(){
	var category = getCookie("category"); //setCookie("category")로 세팅한 category 변수 명
	var scrollPoint = getCookie("scrollPoint"); //setCookie("scrollPoint")로 세팅한 스크롤 위치
	var currentCategory = "mainScrollPoint"; //이벤트 발생 후 새로 로드된 현재 페이지의 카테고리 지정
	 
	if (category != "" && category != 'undefined' && category == currentCategory && scrollPoint != "" && scrollPoint != 'undefined') {
	    
		window.scroll(0, scrollPoint); 
	}
	// 쿠키 삭제
	deleteCookie("category"); //또는 setCookie("category", "");
	deleteCookie("scrollPoint"); //또는 setCookie("scrollPoint", "");
}


