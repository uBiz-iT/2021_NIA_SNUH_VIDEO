$(document).ready(function() {
	
	/** date picker */
	datePicker($("#fromDate"));
	datePicker($("#toDate"));	

});

$(function(){
	
	if($("#search_yn").val() == 'Y'){
		fnSubSearch();
	}
	
})


var subPage = function(pageNo){
	if(pageNo == undefined || pageNo == "") pageNo = 1;
	
	var url = "image.title.search.do";
	
	var data = new Object();
	data.fromDate 	  = $('#fromDate').val(),
	data.toDate 	  = $('#toDate').val(),
	data.code_name 	  = $('#code_name').val(),
	data.sub_yn 	  = $('#sub_yn option:selected').val(),
	data.project_name = $('#project_name').val(),
	data.image_name   = $('#image_name').val(),
	data.refer_yn 	  = $('#refer_yn option:selected').val(),
	data.search_yn	  = $('#search_yn').val()
	data.page_no = pageNo;
	data.row_size = 10;
	
	var async = false;
	
	callAjax(url, data, async, function(json){
		createTableRowPage("imageTitleTable", json, pageNo, 10, "subPage");
	});
	
}


function fnSubSearch(){
	subPage(1);
}

function getImage(obj){
	
	var project_code = $(obj).closest("tr").find("td:eq(1)").text();
	$('.comment').css('display', 'block');
	
	$.jgrid.gridUnload("grid");
	
	$("#grid").jqGrid({

		url: 'image.search.do',
	    mtype : "POST",
	    datatype : 'json',
	    jsonReader : {
	    	root : "rows"
//	    	records : "pageCnt"
	    },
		postData : {
			project_cd : project_code
		},
//	    colNames:['이미지 ID','이미지 파일명','이미지보기','서브이미지 여부','등록일자'],
	    colNames:['환자번호', '성별', '나이', '이미지 개수'],
	    colModel:[
	              {name:'image_id'		,index:'image_id'		,width:300		,align:"center"},
	              {name:'di_gender'		,index:'di_gender'		,width:200		,align:"center"},
	              {name:'di_age'		,index:'di_age'			,width:200		,align:"center"},
	              {name:'sub_cnt'		,index:'sub_cnt'		,width:200		,align:"center"},
//	              {name:'image_name' 	,index:'image_name'  	,width:400  	,align:"left"},
//	              {name:'image_view' 	,index:'image_view'    	,width:100  	,align:"center"},
//	              {name:'sub_yn' 		,index:'sub_yn'    		,width:150  	,align:"center"},
//	              {name:'reg_dt'  		,index:'reg_dt'  		,width:150  	,align:"center"}
	             ],
	              
	    rowNum: parseInt($("#page_cnt1").val()),
	    rowList: [50,100,150, 200],
	    height: 350,
	    loadonce: true,
	    autowidth:true,    	 // jQgrid width 자동100% 채워지게
	    shrinkToFit:false,  // width를 자동설정 해주는 기능
	    gridview: true,
	    cmTemplate: { sortable: false },
	    rownumbers  : true,                     
	    pager: '#pager',
        ondblClickRow : function(rowId, iRow, iCol, e) {
        	var image_id = $("#grid").getCell(rowId, "image_id");
        	getSubImage2(image_id, project_code);
        },
        
        viewrecords: true,
        loadComplete : function(data){

        	$("#list_grid1 .ui-pg-selbox").change(function(){
        		$("#page_cnt1").val($(this).val());
        	})
        	
        },
        caption:" "
    	
    });
	
	$("#grid2").jqGrid('clearGridData', true);
	
}

/** 서울대 버전 **/
function getSubImage2(image_id, project_code){
	
	$.jgrid.gridUnload("grid2");
	 
	$("#grid2").jqGrid({
		url: 'image.sub.search.do',
	    mtype : "POST",
	    datatype : 'json',
	    jsonReader : {
	    	root : "rows"
//	    	records : "pageCnt"
	    },
		postData : {
			image_id : image_id,
			project_code : project_code
		},
	    colNames:['이미지 ID','이미지 파일명','이미지보기','원본이미지보기'],
	    colModel:[
	              {name:'image_id'		 ,index:'image_id'			,width:300		,align:"center"},
	              {name:'image_name' 	 ,index:'image_name'  		,width:300  	,align:"center"},
	              {name:'image_view' 	 ,index:'image_view'  		,width:150  	,align:"center"},
	              {name:'ori_image_view' ,index:'ori_image_view'  	,width:150  	,align:"center"},
//	              {name:'image_sub_id'	 ,index:'image_sub_id'		,width:200		,align:"center"},
//	              {name:'image_sub_name' ,index:'image_sub_name'  	,width:200  	,align:"left"},
//	              {name:'image_view' 	 ,index:'image_view'    	,width:100  	,align:"center"},
//	              {name:'reg_dt'  		 ,index:'reg_dt'  			,width:120  	,align:"center"}
	             ],
	              
	    rowNum: parseInt($("#page_cnt2").val()),
	    rowList: [50,100,150, 200],
	    height: 350,
	    loadonce: true,
	    autowidth:true,    	 // jQgrid width자동100% 채워지게
	    shrinkToFit:false,  // width를 자동설정 해주는 기능
	    gridview: true,
	    cmTemplate: { sortable: false },
	    rownumbers  : true,                     
	    pager: '#pager2',
        ondblClickRow : function(rowId, iRow, iCol, e) {
        	
        },
        
        viewrecords: true,
        loadComplete : function(data){
        	$("#grid2").jqGrid("hideCol", "ori_image_view");
        	
        	$("#list_grid2 .ui-pg-selbox").change(function(){
        		$("#page_cnt2").val($(this).val());
        	})
        	
        },
        caption:" "
	});
	
}

/** 건양대,아주대 버전 **/
function getSubImage(obj){

	var project_code = $(obj).closest("tr").find("td:eq(1)").text();
	
	$.jgrid.gridUnload("grid");
	
	$("#grid").jqGrid({

		url: 'image.sub.search.do',
	    mtype : "POST",
	    datatype : 'json',
	    jsonReader : {
	    	root : "rows"
//	    	records : "pageCnt"
	    },
		postData : {
			project_cd : project_code
		},
	    colNames:['이미지 ID','이미지 파일명','서브이미지 ID', '서브이미지 파일명','서브이미지보기','등록일자'],
	    colModel:[
	              {name:'image_id'		 ,index:'image_id'			,width:200		,align:"center"},
	              {name:'image_name' 	 ,index:'image_name'  		,width:200  	,align:"left"},
	              {name:'image_sub_id'	 ,index:'image_sub_id'		,width:200		,align:"center"},
	              {name:'image_sub_name' ,index:'image_sub_name'  	,width:200  	,align:"left"},
	              {name:'image_view' 	 ,index:'image_view'    	,width:100  	,align:"center"},
	              {name:'reg_dt'  		 ,index:'reg_dt'  			,width:120  	,align:"center"}
	             ],
	              
	    rowNum: 50,
	    rowList: [50,100,150, 200],
	    height: 350,
	    loadonce: true,
	    autowidth:true,    	 // jQgrid width 자동100% 채워지게
	    shrinkToFit:false,  // width를 자동설정 해주는 기능
	    gridview: true,
	    cmTemplate: { sortable: false },
	    rownumbers  : true,                     
	    pager: '#pager',
        ondblClickRow : function(rowId, iRow, iCol, e) {
        	
        },
        
        viewrecords: true,
        loadComplete : function(data){

        },
        caption:" "
    	
    });
	
}


function getRefImage(obj){

	var project_code = $(obj).closest("tr").find("td:eq(1)").text();
	
	$.jgrid.gridUnload("grid");
	
	$("#grid").jqGrid({

		url: 'image.ref.search.do',
	    mtype : "POST",
	    datatype : 'json',
	    jsonReader : {
	    	root : "rows"
//	    	records : "pageCnt"
	    },
		postData : {
			project_cd : project_code
		},
	    colNames:['참조이미지 ID','참조이미지 파일명','참조이미지보기','등록일자'],
	    colModel:[
	              {name:'image_id'		 ,index:'image_id'			,width:200		,align:"center"},
	              {name:'image_name' 	 ,index:'image_name'  		,width:400  	,align:"left"},
	              {name:'image_view' 	 ,index:'image_view'    	,width:120  	,align:"center"},
	              {name:'reg_dt'  		 ,index:'reg_dt'  			,width:120  	,align:"center"}
	             ],
	              
	    rowNum: 50,
	    rowList: [50,100,150, 200],
	    height: 350,
	    loadonce: true,
	    autowidth:true,    	 // jQgrid width 자동100% 채워지게
	    shrinkToFit:false,  // width를 자동설정 해주는 기능
	    gridview: true,
	    cmTemplate: { sortable: false },
	    rownumbers  : true,                     
	    pager: '#pager',
        ondblClickRow : function(rowId, iRow, iCol, e) {
        	
        },
        
        viewrecords: true,
        loadComplete : function(data){

        },
        caption:" "
    	
    });
	
} 


/** 이미지 팝업 **/
function imageView(image_dir, image_org_dir){
	
	var url = "/MLA_SNUH";
	url += "/image.imageView.do"
	url += "?image_dir="+image_dir;
	url += "&image_org_dir="+image_org_dir;
	
	openPopup(url, "840", "900", "POPUP_IMAGE_VIEW", "yes", "yes", "");
	
}


