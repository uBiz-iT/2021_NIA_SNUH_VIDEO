/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : LabelDetailVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 9. 14.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 9. 14.
 * @version : 1.0
 * 
 */
public class LabelDetailVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String code_name;       //프로젝트코드명
	private String project_name;    //프로젝트명
	private String target_cd; 		 //타겟코드
	private String target_nm;       //타겟명
	private String screen_loc;      //화면상위치
	private String reg_user_id;     //등록자
	
	public String getCode_name() {
		return code_name;
	}
	public void setCode_name(String code_name) {
		this.code_name = code_name;
	}
	public String getProject_name() {
		return project_name;
	}
	public void setProject_name(String project_name) {
		this.project_name = project_name;
	}
	public String getTarget_cd() {
		return target_cd;
	}
	public void setTarget_cd(String target_cd) {
		this.target_cd = target_cd;
	}
	public String getTarget_nm() {
		return target_nm;
	}
	public void setTarget_nm(String target_nm) {
		this.target_nm = target_nm;
	}
	public String getScreen_loc() {
		return screen_loc;
	}
	public void setScreen_loc(String screen_loc) {
		this.screen_loc = screen_loc;
	}
	public String getReg_user_id() {
		return reg_user_id;
	}
	public void setReg_user_id(String reg_user_id) {
		this.reg_user_id = reg_user_id;
	}
	
	
}
