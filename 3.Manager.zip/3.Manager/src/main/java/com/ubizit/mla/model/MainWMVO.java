/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : MainWeekVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 6. 7.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 6. 7.
 * @version : 1.0
 * 
 */
public class MainWMVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String wm;
	private String month;
	private String week_start;
	private String week_end;
	private String week_of_month;
	private String psg_cnt;
	private String work_cnt;
	private String pass_cnt;
	
	public String getWm() {
		return wm;
	}
	public void setWm(String wm) {
		this.wm = wm;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getWeek_start() {
		return week_start;
	}
	public void setWeek_start(String week_start) {
		this.week_start = week_start;
	}
	public String getWeek_end() {
		return week_end;
	}
	public void setWeek_end(String week_end) {
		this.week_end = week_end;
	}
	public String getWeek_of_month() {
		return week_of_month;
	}
	public void setWeek_of_month(String week_of_month) {
		this.week_of_month = week_of_month;
	}
	public String getPsg_cnt() {
		return psg_cnt;
	}
	public void setPsg_cnt(String psg_cnt) {
		this.psg_cnt = psg_cnt;
	}
	public String getWork_cnt() {
		return work_cnt;
	}
	public void setWork_cnt(String work_cnt) {
		this.work_cnt = work_cnt;
	}
	public String getPass_cnt() {
		return pass_cnt;
	}
	public void setPass_cnt(String pass_cnt) {
		this.pass_cnt = pass_cnt;
	}
	

}
