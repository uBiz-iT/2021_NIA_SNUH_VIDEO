/**
 * 
 */
package com.ubizit.mla.service.impl;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

/**
 * @Class Name : UserDAO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
@Repository("userDAO")
public class UserDAO extends EgovAbstractDAO{

	private static final Logger LOGGER = LoggerFactory.getLogger(UserDAO.class);
	
	/**
	 * Method : getUserSearchList
	 * 최초작성일 : 2020. 9. 8.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 사용자 리스트 조회
	 */
	public void getUserSearchList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> UserDAO.getUserSearchList >>>>>>");
		System.out.println(">>>>>> UserDAO.getUserSearchList >>>>>>");
		
		select("user.search", map);
	}

	/**
	 * Method : saveUserList
	 * 최초작성일 : 2021. 6. 18.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 사용자 저장
	 */
	public void saveUserList(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> UserDAO.saveUserList >>>>>>");
		System.out.println(">>>>>> UserDAO.saveUserList >>>>>>");
		
		select("user.save", map);
	}

	/**
	 * Method : userExcelDown
	 * 최초작성일 : 2021. 8. 3.
	 * 작성자 : 장두언
	 * 변경이력 :
	 * @return
	 * Method 설명 : 검수자 현황 엑셀 다운로드
	 */
	public List<Map<String, Object>> userExcelDown(Map<String, Object> map) throws Exception{
		LOGGER.debug(">>>>>> UserDAO.userExcelDown >>>>>>");
		System.out.println(">>>>>> UserDAO.userExcelDown >>>>>>");
		
		return (List<Map<String, Object>>) list("manage.user.excelDown",map);
	}

}
