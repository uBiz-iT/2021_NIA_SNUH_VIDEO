/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : LabelVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
public class LabelVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String label_cd;		//라벨코드
	private String label_desc;		//라벨명
	private String mark_rgb;		//마크 색상
	private String reg_user_id;	//등록자
	private String reg_dt;			//등록일자
	
	public String getLabel_cd() {
		return label_cd;
	}
	public void setLabel_cd(String label_cd) {
		this.label_cd = label_cd;
	}
	public String getLabel_desc() {
		return label_desc;
	}
	public void setLabel_desc(String label_desc) {
		this.label_desc = label_desc;
	}
	public String getMark_rgb() {
		return mark_rgb;
	}
	public void setMark_rgb(String mark_rgb) {
		this.mark_rgb = mark_rgb;
	}
	public String getReg_user_id() {
		return reg_user_id;
	}
	public void setReg_user_id(String reg_user_id) {
		this.reg_user_id = reg_user_id;
	}
	public String getReg_dt() {
		return reg_dt;
	}
	public void setReg_dt(String reg_dt) {
		this.reg_dt = reg_dt;
	}
	
	
	
}
