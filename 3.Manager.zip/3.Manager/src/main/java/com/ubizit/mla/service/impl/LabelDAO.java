/**
 * 
 */
package com.ubizit.mla.service.impl;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.ubizit.mla.model.TargetVO;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

/**
 * @Class Name : LabelDAO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 5. 12.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 5. 12.
 * @version : 1.0
 *
 */
@Repository("labelDAO")
public class LabelDAO extends EgovAbstractDAO{

	private static final Logger LOGGER = LoggerFactory.getLogger(LabelDAO.class);

	/**
	 * Method : getLabelSearchList
	 * 최초작성일 : 2021. 5. 12.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 타겟별 라벨 목록 데이터 가져오기
	 */
	public void getLabelSearchList(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> LabelServiceImpl.getLabelSearchList >>>>>>");
		System.out.println(">>>>>> LabelServiceImpl.getLabelSearchList >>>>>>");
		
		select("label.target.search", map);
	}

	/**
	 * Method : getTargetInfo
	 * 최초작성일 : 2021. 5. 12.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param mission_cd
	 * @return
	 * Method 설명 : 미션코드에 해당하는 타겟 정보 가져오기
	 */
	public List<TargetVO> getTargetInfo(String mission_cd) throws Exception{
		LOGGER.info(">>>>>> LabelServiceImpl.getTargetInfo >>>>>>");
		System.out.println(">>>>>> LabelServiceImpl.getTargetInfo >>>>>>");
		
		return (List<TargetVO>) list("labelDAO.target.info", mission_cd);
	}

	/**
	 * Method : saveLabelList
	 * 최초작성일 : 2021. 5. 17.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 라벨 등록 현황에서 변경된 라벨 내용 저장하기 위한 기능
	 */
	public void saveLabelList(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> LabelServiceImpl.saveLabelList >>>>>>");
		System.out.println(">>>>>> LabelServiceImpl.saveLabelList >>>>>>");
		
		update("label.save", map);
	}
	
	

}
