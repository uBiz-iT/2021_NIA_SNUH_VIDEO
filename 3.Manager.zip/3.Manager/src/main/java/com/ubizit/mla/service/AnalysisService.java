/**
 * 
 */
package com.ubizit.mla.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

/**
 * @Class Name : AnalysisService.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
public interface AnalysisService {

	/**
	 * Method : getProjectList
	 * 최초작성일 : 2020. 9. 16.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * Method 설명 : 프로젝트 조회
	 */
	List<?> getProjectList(String project_cd) throws Exception;

	/**
	 * Method : getSelectItemsList
	 * 최초작성일 : 2020. 9. 17.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트, 판독자, 라벨링차수, 타겟 리스트..
	 */
	void getSelectItemsList(Map<String, Object> map) throws Exception;

	/**
	 * Method : getStartAnalysis
	 * 최초작성일 : 2020. 9. 21.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 분석 결과
	 */
	void getStartAnalysis(Map<String, Object> map) throws Exception;

	/**
	 * Method : getConsistencyAnalysis
	 * 최초작성일 : 2020. 11. 2.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 일치도 그래프
	 */
	void getConsistencyAnalysis(Map<String, Object> map) throws Exception;

	/**
	 * Method : getLabelingAnalysis
	 * 최초작성일 : 2020. 11. 2.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 라벨링 작업량
	 */
	void getLabelingAnalysis(Map<String, Object> map) throws Exception;

	/**
	 * Method : getCrossChkAnalysis
	 * 최초작성일 : 2020. 11. 5.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 이미지 세트별 크로스체크
	 */
	void getCrossChkAnalysis(Map<String, Object> map) throws Exception;

	/**
	 * Method : getConsistencyCrossChk
	 * 최초작성일 : 2020. 11. 5.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 일치도 그래프
	 */
	void getConsistencyCrossChk(Map<String, Object> map) throws Exception;

	/**
	 * Method : getLabelingCrossChk
	 * 최초작성일 : 2020. 11. 5.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 라벨링 작업량
	 */
	void getLabelingCrossChk(Map<String, Object> map) throws Exception;

	/**
	 * Method : selectAnalysisExcelDown
	 * 최초작성일 : 2021. 3. 15.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * Method 설명 : 프로젝트별 교차 검증 pass/non-pass 엑셀다운로드
	 */
	List<Map<String, Object>> selectAnalysisExcelDown(Map<String, Object> map) throws SQLException;

	/**
	 * Method : selectAnalysisExcelCnt
	 * 최초작성일 : 2021. 3. 15.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param param
	 * @return
	 * Method 설명 : 프로젝트별 교차 검증 pass/non-pass 판독자 수
	 */
	int selectAnalysisExcelCnt(Map<String, Object> map) throws Exception;

	/**
	 * Method : crossChkList
	 * 최초작성일 : 2021. 7. 9.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 검수 결과 크로스 체크
	 */
	void crossChkList(Map<String, Object> map) throws Exception;

	/**
	 * Method : psgUser
	 * 최초작성일 : 2021. 7. 13.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param jsonObject
	 * @return
	 * Method 설명 : 검수자 목록
	 */
	List<Map<String, Object>> psgUser(JSONObject jsonObject) throws Exception;

	/**
	 * Method : eventList
	 * 최초작성일 : 2021. 7. 13.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 크로스체크 이벤트 리스트
	 */
	void eventList(Map<String, Object> map) throws Exception;

	/**
	 * Method : eventExcelDown
	 * 최초작성일 : 2021. 8. 10.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * @return
	 * Method 설명 : 이벤트 검수 결과 엑셀 다운로드
	 */
	List<Map<String, Object>> eventExcelDown(Map<String, Object> map) throws Exception;

	/**
	 * Method : videoPath
	 * 최초작성일 : 2021. 8. 11.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param jsonObject
	 * @return
	 * Method 설명 : video 경로
	 */
	Map<String, Object> videoPath(JSONObject jsonObject) throws Exception;


}
