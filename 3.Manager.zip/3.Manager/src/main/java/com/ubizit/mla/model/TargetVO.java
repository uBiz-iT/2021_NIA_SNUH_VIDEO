/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : TargetVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 5. 12.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 5. 12.
 * @version : 1.0
 * 
 */
public class TargetVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String target_cd;	//타겟코드
	private String target_nm;	//타켓명
	
	public String getTarget_cd() {
		return target_cd;
	}
	public void setTarget_cd(String target_cd) {
		this.target_cd = target_cd;
	}
	public String getTarget_nm() {
		return target_nm;
	}
	public void setTarget_nm(String target_nm) {
		this.target_nm = target_nm;
	}
	

}
