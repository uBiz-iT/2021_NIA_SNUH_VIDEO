/**
 * 
 */
package com.ubizit.mla.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ubizit.mla.model.UserReqVO;
import com.ubizit.mla.model.UserVO;
import com.ubizit.mla.service.UserService;
import com.ubizit.mla.util.ExcelUtil;
import com.ubizit.mla.util.StringUtil;

import net.sf.json.JSONObject;

/**
 * @Class Name : UserController.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
@Controller
public class UserController {

	/** UserService **/
	@Resource(name="userService")
	private UserService userService;
	
	private final static Logger logger = Logger.getLogger(UserController.class);
	
	/**
	 * Method : userList
	 * 최초작성일 : 2020. 9. 8.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * @throws Exception
	 * Method 설명 : 사용자 등록관리 메인 화면
	 */
	@RequestMapping(value="/manage.userList.do")
	public String userList(ModelMap model, HttpServletRequest request) throws Exception {
		logger.debug(">>>>>> UserController >>>>>>");
		System.out.println(">>>>>> UserController >>>>>>");
		
		if(StringUtil.isNotBlank(request.getParameter("userId"))){
			model.addAttribute("userId", request.getParameter("userId"));
		}
		if(StringUtil.isNotBlank(request.getParameter("userNm"))){
			model.addAttribute("userNm", request.getParameter("userNm"));
		}
		if(StringUtil.isNotBlank(request.getParameter("page_cnt"))){
			model.addAttribute("page_cnt", request.getParameter("page_cnt"));
		}else{
			model.addAttribute("page_cnt", 10);
		}
		
		return "user_list";
	}
	
	/**
	 * Method : getSearchList
	 * 최초작성일 : 2020. 9. 8.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 검색조건 조회
	 */
	@RequestMapping(value="/manage.user.search.do")
	@ResponseBody
	public Map<String, Object> getSearchList(HttpServletRequest request) throws Exception {
		logger.debug(">>>>>> UserController.getSearchList() >>>>>>");
		System.out.println(">>>>>> UserController.getSearchList() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<UserVO> p_ret_json = new ArrayList<>();
		
		String userId 	= ((String[])paramMap.get("userId"))[0];
		String userNm 	= ((String[])paramMap.get("userNm"))[0];		
		
		jsonObject.put("USER_ID", userId);
		jsonObject.put("USER_NM", userNm);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		userService.getUserSearchList(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<UserVO>) resultMap.get("p_ret_json");
			
			for(int i = 0; i < p_ret_json.size(); i++){
				String user_nm 		= p_ret_json.get(i).getUser_nm();
				String is_manager 	= p_ret_json.get(i).getIs_manager();
				String delete_fg 	= p_ret_json.get(i).getDelete_fg();
				String passwd       = p_ret_json.get(i).getPasswd();
				
				user_nm = "<input type='text' class='input_text' value='"+user_nm+"'/>";
				passwd = "<input type='text' class='input_text' value='"+passwd+"'/>";
				if(is_manager.equals("Y")){
					is_manager = "<input type='checkbox' checked/>";
				}else{
					is_manager = "<input type='checkbox'/>";
				}
				if(delete_fg.equals("Y")){
					delete_fg = "<input type='checkbox' checked/>";
				}else{
					delete_fg = "<input type='checkbox'/>";
				}
				
				p_ret_json.get(i).setUser_nm(user_nm);
				p_ret_json.get(i).setIs_manager(is_manager);
				p_ret_json.get(i).setDelete_fg(delete_fg);
				p_ret_json.get(i).setPasswd(passwd);
			}
			
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
	}

	
	/**
	 * Method : updateUserList
	 * 최초작성일 : 2021. 6. 18.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 사용자 정보 저장
	 */
	@RequestMapping(value="/manage.user.save.do")
	@ResponseBody
	public Map<String, Object> saveUserList(HttpServletRequest request, HttpSession session) throws Exception {
		logger.debug(">>>>>> UserController.saveUserList() >>>>>>");
		System.out.println(">>>>>> UserController.saveUserList() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		String p_ret_msg = "";
		int p_ret_code = 0;
		
		String reg_user_id = (String) session.getAttribute("user_id");
		String user_list = ((String[])paramMap.get("user_list"))[0];
		
		jsonObject.put("REG_USER_ID", reg_user_id);
		jsonObject.put("USER_LIST", user_list);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		userService.saveUserList(resultMap);
		
		p_ret_msg = (String) resultMap.get("p_ret_msg");
		p_ret_code = (int) resultMap.get("p_ret_code");
		
		/** return map **/
		map.put("p_ret_msg", p_ret_msg);
		map.put("p_ret_code", p_ret_code);
		
		return map;
	}
	
	/**
	 * Method : userExcelDown
	 * 최초작성일 : 2021. 8. 3.
	 * 작성자 : 장두언
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 검수자 현황 엑셀 다운로드
	 */
	@RequestMapping(value="/manage.user.excelDown.do")
	@ResponseBody
	public Map<String, Object> userExcelDown(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(">>>>>> UserController.userExcelDown() >>>>>>");
		System.out.println(">>>>>> UserController.userExcelDown() >>>>>>");
		
		
		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");
		
		/** Object 선언 **/
		Map<String, Object> map = new HashMap<>();
		Map<?, ?> paramMap = request.getParameterMap();	
		
		String userId = ((String[])paramMap.get("userId"))[0];
		String userNm = ((String[])paramMap.get("userNm"))[0];
		
		map.put("userId", userId);
		map.put("userNm", userNm);
		
		List<Map<String,Object>> dataList = userService.userExcelDown(map);
		
		List<String> logical_list = new ArrayList();
		logical_list.add("검수자 ID");
		logical_list.add("검수자 이름");
		logical_list.add("관리자 여부");
		logical_list.add("등록자");
		logical_list.add("삭제 여부");
		
		List<String> physical_list = new ArrayList();
		physical_list.add("USER_ID");
		physical_list.add("USER_NM");
		physical_list.add("IS_MANAGER");
		physical_list.add("REG_USER_ID");
		physical_list.add("DELETE_FG");
		
		
		int[] type_int = null;
		int[][] cellRangeAddress = null;
		
		String downFileName = "검수자_현황_"+StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] logical_names = logical_list.toArray(new String[logical_list.size()]);
		String[] physical_names = physical_list.toArray(new String[physical_list.size()]);
		
		int[] widths = new int[logical_names.length];
		
		for(int i = 0; i < logical_names.length; i++){
			widths[i] = 25;
		}
		
		ExcelUtil.excelDownload(response, cellRangeAddress, logical_names, physical_names, widths, type_int, downFileName, dataList);
		
		map.put("result", "Y");
		
		return map;
	}	
	
}










