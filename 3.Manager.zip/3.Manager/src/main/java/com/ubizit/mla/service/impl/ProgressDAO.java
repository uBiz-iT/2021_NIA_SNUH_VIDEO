/**
 * 
 */
package com.ubizit.mla.service.impl;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

/**
 * @Class Name : ProgressDAO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
@Repository("progressDAO")
public class ProgressDAO extends EgovAbstractDAO{

	private static final Logger LOGGER = LoggerFactory.getLogger(ProgressDAO.class);

	/**
	 * Method : getProgressProjectSearchList
	 * 최초작성일 : 2020. 9. 24.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트 진행률 리스트 조회
	 */
	public void getProgressProjectSearchList(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> ProgressDAO.getProgressProjectSearchList >>>>>>");
		System.out.println(">>>>>> ProgressDAO.getProgressProjectSearchList >>>>>>");
		
		select("progress.project.search", map);
	}

	/**
	 * Method : getProjectProgress
	 * 최초작성일 : 2020. 9. 24.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트 차트 진행률
	 */
	public void getProjectProgress(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> ProgressDAO.getProjectProgress >>>>>>");
		System.out.println(">>>>>> ProgressDAO.getProjectProgress >>>>>>");
		
		select("progress.project.chart", map);
	}

	/**
	 * Method : getProgressUserSearchList
	 * 최초작성일 : 2020. 9. 25.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 유저 진행률 리스트 조회
	 */
	public void getProgressUserSearchList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProgressDAO.getProgressUserSearchList >>>>>>");
		System.out.println(">>>>>> ProgressDAO.getProgressUserSearchList >>>>>>");
		
		select("progress.user.search", map);
	}

	/**
	 * Method : getUserProgress
	 * 최초작성일 : 2020. 9. 25.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 유저 차트 진행률
	 */
	public void getUserProgress(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProgressDAO.getUserProgress >>>>>>");
		System.out.println(">>>>>> ProgressDAO.getUserProgress >>>>>>");
	
		select("progress.user.chart", map);
	}

	/**
	 * Method : getTotalSearch
	 * 최초작성일 : 2020. 12. 22.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트 총 진행률/라벨링 및 프로젝트 완료 건수
	 */
	public void getTotalSearch(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProgressDAO.getTotalSearch >>>>>>");
		System.out.println(">>>>>> ProgressDAO.getTotalSearch >>>>>>");
		
		select("progress.project.total", map);
	}

	/**
	 * Method : selectProjectExcel
	 * 최초작성일 : 2020. 12. 23.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * @return
	 * Method 설명 : 프로젝트 진행률에서 엑셀 다운로드
	 */
	public List<Map<String, Object>> selectProjectExcel(Map<String, Object> map) throws SQLException {
		LOGGER.info(">>>>>> ProgressDAO.selectProjectExcel >>>>>>");
		System.out.println(">>>>>> ProgressDAO.selectProjectExcel >>>>>>");
		
		return (List<Map<String, Object>>) list("progress.project.excelDown", map);
	}

	/**
	 * Method : selectProjectExcelCnt
	 * 최초작성일 : 2020. 12. 23.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * @return
	 * Method 설명 : 프로젝트 진행률에서 판독자 수
	 */
	public int selectProjectExcelCnt(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> ProgressDAO.selectProjectExcelCnt >>>>>>");
		System.out.println(">>>>>> ProgressDAO.selectProjectExcelCnt >>>>>>");
		
		return (int) select("progress.project.excelDown.cnt", map);
	}

	/**
	 * Method : progressProjectPopupTotal
	 * 최초작성일 : 2021. 1. 4.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트 진행률 화면의 팝업창 상단 데이터
	 */
	public void progressProjectPopupTotal(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProgressDAO.progressProjectPopupTotal >>>>>>");
		System.out.println(">>>>>> ProgressDAO.progressProjectPopupTotal >>>>>>");
	
		select("progress.project.popup.total", map);
	}

	/**
	 * Method : progressProjectPopupChart1
	 * 최초작성일 : 2021. 1. 5.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트 진행률 화면의 팝업창 판독자 accept, reject 데이터
	 */
	public void progressProjectPopupChart1(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> ProgressDAO.progressProjectPopupTotal >>>>>>");
		System.out.println(">>>>>> ProgressDAO.progressProjectPopupTotal >>>>>>");
	
		select("progress.project.popup.chart1", map);
	}

	/**
	 * Method : progressProjectPopupChart2
	 * 최초작성일 : 2021. 1. 5.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 일치도(accept, reject), 불일치도, 미완료건수
	 */
	public void progressProjectPopupChart2(Map<String, Object> map) {
		LOGGER.info(">>>>>> ProgressDAO.progressProjectPopupChart2 >>>>>>");
		System.out.println(">>>>>> ProgressDAO.progressProjectPopupChart2 >>>>>>");
	
		select("progress.project.popup.chart2", map);
		
	}

	/**
	 * Method : progressProjectPopupData
	 * 최초작성일 : 2021. 1. 6.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param param
	 * @return
	 * Method 설명 : 데이터셋 Accept, Reject 표
	 */
	public List<Map<String, Object>> progressProjectPopupData(String param) throws Exception{
		LOGGER.info(">>>>>> ProgressDAO.progressProjectPopupData >>>>>>");
		System.out.println(">>>>>> ProgressDAO.progressProjectPopupData >>>>>>");
		
		return (List<Map<String, Object>>) list("progress.project.popup.data", param);
	}

	/**
	 * Method : progressProjectPoupDataset
	 * 최초작성일 : 2021. 1. 6.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 데이터셋 Accept, Reject 표
	 */
	public void progressProjectPoupDataset(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> ProgressDAO.progressProjectPoupDataset >>>>>>");
		System.out.println(">>>>>> ProgressDAO.progressProjectPoupDataset >>>>>>");
	
		select("progress.project.popup.dataset", map);
	}

	/**
	 * Method : progressProjectUser
	 * 최초작성일 : 2021. 1. 6.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param project_cd
	 * @return
	 * Method 설명 : 데이터셋 Accept, Reject 표의 유저
	 */
	public List<Map<String, Object>> progressProjectUser(String project_cd) throws Exception{
		LOGGER.info(">>>>>> ProgressDAO.progressProjectUser >>>>>>");
		System.out.println(">>>>>> ProgressDAO.progressProjectUser >>>>>>");
		
		return (List<Map<String, Object>>) list("progress.project.popup.user", project_cd);
	}

	/**
	 * Method : selectProjectPassExDownSelect
	 * 최초작성일 : 2021. 1. 15.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * Method 설명 : Accept(Pass) 건 전체 프로젝트 엑셀다운로드
	 */
	public List<Map<String, Object>> selectProjectPassExDownSelect() throws Exception{
		LOGGER.info(">>>>>> ProgressDAO.selectProjectPassExDownSelect >>>>>>");
		System.out.println(">>>>>> ProgressDAO.selectProjectPassExDownSelect >>>>>>");
		
		return (List<Map<String, Object>>) list("progress.project.pass.exDownSelect");
	}
	
	/**
	 * Method : selectProjectPassExDownSelect
	 * 최초작성일 : 2021. 1. 15.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * Method 설명 : Reject(Non-Pass) 건 전체 프로젝트 엑셀다운로드
	 */
	public List<Map<String, Object>> selectProjectNonPassExDownSelect() throws Exception{
		LOGGER.info(">>>>>> ProgressDAO.selectProjectNonPassExDownSelect >>>>>>");
		System.out.println(">>>>>> ProgressDAO.selectProjectNonPassExDownSelect >>>>>>");
		
		return (List<Map<String, Object>>) list("progress.project.nonPass.exDownSelect");
	}

	/**
	 * Method : selectProjectPNExDownSelect
	 * 최초작성일 : 2021. 2. 18.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * Method 설명 :
	 */
	public List<Map<String, Object>> selectProjectPNExDownSelect() throws Exception{
		LOGGER.info(">>>>>> ProgressDAO.selectProjectPNExDownSelect >>>>>>");
		System.out.println(">>>>>> ProgressDAO.selectProjectPNExDownSelect >>>>>>");
		
		return (List<Map<String, Object>>) list("progress.project.pn.exDownSelect");
	}

	/**
	 * Method : progressProjectViewTotal
	 * 최초작성일 : 2021. 6. 30.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 검수 완료/PASS/FAIL/미완료
	 */
	public void progressProjectViewTotal(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> ProgressDAO.selectProjectPNExDownSelect >>>>>>");
		System.out.println(">>>>>> ProgressDAO.selectProjectPNExDownSelect >>>>>>");
		
		select("progress.project.view.total", map);
	}

	/**
	 * Method : progressProjectViewChart1
	 * 최초작성일 : 2021. 7. 5.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 검수자 PASS, FAIL 그래프
	 */
	public void progressProjectViewChart1(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> ProgressDAO.progressProjectViewChart1 >>>>>>");
		System.out.println(">>>>>> ProgressDAO.progressProjectViewChart1 >>>>>>");
		
		select("progress.pro.view.chart1", map);
	}

	/**
	 * Method : progressProjectViewChart2
	 * 최초작성일 : 2021. 7. 5.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : PASS, FAIL 일치 비율 그래프
	 */
	public void progressProjectViewChart2(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> ProgressDAO.progressProjectViewChart2 >>>>>>");
		System.out.println(">>>>>> ProgressDAO.progressProjectViewChart2 >>>>>>");
		
		select("progress.pro.view.chart2", map);
	}

	/**
	 * Method : progressUserViewTotal
	 * 최초작성일 : 2021. 7. 8.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 검수 완료/PASS/FAIL/미완료
	 */
	public void progressUserViewTotal(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> ProgressDAO.progressProjectViewChart2 >>>>>>");
		System.out.println(">>>>>> ProgressDAO.progressProjectViewChart2 >>>>>>");
		
		select("progress.user.view.total", map);
	}

	/**
	 * Method : progressUserViewChart1
	 * 최초작성일 : 2021. 7. 8.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : PSG 검수 및 이벤트 진행
	 */
	public void progressUserViewChart1(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> ProgressDAO.progressUserViewChart1 >>>>>>");
		System.out.println(">>>>>> ProgressDAO.progressUserViewChart1 >>>>>>");
		
		select("progress.user.view.chart1", map);
	}

	/**
	 * Method : progressUserViewChart2
	 * 최초작성일 : 2021. 7. 8.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트별 PASS, FAIL
	 */
	public void progressUserViewChart2(Map<String, Object> map) throws Exception{
		LOGGER.info(">>>>>> ProgressDAO.progressUserViewChart2 >>>>>>");
		System.out.println(">>>>>> ProgressDAO.progressUserViewChart2 >>>>>>");
		
		select("progress.user.view.chart2", map);
	}

	/**
	 * Method : projectListExcelDown
	 * 최초작성일 : 2021. 8. 4.
	 * 작성자 : 장두언
	 * 변경이력 :
	 * @return
	 * Method 설명 : 프로젝트 진행 목록 엑셀 다운로드
	 */
	public List<Map<String, Object>> projectListExcelDown(Map<String, Object> map) throws Exception{
		LOGGER.debug(">>>>>> ProgressDAO.projectListExcelDown >>>>>>");
		System.out.println(">>>>>> ProgressDAO.projectListExcelDown >>>>>>");
		
		return (List<Map<String, Object>>) list("progress.project.list.excelDown", map);
	}
	
	/**
	 * Method : userListExcelDown
	 * 최초작성일 : 2021. 8. 4.
	 * 작성자 : 장두언
	 * 변경이력 :
	 * @return
	 * Method 설명 : 검수자 진행 현황 엑셀 다운로드
	 */
	public List<Map<String, Object>> userListExcelDown(Map<String, Object> map) throws Exception{
		LOGGER.debug(">>>>>> ProgressDAO.userListExcelDown >>>>>>");
		System.out.println(">>>>>> ProgressDAO.userListExcelDown >>>>>>");
		
		return (List<Map<String, Object>>) list("progress.user.list.excelDown", map);
	}

	
}
