/**
 * 
 */
package com.ubizit.mla.service.impl;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

/**
 * @Class Name : ProjectDAO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
@Repository("projectDAO")
public class ProjectDAO extends EgovAbstractDAO{

	private static final Logger LOGGER = LoggerFactory.getLogger(ProjectDAO.class);
	
	/**
	 * Method : getProjectSearchList
	 * 최초작성일 : 2020. 9. 3.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트 리스트 조회
	 */
	public void getProjectSearchList(Map<String, Object> map) throws Exception {
		LOGGER.debug(">>>>>> ProjectDAO.getProjectSearchList >>>>>>");
		System.out.println(">>>>>> ProjectDAO.getProjectSearchList >>>>>>");
		
		select("project.search", map);
	}

	/**
	 * Method : getProjectDetailView
	 * 최초작성일 : 2020. 9. 14.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트 상세화면
	 */
	public void getProjectDetailView(Map<String, Object> map) throws Exception {
		LOGGER.debug(">>>>>> ProjectDAO.getProjectDetailView >>>>>>");
		System.out.println(">>>>>> ProjectDAO.getProjectDetailView >>>>>>");
		
		select("project.detail.search", map);
	
	}

	/**
	 * Method : getProjectReadManager
	 * 최초작성일 : 2020. 9. 14.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 판독 담당자 조회
	 */
	public void getProjectReadManager(Map<String, Object> map) throws Exception {
		LOGGER.debug(">>>>>> ProjectDAO.getProjectReadManager >>>>>>");
		System.out.println(">>>>>> ProjectDAO.getProjectReadManager >>>>>>");
		
		select("project.read.manager", map);
	}

	/**
	 * Method : getProjectReadUser
	 * 최초작성일 : 2020. 9. 14.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 일반 판독자 조회
	 */
	public void getProjectReadUser(Map<String, Object> map) throws Exception {
		LOGGER.debug(">>>>>> ProjectDAO.getProjectReadUser >>>>>>");
		System.out.println(">>>>>> ProjectDAO.getProjectReadUser >>>>>>");
		
		select("project.read.user", map);
	}

	/**
	 * Method : insertProject
	 * 최초작성일 : 2020. 9. 28.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트 등록
	 */
	public void insertProject(Map<String, Object> map) throws Exception{
		LOGGER.debug(">>>>>> ProjectDAO.insertProject >>>>>>");
		System.out.println(">>>>>> ProjectDAO.insertProject >>>>>>");
		
		insert("project.insert", map);
	}

	/**
	 * Method : updateProject
	 * 최초작성일 : 2020. 9. 29.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트 수정
	 */
	public void updateProject(Map<String, Object> map) throws Exception{
		LOGGER.debug(">>>>>> ProjectDAO.updateProject >>>>>>");
		System.out.println(">>>>>> ProjectDAO.updateProject >>>>>>");
	
		update("project.update", map);
	}

	/**
	 * Method : getUserSearch
	 * 최초작성일 : 2020. 10. 8.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param userName
	 * @return
	 * Method 설명 : 판독자 조회 (팝업)
	 */
	public List<?> getUserSearch(String userName) throws Exception {
		LOGGER.debug(">>>>>> ProjectDAO.getUserSearch >>>>>>");
		System.out.println(">>>>>> ProjectDAO.getUserSearch >>>>>>");
		
		return list("projectDAO.user.search", userName);
	}

	/**
	 * Method : projectExcelDown
	 * 최초작성일 : 2021. 8. 3.
	 * 작성자 : 장두언
	 * 변경이력 :
	 * @return
	 * Method 설명 : 프로젝트 현황 엑셀 다운로드
	 */
	public List<Map<String, Object>> projectExcelDown(Map<String, Object> map) throws Exception{
		LOGGER.debug(">>>>>> ProjectDAO.projectExcelDown >>>>>>");
		System.out.println(">>>>>> ProjectDAO.projectExcelDown >>>>>>");
		
		return (List<Map<String, Object>>) list("project.excelDown",map);
	}

}
