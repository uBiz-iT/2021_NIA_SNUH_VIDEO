/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : ProjectReqVO.java
 * @Description : 프로젝트 현황 조회 시 검색 조건
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 5. 10.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 5. 10.
 * @version : 1.0
 *
 */
public class ProjectReqVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String project_cd;			//프로젝트코드
	private String project_nm;			//프로젝트명
	private String complete_yn;		//프로젝트 완료 여부
	private String delete_fg;			//삭제여부
	
	public String getProject_cd() {
		return project_cd;
	}
	public void setProject_cd(String project_cd) {
		this.project_cd = project_cd;
	}
	public String getProject_nm() {
		return project_nm;
	}
	public void setProject_nm(String project_nm) {
		this.project_nm = project_nm;
	}
	public String getComplete_yn() {
		return complete_yn;
	}
	public void setComplete_yn(String complete_yn) {
		this.complete_yn = complete_yn;
	}
	public String getDelete_fg() {
		return delete_fg;
	}
	public void setDelete_fg(String delete_fg) {
		this.delete_fg = delete_fg;
	}
	
	
}
