/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : PgUserVeCt1VO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 7. 8.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 7. 8.
 * @version : 1.0
 * 
 */
public class PgUserVeCt1VO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String project_cd;
	private String psg_cnt;
	private String work_cnt;
	
	public String getProject_cd() {
		return project_cd;
	}
	public void setProject_cd(String project_cd) {
		this.project_cd = project_cd;
	}
	public String getPsg_cnt() {
		return psg_cnt;
	}
	public void setPsg_cnt(String psg_cnt) {
		this.psg_cnt = psg_cnt;
	}
	public String getWork_cnt() {
		return work_cnt;
	}
	public void setWork_cnt(String work_cnt) {
		this.work_cnt = work_cnt;
	}
	
}
