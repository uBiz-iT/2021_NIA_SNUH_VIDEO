/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : ErrorVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
public class ErrorVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String issue_dt;		//발생일자
	private String proc_nm;		//실행 프로시저명
	private String error_code;		//에러코드명
	private String error_msg;		//에러메세지
    private String error_data;		//데이터
    
	public String getIssue_dt() {
		return issue_dt;
	}
	public void setIssue_dt(String issue_dt) {
		this.issue_dt = issue_dt;
	}
	public String getProc_nm() {
		return proc_nm;
	}
	public void setProc_nm(String proc_nm) {
		this.proc_nm = proc_nm;
	}
	public String getError_code() {
		return error_code;
	}
	public void setError_code(String error_code) {
		this.error_code = error_code;
	}
	public String getError_msg() {
		return error_msg;
	}
	public void setError_msg(String error_msg) {
		this.error_msg = error_msg;
	}
	public String getError_data() {
		return error_data;
	}
	public void setError_data(String error_data) {
		this.error_data = error_data;
	}
    
    
}
