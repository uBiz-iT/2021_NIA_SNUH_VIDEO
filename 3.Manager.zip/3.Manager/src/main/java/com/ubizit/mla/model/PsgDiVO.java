/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : PsgDiVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 6. 16.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 6. 16.
 * @version : 1.0
 * 
 */
public class PsgDiVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String project_cd;
	private String psg_id;
	private String di_gender;
	private String di_age;
	private String di_bmi;
	private String di_tot_sleep_time;
	private String di_sleep_effi;
	private String di_sleep_latency;
	private String di_ahi;
	private String di_tot_lm_index;
	private String di_tot_lm_arou;
	private String di_arou_index;
	private String di_rdi;
	private String di_oxy_satu_avg;
	private String di_oxy_satu_min;
	
	public String getProject_cd() {
		return project_cd;
	}
	public void setProject_cd(String project_cd) {
		this.project_cd = project_cd;
	}
	public String getPsg_id() {
		return psg_id;
	}
	public void setPsg_id(String psg_id) {
		this.psg_id = psg_id;
	}
	public String getDi_gender() {
		return di_gender;
	}
	public void setDi_gender(String di_gender) {
		this.di_gender = di_gender;
	}
	public String getDi_age() {
		return di_age;
	}
	public void setDi_age(String di_age) {
		this.di_age = di_age;
	}
	public String getDi_bmi() {
		return di_bmi;
	}
	public void setDi_bmi(String di_bmi) {
		this.di_bmi = di_bmi;
	}
	public String getDi_tot_sleep_time() {
		return di_tot_sleep_time;
	}
	public void setDi_tot_sleep_time(String di_tot_sleep_time) {
		this.di_tot_sleep_time = di_tot_sleep_time;
	}
	public String getDi_sleep_effi() {
		return di_sleep_effi;
	}
	public void setDi_sleep_effi(String di_sleep_effi) {
		this.di_sleep_effi = di_sleep_effi;
	}
	public String getDi_sleep_latency() {
		return di_sleep_latency;
	}
	public void setDi_sleep_latency(String di_sleep_latency) {
		this.di_sleep_latency = di_sleep_latency;
	}
	public String getDi_ahi() {
		return di_ahi;
	}
	public void setDi_ahi(String di_ahi) {
		this.di_ahi = di_ahi;
	}
	public String getDi_tot_lm_index() {
		return di_tot_lm_index;
	}
	public void setDi_tot_lm_index(String di_tot_lm_index) {
		this.di_tot_lm_index = di_tot_lm_index;
	}
	public String getDi_tot_lm_arou() {
		return di_tot_lm_arou;
	}
	public void setDi_tot_lm_arou(String di_tot_lm_arou) {
		this.di_tot_lm_arou = di_tot_lm_arou;
	}
	public String getDi_arou_index() {
		return di_arou_index;
	}
	public void setDi_arou_index(String di_arou_index) {
		this.di_arou_index = di_arou_index;
	}
	public String getDi_rdi() {
		return di_rdi;
	}
	public void setDi_rdi(String di_rdi) {
		this.di_rdi = di_rdi;
	}
	public String getDi_oxy_satu_avg() {
		return di_oxy_satu_avg;
	}
	public void setDi_oxy_satu_avg(String di_oxy_satu_avg) {
		this.di_oxy_satu_avg = di_oxy_satu_avg;
	}
	public String getDi_oxy_satu_min() {
		return di_oxy_satu_min;
	}
	public void setDi_oxy_satu_min(String di_oxy_satu_min) {
		this.di_oxy_satu_min = di_oxy_satu_min;
	}
	
	
}
