/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : ProjectDetailVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 9. 14.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 9. 14.
 * @version : 1.0
 * 
 */
public class ProjectDetailVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String project_cd;    		//프로젝트코드
	private String project_nm;			//프로젝트명
	private String psg_cnt;			//PSG검사 등록 건 수
	private String psg_reg_date;		//PSG검사 등록 일자
	private String event_cnt;			//이벤트 총 등록 건 수
	private String user_cnt;			//검수 인원
	private String data_dir;			//데이터 디렉토리
	private String complete_yn;	 	//프로젝트 완료여부
	private String delete_fg;	     	//프로젝트 삭제여부
	private String reg_dt;  			//프로젝트 등록일자
	private String reg_user_id;     	//등록자
	
	public String getProject_cd() {
		return project_cd;
	}
	public void setProject_cd(String project_cd) {
		this.project_cd = project_cd;
	}
	public String getProject_nm() {
		return project_nm;
	}
	public void setProject_nm(String project_nm) {
		this.project_nm = project_nm;
	}
	public String getPsg_cnt() {
		return psg_cnt;
	}
	public void setPsg_cnt(String psg_cnt) {
		this.psg_cnt = psg_cnt;
	}
	public String getPsg_reg_date() {
		return psg_reg_date;
	}
	public void setPsg_reg_date(String psg_reg_date) {
		this.psg_reg_date = psg_reg_date;
	}
	public String getEvent_cnt() {
		return event_cnt;
	}
	public void setEvent_cnt(String event_cnt) {
		this.event_cnt = event_cnt;
	}
	public String getUser_cnt() {
		return user_cnt;
	}
	public void setUser_cnt(String user_cnt) {
		this.user_cnt = user_cnt;
	}
	public String getData_dir() {
		return data_dir;
	}
	public void setData_dir(String data_dir) {
		this.data_dir = data_dir;
	}
	public String getComplete_yn() {
		return complete_yn;
	}
	public void setComplete_yn(String complete_yn) {
		this.complete_yn = complete_yn;
	}
	public String getDelete_fg() {
		return delete_fg;
	}
	public void setDelete_fg(String delete_fg) {
		this.delete_fg = delete_fg;
	}
	public String getReg_dt() {
		return reg_dt;
	}
	public void setReg_dt(String reg_dt) {
		this.reg_dt = reg_dt;
	}
	public String getReg_user_id() {
		return reg_user_id;
	}
	public void setReg_user_id(String reg_user_id) {
		this.reg_user_id = reg_user_id;
	}

	
	
}
