/**
 * 
 */
package com.ubizit.mla.service;

import java.util.Map;

/**
 * @Class Name : MainService.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
public interface MainService {

	/**
	 * Method : getProgressCounts
	 * 최초작성일 : 2021. 6. 1.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 메인(대시보드) 화면 건 수 데이터들
	 */
	void getProgressCounts(Map<String, Object> map) throws Exception;

	/**
	 * Method : getWeekMonthCharts
	 * 최초작성일 : 2021. 6. 7.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 주간/월간 실적 그래프
	 */
	void getWeekMonthCharts(Map<String, Object> map) throws Exception;

	/**
	 * Method : getUserCharts
	 * 최초작성일 : 2021. 6. 8.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : PSG 검수자 실적도
	 */
	void getUserCharts(Map<String, Object> map) throws Exception;
	
	/**
	 * Method : getProjectStatusSearchCnt
	 * 최초작성일 : 2020. 9. 14.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 사용자별 프로젝트 to_do, ing, complete count
	 */
	void getProjectStatusSearchCnt(Map<String, Object> map) throws Exception;	

	/**
	 * Method : getProjectStatusSearchList
	 * 최초작성일 : 2020. 9. 14.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 사용자별 프로젝트 to_do, ing, complete 리스트
	 */
	void getProjectStatusSearchList(Map<String, Object> map) throws Exception;
	
	
	
	
	/**
	 * Method : getUserSearchList
	 * 최초작성일 : 2020. 9. 11.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 사용자 월별 진행 현황
	 */
	void getUserSearchList(Map<String, Object> map) throws Exception;

	/**
	 * Method : getChartSearchList
	 * 최초작성일 : 2020. 9. 11.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트 월별 진행 현황
	 */
	void getChartSearchList(Map<String, Object> map) throws Exception;

	/**
	 * Method : getProjectSearchList
	 * 최초작성일 : 2020. 9. 11.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param resultMap
	 * Method 설명 : 프로젝트 월별 진행 현황에 따른 사용자 진행률 조회
	 */
	void getProjectSearchList(Map<String, Object> map) throws Exception;


}
