/**
 * 
 */
package com.ubizit.mla.service.impl;

import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.mla.service.MainService;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * @Class Name : MainServiceImpl.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
@Service("mainService")
public class MainServiceImpl extends EgovAbstractServiceImpl implements MainService{

	private static final Logger LOGGER = LoggerFactory.getLogger(MainServiceImpl.class);

	@Resource(name="mainDAO")
	private MainDAO mainDAO;

	@Override
	public void getProgressCounts(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> MainServiceImpl.getProgressCounts >>>>>>");
		System.out.println(">>>>>> MainServiceImpl.getProgressCounts >>>>>>");
		
		mainDAO.getProgressCounts(map);
	}

	@Override
	public void getWeekMonthCharts(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> MainServiceImpl.getWeekMonthCharts >>>>>>");
		System.out.println(">>>>>> MainServiceImpl.getWeekMonthCharts >>>>>>");
		
		mainDAO.getWeekMonthCharts(map);
	}

	@Override
	public void getUserCharts(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> MainServiceImpl.getUserCharts >>>>>>");
		System.out.println(">>>>>> MainServiceImpl.getUserCharts >>>>>>");
		
		mainDAO.getUserCharts(map);
	}
	
	@Override
	public void getProjectStatusSearchCnt(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> MainServiceImpl.getProjectStatusSearchCnt >>>>>>");
		System.out.println(">>>>>> MainServiceImpl.getProjectStatusSearchCnt >>>>>>");
		
		mainDAO.getProjectStatusSearchCnt(map);
	}

	@Override
	public void getProjectStatusSearchList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> MainServiceImpl.getProjectStatusSearchList >>>>>>");
		System.out.println(">>>>>> MainServiceImpl.getProjectStatusSearchList >>>>>>");
		
		mainDAO.getProjectStatusSearchList(map);
	}
	
	
	
	
	
	
	@Override
	public void getUserSearchList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> MainServiceImpl.getUserSearchList >>>>>>");
		System.out.println(">>>>>> MainServiceImpl.getUserSearchList >>>>>>");
		
		mainDAO.getUserSearchList(map);
	}

	@Override
	public void getChartSearchList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> MainServiceImpl.getChartSearchList >>>>>>");
		System.out.println(">>>>>> MainServiceImpl.getChartSearchList >>>>>>");
		
		mainDAO.getChartSearchList(map);
	}

	@Override
	public void getProjectSearchList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> MainServiceImpl.getProjectSearchList >>>>>>");
		System.out.println(">>>>>> MainServiceImpl.getProjectSearchList >>>>>>");
		
		mainDAO.getProjectSearchList(map);
	}








}
