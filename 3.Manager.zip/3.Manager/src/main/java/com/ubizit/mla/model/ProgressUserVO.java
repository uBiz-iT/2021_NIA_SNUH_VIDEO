/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : ProgressUserVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 5. 24.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 5. 24.
 * @version : 1.0
 *
 */
public class ProgressUserVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String row_num;			//순번
	private String user_id;       		//사용자 아이디
	private String user_nm;    		//사용자 이름
	private String project_cnt;		//참여 프로젝트 수
	private String total_progress;		//전체 진행률
	private String psg_cnt;			//검수 대상 건수
	private String psg_complete;		//검수 완료 건수
	private String psg_uncomplete;		//검수 미완료 건수
	private String progress_chk;		//진행률 확인
	
	public String getRow_num() {
		return row_num;
	}
	public void setRow_num(String row_num) {
		this.row_num = row_num;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_nm() {
		return user_nm;
	}
	public void setUser_nm(String user_nm) {
		this.user_nm = user_nm;
	}
	public String getProject_cnt() {
		return project_cnt;
	}
	public void setProject_cnt(String project_cnt) {
		this.project_cnt = project_cnt;
	}
	public String getTotal_progress() {
		return total_progress;
	}
	public void setTotal_progress(String total_progress) {
		this.total_progress = total_progress;
	}
	public String getPsg_cnt() {
		return psg_cnt;
	}
	public void setPsg_cnt(String psg_cnt) {
		this.psg_cnt = psg_cnt;
	}
	public String getPsg_complete() {
		return psg_complete;
	}
	public void setPsg_complete(String psg_complete) {
		this.psg_complete = psg_complete;
	}
	public String getPsg_uncomplete() {
		return psg_uncomplete;
	}
	public void setPsg_uncomplete(String psg_uncomplete) {
		this.psg_uncomplete = psg_uncomplete;
	}
	public String getProgress_chk() {
		return progress_chk;
	}
	public void setProgress_chk(String progress_chk) {
		this.progress_chk = progress_chk;
	}
	

}
