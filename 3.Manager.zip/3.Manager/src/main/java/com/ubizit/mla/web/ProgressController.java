/**
 * 
 */
package com.ubizit.mla.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ubizit.mla.model.PgProPuCt1VO;
import com.ubizit.mla.model.PgProPuCt2VO;
import com.ubizit.mla.model.PgProPuDataVO;
import com.ubizit.mla.model.PgProPuTotalVO;
import com.ubizit.mla.model.PgProVeCt1VO;
import com.ubizit.mla.model.PgProVeCt2VO;
import com.ubizit.mla.model.PgProVeTotalVO;
import com.ubizit.mla.model.PgUserVeCt1VO;
import com.ubizit.mla.model.PgUserVeCt2VO;
import com.ubizit.mla.model.PgUserVeTotalVO;
import com.ubizit.mla.model.ProgressProjectTotalVO;
import com.ubizit.mla.model.ProgressProjectVO;
import com.ubizit.mla.model.ProgressReqVO;
import com.ubizit.mla.model.ProgressUserReqVO;
import com.ubizit.mla.model.ProgressUserVO;
import com.ubizit.mla.model.UserChartVO;
import com.ubizit.mla.service.ProgressService;
import com.ubizit.mla.util.ExcelUtil;
import com.ubizit.mla.util.StringUtil;

import net.sf.json.JSONObject;

/**
 * @Class Name : ProgressController.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 9. 1.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 9. 1.
 * @version : 1.0
 * 
 */
@Controller
public class ProgressController {

	/** ProgressService **/
	@Resource(name="progressService")
	private ProgressService progressService;
	
	private final static Logger logger = Logger.getLogger(ProgressController.class);
	
	/**
	 * Method : projectList
	 * 최초작성일 : 2020. 9. 23.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * @throws Exception
	 * Method 설명 : 통계 프로젝트 현황 메인 화면
	 */
	@RequestMapping(value="/progress.projectList.do")
	public String projectList(ProgressReqVO progressReqVO, ModelMap model) throws Exception {
		logger.info(">>>>>> ProgressController.projectList() >>>>>>");
		System.out.println(">>>>>> ProgressController.projectList() >>>>>>");
		
		if(StringUtil.isNotBlank(progressReqVO.getProject_cd())){
			model.addAttribute("project_cd", progressReqVO.getProject_cd());
		}
		if(StringUtil.isNotBlank(progressReqVO.getComplete_yn())){
			model.addAttribute("complete_yn", progressReqVO.getComplete_yn());
		}
		
		return "progress_project_list";
	}

	/**
	 * Method : getTotalSearch
	 * 최초작성일 : 2021. 06. 28.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * @throws Exception
	 * Method 설명 : PSG등록건수 / 검수완료건수 / 검수PASS건수 / 검수FAIL건수
	 */
	@RequestMapping(value="/progress.project.total.search.do")
	@ResponseBody	
	public Map<String, Object> getTotalSearch(HttpSession session) throws Exception {
		logger.info(">>>>>> ProgressController.getTotalSearch() >>>>>>");
		System.out.println(">>>>>> ProgressController.getTotalSearch() >>>>>>");
		
		/** Object 선언 **/
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<ProgressProjectTotalVO> p_ret_json = new ArrayList<>();
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json",StringUtil.parseJsonObjectToString(jsonObject));
		
		progressService.getTotalSearch(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<ProgressProjectTotalVO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
	}
	
	
	/**
	 * Method : getSearchList
	 * 최초작성일 : 2020. 9. 24.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 검색조건 조회
	 */
	@RequestMapping(value="/progress.project.search.do")
	@ResponseBody
	public Map<String, Object> getSearchList(HttpServletRequest request, HttpSession session) throws Exception {
		logger.info(">>>>>> ProgressController.getSearchList() >>>>>>");
		System.out.println(">>>>>> ProgressController.getSearchList() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<ProgressProjectVO> p_ret_json = new ArrayList<>();
		
		String project_cd 		= ((String[])paramMap.get("project_cd"))[0];
		String complete_yn 		= ((String[])paramMap.get("complete_yn"))[0];		
//		int page_no = Integer.parseInt(((String[])paramMap.get("page_no"))[0]);
//		int row_size = Integer.parseInt(((String[])paramMap.get("row_size"))[0]);
		
		jsonObject.put("PROJECT_CD", project_cd);
		jsonObject.put("COMPLETE_YN", complete_yn);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		progressService.getProgressProjectSearchList(resultMap);
		
		//프로젝트 진행률 변경 화면
		int originalSize = 1;
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<ProgressProjectVO>) resultMap.get("p_ret_json");
			originalSize = p_ret_json.size();
		}else{
			p_ret_json = null;
		}
		///////////////////////////
		
//		int originalSize = 1;
//		if((int)resultMap.get("p_ret_code") == 0){
//			p_ret_json = (List<ProgressProjectVO>) resultMap.get("p_ret_json");
//			
//			originalSize = p_ret_json.size();
//			
//			int start = Math.min(originalSize, Math.abs((page_no-1) * row_size));
//			
//			if(page_no == 1 && originalSize > row_size){
//				p_ret_json.subList(row_size, originalSize).clear();
//			
//			}else if(page_no == 1 && originalSize <= row_size){
//				
//			}else if(page_no != 1){
//				p_ret_json.subList(0, start).clear();
//				
//				int size = p_ret_json.size();
//				int end = Math.min(row_size, size);
//				p_ret_json.subList(end, size).clear();
//			}
//			
//			
//		}else{
//			p_ret_json = null;
//		}
		
		/** return map */
		map.put("total", originalSize);
		map.put("rows", p_ret_json);
		
		return map;
	}
	
	
	/**
	 * Method : progressProjectView
	 * 최초작성일 : 2021. 6. 29.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 * Method 설명 : 프로젝트 진행 현황 -> 진행률 확인 클릭 이벤트
	 */
	@RequestMapping(value="/progress.project.view.do")
	public String progressProjectView(HttpServletRequest request, ModelMap model) throws Exception {
		logger.info(">>>>>> ProgressController.projectProgressView() >>>>>>");
		System.out.println(">>>>>> ProgressController.projectProgressView() >>>>>>");
		
		String project_cd = request.getParameter("project_code");
		
		model.addAttribute("project_cd", project_cd);
		
		return "progress_project_view";
	}
	
	/**
	 * Method : progressProjectViewTotal
	 * 최초작성일 : 2021. 6. 30.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * @throws Exception
	 * Method 설명 : 검수 완료/PASS/FAIL/미완료
	 */
	@RequestMapping(value="/progress.pro.view.total.do")
	@ResponseBody
	public Map<String, Object> progressProjectViewTotal(HttpServletRequest request) throws Exception{
		logger.info(">>>>>> ProgressController.progressProjectViewTotal() >>>>>>");
		System.out.println(">>>>>> ProgressController.progressProjectViewTotal() >>>>>>");
		
		/** Object 선언 **/
		JSONObject jsonObject = new JSONObject();
		Map<?, ?> paramMap = request.getParameterMap();
		Map<String, Object> map = new HashMap<>();
		List<PgProVeTotalVO> p_ret_json = new ArrayList<>();
		
		String project_cd = ((String[])paramMap.get("project_cd"))[0];
		
		jsonObject.put("PROJECT_CD", project_cd);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		progressService.progressProjectViewTotal(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<PgProVeTotalVO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
	}
	

	/**
	 * Method : progressProjectViewChart1
	 * 최초작성일 : 2021. 7. 5.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 검수자 PASS, FAIL 그래프
	 */
	@RequestMapping(value="/progress.pro.view.chart1.do")
	@ResponseBody
	public Map<String, Object> progressProjectViewChart1(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> ProgressController.progressProjectViewChart1() >>>>>>");
		System.out.println(">>>>>> ProgressController.progressProjectViewChart1() >>>>>>");
		
		/** Object 선언 **/
		JSONObject jsonObject = new JSONObject();
		Map<?, ?> paramMap = request.getParameterMap();
		Map<String, Object> map = new HashMap<>();
		List<PgProVeCt1VO> p_ret_json = new ArrayList<>();
		
		String project_cd = ((String[])paramMap.get("project_cd"))[0];
		
		jsonObject.put("PROJECT_CD", project_cd);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		progressService.progressProjectViewChart1(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<PgProVeCt1VO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
	}
	
	/**
	 * Method : progressProjectViewChart1
	 * 최초작성일 : 2021. 7. 5.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : PASS, FAIL 일치 비율 그래프
	 */
	@RequestMapping(value="/progress.pro.view.chart2.do")
	@ResponseBody
	public Map<String, Object> progressProjectViewChart2(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> ProgressController.progressProjectViewChart2() >>>>>>");
		System.out.println(">>>>>> ProgressController.progressProjectViewChart2() >>>>>>");
		
		/** Object 선언 **/
		JSONObject jsonObject = new JSONObject();
		Map<?, ?> paramMap = request.getParameterMap();
		Map<String, Object> map = new HashMap<>();
		List<PgProVeCt2VO> p_ret_json = new ArrayList<>();
		
		String project_cd = ((String[])paramMap.get("project_cd"))[0];
		
		jsonObject.put("PROJECT_CD", project_cd);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		progressService.progressProjectViewChart2(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<PgProVeCt2VO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
	}
	
	
	/**
	 * Method : userList
	 * 최초작성일 : 2020. 9. 23.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * @throws Exception
	 * Method 설명 : 통계 사용자 현황 메인 화면
	 */
	@RequestMapping(value="/progress.userList.do")
	public String userList(ProgressUserReqVO progressReqVO, ModelMap model) throws Exception {
		logger.info(">>>>>> ProgressController.userList() >>>>>>");
		System.out.println(">>>>>> ProgressController.userList() >>>>>>");
		
		if(StringUtil.isNotBlank(progressReqVO.getUser_info())){
			model.addAttribute("user_info", progressReqVO.getUser_info());
		}
		if(StringUtil.isNotBlank(progressReqVO.getDelete_fg())){
			model.addAttribute("delete_fg", progressReqVO.getDelete_fg());
		}
		
		return "progress_user_list";
	}
	

	/**
	 * Method : getUserSearchList
	 * 최초작성일 : 2020. 9. 24.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 :  사용자 검색조건 조회
	 */
	@RequestMapping(value="/progress.user.search.do")
	@ResponseBody
	public Map<String, Object> getUserSearchList(HttpServletRequest request, HttpSession session) throws Exception {
		logger.info(">>>>>> ProgressController.getUserSearchList() >>>>>>");
		System.out.println(">>>>>> ProgressController.getUserSearchList() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<ProgressUserVO> p_ret_json = new ArrayList<>();
		
		String user_info  = ((String[])paramMap.get("user_info"))[0];
		String delete_fg  = ((String[])paramMap.get("delete_fg"))[0];
		
		jsonObject.put("USER_INFO", user_info);
		jsonObject.put("DELETE_FG", delete_fg);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		progressService.getProgressUserSearchList(resultMap);
		
		//사용자 진행률 변경 화면
		int originalSize = 1;
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<ProgressUserVO>) resultMap.get("p_ret_json");
			originalSize = p_ret_json.size();
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("total", originalSize);
		map.put("rows", p_ret_json);
		
		return map;
	}

	
	/**
	 * Method : progressUserView
	 * 최초작성일 : 2021. 6. 29.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 * Method 설명 : 사용자 진행 현황 -> 진행률 확인 클릭 이벤트
	 */
	@RequestMapping(value="/progress.user.view.do")
	public String progressUserView(HttpServletRequest request, ModelMap model) throws Exception {
		logger.info(">>>>>> ProgressController.projectProgressView() >>>>>>");
		System.out.println(">>>>>> ProgressController.projectProgressView() >>>>>>");
		
		String userId = request.getParameter("userId");
		String userNm = request.getParameter("userNm");
		
		model.addAttribute("userId", userId);
		model.addAttribute("userNm", userNm);
		
		return "progress_user_view";
	}
	
	/**
	 * Method : progressUserViewTotal
	 * 최초작성일 : 2021. 6. 30.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * @throws Exception
	 * Method 설명 : 검수 완료/PASS/FAIL/미완료
	 */
	@RequestMapping(value="/progress.user.view.total.do")
	@ResponseBody
	public Map<String, Object> progressUserViewTotal(HttpServletRequest request) throws Exception{
		logger.info(">>>>>> ProgressController.progressProjectViewTotal() >>>>>>");
		System.out.println(">>>>>> ProgressController.progressProjectViewTotal() >>>>>>");
		
		/** Object 선언 **/
		JSONObject jsonObject = new JSONObject();
		Map<?, ?> paramMap = request.getParameterMap();
		Map<String, Object> map = new HashMap<>();
		List<PgUserVeTotalVO> p_ret_json = new ArrayList<>();
		
		String user_id = ((String[])paramMap.get("user_id"))[0];
		
		jsonObject.put("USER_ID", user_id);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		progressService.progressUserViewTotal(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<PgUserVeTotalVO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
	}
	
	/**
	 * Method : progressUserViewChart1
	 * 최초작성일 : 2021. 7. 08.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * @throws Exception
	 * Method 설명 : PSG 검수 및 이벤트 진행
	 */
	@RequestMapping(value="/progress.user.view.chart1.do")
	@ResponseBody
	public Map<String, Object> progressUserViewChart1(HttpServletRequest request) throws Exception{
		logger.info(">>>>>> ProgressController.progressUserViewChart1() >>>>>>");
		System.out.println(">>>>>> ProgressController.progressUserViewChart1() >>>>>>");
		
		/** Object 선언 **/
		JSONObject jsonObject = new JSONObject();
		Map<?, ?> paramMap = request.getParameterMap();
		Map<String, Object> map = new HashMap<>();
		List<PgUserVeCt1VO> p_ret_json = new ArrayList<>();
		
		String user_id = ((String[])paramMap.get("user_id"))[0];
		
		jsonObject.put("USER_ID", user_id);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		progressService.progressUserViewChart1(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<PgUserVeCt1VO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
	}
	
	/**
	 * Method : progressUserViewChart2
	 * 최초작성일 : 2021. 7. 08.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * @throws Exception
	 * Method 설명 : 프로젝트별 PASS, FAIL
	 */
	@RequestMapping(value="/progress.user.view.chart2.do")
	@ResponseBody
	public Map<String, Object> progressUserViewChart2(HttpServletRequest request) throws Exception{
		logger.info(">>>>>> ProgressController.progressUserViewChart2() >>>>>>");
		System.out.println(">>>>>> ProgressController.progressUserViewChart2() >>>>>>");
		
		/** Object 선언 **/
		JSONObject jsonObject = new JSONObject();
		Map<?, ?> paramMap = request.getParameterMap();
		Map<String, Object> map = new HashMap<>();
		List<PgUserVeCt2VO> p_ret_json = new ArrayList<>();
		
		String user_id = ((String[])paramMap.get("user_id"))[0];
		
		jsonObject.put("USER_ID", user_id);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		progressService.progressUserViewChart2(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<PgUserVeCt2VO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
	}
	
	
	/**
	 * Method : getUserProgress
	 * 최초작성일 : 2020. 9. 24.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param 프로젝트 코드
	 * @return
	 * @throws Exception
	 * Method 설명 : 판독자 진행률 조회
	 */
	@RequestMapping(value="/progress.user.chart.do")
	@ResponseBody
	public Map<String, Object> getUserProgress(HttpServletRequest request) throws Exception{
		logger.info(">>>>>> ProgressController.getUserProgress() >>>>>>");
		System.out.println(">>>>>> ProgressController.getUserProgress() >>>>>>");
		
		/** Object 선언 **/
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<UserChartVO> p_ret_json = new ArrayList<>();
		
		String code_name = request.getParameter("user_id"); 
		
		jsonObject.put("USER_ID", code_name);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		progressService.getUserProgress(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<UserChartVO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
	}
	
	/**
	 * Method : progressProjectPopup
	 * 최초작성일 : 2020. 11. 3.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param model
	 * @param project_cd
	 * @return
	 * @throws Exception
	 * Method 설명 : 프로젝트 단위 진행률 팝업
	 */
	@RequestMapping(value="/progress.project.popup.do")
	public String progressProjectPopup(ModelMap model, @RequestParam(value="code_name", defaultValue="") String project_cd) throws Exception {
		logger.info(">>>>>> ProgressController.progressProjectPopup() >>>>>>");
		System.out.println(">>>>>> ProgressController.progressProjectPopup() >>>>>>");
		
		if(StringUtil.isNotBlank(project_cd)){
			model.addAttribute("project_cd", project_cd);
		}
		
		List<Map<String, Object>> list = progressService.progressProjectUser(project_cd);
		
		model.addAttribute("user_list", list);
		
		return "progress_project_popup";
	}
	
	/**
	 * 
	 * Method : progressProjectPopupTotal
	 * 최초작성일 : 2021. 1. 4.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 * Method 설명 : 프로젝트 진행률 화면의 팝업창 상단 데이터
	 */
	@RequestMapping(value="/progress.pro.popup.total.do")
	@ResponseBody
	public Map<String, Object> progressProjectPopupTotal(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> ProgressController.progressProjectPopupTotal() >>>>>>");
		System.out.println(">>>>>> ProgressController.progressProjectPopupTotal() >>>>>>");
		
		/** Object 선언 **/
		JSONObject jsonObject = new JSONObject();
		Map<?, ?> paramMap = request.getParameterMap();
		Map<String, Object> map = new HashMap<>();
		List<PgProPuTotalVO> p_ret_json = new ArrayList<>();
		
		String project_cd = ((String[])paramMap.get("project_cd"))[0];
		
		jsonObject.put("PROJECT_CD", project_cd);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		progressService.progressProjectPopupTotal(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<PgProPuTotalVO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
	}
	
	/**
	 * Method : progressProjectPopupChart1
	 * 최초작성일 : 2021. 1. 5.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 판독자별 Accept, Reject 데이터
	 */
	@RequestMapping(value="/progress.pro.popup.chart1.do")
	@ResponseBody
	public Map<String, Object> progressProjectPopupChart1(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> ProgressController.progressProjectPopupChart1() >>>>>>");
		System.out.println(">>>>>> ProgressController.progressProjectPopupChart1() >>>>>>");
		
		/** Object 선언 **/
		JSONObject jsonObject = new JSONObject();
		Map<?, ?> paramMap = request.getParameterMap();
		Map<String, Object> map = new HashMap<>();
		List<PgProPuCt1VO> p_ret_json = new ArrayList<>();
		
		String project_cd = ((String[])paramMap.get("project_cd"))[0];
		
		jsonObject.put("PROJECT_CD", project_cd);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		progressService.progressProjectPopupChart1(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<PgProPuCt1VO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
	}
	
	/**
	 * Method : progressProjectPopupChart2
	 * 최초작성일 : 2021. 1. 5.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 일치도(accept, reject), 불일치도, 미완료건수
	 */
	@RequestMapping(value="/progress.pro.popup.chart2.do")
	@ResponseBody
	public Map<String, Object> progressProjectPopupChart2(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> ProgressController.progressProjectPopupChart2() >>>>>>");
		System.out.println(">>>>>> ProgressController.progressProjectPopupChart2() >>>>>>");
		
		/** Object 선언 **/
		JSONObject jsonObject = new JSONObject();
		Map<?, ?> paramMap = request.getParameterMap();
		Map<String, Object> map = new HashMap<>();
		List<PgProPuCt2VO> p_ret_json = new ArrayList<>();
		
		String project_cd = ((String[])paramMap.get("project_cd"))[0];
		
		jsonObject.put("PROJECT_CD", project_cd);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		progressService.progressProjectPopupChart2(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<PgProPuCt2VO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
	}
	
	/**
	 * Method : progressProjectPopupData
	 * 최초작성일 : 2021. 1. 6.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @param param
	 * @return
	 * @throws Exception
	 * Method 설명 : 데이터셋 Accept, Reject 표
	 */
	@RequestMapping(value="/progress.pro.popup.data.do")
	@ResponseBody
	public Map<String, Object> progressProjectPopupData(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> ProgressController.progressProjectPopupData() >>>>>>");
		System.out.println(">>>>>> ProgressController.progressProjectPopupData() >>>>>>");
		
		/** Object 선언 **/
		JSONObject jsonObject = new JSONObject();
		Map<?, ?> paramMap = request.getParameterMap();
		Map<String, Object> map = new HashMap<>();
		List<PgProPuDataVO> p_ret_json = new ArrayList();
		
		String project_cd = request.getParameter("project_cd");
		
		jsonObject.put("PROJECT_CD", project_cd);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		progressService.progressProjectPoupDataset(resultMap);
		
//		List<Map<String,Object>> dataList = progressService.progressProjectPopupData(project_cd);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<PgProPuDataVO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
	}
	
	
	/**
	 * Method : progressUserPopup
	 * 최초작성일 : 2020. 11. 3.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param model
	 * @param project_cd
	 * @return
	 * @throws Exception
	 * Method 설명 : 사용자 단위 진행률 팝업
	 */
	@RequestMapping(value="/progress.user.popup.do")
	public String progressUserPopup(ModelMap model, @RequestParam(value="userId", defaultValue="") String userId) throws Exception {
		logger.info(">>>>>> ProgressController.progressUserPopup() >>>>>>");
		System.out.println(">>>>>> ProgressController.progressUserPopup() >>>>>>");
		
		if(StringUtil.isNotBlank(userId)){
			model.addAttribute("userId", userId);
		}
		
		return "progress_user_popup";
	}
	
	/**
	 * Method : projectExcelDown
	 * 최초작성일 : 2020. 12. 23.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @param response
	 * @param param
	 * @throws Exception
	 * Method 설명 : 프로젝트별 엑셀다운로드
	 */
	@RequestMapping(value="/progress.project.excelDown.do")
	@ResponseBody
	public Map<String, Object> projectExcelDown(HttpServletRequest request, HttpServletResponse response, @RequestParam Map<String,Object> param) throws Exception {
		logger.info(">>>>>> ProgressController.projectExcelDown() >>>>>>");
		System.out.println(">>>>>> ProgressController.projectExcelDown() >>>>>>");
		
		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		Map<String, Object> map = new HashMap<>();
		
		String project_cd = ((String[])paramMap.get("project_cd"))[0];
		
		param.put("project_cd", project_cd);
		
		List<Map<String,Object>> dataList = progressService.selectProjectExcel(param);
		
		for(int i = 0; i < dataList.size(); i++){
			String user_nm = (String) dataList.get(i).get("USER_NM");
			String[] user_nm_list = user_nm.split("/");
			
			String user_memo = (String) dataList.get(i).get("MEMO");
			String[] user_memo_list = user_memo.split("/");
			
			for(int j = 0; j < user_nm_list.length; j++){
				dataList.get(i).put("USER_NM_"+(j+1), user_nm_list[j]);
				dataList.get(i).put("USER_MEMO_"+(j+1), user_memo_list[j]);
			}

			dataList.get(i).remove("USER_NM");
			dataList.get(i).remove("MEMO");
		
		}
		int user_cnt = progressService.selectProjectExcelCnt(param);
		
		List<String> logical_list = new ArrayList();
		logical_list.add("프로젝트 코드");
		logical_list.add("데이터셋 번호");
		
//		logical_list.add("ACCEPT/REJECT 여부");	//accept_reject 컬럼 추가
		
		logical_list.add("Reject된 이미지 번호");
		
//		logical_list.add("프로젝트명");			//프로젝트명 컬럼 추가
		
		List<String> physical_list = new ArrayList();
		physical_list.add("PROJECT_CD");
		physical_list.add("IMAGE_ID");
		
//		physical_list.add("ACCEPT_REJECT");	//accept_reject 컬럼 추가
		
		physical_list.add("SUB_IMAGE_ID");
		
//		physical_list.add("PROJECT_NM");	//프로젝트명 컬럼 추가
		
		for(int i = 1; i <= user_cnt; i++){
			
			logical_list.add("Reject한 판독자 "+ i);
			logical_list.add("Reject 사유(메모)");
			
			physical_list.add("USER_NM_" + i);
			physical_list.add("USER_MEMO_" + i);
			
		}
		
		int[] type_int = null;
		int[][] cellRangeAddress = null;
		
//		String downFileName = "Accept 데이터셋 리스트" + "_"+StringUtil.getSimpleDateFormat("yyyyMMdd");
		String downFileName = "Reject 이미지 리스트_"+project_cd+"_"+StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] logical_names = logical_list.toArray(new String[logical_list.size()]);
		String[] physical_names = physical_list.toArray(new String[physical_list.size()]);
		
		int[] widths = new int[logical_names.length];
		
		for(int i = 0; i < logical_names.length; i++){
			widths[i] = 25;
		}
		
		ExcelUtil.excelDownload(response, cellRangeAddress, logical_names, physical_names, widths, type_int, downFileName, dataList);
		
		map.put("result", "Y");
		
		return map;
	}
	
	/**
	 * Method : projectPassExDownSelect
	 * 최초작성일 : 2020. 01. 15.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @param response
	 * @throws Exception
	 * Method 설명 : Accept(Pass) 건 전체 프로젝트 엑셀다운로드
	 */
	@RequestMapping(value="/progress.project.pass.exDownSelect.do")
	@ResponseBody
	public Map<String, Object> projectPassExDownSelect(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(">>>>>> ProgressController.projectPassExDownSelect() >>>>>>");
		System.out.println(">>>>>> ProgressController.projectPassExDownSelect() >>>>>>");
		
		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		Map<String, Object> map = new HashMap<>();
		
		List<Map<String,Object>> dataList = progressService.selectProjectPassExDownSelect();
		
		List<String> logical_list = new ArrayList();
		logical_list.add("프로젝트 코드");
		logical_list.add("프로젝트명");			//프로젝트명 컬럼 추가
		logical_list.add("데이터셋 번호");
		
		
		List<String> physical_list = new ArrayList();
		physical_list.add("PROJECT_CD");
		physical_list.add("PROJECT_NM");	//프로젝트명 컬럼 추가
		physical_list.add("IMAGE_ID");
		
		
		int[] type_int = null;
		int[][] cellRangeAddress = null;
		
		String downFileName = "Pass 데이터셋 리스트" + "_"+StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] logical_names = logical_list.toArray(new String[logical_list.size()]);
		String[] physical_names = physical_list.toArray(new String[physical_list.size()]);
		
		int[] widths = new int[logical_names.length];
		
		for(int i = 0; i < logical_names.length; i++){
			widths[i] = 25;
		}
		
		ExcelUtil.excelDownload(response, cellRangeAddress, logical_names, physical_names, widths, type_int, downFileName, dataList);
		
		map.put("result", "Y");
		
		return map;
	}
	
	/**
	 * Method : projectNonPassExDownSelect
	 * 최초작성일 : 2020. 01. 15.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @param response
	 * @throws Exception
	 * Method 설명 : Reject(Non-pass) 건 전체 프로젝트 엑셀다운로드
	 */
	@RequestMapping(value="/progress.project.nonPass.exDownSelect.do")
	@ResponseBody
	public Map<String, Object> projectNonPassExDownSelect(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(">>>>>> ProgressController.projectNonPassExDownSelect() >>>>>>");
		System.out.println(">>>>>> ProgressController.projectNonPassExDownSelect() >>>>>>");
		
		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		Map<String, Object> map = new HashMap<>();
		
		List<Map<String,Object>> dataList = progressService.selectProjectNonPassExDownSelect();
		
		List<String> logical_list = new ArrayList();
		logical_list.add("프로젝트 코드");
		logical_list.add("프로젝트명");			//프로젝트명 컬럼 추가
		logical_list.add("데이터셋 번호");
		
		
		List<String> physical_list = new ArrayList();
		physical_list.add("PROJECT_CD");
		physical_list.add("PROJECT_NM");	//프로젝트명 컬럼 추가
		physical_list.add("IMAGE_ID");
		
		
		int[] type_int = null;
		int[][] cellRangeAddress = null;
		
		String downFileName = "Non-pass 데이터셋 리스트" + "_"+StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] logical_names = logical_list.toArray(new String[logical_list.size()]);
		String[] physical_names = physical_list.toArray(new String[physical_list.size()]);
		
		int[] widths = new int[logical_names.length];
		
		for(int i = 0; i < logical_names.length; i++){
			widths[i] = 25;
		}
		
		ExcelUtil.excelDownload(response, cellRangeAddress, logical_names, physical_names, widths, type_int, downFileName, dataList);
		
		map.put("result", "Y");
		
		return map;
	}
	
	/**
	 * Method : projectPNExDownSelect
	 * 최초작성일 : 2020. 02. 18.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @param response
	 * @throws Exception
	 * Method 설명 : pass/Non-pass 건 수 전체 프로젝트 엑셀다운로드
	 */
	@RequestMapping(value="/progress.project.pn.exDownSelect.do")
	@ResponseBody
	public Map<String, Object> projectPNExDownSelect(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(">>>>>> ProgressController.projectPNExDownSelect() >>>>>>");
		System.out.println(">>>>>> ProgressController.projectPNExDownSelect() >>>>>>");
		
		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		Map<String, Object> map = new HashMap<>();
		
		List<Map<String,Object>> dataList = progressService.selectProjectPNExDownSelect();
		
		List<String> logical_list = new ArrayList();
		logical_list.add("프로젝트 코드");
		logical_list.add("프로젝트명");			//프로젝트명 컬럼 추가
		logical_list.add("PASS 건 수");
		logical_list.add("PASS 이미지건수");
		logical_list.add("NON-PASS 건 수");
		logical_list.add("NON-PASS 이미지건수");
		
		
		List<String> physical_list = new ArrayList();
		physical_list.add("PROJECT_CD");
		physical_list.add("PROJECT_NM");	//프로젝트명 컬럼 추가
		physical_list.add("PASS_CNT");
		physical_list.add("PASS_IMAGE_CNT");
		physical_list.add("NON_PASS_CNT");
		physical_list.add("NON_PASS_IMAGE_CNT");
		
		
		int[] type_int = {-1,-1,2,3,4,5};
		int[][] cellRangeAddress = null;
		
		String downFileName = "Pass_Non-pass 건 수 리스트" + "_"+StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] logical_names = logical_list.toArray(new String[logical_list.size()]);
		String[] physical_names = physical_list.toArray(new String[physical_list.size()]);
		
		int[] widths = new int[logical_names.length];
		
		for(int i = 0; i < logical_names.length; i++){
			widths[i] = 25;
		}
		
		ExcelUtil.excelDownload(response, cellRangeAddress, logical_names, physical_names, widths, type_int, downFileName, dataList);
		
		map.put("result", "Y");
		
		return map;
	}
	
	
	/**
	 * Method : projectListExcelDown
	 * 최초작성일 : 2021. 8. 4.
	 * 작성자 : 장두언
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 프로젝트 진행 목록 엑셀 다운로드
	 */
	@RequestMapping(value="/progress.project.list.excelDown.do")
	@ResponseBody
	public Map<String, Object> projectListExcelDown(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(">>>>>> ProgressController.projectListExcelDown() >>>>>>");
		System.out.println(">>>>>> ProgressController.projectListExcelDown() >>>>>>");
		
		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");
		
		/** Object 선언 **/
		Map<String, Object> map = new HashMap<>();
		
		Map<?, ?> paramMap = request.getParameterMap();	
		
		String project_cd  = ((String[])paramMap.get("project_cd"))[0];
		String complete_yn  = ((String[])paramMap.get("complete_yn"))[0];
		
		map.put("project_cd", project_cd);
		map.put("complete_yn", complete_yn);
		
		List<Map<String,Object>> dataList = progressService.projectListExcelDown(map);
		
		List<String> logical_list = new ArrayList();
		logical_list.add("프로젝트 코드");
		logical_list.add("프로젝트명");
		logical_list.add("검수 인원");
		logical_list.add("전체 진행률(%)");
		logical_list.add("검수 완료/대상 건수");
		logical_list.add("PASS/대상 건수");
		logical_list.add("FAIL/대상 건수");
		
		
		List<String> physical_list = new ArrayList();
		physical_list.add("PROJECT_CD");
		physical_list.add("PROJECT_NM");
		physical_list.add("USER_CNT");
		physical_list.add("TOTAL_PROGRESS");
		physical_list.add("WORK_CNT");
		physical_list.add("PASS_CNT");
		physical_list.add("FAIL_CNT");
		
		
		int[] type_int = null;
		int[][] cellRangeAddress = null;
		
		String downFileName = "프로젝트_진행_목록_"+StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] logical_names = logical_list.toArray(new String[logical_list.size()]);
		String[] physical_names = physical_list.toArray(new String[physical_list.size()]);
		
		int[] widths = new int[logical_names.length];
		
		for(int i = 0; i < logical_names.length; i++){
			widths[i] = 25;
		}
		
		ExcelUtil.excelDownload(response, cellRangeAddress, logical_names, physical_names, widths, type_int, downFileName, dataList);
		
		map.put("result", "Y");
		
		return map;
	}	

	/**
	 * Method : userListExcelDown
	 * 최초작성일 : 2021. 8. 4.
	 * 작성자 : 장두언
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 검수자 진행 현황 엑셀 다운로드
	 */
	@RequestMapping(value="/progress.user.list.excelDown.do")
	@ResponseBody
	public Map<String, Object> userListExcelDown(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(">>>>>> ProgressController.userListExcelDown() >>>>>>");
		System.out.println(">>>>>> ProgressController.userListExcelDown() >>>>>>");
		
		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");
		
		/** Object 선언 **/
		Map<String, Object> map = new HashMap<>();
		
		Map<?, ?> paramMap = request.getParameterMap();	
		
		String user_info  = ((String[])paramMap.get("user_info"))[0];
		String delete_fg  = ((String[])paramMap.get("delete_fg"))[0];
		
		map.put("user_info", user_info);
		map.put("delete_fg", delete_fg);
		
		List<Map<String,Object>> dataList = progressService.userListExcelDown(map);
		
		List<String> logical_list = new ArrayList();
		logical_list.add("검수자 아이디");
		logical_list.add("검수자 이름");
		logical_list.add("참여 프로젝트 수");
		logical_list.add("전체 진행률(%)");
		logical_list.add("검수 대상 건수");
		logical_list.add("검수 완료 건수");
		logical_list.add("검수 미완료 건수");
		
		
		List<String> physical_list = new ArrayList();
		physical_list.add("USER_ID");
		physical_list.add("USER_NM");
		physical_list.add("PROJECT_CNT");
		physical_list.add("TOTAL_PROGRESS");
		physical_list.add("PSG_CNT");
		physical_list.add("PSG_COMPLETE");
		physical_list.add("PSG_UNCOMPLETE");
		
		
		int[] type_int = null;
		int[][] cellRangeAddress = null;
		
		String downFileName = "검수자_진행_현황_"+StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] logical_names = logical_list.toArray(new String[logical_list.size()]);
		String[] physical_names = physical_list.toArray(new String[physical_list.size()]);
		
		int[] widths = new int[logical_names.length];
		
		for(int i = 0; i < logical_names.length; i++){
			widths[i] = 25;
		}
		
		ExcelUtil.excelDownload(response, cellRangeAddress, logical_names, physical_names, widths, type_int, downFileName, dataList);
		
		map.put("result", "Y");
		
		return map;
	}	
	
}








