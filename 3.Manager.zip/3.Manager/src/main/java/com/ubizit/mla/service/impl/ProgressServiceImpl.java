package com.ubizit.mla.service.impl;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.mla.service.ProgressService;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * @Class Name : ProgressServiceImpl.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
@Service("progressService")
public class ProgressServiceImpl extends EgovAbstractServiceImpl implements ProgressService{

	private static final Logger LOGGER = LoggerFactory.getLogger(ProgressServiceImpl.class);
	
	@Resource(name="progressDAO")
	private ProgressDAO progressDAO;

	@Override
	public void getProgressProjectSearchList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProgressServiceImpl.getProgressProjectSearchList >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.getProgressProjectSearchList >>>>>>");
		
		progressDAO.getProgressProjectSearchList(map);
	}

	@Override
	public void getProjectProgress(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProgressServiceImpl.getProjectProgress >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.getProjectProgress >>>>>>");
		
		progressDAO.getProjectProgress(map);
	}

	@Override
	public void getProgressUserSearchList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProgressServiceImpl.getProgressUserSearchList >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.getProgressUserSearchList >>>>>>");
		
		progressDAO.getProgressUserSearchList(map);
	}

	@Override
	public void getUserProgress(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProgressServiceImpl.getUserProgress >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.getUserProgress >>>>>>");
		
		progressDAO.getUserProgress(map);
	}

	@Override
	public void getTotalSearch(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProgressServiceImpl.getTotalSearch >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.getTotalSearch >>>>>>");
		
		progressDAO.getTotalSearch(map);
	}

	@Override
	public List<Map<String, Object>> selectProjectExcel(Map<String, Object> map) throws SQLException {
		LOGGER.info(">>>>>> ProgressServiceImpl.selectProjectExcel >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.selectProjectExcel >>>>>>");
		
		return progressDAO.selectProjectExcel(map);
	}

	@Override
	public int selectProjectExcelCnt(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProgressServiceImpl.selectProjectExcelCnt >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.selectProjectExcelCnt >>>>>>");
		
		return progressDAO.selectProjectExcelCnt(map);
	}

	@Override
	public void progressProjectPopupTotal(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProgressServiceImpl.progressProjectPopupTotal >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.progressProjectPopupTotal >>>>>>");
		
		progressDAO.progressProjectPopupTotal(map);
	}

	@Override
	public void progressProjectPopupChart1(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProgressServiceImpl.progressProjectPopupChart1 >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.progressProjectPopupChart1 >>>>>>");
		
		progressDAO.progressProjectPopupChart1(map);
		
	}

	@Override
	public void progressProjectPopupChart2(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProgressServiceImpl.progressProjectPopupChart2 >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.progressProjectPopupChart2 >>>>>>");
		
		progressDAO.progressProjectPopupChart2(map);
		
	}

	@Override
	public List<Map<String, Object>> progressProjectPopupData(String param) throws Exception {
		LOGGER.info(">>>>>> ProgressServiceImpl.progressProjectPopupData >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.progressProjectPopupData >>>>>>");
		
		return progressDAO.progressProjectPopupData(param);
	}

	@Override
	public void progressProjectPoupDataset(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProgressServiceImpl.progressProjectPoupDataset >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.progressProjectPoupDataset >>>>>>");
		
		progressDAO.progressProjectPoupDataset(map);
	}

	@Override
	public List<Map<String, Object>> progressProjectUser(String project_cd) throws Exception {
		LOGGER.info(">>>>>> ProgressServiceImpl.progressProjectUser >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.progressProjectUser >>>>>>");
		
		return progressDAO.progressProjectUser(project_cd);
	}

	@Override
	public List<Map<String, Object>> selectProjectPassExDownSelect() throws Exception {
		LOGGER.info(">>>>>> ProgressServiceImpl.selectProjectPassExDownSelect >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.selectProjectPassExDownSelect >>>>>>");
		
		return progressDAO.selectProjectPassExDownSelect();
	}
	
	@Override
	public List<Map<String, Object>> selectProjectNonPassExDownSelect() throws Exception {
		LOGGER.info(">>>>>> ProgressServiceImpl.selectProjectNonPassExDownSelect >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.selectProjectNonPassExDownSelect >>>>>>");
		
		return progressDAO.selectProjectNonPassExDownSelect();
	}

	@Override
	public List<Map<String, Object>> selectProjectPNExDownSelect() throws Exception {
		LOGGER.info(">>>>>> ProgressServiceImpl.selectProjectPNExDownSelect >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.selectProjectPNExDownSelect >>>>>>");
		
		return progressDAO.selectProjectPNExDownSelect();
	}

	@Override
	public void progressProjectViewTotal(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProgressServiceImpl.progressProjectViewTotal >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.progressProjectViewTotal >>>>>>");
		
		progressDAO.progressProjectViewTotal(map);
	}

	@Override
	public void progressProjectViewChart1(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProgressServiceImpl.progressProjectViewChart1 >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.progressProjectViewChart1 >>>>>>");
		
		progressDAO.progressProjectViewChart1(map);
		
	}

	@Override
	public void progressProjectViewChart2(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProgressServiceImpl.progressProjectViewChart2 >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.progressProjectViewChart2 >>>>>>");
		
		progressDAO.progressProjectViewChart2(map);
	}

	@Override
	public void progressUserViewTotal(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProgressServiceImpl.progressUserViewTotal >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.progressUserViewTotal >>>>>>");
		
		progressDAO.progressUserViewTotal(map);
		
	}

	@Override
	public void progressUserViewChart1(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProgressServiceImpl.progressUserViewChart1 >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.progressUserViewChart1 >>>>>>");
		
		progressDAO.progressUserViewChart1(map);
	}

	@Override
	public void progressUserViewChart2(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProgressServiceImpl.progressUserViewChart2 >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.progressUserViewChart2 >>>>>>");
		
		progressDAO.progressUserViewChart2(map);
	}
	
	@Override
	public List<Map<String, Object>> projectListExcelDown(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProgressServiceImpl.projectListExcelDown >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.projectListExcelDown >>>>>>");
		
		return progressDAO.projectListExcelDown(map);
	}

	@Override
	public List<Map<String, Object>> userListExcelDown(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProgressServiceImpl.userListExcelDown >>>>>>");
		System.out.println(">>>>>> ProgressServiceImpl.userListExcelDown >>>>>>");
		
		return progressDAO.userListExcelDown(map);
	}	
	
}
