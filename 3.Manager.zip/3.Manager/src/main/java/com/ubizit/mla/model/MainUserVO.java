/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : MainUserVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 9. 11.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 9. 11.
 * @version : 1.0
 * 
 */
public class MainUserVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String user_id;
	private String user_nm;
	private String assign_cnt;
	private String work_cnt;
	
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_nm() {
		return user_nm;
	}
	public void setUser_nm(String user_nm) {
		this.user_nm = user_nm;
	}
	public String getAssign_cnt() {
		return assign_cnt;
	}
	public void setAssign_cnt(String assign_cnt) {
		this.assign_cnt = assign_cnt;
	}
	public String getWork_cnt() {
		return work_cnt;
	}
	public void setWork_cnt(String work_cnt) {
		this.work_cnt = work_cnt;
	}
	
	
	
}
