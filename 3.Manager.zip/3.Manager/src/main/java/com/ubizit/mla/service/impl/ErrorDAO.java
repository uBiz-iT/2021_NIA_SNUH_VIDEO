/**
 * 
 */
package com.ubizit.mla.service.impl;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

/**
 * @Class Name : ErrorDAO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
@Repository("errorDAO")
public class ErrorDAO extends EgovAbstractDAO{

	private static final Logger LOGGER = LoggerFactory.getLogger(ErrorDAO.class);
	
	/**
	 * Method : getErrorSearchList
	 * 최초작성일 : 2020. 9. 8.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 에러 로그 리스트 조회
	 */
	public void getErrorSearchList(Map<String, Object> map) throws Exception {
		LOGGER.debug(">>>>>> ErrorDAO.getErrorSearchList >>>>>>");
		System.out.println(">>>>>> ErrorDAO.getErrorSearchList >>>>>>");
		
		select("error.search", map);
	}

}
