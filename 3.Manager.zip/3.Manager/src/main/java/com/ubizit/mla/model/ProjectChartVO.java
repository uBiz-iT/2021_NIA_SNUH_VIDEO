/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : ProjectChartVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
public class ProjectChartVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String user_name;		//사용자 이름
	private String user_num;		//완료/총 건수
	private String progress;		//사용자 진행률
	private String labeling_ord;	//라벨링 차수
	
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_num() {
		return user_num;
	}
	public void setUser_num(String user_num) {
		this.user_num = user_num;
	}
	public String getProgress() {
		return progress;
	}
	public void setProgress(String progress) {
		this.progress = progress;
	}
	public String getLabeling_ord() {
		return labeling_ord;
	}
	public void setLabeling_ord(String labeling_ord) {
		this.labeling_ord = labeling_ord;
	}
	
	
}
