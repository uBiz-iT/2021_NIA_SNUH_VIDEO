/**
 * 
 */
package com.ubizit.mla.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ubizit.mla.model.ImageRefVO;
import com.ubizit.mla.model.ImageReqVO;
import com.ubizit.mla.model.ImageSubVO;
import com.ubizit.mla.model.ImageTitleVO;
import com.ubizit.mla.model.ImageVO;
import com.ubizit.mla.service.ImageService;
import com.ubizit.mla.util.StringUtil;

import net.sf.json.JSONObject;

/**
 * @Class Name : ImageController.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
@Controller
public class ImageController {

	/** ImageService **/
	@Resource(name="imageService")
	private ImageService imageService;
	
	private final static Logger logger = Logger.getLogger(ImageController.class);
	
	/**
	 * Method : imageList
	 * 최초작성일 : 2020. 9. 9.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * @throws Exception
	 * Method 설명 : 프로젝트 이미지 현황 메인 화면
	 */
	@RequestMapping(value="/image.imageList.do")
	public String imageList(ImageReqVO imageReqVO, ModelMap model, HttpServletRequest request) throws Exception {
		logger.debug(">>>>>> ImageController >>>>>>");
		System.out.println(">>>>>> ImageController >>>>>>");
		
		if(StringUtil.isNotBlank(imageReqVO.getFromDate())){
			model.addAttribute("fromDate", imageReqVO.getFromDate());
		}
		if(StringUtil.isNotBlank(imageReqVO.getToDate())){
			model.addAttribute("toDate", imageReqVO.getToDate());
		}
		if(StringUtil.isNotBlank(imageReqVO.getCode_name())){
			model.addAttribute("code_name", imageReqVO.getCode_name());
		}
		if(StringUtil.isNotBlank(imageReqVO.getSub_yn())){
			model.addAttribute("sub_yn", imageReqVO.getSub_yn());
		}
		if(StringUtil.isNotBlank(imageReqVO.getProject_name())){
			model.addAttribute("project_name", imageReqVO.getProject_name());
		}
		if(StringUtil.isNotBlank(imageReqVO.getImage_name())){
			model.addAttribute("image_name", imageReqVO.getImage_name());
		}
		if(StringUtil.isNotBlank(imageReqVO.getRefer_yn())){
			model.addAttribute("refer_yn", imageReqVO.getRefer_yn());
		}
		if(StringUtil.isNotBlank(imageReqVO.getSearch_yn())){
			model.addAttribute("search_yn", imageReqVO.getSearch_yn());
		}
		if(StringUtil.isNotBlank(request.getParameter("page_cnt1"))){
			model.addAttribute("page_cnt1", request.getParameter("page_cnt1"));
		}else{
			model.addAttribute("page_cnt1", 50);
		}
		if(StringUtil.isNotBlank(request.getParameter("page_cnt2"))){
			model.addAttribute("page_cnt2", request.getParameter("page_cnt2"));
		}else{
			model.addAttribute("page_cnt2", 50);
		}
		return "image_list";
	}
	
	/**
	 * Method : getTitleSearchList
	 * 최초작성일 : 2020. 9. 9.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 검색조건 TITLE 조회
	 */
	@RequestMapping(value="/image.title.search.do")
	@ResponseBody
	public Map<String, Object> getTitleSearchList(HttpServletRequest request) throws Exception {
		logger.debug(">>>>>> ImageController.getTitleSearchList() >>>>>>");
		System.out.println(">>>>>> ImageController.getTitleSearchList() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<ImageTitleVO> p_ret_json = new ArrayList<>();
		
		String fromDate      = ((String[])paramMap.get("fromDate"))[0];
		String toDate        = ((String[])paramMap.get("toDate"))[0];
		String code_name     = ((String[])paramMap.get("code_name"))[0];
		String sub_yn  		 = ((String[])paramMap.get("sub_yn"))[0];
		String project_name  = ((String[])paramMap.get("project_name"))[0];
		String image_name    = ((String[])paramMap.get("image_name"))[0];
		String refer_yn      = ((String[])paramMap.get("refer_yn"))[0];
		String search_yn     = ((String[])paramMap.get("search_yn"))[0];
		int page_no = Integer.parseInt(((String[])paramMap.get("page_no"))[0]);
		int row_size = Integer.parseInt(((String[])paramMap.get("row_size"))[0]);
		
		if("Y".equals(search_yn)){
			jsonObject.put("FROMDATE", fromDate);
			jsonObject.put("TODATE", toDate);
			jsonObject.put("CODE_NAME", code_name);
			jsonObject.put("SUB_YN", sub_yn);
			jsonObject.put("PROJECT_NAME", project_name);
			jsonObject.put("IMAGE_NAME", image_name);
			jsonObject.put("REFER_YN", refer_yn);
			
			Map<String, Object> resultMap = new HashMap<String, Object>();
			resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
			
			imageService.getImageTitleSearchList(resultMap);
			
			int originalSize = 1;
			if((int)resultMap.get("p_ret_code") == 0){
				p_ret_json = (List<ImageTitleVO>) resultMap.get("p_ret_json");

				originalSize = p_ret_json.size();
				
				int start = Math.min(originalSize, Math.abs((page_no-1) * row_size));
				
				if(page_no == 1 && originalSize > row_size){
					p_ret_json.subList(row_size, originalSize).clear();
				
				}else if(page_no == 1 && originalSize <= row_size){
					
				}else if(page_no != 1){
					p_ret_json.subList(0, start).clear();
					
					int size = p_ret_json.size();
					int end = Math.min(row_size, size);
					p_ret_json.subList(end, size).clear();
				}
				
				
			}else{
				p_ret_json = null;
			}
		
			/** return map */
			map.put("total", originalSize);
			map.put("rows", p_ret_json);
			
		}

		return map;
		
	}
	
	/**
	 * Method : getImageSearchList
	 * 최초작성일 : 2020. 9. 10.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 프로젝트별 이미지 리스트 조회
	 */
	@RequestMapping(value="/image.search.do")
	@ResponseBody
	public Map<String, Object> getImageSearchList(HttpServletRequest request) throws Exception {
		logger.debug(">>>>>> ImageController.getImageSearchList() >>>>>>");
		System.out.println(">>>>>> ImageController.getImageSearchList() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<ImageVO> p_ret_json = new ArrayList<>();
		
		String project_cd = request.getParameter("project_cd");

		jsonObject.put("PROJECT_CD", project_cd);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		imageService.getImageSearchList(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<ImageVO>) resultMap.get("p_ret_json");
			
		}else{
			p_ret_json = null;
		}
	
		/** return map */
		map.put("rows", p_ret_json);
			
		
		return map;
	}
	
	
	/**
	 * Method : getImageSubSearchList
	 * 최초작성일 : 2020. 9. 10.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 프로젝트 이미지별 서브이미지 리스트 조회
	 */
	@RequestMapping(value="/image.sub.search.do")
	@ResponseBody
	public Map<String, Object> getImageSubSearchList(HttpServletRequest request) throws Exception {
		logger.debug(">>>>>> ImageController.getImageSubSearchList() >>>>>>");
		System.out.println(">>>>>> ImageController.getImageSubSearchList() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<ImageSubVO> p_ret_json = new ArrayList<>();
		
		String image_id = request.getParameter("image_id");
		String project_cd = request.getParameter("project_code");

		jsonObject.put("IMAGE_ID", image_id);
		jsonObject.put("PROJECT_CD", project_cd);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		imageService.getImageSubSearchList(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<ImageSubVO>) resultMap.get("p_ret_json");
			
		}else{
			p_ret_json = null;
		}
	
		/** return map */
		map.put("rows", p_ret_json);
			
		
		return map;
	}
	
	
	/**
	 * Method : getImageRefSearchList
	 * 최초작성일 : 2020. 9. 10.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 프로젝트별 참조이미지 리스트 조회
	 */
	@RequestMapping(value="/image.ref.search.do")
	@ResponseBody
	public Map<String, Object> getImageRefSearchList(HttpServletRequest request) throws Exception {
		logger.debug(">>>>>> ImageController.getImageRefSearchList() >>>>>>");
		System.out.println(">>>>>> ImageController.getImageRefSearchList() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<ImageRefVO> p_ret_json = new ArrayList<>();
		
		String project_cd = request.getParameter("project_cd");

		jsonObject.put("PROJECT_CD", project_cd);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		imageService.getImageRefSearchList(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<ImageRefVO>) resultMap.get("p_ret_json");
			
		}else{
			p_ret_json = null;
		}
	
		/** return map */
		map.put("rows", p_ret_json);
			
		
		return map;
	}	
	
	
	/**
	 * Method : getImageView
	 * 최초작성일 : 2020. 12. 1.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @param model
	 * @return
	 * @throws Exception
	 * Method 설명 : 이미지 팝업창 띄우기
	 */
	@RequestMapping(value="/image.imageView.do")
	public String getImageView(HttpServletRequest request, ModelMap model) throws Exception {
		logger.debug(">>>>>> ImageController.getImageView() >>>>>>");
		System.out.println(">>>>>> ImageController.getImageView() >>>>>>");
		
		String image_dir = request.getParameter("image_dir");
		String image_org_dir = request.getParameter("image_org_dir");
		
		List<String> image_list = new ArrayList<String>();
		image_list.add(image_dir);
		image_list.add(image_org_dir);
		
		model.addAttribute("image_list", image_list);
		
		return "image_view";
	}	
	
	
	
	
	
}


