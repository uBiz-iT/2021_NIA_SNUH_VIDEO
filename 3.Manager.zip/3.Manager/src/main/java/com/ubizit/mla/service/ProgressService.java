/**
 * 
 */
package com.ubizit.mla.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/**
 * @Class Name : ProgressService.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
public interface ProgressService {

	/**
	 * Method : getProgressProjectSearchList
	 * 최초작성일 : 2020. 9. 24.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 검색조건 조회 (프로젝트 현황)
	 */
	void getProgressProjectSearchList(Map<String, Object> map) throws Exception;

	/**
	 * Method : getProjectProgress
	 * 최초작성일 : 2020. 9. 24.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트 차트 진행률
	 */
	void getProjectProgress(Map<String, Object> map) throws Exception;

	/**
	 * Method : getProgressUserSearchList
	 * 최초작성일 : 2020. 9. 25.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 검색조건 조회 (사용자 현황)
	 */
	void getProgressUserSearchList(Map<String, Object> map) throws Exception;

	/**
	 * Method : getUserProgress
	 * 최초작성일 : 2020. 9. 25.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param resultMap
	 * Method 설명 : 유저 차트 진행률
	 */
	void getUserProgress(Map<String, Object> map) throws Exception;

	/**
	 * Method : getTotalSearch
	 * 최초작성일 : 2020. 12. 22.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param resultMap
	 * Method 설명 : 프로젝트 진행률 화면의 프로젝트 진행률/라벨링 대상개수/라벨링 완료건수/라벨링 미완료 건수
	 */
	void getTotalSearch(Map<String, Object> map) throws Exception;

	/**
	 * Method : selectProjectExcel
	 * 최초작성일 : 2020. 12. 23.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * @return
	 * Method 설명 : 프로젝트 진행률에서 엑셀 다운로드
	 */
	List<Map<String, Object>> selectProjectExcel(Map<String, Object> map) throws SQLException;

	/**
	 * Method : selectProjectExcelCnt
	 * 최초작성일 : 2020. 12. 23.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * @return
	 * Method 설명 : 프로젝트 진행률에서 판독자 수
	 */
	int selectProjectExcelCnt(Map<String, Object> map) throws Exception;

	/**
	 * Method : progressProjectPopupTotal
	 * 최초작성일 : 2021. 1. 4.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트 진행률 화면의 팝업창 상단 데이터
	 */
	void progressProjectPopupTotal(Map<String, Object> map) throws Exception;

	/**
	 * Method : progressProjectPopupChart1
	 * 최초작성일 : 2021. 1. 5.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트 진행률 화면의 팝업창 판독자 accept, reject 데이터
	 */
	void progressProjectPopupChart1(Map<String, Object> map) throws Exception;

	/**
	 * Method : progressProjectPopupChart2
	 * 최초작성일 : 2021. 1. 5.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param resultMap
	 * Method 설명 : 일치도(accept, reject), 불일치도, 미완료건수
	 */
	void progressProjectPopupChart2(Map<String, Object> map) throws Exception;

	/**
	 * Method : progressProjectPopupData
	 * 최초작성일 : 2021. 1. 6.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param param
	 * @return
	 * Method 설명 : 데이터셋 Accept, Reject 표
	 */
	List<Map<String, Object>> progressProjectPopupData(String param) throws Exception;

	/**
	 * Method : progressProjectPoupDataset
	 * 최초작성일 : 2021. 1. 6.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 데이터셋 Accept, Reject 표 (프로시저)
	 */
	void progressProjectPoupDataset(Map<String, Object> map) throws Exception;

	/**
	 * Method : progressProjectUser
	 * 최초작성일 : 2021. 1. 6.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param project_cd
	 * @return
	 * Method 설명 : 데이터셋 Accept, Reject 표의 유저
	 */
	List<Map<String, Object>> progressProjectUser(String project_cd) throws Exception;

	/**
	 * Method : selectProjectPassExDownSelect
	 * 최초작성일 : 2021. 1. 15.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * Method 설명 : Accept(Pass) 건 전체 프로젝트 엑셀다운로드
	 */
	List<Map<String, Object>> selectProjectPassExDownSelect() throws Exception;
	
	/**
	 * Method : selectProjectNonPassExDownSelect
	 * 최초작성일 : 2021. 1. 15.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * Method 설명 : Reject(Non-Pass) 건 전체 프로젝트 엑셀다운로드
	 */
	List<Map<String, Object>> selectProjectNonPassExDownSelect() throws Exception;

	/**
	 * Method : selectProjectPNExDownSelect
	 * 최초작성일 : 2021. 2. 18.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * Method 설명 :
	 */
	List<Map<String, Object>> selectProjectPNExDownSelect() throws Exception;

	/**
	 * Method : progressProjectViewTotal
	 * 최초작성일 : 2021. 6. 30.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 검수 완료/PASS/FAIL/미완료
	 */
	void progressProjectViewTotal(Map<String, Object> map) throws Exception;

	/**
	 * Method : progressProjectViewChart1
	 * 최초작성일 : 2021. 7. 5.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map 
	 * Method 설명 : 검수자 PASS, FAIL 그래프
	 */
	void progressProjectViewChart1(Map<String, Object> map) throws Exception;

	/**
	 * Method : progressProjectViewChart2
	 * 최초작성일 : 2021. 7. 5.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : PASS, FAIL 일치 비율 그래프
	 */
	void progressProjectViewChart2(Map<String, Object> map) throws Exception;

	/**
	 * Method : progressUserViewTotal
	 * 최초작성일 : 2021. 7. 8.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 검수 완료/PASS/FAIL/미완료
	 */
	void progressUserViewTotal(Map<String, Object> map) throws Exception;

	/**
	 * Method : progressUserViewChart1
	 * 최초작성일 : 2021. 7. 8.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : PSG 검수 및 이벤트 진행
	 */
	void progressUserViewChart1(Map<String, Object> map) throws Exception;

	/**
	 * Method : progressUserViewChart2
	 * 최초작성일 : 2021. 7. 8.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 프로젝트별 PASS, FAIL
	 */
	void progressUserViewChart2(Map<String, Object> map) throws Exception;

	/**
	 * Method : projectListExcelDown
	 * 최초작성일 : 2021. 8. 4.
	 * 작성자 : 장두언
	 * 변경이력 :
	 * @return
	 * Method 설명 : 프로젝트 진행 목록 엑셀 다운로드
	 */
	List<Map<String, Object>> projectListExcelDown(Map<String, Object> map) throws Exception;

	/**
	 * Method : userListExcelDown
	 * 최초작성일 : 2021. 8. 4.
	 * 작성자 : 장두언
	 * 변경이력 :
	 * @return
	 * Method 설명 : 검수자 진행 현황 엑셀 다운로드
	 */
	List<Map<String, Object>> userListExcelDown(Map<String, Object> map) throws Exception;	
}
