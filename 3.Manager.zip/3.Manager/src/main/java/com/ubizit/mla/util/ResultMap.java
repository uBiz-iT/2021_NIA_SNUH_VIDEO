/**
 * 
 */
package com.ubizit.mla.util;

import java.sql.Clob;
import java.sql.NClob;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @Class Name : ResultMap.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 9. 2.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 9. 2.
 * @version : 1.0
 * 
 */
public class ResultMap extends HashMap<String, Object>{
	
	private static final long serialVersionUID = 1L;

	public static ResultMap singleMap(String key, Object value){
		ResultMap map = new ResultMap();
		map.put(key, value);
		return map;
	}
	
	public void removeAll(){
		String[] arrKey = getKeyNames();
		if(arrKey != null && arrKey.length > 0){
			for(String key : arrKey){
				this.remove(key);
			}
		}
		
	}
	
	public void putAll(ResultMap map){
		Set<String> set = map.keySet();
		for(String key : set){
			this.put(key, map.get(key));
		}
	}
	
	public void putString(String key, String value){
		put(key, value);
	}
	
	
	/**
	 * Method : getString
	 * 최초작성일 : 2020. 9. 2.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param key
	 * @return
	 * Method 설명 : String 형으로 값 받기
	 */
	public String getString(Object key){
		Object obj = get(key);
		
		String rtnStr = "";
		if(obj instanceof String[]){
			String[] rtnVaL = getArrStr(key);
			rtnStr = StringUtil.getCodestrFromArray(rtnVaL, ",");
			
		}else if(obj instanceof List){
			List list = (List)obj;
			for(int i = 0; i < list.size(); i++){
				if(i > 0) rtnStr += ",";
				rtnStr += list.get(i);
			}
			
		}else if(obj instanceof Date){
			rtnStr = String.valueOf(obj);
			rtnStr = StringUtil.substring(rtnStr, 0, 10);
			
		}else if(obj instanceof Clob){
			rtnStr = StringUtil.getClobToString((Clob) obj);
		
		}else if(obj instanceof NClob){
			rtnStr = StringUtil.getNClobToString((NClob) obj);
			
		}else{
			rtnStr = (obj == null ? "" : String.valueOf(obj));
		
		}
		
		if("null".equals(rtnStr) || "undefined".equals(rtnStr)){
			rtnStr = "";
		}
		
		return rtnStr;
	}
	
	/**
	 * Method : getArrStr
	 * 최초작성일 : 2020. 9. 2.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param key
	 * @return
	 * Method 설명 : String 배열형으로 값 받기
	 */
	public String[] getArrStr(Object key){
		Object obj = get(key);
		
		String[] objVal = null;
		
		if(obj instanceof String[]){
			objVal = (String[])obj;
			
		}else if(obj instanceof List){
			List list = (List)obj;
			objVal = new String[list.size()];
			for(int i = 0; i < list.size(); i++){
				objVal[i] = (String) list.get(i);
			}
			
		}else{
			if(StringUtil.isNotBlank(getString(key))){
				objVal = new String[1];
				objVal[0] = getString(key);
				
			}else{
				objVal = null;
			}
		}
		
		return objVal;
	}
	
	/**
	 * Method : getMap
	 * 최초작성일 : 2020. 9. 2.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param key
	 * @return
	 * Method 설명 : Map 형태로 리턴
	 */
	public Map<String, Object> getMap(Object key){
		Object obj = get(key);
		if(obj instanceof Map){
			return (Map<String, Object>)obj;
		}else{
			return new HashMap<String, Object>();
		}
	}
	
	
	public String[] getKeyNames(){
		String commaKey = "";
		Iterator<String> keys = keySet().iterator();
		int counter = 0;
		
		while(keys.hasNext()){
			String key = keys.next();
			if(StringUtil.isNotBlank(key)){
				counter++;
				if(counter > 1){commaKey += ",";}
				commaKey += key;
			}
		}
		
		if(StringUtil.isNotBlank(commaKey)){
			return commaKey.split(",");
		}else{
			return null;
		}
		
	}
	
	
	
	
	

}
