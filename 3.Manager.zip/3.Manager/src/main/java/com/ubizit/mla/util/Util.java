package com.ubizit.mla.util;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.net.Inet4Address;
import java.net.UnknownHostException;
import java.sql.Clob;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.FieldPosition;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

public class Util {
	private static final Logger logger = LoggerFactory.getLogger(Util.class);
	

	public static String nullToStr(Object obj) {
		if (obj == null) {
			return "";
		}

		return obj.toString();
	}

	/**
	 * 대상 문자 변수가 null인 경우 넘겨온 기본값으로 반환
	 */
	public static String nullToStr(Object obj, String replaceStr) {
		if (obj == null || "".equals(obj)) {
			return replaceStr;
		}
		return obj.toString();
	}

	/**
	 * replace
	 *
	 * @param str String : 대상문자열
	 * @param pattern String : 바꿀 문자열
	 * @param replace String : 바뀔 문자열
	 */
	public static String replace(String str, String pattern, String replace) {
		int s = 0;
		int e = 0;
		StringBuffer result = new StringBuffer();

		while ((e = str.indexOf(pattern, s)) >= 0) {
			result.append(str.substring(s, e));
			result.append(replace);
			s = e + pattern.length();
		}

		result.append(str.substring(s));
		return result.toString();
	}

	/**
	 * <pre>
	 * 날짜 중 한 요소를 포맷에 따라 반환
	 * </pre>
	 *
	 * @param Date 변환대상 Date 객체
	 * @param String 포맷 문자열 "yyyy-MM-dd HH:mm:ss"
	 * @return String "yyyy-MM-dd HH:mm:ss" 형태로 변환된 문자열
	 */
	@SuppressWarnings("unused")
	public static String getToDay(String format) {
		Date d = new Date();
		if (d == null) {
			return null;
		}
		SimpleDateFormat smf = new SimpleDateFormat(format);
		return smf.format(d);
	}

	/**
	 * <pre>
	 * 날짜 형식의 문자열 8자리를 입력받아 format으로 지정된 형태로 반환
	 * </pre>
	 * @param date 날짜형태의 문자열 8자리 - 20080421
	 * @param format 반환될 문자열 형태 - yyyy-MM-dd HH:mm:ss
	 * @return String "yyyy-MM-dd HH:mm:ss" 형태로 변환된 문자열
	 */
	public static String getTimeStampString(String date, String format)
			throws ParseException {
		if (date == null) {
			return "";
		}

		if (date.length() == 12) {
			date = date + "00";
		} else if (date.length() == 10) {
			date = date + "0000";
		} else if (date.length() == 8) {
			date = date + "000000";
		} else if (date.length() == 6) {
			date = date + "01000000";
		} else if (date.length() == 4) {
			date = date + "0101000000";
		} else {
			return "";
		}

		Date d = null;
		SimpleDateFormat tmpFormat = new SimpleDateFormat("yyyyMMddHHmmss",
				Locale.KOREA);

		if (date.equals("")) {
			d = new Date();
		} else {
			tmpFormat.setLenient(true);
			d = tmpFormat.parse(date);
		}

		return getTimeStampString(d, format);
	}

	public static String getTimeStampString(Date date, String format) {
		SimpleDateFormat formatter = new SimpleDateFormat(format, Locale.KOREA);
		return formatter.format(date);
	}

	/**
	 * StringTokenizer를 이용해서 문자열을 분리해서 쿼리용(IN ())으로 문자열 조정
	 *
	 * @param str String : 대상문자열
	 * @param delim String : 분리자
	 */
	public static String getForInQuery(String str, String delim) {
		StringTokenizer stz = new StringTokenizer(str, delim);
		String inStr = "";
		int i = 0;
		while (stz.hasMoreTokens()) {
			inStr = inStr + (i == 0 ? "" : ",") + "'" + stz.nextToken().trim()
					+ "'";
			i++;
		}
		return inStr;
	}

	/**
	 * If string is null or empty string, return false. <br>
	 * If not, return true.
	 *
	 * <pre>
	 * StringUtil.isNotEmpty('') 		= false
	 * StringUtil.isNotEmpty(null) 		= false
	 * StringUtil.isNotEmpty('abc') 	= true
	 * </pre>
	 *
	 * @param str
	 * @return which empty string or not.
	 */
	public static boolean isNotEmpty(String str) {
		return !isEmpty(str);
	}

	/**
	 * If string is null or empty string, return true. <br>
	 * If not, return false.
	 *
	 * <pre>
	 * StringUtil.isEmpty('') 		= true
	 * StringUtil.isEmpty(null) 	= true
	 * StringUtil.isEmpty('abc') 	= false
	 * </pre>
	 *
	 * @param str
	 * @return which empty string or not.
	 */
	public static boolean isEmpty(String str) {
		return (str == null || str.length() == 0);
	}

	public static int nullToZero(String str) {

		if (str == null || "".equals(str)) {
			return 0;
		}

		int ret = 0;

		try {
			ret = Integer.parseInt(str);
		} catch (NullPointerException ne) {
			logger.info("exception : {}", ne);
		} catch (Exception e) {
			logger.info("exception : {}", e);
		}

		return ret;
	}
	
	public static int nullToZero(Object obj, int replaceInt) {
		if (obj == null || "".equals(obj)) {
			return replaceInt;
		}
		
		int ret = 0;

		try {
			ret = Integer.parseInt(obj.toString());
		} catch (NullPointerException ne) {
			logger.info("exception : {}", ne);			  
		} catch (Exception e) {
			logger.info("exception : {}", e);
		}

		return ret;
	}

	public static int nullToZero(Object str) {
		if (str == null || "".equals(str)) {
			return 0;
		}

		int ret = 0;

		try {
			ret = Integer.parseInt(str.toString());
		} catch (NullPointerException ne) {
			logger.info("exception : {}", ne);   			
		} catch (Exception e) {
			logger.info("exception : {}", e);
		}

		return ret;
	}
	
	
	
	public static int nullToDefault(Object str, int defaultValue) {
		if (str == null || "".equals(str)) {
			return defaultValue;
		}

		int ret = 0;

		try {
			ret = Integer.parseInt(str.toString());
		} catch (NullPointerException ne) {
			logger.info("exception : {}", ne);   			
		} catch (Exception e) {
			logger.info("exception : {}", e);
		}

		return ret;
	}

	public static String nullToBlank(String str) {

		if (str == null || "".equals(str)) {
			return "";
		} else {
			return str;
		}
	}

	public static String nullToBlank(Object str) {

		if (str == null) {
			return "";
		} else {
			return str.toString();
		}
	}

	public static String escape(String targetText_) {

		String targetText = targetText_;
		if (targetText == null || "".equals(targetText)) {
			return targetText;
		}
		targetText = nullToBlank(targetText);
		targetText = targetText.replaceAll("&", "&#38");
		targetText = targetText.replaceAll("\"", "&#34");
		targetText = targetText.replaceAll("'", "&#39");

		return targetText;
	}

	public static String getNowDatetime() {
		StringBuffer dateResult = new StringBuffer();
		Date date = new Date();
		SimpleDateFormat simpleDate = new SimpleDateFormat(
				"yyyy-MM-dd HH:mm:ss", Locale.KOREA);
		simpleDate.format(date, dateResult, new FieldPosition(1));
		return dateResult.toString();
	}

	/**
	 * file 확장자 추출 주의) Param Field 는 list 형태로 고정 되어야함.
	 *
	 * @param list
	 * @return Map
	 * @author KMH
	 */
	public static String getFileExt(Object orgFileName) {
		String filename = Util.nullToStr(orgFileName);
		int index = filename.lastIndexOf(".");
		if (index != -1) {
			return filename.substring(index + 1);
		} else {
			return "";
		}
	}

	public static String withSuffix(long count) {
		if (count < 1000) return "" + count;
		int exp = (int) (Math.log(count) / Math.log(1000));
		return String.format("%.1f%c",
							 count / Math.pow(1000, exp),
							 "kMGTPE".charAt(exp-1));
	}

	public static String withSuffix(String count) {
		if(count.matches("\\d*")) {
			return withSuffix(Long.valueOf(count));
		} else {
			return "0";
		}
	}

	public static String arrayToString(String[] arr, String separator) {

		if(arr != null && arr.length > 0 && separator!=null && !"".equals(separator.trim())) {

			List<String> list = new LinkedList<String>();
			Collections.addAll(list, arr);

			return listToString(list, separator);

		} else {
			return "";
		}
	}

	public static String listToString(List<String> list, String separator) {

		StringBuilder sb = new StringBuilder();

		if(list != null  && list.size() > 0 && separator!=null && !"".equals(separator.trim())) {

			for(int i=0 ; i<list.size() ; i++) {
				sb.append(list.get(i));

				if(i != (list.size()-1)) {
					sb.append(separator);
				}
			}
		}

		return sb.toString();
	}

	public static int colnToCnt(String coln) {
		int result = 0;
		switch (coln) {
		case "a": result = 1; break;
		case "b": result = 6; break;
		case "c": result = 104; break;
		case "d": result = 365; break;
		case "e": result = 26; break;
		case "f": result = 2; break;
		case "g": result = 0; break; //0.5
		case "h": result = 0; break; //0.3
		case "i": result = 156; break;
		case "k": result = 3; break;
		case "l": result = 5; break;
		case "m": result = 12; break;
		case "n": result = 7; break;
		case "o": result = 8; break;
		case "p": result = 9; break;
		case "q": result = 4; break;
		case "r": result = 10; break;
		case "s": result = 24; break;
		case "t": result = 36; break;
		case "u": result = 0; break;
		case "v": result = 0; break; //0.5
		case "w": result = 52; break;
		case "z": result = 0; break;
		default: result = 6;
		}

		return result;
	}

	public static String zeroToDot(String str) {
		if (str == null || "".equals(str) || str.equals("0")) {
			str = "-";
		}
		return str;
	}

	public static String zeroToDot(Object str) {
		if (str == null || "".equals(str) || "0".equals(str.toString()) ) {
			str = "-";
		}
		return str.toString();
	}
	
	public static String replaceStringByRegexp(String regex, String inputText, String toChar) {
		
		String resultText = "";
	
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(inputText); 
		
		StringBuffer replacedString = new StringBuffer();
		
		while(m.find()) {
			m.appendReplacement(replacedString, toChar);
		}
		
		m.appendTail(replacedString);
		
		resultText = replacedString.toString();

		return resultText ;
	}
	
	// 숫자체크 -------------------------------------------------------------------------
	public static boolean isNumberChk(String str){ 
		boolean result = true;
		if ("".equals(str)) {
			result = false;
		}
		
		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			
			if (c < 48 || c > 59) {
				result = false;
				break;
			}
		}
		return result;
	}
	
	public static String[] getParamArray(HttpServletRequest request, String key) {
		String[] array = null;
		
		Object obj = request.getParameterMap().get(key);
		
		if(obj instanceof String) {
			array = new String[1];
			array[0] = (String) obj;
		} else {
			array = (String[]) obj;
		}
		
		return array;
	}
	
	public static List<String> getParamList(HttpServletRequest request, String key) {
		List<String> list = new LinkedList<String>();
		
		Object obj = request.getParameterMap().get(key);
		
		if(obj instanceof String) {
			list.add((String) obj);
		} else {
			String[] array = (String[]) obj;
			for(String data : array){
				list.add(data);
			}
		}
		
		return list;
	}
	
	public static String getListToString(List<String> list){
		StringBuffer sb = new StringBuffer();
		
		for(String str : list){
			if(sb.length() > 0){
				sb.append(";");
			}
			
			sb.append(str);
		}
		
		if(sb.length() > 0){
			sb.append(";");
		}
		
		return sb.toString();
	}
	
	public static HashMap<String, Object> getLowerCaseKeyMap(HashMap<String, Object> input) {
		HashMap<String, Object> result = new HashMap<String, Object>();
		Iterator<String> iter = input.keySet().iterator();
		while(iter.hasNext()) {
			String key = iter.next();
			Object value = input.get(key);
			result.put(key.toLowerCase(), value);
		}
		return result;
	}
	
	/**
	 * <pre>
	 * 대상문자열(strTarget)에서 구분문자열(strDelim)을 기준으로 문자열을 분리하여
	 * 각 분리된 문자열을 배열에 할당하여 반환한다.
	 * </pre>
	 *
	 * @param strTarget
	 *            분리 대상 문자열
	 * @param strDelim
	 *            구분시킬 문자열로서 결과 문자열에는 포함되지 않는다.
	 * @param bContainNull
	 *            구분되어진 문자열중 공백문자열의 포함여부. true : 포함, false : 포함하지 않음.
	 * @return 분리된 문자열을 순서대로 배열에 격납하여 반환한다.
	 */
	public static String[] split(String strTarget, String strDelim, boolean bContainNull) {
		// StringTokenizer는 구분자가 연속으로 중첩되어 있을 경우 공백 문자열을 반환하지 않음.
		// 따라서 아래와 같이 작성함.
		int index = 0;
		String[] resultStrArray = new String[getStrCnt(strTarget, strDelim) + 1];
		String strCheck = new String(strTarget);
		while (strCheck.length() != 0) {
			int begin = strCheck.indexOf(strDelim);
			if (begin == -1) {
				resultStrArray[index] = strCheck;
				break;
			} else {
				int end = begin + strDelim.length();
				if (bContainNull) {
					resultStrArray[index++] = strCheck.substring(0, begin);
				}
				strCheck = strCheck.substring(end);
				if (strCheck.length() == 0 && bContainNull) {
					resultStrArray[index] = strCheck;
					break;
				}
			}
		}
		return resultStrArray;
	}
	
	public static int getStrCnt(String strTarget, String strSearch) {
		int result = 0;
		String strCheck = new String(strTarget);
		for (int i = 0; i < strTarget.length();) {
			int loc = strCheck.indexOf(strSearch);
			if (loc == -1) {
				break;
			} else {
				result++;
				i = loc + strSearch.length();
				strCheck = strCheck.substring(i);
			}
		}
		return result;
	}
	
	public static String[] getStringArray(String str, String strToken) {
		if (str.indexOf(strToken) != -1) {
			StringTokenizer st = new StringTokenizer(str, strToken);
			String[] stringArray = new String[st.countTokens()];
			for (int i = 0; st.hasMoreTokens(); i++) {
				stringArray[i] = st.nextToken();
			}
			return stringArray;
		}
		return new String[] { str };
	}
	
	public static String cropDot(String str, int i) {
		if(str==null) return "";
		return (str.length() > i) ? str.substring(0, i) + "..." : str;
	}
	
	public static String insertComma(String value_) {
		String value = value_;
		if (value == null || value.trim().equals(""))
			value = "0";
		long val = Long.parseLong(value);
		NumberFormat formatter = NumberFormat.getInstance();
		String money = formatter.format(val);
		return money;
	}
	
	public static String insertComma(long value) {
		NumberFormat formatter = NumberFormat.getInstance();
		String money = formatter.format(value);
		return money;
	}
	
	public static String mapToqueryString(Map<String, Object> param) {
		
		StringBuilder sb = new StringBuilder();
		
		Iterator<String> iter = param.keySet().iterator();
		while(iter.hasNext()) {
			String key = iter.next();
			Object obj = param.get(key);
			if(obj instanceof String && !key.equals("curPage")) {
				sb.append("&");
				sb.append(key);
				sb.append("=");
				sb.append((String)obj);
			}
		}
		
		if(sb.toString().length() > 2) {
			sb = new StringBuilder(sb.toString().substring(1));
		}
		
		return sb.toString();
	}
	
	
	public static String getIpAdress() {
		HttpServletRequest request =((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		return request.getRemoteAddr();
	}
	
	public static String clobToString(Clob clob) throws SQLException, IOException {
		
		if (clob == null) {
			return "";
		} else {
			return clob.getSubString(1, (int) clob.length());
		}
	}
	
	public static String clobToString(Object o) throws SQLException, IOException {
		if(o == null) {
			return "";
		}
		
		try {
			if(o instanceof Clob) {
				Clob clob = (Clob) o;
				return clob.getSubString(1, (int) clob.length());
			} else {
				return (String) o;
			}
		} catch(SQLException e) {
			logger.error("SQLException 에러", e);
		}
		return "";
	}
	
	public static Map<String, Object> clobToStringForMap(Map<String, Object> map) throws SQLException, IOException {
		for(String key : map.keySet()) {
			Object o = map.get(key);
			if(o instanceof Clob) {
				Clob clob = (Clob) o;
				
				map.put(key, clob.getSubString(1, (int) clob.length()));
			}
		}
		
		return map;
	}
	
	public static String getStringForCLOB(Clob clob) {
		StringBuilder sb = new StringBuilder();
		BufferedReader br = null;
		
	    try {
	        Reader reader = clob.getCharacterStream();
	        br = new BufferedReader(reader);

	        String line;
	        while(null != (line = br.readLine())) {
	            sb.append(line);
	        }
	        
	    } catch (SQLException e) {
	    	logger.error("SQLException 에러", e);
	    } catch (IOException e) {
	    	logger.error("IOException 에러", e);
	    } finally {
	    	try {
				br.close();
			} catch (IOException e) {
				logger.error("IOException 에러", e);
			}
		}
	    return sb.toString();
	}
	
	public static String fmDate(Date inTime, String xFormat) {
  		SimpleDateFormat fmt = new SimpleDateFormat(xFormat);
  		return fmt.format(inTime);
  	}
	
	public static String decimalFormat(double in, String pattern) {
  		DecimalFormat df = new DecimalFormat(pattern);
  		return df.format(in);
  	}
	
	public static String escapeString(String str){
		str = str.replace("<", "&lt;");	
		str = str.replace(">", "&gt;");	
		return str;
	}
	
	/*IP 가져오기*/
	public static String getIp(HttpServletRequest request){
		
		String ip = "";
		
		
		ip = request.getHeader("X-Forwarded-For");
        
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
            ip = request.getHeader("Proxy-Client-IP"); 
        } 
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
            ip = request.getHeader("WL-Proxy-Client-IP"); 
        } 
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
            ip = request.getHeader("HTTP_CLIENT_IP"); 
        } 
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
            ip = request.getHeader("HTTP_X_FORWARDED_FOR"); 
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
            ip = request.getHeader("X-Real-IP"); 
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
            ip = request.getHeader("X-RealIP"); 
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
            ip = request.getHeader("REMOTE_ADDR");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
        	ip = request.getRemoteAddr();
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
            try {
				ip = Inet4Address.getLocalHost().getHostAddress();
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
		
		return ip;
	}
	
	/*브라우져 가져오기*/
	public static String getBrowser(HttpServletRequest request){
		
		String browser = "";
		String agent = request.getHeader("User-Agent");
		
		if (agent != null) {
		   if (agent.indexOf("Trident") > -1) {
			   browser = "Explorer";
		   } else if (agent.indexOf("Edg") > -1) {
			   browser = "Edge";
		   } else if (agent.indexOf("Firefox") > -1) {
			   browser = "Firefox";
		   } else if (agent.indexOf("Chrome") > -1) {
			   browser = "Chrome/Safari";
		   } else if (agent.indexOf("Opera") > -1) {
			   browser = "Opera";
		   } else if (agent.indexOf("iPhone") > -1 && agent.indexOf("Mobile") > -1) {
			   browser = "iPhone";
		   } else if (agent.indexOf("Android") > -1 && agent.indexOf("Mobile") > -1) {
			   browser = "Android";
		   }
		}
		
		return browser;
	}
	
	/*os 가져오기*/
	public static String getOs(HttpServletRequest request){
		
		String os = "";
		String agent = request.getHeader("User-Agent");
		
		if (agent != null) {
			if(agent.indexOf("NT 10.0") != -1) os = "Windows 10";
			else if(agent.indexOf("NT 6.3") != -1) os = "Windows 8.1";
			else if(agent.indexOf("NT 6.2") != -1) os = "Windows 8";
			else if(agent.indexOf("NT 6.1") != -1) os = "Windows 7";
			else if(agent.indexOf("NT 6.0") != -1) os = "Windows Vista";
			else if(agent.indexOf("NT 5.2") != -1) os = "Windows Server 2003";
			else if(agent.indexOf("NT 5.1") != -1) os = "Windows XP";
			else if(agent.indexOf("NT 5.0") != -1) os = "Windows 2000";
			else if(agent.indexOf("NT") != -1) os = "Windows NT";
			else if(agent.indexOf("9x 4.90") != -1) os = "Windows Me";
			else if(agent.indexOf("98") != -1) os = "Windows 98";
			else if(agent.indexOf("95") != -1) os = "Windows 95";
			else if(agent.indexOf("Win16") != -1) os = "Windows 3.x";
			else if(agent.indexOf("Windows") != -1) os = "Windows";
			else if(agent.indexOf("Linux") != -1) os = "Linux";
			else if(agent.indexOf("Macintosh") != -1) os = "Macintosh";
			else os = ""; 
		}
		
		return os;
	}
}

