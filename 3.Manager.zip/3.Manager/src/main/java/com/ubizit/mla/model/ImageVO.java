/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : ImageVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
public class ImageVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String image_id;		//이미지 ID
	private String di_gender;		//성별
	private String di_age;			//나이
	private String sub_cnt;		//서브이미지 개수
//	private String image_name;		//이미지 파일명
//	private String image_view;		//이미지 보기
//	private String sub_yn;			//서브이미지 여부(개수)
//	private String reg_dt;			//등록일자
	
	public String getImage_id() {
		return image_id;
	}
	public void setImage_id(String image_id) {
		this.image_id = image_id;
	}
	public String getDi_gender() {
		return di_gender;
	}
	public void setDi_gender(String di_gender) {
		this.di_gender = di_gender;
	}
	public String getDi_age() {
		return di_age;
	}
	public void setDi_age(String di_age) {
		this.di_age = di_age;
	}
	public String getSub_cnt() {
		return sub_cnt;
	}
	public void setSub_cnt(String sub_cnt) {
		this.sub_cnt = sub_cnt;
	}
	
//	public String getImage_name() {
//		return image_name;
//	}
//	public void setImage_name(String image_name) {
//		this.image_name = image_name;
//	}
//	public String getImage_view() {
//		return image_view;
//	}
//	public void setImage_view(String image_view) {
//		this.image_view = image_view;
//	}
//	public String getSub_yn() {
//		return sub_yn;
//	}
//	public void setSub_yn(String sub_yn) {
//		this.sub_yn = sub_yn;
//	}
//	public String getReg_dt() {
//		return reg_dt;
//	}
//	public void setReg_dt(String reg_dt) {
//		this.reg_dt = reg_dt;
//	}

}
