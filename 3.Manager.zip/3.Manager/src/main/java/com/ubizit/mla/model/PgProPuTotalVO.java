/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : PgProPuTotalVO.java
 * @Description : Progress Project Popup Total
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 1. 4.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 1. 4.
 * @version : 1.0
 * 
 */
public class PgProPuTotalVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String progress;				//프로젝트 진행률
	private String complete_labeling;		//라벨링 완료 건수
	private String complete_percent;		//라벨링 완료 건수 백분율
	private String incomplete_labeling;	//라벨링 미완료 건수
	private String incomplete_percent;		//라벨링 미완료 건수 백분율
	private String total_num;				//라벨링 총 건수
	
	public String getProgress() {
		return progress;
	}
	public void setProgress(String progress) {
		this.progress = progress;
	}
	public String getComplete_labeling() {
		return complete_labeling;
	}
	public void setComplete_labeling(String complete_labeling) {
		this.complete_labeling = complete_labeling;
	}
	public String getComplete_percent() {
		return complete_percent;
	}
	public void setComplete_percent(String complete_percent) {
		this.complete_percent = complete_percent;
	}
	public String getIncomplete_labeling() {
		return incomplete_labeling;
	}
	public void setIncomplete_labeling(String incomplete_labeling) {
		this.incomplete_labeling = incomplete_labeling;
	}
	public String getIncomplete_percent() {
		return incomplete_percent;
	}
	public void setIncomplete_percent(String incomplete_percent) {
		this.incomplete_percent = incomplete_percent;
	}
	public String getTotal_num() {
		return total_num;
	}
	public void setTotal_num(String total_num) {
		this.total_num = total_num;
	}
	
}
