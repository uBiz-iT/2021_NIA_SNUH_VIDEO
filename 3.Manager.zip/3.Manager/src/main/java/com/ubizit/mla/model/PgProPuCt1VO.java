/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : PgProPuCt1VO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 1. 5.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 1. 5.
 * @version : 1.0
 * 
 */
public class PgProPuCt1VO implements Serializable{

	private static final long serialVersionUID = 1L;

	private String user_nm;
	private String accept_cnt;
	private String reject_cnt;
	private String accept_progress;
	private String reject_progress;
	
	public String getUser_nm() {
		return user_nm;
	}
	public void setUser_nm(String user_nm) {
		this.user_nm = user_nm;
	}
	public String getAccept_cnt() {
		return accept_cnt;
	}
	public void setAccept_cnt(String accept_cnt) {
		this.accept_cnt = accept_cnt;
	}
	public String getReject_cnt() {
		return reject_cnt;
	}
	public void setReject_cnt(String reject_cnt) {
		this.reject_cnt = reject_cnt;
	}
	public String getAccept_progress() {
		return accept_progress;
	}
	public void setAccept_progress(String accept_progress) {
		this.accept_progress = accept_progress;
	}
	public String getReject_progress() {
		return reject_progress;
	}
	public void setReject_progress(String reject_progress) {
		this.reject_progress = reject_progress;
	}
	
}
