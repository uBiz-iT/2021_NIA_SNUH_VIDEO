/**
 * 
 */
package com.ubizit.mla.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.mla.service.ProjectService;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * @Class Name : ProjectServiceImpl.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
@Service("projectService")
public class ProjectServiceImpl extends EgovAbstractServiceImpl implements ProjectService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProjectServiceImpl.class);
	
	@Resource(name="projectDAO")
	private ProjectDAO projectDAO;

	@Override
	public void getProjectSearchList(Map<String, Object> map) throws Exception {
		LOGGER.debug(">>>>>> ProjectServiceImpl.getProjectSearchList >>>>>>");
		System.out.println(">>>>>> ProjectServiceImpl.getProjectSearchList >>>>>>");
		
		projectDAO.getProjectSearchList(map);
	}

	@Override
	public void getProjectDetailView(Map<String, Object> map) throws Exception {
		LOGGER.debug(">>>>>> ProjectServiceImpl.getProjectDetailView >>>>>>");
		System.out.println(">>>>>> ProjectServiceImpl.getProjectDetailView >>>>>>");
		
		projectDAO.getProjectDetailView(map);
	}

	@Override
	public void getProjectReadManager(Map<String, Object> map) throws Exception {
		LOGGER.debug(">>>>>> ProjectServiceImpl.getProjectReadManager >>>>>>");
		System.out.println(">>>>>> ProjectServiceImpl.getProjectReadManager >>>>>>");
		
		projectDAO.getProjectReadManager(map);
	}

	@Override
	public void getProjectReadUser(Map<String, Object> map) throws Exception {
		LOGGER.debug(">>>>>> ProjectServiceImpl.getProjectReadUser >>>>>>");
		System.out.println(">>>>>> ProjectServiceImpl.getProjectReadUser >>>>>>");
		
		projectDAO.getProjectReadUser(map);
	}

	@Override
	public void insertProject(Map<String, Object> map) throws Exception {
		LOGGER.debug(">>>>>> ProjectServiceImpl.insertProject >>>>>>");
		System.out.println(">>>>>> ProjectServiceImpl.insertProject >>>>>>");
		
		projectDAO.insertProject(map);
	}

	@Override
	public void updateProject(Map<String, Object> map) throws Exception {
		LOGGER.debug(">>>>>> ProjectServiceImpl.updateProject >>>>>>");
		System.out.println(">>>>>> ProjectServiceImpl.updateProject >>>>>>");
		
		projectDAO.updateProject(map);
	}

	@Override
	public List<?> getUserSearch(String userName) throws Exception {
		LOGGER.debug(">>>>>> ProjectServiceImpl.getUserSearch >>>>>>");
		System.out.println(">>>>>> ProjectServiceImpl.getUserSearch >>>>>>");
		
		return projectDAO.getUserSearch(userName);
	}

	@Override
	public List<Map<String, Object>> projectExcelDown(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> ProjectServiceImpl.projectExcelDown >>>>>>");
		System.out.println(">>>>>> ProjectServiceImpl.projectExcelDown >>>>>>");
		
		return projectDAO.projectExcelDown(map);
	}
	
}
