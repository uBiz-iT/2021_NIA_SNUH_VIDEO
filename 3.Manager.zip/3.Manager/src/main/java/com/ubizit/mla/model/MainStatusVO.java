/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : MainStatusVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 9. 14.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 9. 14.
 * @version : 1.0
 * 
 */
public class MainStatusVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String project_cd;			//프로젝트 코드명
	private String project_nm;			//프로젝트명
	private String user_cnt;			//검수인원
	private String psg_cnt;			//PSG 검사등록건수
	private String reg_user_id;		//프로젝트 관리자
	private String reg_dt;				//등록일자
	
	public String getProject_cd() {
		return project_cd;
	}
	public void setProject_cd(String project_cd) {
		this.project_cd = project_cd;
	}
	public String getProject_nm() {
		return project_nm;
	}
	public void setProject_nm(String project_nm) {
		this.project_nm = project_nm;
	}
	public String getUser_cnt() {
		return user_cnt;
	}
	public void setUser_cnt(String user_cnt) {
		this.user_cnt = user_cnt;
	}
	public String getPsg_cnt() {
		return psg_cnt;
	}
	public void setPsg_cnt(String psg_cnt) {
		this.psg_cnt = psg_cnt;
	}
	public String getReg_user_id() {
		return reg_user_id;
	}
	public void setReg_user_id(String reg_user_id) {
		this.reg_user_id = reg_user_id;
	}
	public String getReg_dt() {
		return reg_dt;
	}
	public void setReg_dt(String reg_dt) {
		this.reg_dt = reg_dt;
	}
	
	

}
