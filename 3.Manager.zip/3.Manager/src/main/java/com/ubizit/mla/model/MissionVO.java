/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : MissionVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 7. 14.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 7. 14.
 * @version : 1.0
 * 
 */
public class MissionVO implements Serializable{

	private static final long serialVersionUID = 1L;

	private String week_base;
	private float pass_rate;
	private float pass_cnt_rate;
	private String beg_date;
	private String end_date;
	private String plan_cnt;
	
	public String getWeek_base() {
		return week_base;
	}
	public void setWeek_base(String week_base) {
		this.week_base = week_base;
	}
	public float getPass_rate() {
		return pass_rate;
	}
	public void setPass_rate(float pass_rate) {
		this.pass_rate = pass_rate;
	}
	public float getPass_cnt_rate() {
		return pass_cnt_rate;
	}
	public void setPass_cnt_rate(float pass_cnt_rate) {
		this.pass_cnt_rate = pass_cnt_rate;
	}
	public String getBeg_date() {
		return beg_date;
	}
	public void setBeg_date(String beg_date) {
		this.beg_date = beg_date;
	}
	public String getEnd_date() {
		return end_date;
	}
	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
	public String getPlan_cnt() {
		return plan_cnt;
	}
	public void setPlan_cnt(String plan_cnt) {
		this.plan_cnt = plan_cnt;
	}
	
}
