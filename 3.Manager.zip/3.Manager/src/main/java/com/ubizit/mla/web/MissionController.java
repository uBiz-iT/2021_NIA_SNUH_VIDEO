/**
 * 
 */
package com.ubizit.mla.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ubizit.mla.model.MainWMVO;
import com.ubizit.mla.model.MissionProgressVO;
import com.ubizit.mla.model.MissionVO;
import com.ubizit.mla.service.MissionService;
import com.ubizit.mla.util.ExcelUtil;
import com.ubizit.mla.util.StringUtil;

import net.sf.json.JSONObject;

/**
 * @Class Name : MissionController.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 7. 14.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 7. 14.
 * @version : 1.0
 *
 */
@Controller
public class MissionController {

	/** missionService **/
	@Resource(name="missionService")
	private MissionService missionService;
	
	private final static Logger logger = Logger.getLogger(MissionController.class);
	

	@RequestMapping(value="/manage.mission.do")
	public String mission(ModelMap model, HttpServletRequest request) throws Exception {
		logger.info(">>>>>> MissionController.mission >>>>>>");
		System.out.println(">>>>>> MissionController.mission >>>>>>");

		if(StringUtil.isNotBlank(request.getParameter("page_cnt"))){
			model.addAttribute("page_cnt", request.getParameter("page_cnt"));
		}else{
			model.addAttribute("page_cnt", 10);
		}
		
		return "mission";
	}
	
	
	/**
	 * Method : getMissionList
	 * 최초작성일 : 2021. 7. 14.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 과제 기준 정보 가져오기
	 */
	@RequestMapping(value="/manage.missionList.do")
	@ResponseBody
	public Map<String, Object> getMissionList(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> MissionController.getMissionList >>>>>>");
		System.out.println(">>>>>> MissionController.getMissionList >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<MissionVO> p_ret_json = new ArrayList<>();
		
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		missionService.getMissionList(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<MissionVO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		
		List<?> sumList = missionService.getSumMProgress();
		
		/** return map */
		map.put("rows", p_ret_json);
		map.put("sums", sumList);
		
		return map;
	}
	
	/**
	 * Method : getMissionProgress
	 * 최초작성일 : 2021. 7. 14.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 과제 진행 리스트
	 */
	@RequestMapping(value="/manage.mission.progress.do")
	@ResponseBody
	public Map<String, Object> getMissionProgress(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> MissionController.getMissionProgress >>>>>>");
		System.out.println(">>>>>> MissionController.getMissionProgress >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<MissionProgressVO> p_ret_json = new ArrayList<>();
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		missionService.getMissionProgress(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<MissionProgressVO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
	}
	
	/**
	 * Method : getWmAcmCharts
	 * 최초작성일 : 2021. 6. 7.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 주간/월간 누적 실적 그래프
	 */
	@RequestMapping(value="/mission.wmAcm.chart.do")
	@ResponseBody
	public Map<String, Object> getWmAcmCharts(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> MissionController.getWmAcmCharts() >>>>>>");
		System.out.println(">>>>>> MissionController.getWmAcmCharts() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		
		List<MainWMVO> ret_wm_json = new ArrayList<>();
		
		String wm = ((String[])paramMap.get("wm"))[0];
		String wmVal = ((String[])paramMap.get("wmVal"))[0];
		jsonObject.put("WM", wm);
		jsonObject.put("WM_VALUE", wmVal);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		missionService.getWmAcmCharts(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			ret_wm_json = (List<MainWMVO>) resultMap.get("p_ret_json");
		}else{
			ret_wm_json = null;
		}
		map.put("rows", ret_wm_json);
		
		return map;
	}	
	
	/**
	 * Method : saveMissionList
	 * 최초작성일 : 2021. 6. 7.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 과제 기준 정보 저장
	 */
	@RequestMapping(value="/manage.mission.save.do")
	@ResponseBody
	public Map<String, Object> saveMissionList(HttpServletRequest request) throws Exception {
		logger.info(">>>>>> MissionController.saveMissionList() >>>>>>");
		System.out.println(">>>>>> MissionController.saveMissionList() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		String p_ret_msg = "";
		int p_ret_code = 0;
		
		String plan_cnt = ((String[])paramMap.get("plan_cnt"))[0];
		String week_base = ((String[])paramMap.get("week_base"))[0];
		String pass_rate = ((String[])paramMap.get("pass_rate"))[0];
		String pass_cnt_rate = ((String[])paramMap.get("pass_cnt_rate"))[0];
		String beg_date = ((String[])paramMap.get("beg_date"))[0];
		String end_date = ((String[])paramMap.get("end_date"))[0];
		
		jsonObject.put("PLAN_CNT", plan_cnt);
		jsonObject.put("WEEK_BASE", week_base);
		jsonObject.put("PASS_RATE", pass_rate);
		jsonObject.put("PASS_CNT_RATE", pass_cnt_rate);
		jsonObject.put("BEG_DATE", beg_date);
		jsonObject.put("END_DATE", end_date);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		missionService.saveMissionList(resultMap);
		
		p_ret_msg = (String) resultMap.get("p_ret_msg");
		p_ret_code = (int) resultMap.get("p_ret_code");
		
		/** return map **/
		map.put("p_ret_msg", p_ret_msg);
		map.put("p_ret_code", p_ret_code);
		
		return map;
	}	
	
	/**
	 * Method : missionExcelDown
	 * 최초작성일 : 2021. 6. 7.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 기준 일자 등록 및 검수 목록
	 */
	@RequestMapping(value="/mission.excelDown.do")
	@ResponseBody
	public Map<String, Object> missionExcelDown(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(">>>>>> MissionController.missionExcelDown() >>>>>>");
		System.out.println(">>>>>> MissionController.missionExcelDown() >>>>>>");
		
		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");
		
		/** Object 선언 **/
		Map<String, Object> map = new HashMap<>();
		
		List<Map<String,Object>> dataList = missionService.missionExcelDown();
		
		List<String> logical_list = new ArrayList();
		logical_list.add("기준 일자");
		logical_list.add("PSG 등록 수량");
		logical_list.add("PSG 검수 완료 수량");
		logical_list.add("PSG 검수 일치 수량");
		logical_list.add("일치 건 중 PASS 수량");
		logical_list.add("이벤트 등록 수량");
		logical_list.add("이벤트 검수 완료 수량");
		logical_list.add("이벤트 완료 건 중 OK 수량");
		logical_list.add("이벤트 완료 건 중 NG 수량");
		
		List<String> physical_list = new ArrayList();
		physical_list.add("BASE_DATE");
		physical_list.add("PSG_CNT");
		physical_list.add("WORK_CNT");
		physical_list.add("SAME_CNT");
		physical_list.add("PASS_CNT");
		physical_list.add("EVENT_CNT");
		physical_list.add("EVENT_WORK_CNT");
		physical_list.add("EVENT_OK_CNT");
		physical_list.add("EVENT_NG_CNT");
		
		int[] type_int = null;
		int[][] cellRangeAddress = null;
		
		String downFileName = "기준일자_등록_및_검수_목록_"+StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] logical_names = logical_list.toArray(new String[logical_list.size()]);
		String[] physical_names = physical_list.toArray(new String[physical_list.size()]);
		
		int[] widths = new int[logical_names.length];
		
		for(int i = 0; i < logical_names.length; i++){
			widths[i] = 25;
		}
		
		ExcelUtil.excelDownload(response, cellRangeAddress, logical_names, physical_names, widths, type_int, downFileName, dataList);
		
		map.put("result", "Y");
		
		return map;
	}
	
	
}


