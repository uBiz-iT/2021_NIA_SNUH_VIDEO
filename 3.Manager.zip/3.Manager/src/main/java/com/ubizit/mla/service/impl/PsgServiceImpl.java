package com.ubizit.mla.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.mla.model.PsgDiVO;
import com.ubizit.mla.service.PsgService;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * 
 * @Class Name : PsgServiceImpl.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 6. 15.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 6. 15.
 * @version : 1.0
 *
 */
@Service("psgService")
public class PsgServiceImpl extends EgovAbstractServiceImpl implements PsgService{

	private static final Logger LOGGER = LoggerFactory.getLogger(PsgServiceImpl.class);
	
	@Resource(name="psgDAO")
	private PsgDAO psgDAO;

	@Override
	public void getVideoSearchList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> PsgServiceImpl.getVideoSearchList >>>>>>");
		System.out.println(">>>>>> PsgServiceImpl.getVideoSearchList >>>>>>");
		
		psgDAO.getVideoSearchList(map);
	}

	@Override
	public PsgDiVO getDiSearch(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> PsgServiceImpl.getDiSearch >>>>>>");
		System.out.println(">>>>>> PsgServiceImpl.getDiSearch >>>>>>");
		
		return psgDAO.getDiSearch(map);
	}

	@Override
	public void getEventSearchList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> PsgServiceImpl.getEventSearchList >>>>>>");
		System.out.println(">>>>>> PsgServiceImpl.getEventSearchList >>>>>>");
		
		psgDAO.getEventSearchList(map);
	}

	@Override
	public List<?> getEventTpList() throws Exception {
		LOGGER.info(">>>>>> PsgServiceImpl.getEventTpList >>>>>>");
		System.out.println(">>>>>> PsgServiceImpl.getEventTpList >>>>>>");
		
		return psgDAO.getEventTpList();
	}

	@Override
	public void updateEventList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> PsgServiceImpl.updateEventList >>>>>>");
		System.out.println(">>>>>> PsgServiceImpl.updateEventList >>>>>>");
		
		psgDAO.updateEventList(map);
	}

	@Override
	public List<?> eventTypeList() throws Exception {
		LOGGER.info(">>>>>> PsgServiceImpl.eventTypeList >>>>>>");
		System.out.println(">>>>>> PsgServiceImpl.eventTypeList >>>>>>");
		
		return psgDAO.eventTypeList();
	}

	@Override
	public void updateEventTypeList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> PsgServiceImpl.updateEventTypeList >>>>>>");
		System.out.println(">>>>>> PsgServiceImpl.updateEventTypeList >>>>>>");
		
		psgDAO.updateEventTypeList(map);
	}

	@Override
	public List<Map<String, Object>> eventExcelDown() throws Exception {
		LOGGER.info(">>>>>> PsgServiceImpl.eventExcelDown >>>>>>");
		System.out.println(">>>>>> PsgServiceImpl.eventExcelDown >>>>>>");
		
		return psgDAO.eventExcelDown();
	}

	@Override
	public List<Map<String, Object>> videoExcelDown(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> PsgServiceImpl.videoExcelDown >>>>>>");
		System.out.println(">>>>>> PsgServiceImpl.videoExcelDown >>>>>>");
		
		return psgDAO.videoExcelDown(map);
	}

	
	
}
