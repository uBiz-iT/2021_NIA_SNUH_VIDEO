/**
 * 
 */
package com.ubizit.mla.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ubizit.mla.model.AnalysisEventVO;
import com.ubizit.mla.model.AnalysisVO;
import com.ubizit.mla.service.AnalysisService;
import com.ubizit.mla.util.ExcelUtil;
import com.ubizit.mla.util.StringUtil;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * @Class Name : AnalysisController.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
@Controller
public class AnalysisController {

	/** AnalysisService **/
	@Resource(name="analysisService")
	private AnalysisService analysisService;
	
	private final static Logger logger = Logger.getLogger(AnalysisController.class);
	
	/**
	 * Method : analysisList
	 * 최초작성일 : 2020. 9. 16.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * @throws Exception
	 * Method 설명 : 분석 메인 화면
	 */
	@RequestMapping(value="/analysis.analysisList.do")
	public String analysisList(ModelMap model, HttpServletRequest request) throws Exception {
		logger.debug(">>>>>> AnalysisController >>>>>>");
		System.out.println(">>>>>> AnalysisController >>>>>>");

		if(StringUtil.isNotBlank(request.getParameter("page_cnt1"))){
			model.addAttribute("page_cnt1", request.getParameter("page_cnt1"));
		}else{
			model.addAttribute("page_cnt1", 50);
		}
		if(StringUtil.isNotBlank(request.getParameter("page_cnt2"))){
			model.addAttribute("page_cnt2", request.getParameter("page_cnt2"));
		}else{
			model.addAttribute("page_cnt2", 100);
		}
		if(StringUtil.isNotBlank(request.getParameter("project_code"))){
			model.addAttribute("project_code", request.getParameter("project_code"));
		}
		
		return "analysis_list";
	}

	/**
	 * Method : analysisList
	 * 최초작성일 : 2020. 9. 16.
	 * 작성자 : USH
	 * 변경이력 :
	 * @return
	 * @throws Exception
	 * Method 설명 : 프로젝트 진행률에서 크로스체크 넘어올때
	 */
	@RequestMapping(value="/analysis.analysisProgress.do")
	public String analysis(ModelMap model, HttpServletRequest request) throws Exception {
		logger.debug(">>>>>> AnalysisController.analysis>>>>>>");
		System.out.println(">>>>>> AnalysisController.analysis >>>>>>");

		if(StringUtil.isNotBlank(request.getParameter("page_cnt1"))){
			model.addAttribute("page_cnt1", request.getParameter("page_cnt1"));
		}else{
			model.addAttribute("page_cnt1", 50);
		}
		if(StringUtil.isNotBlank(request.getParameter("page_cnt2"))){
			model.addAttribute("page_cnt2", request.getParameter("page_cnt2"));
		}else{
			model.addAttribute("page_cnt2", 100);
		}
		
		if(StringUtil.isNotBlank(request.getParameter("project_code"))){
			model.addAttribute("projectCd", request.getParameter("project_code"));
		}
		
		return "analysis_list";
	}
	
	
	/**
	 * 
	 * Method : projectSearch
	 * 최초작성일 : 2020. 9. 16.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param model
	 * @return
	 * @throws Exception
	 * Method 설명 : 프로젝트 조회 화면
	 */
	@RequestMapping(value="/analysis.write.do")
	public String projectSearch(ModelMap model,@RequestParam(value="project_cd", defaultValue="") String project_cd) throws Exception {
		logger.debug(">>>>>> AnalysisController.getProjectList() >>>>>>");
		System.out.println(">>>>>> AnalysisController.getProjectList() >>>>>>");
		
		if(StringUtil.isNotBlank(project_cd)){
			model.addAttribute("project_cd", project_cd);
		}
		
		return "analysis_write";
	}
	
	
	/**
	 * Method : getProjectList
	 * 최초작성일 : 2020. 9. 16.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param model
	 * @return
	 * @throws Exception
	 * Method 설명 : 프로젝트 목록 조회
	 */
	@RequestMapping(value="/analysis.search.do")
	@ResponseBody
	public Map<String, Object> getProjectList(HttpServletRequest request) throws Exception {
		logger.debug(">>>>>> AnalysisController.getProjectList() >>>>>>");
		System.out.println(">>>>>> AnalysisController.getProjectList() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		Map<String, Object> map = new HashMap<String, Object>();
		
		String project_cd = ((String[])paramMap.get("project_cd"))[0];
		List<?> projectList = analysisService.getProjectList(project_cd);
		
		/** return map */
		map.put("rows", projectList);
		
		return map;
		
	}

	
	
	
	/**
	 * Method : videoPath
	 * 최초작성일 : 2021. 8. 11.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param model
	 * @return
	 * @throws Exception
	 * Method 설명 : video 경로
	 */
	@RequestMapping(value="/analysis.video.do")
	@ResponseBody
	public Map<String, Object> videoPath(HttpServletRequest request) throws Exception {
		logger.debug(">>>>>> AnalysisController.videoPath() >>>>>>");
		System.out.println(">>>>>> AnalysisController.videoPath() >>>>>>");
	
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		
		String project_cd = ((String[])paramMap.get("project_cd"))[0];
		String psg_id = ((String[])paramMap.get("psg_id"))[0];
		
		jsonObject.put("PROJECT_CD", project_cd);
		jsonObject.put("PSG_ID", psg_id);
		
		Map<String, Object> videoPath = analysisService.videoPath(jsonObject);
		
//		System.out.println("video : " + videoPath.get("fileName"));
//		System.out.println("video : " + videoPath.get("videoFilePath"));
		
		return videoPath;
	}
		
	/**
	 * Method : crossChkList
	 * 최초작성일 : 2021. 7. 9.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param model
	 * @return
	 * @throws Exception
	 * Method 설명 : 크로스체크
	 */
	@RequestMapping(value="/analysis.crossChk.do")
	@ResponseBody
	public Map<String, Object> crossChkList (HttpServletRequest request) throws Exception {
		logger.debug(">>>>>> AnalysisController.crossChkList() >>>>>>");
		System.out.println(">>>>>> AnalysisController.crossChkList() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<AnalysisVO> p_ret_json = new ArrayList<>();
		
		String project_cd = ((String[])paramMap.get("project_cd"))[0];
		String same_yn = ((String[])paramMap.get("same_yn"))[0];
		
		jsonObject.put("PROJECT_CD", project_cd);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		analysisService.crossChkList(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<AnalysisVO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		
		
		JSONArray jsonArray = JSONArray.fromObject(p_ret_json);
		
		JSONObject obj = new JSONObject();
		for(int i = 0; i < p_ret_json.size(); i++){
			String[] user_id_list = p_ret_json.get(i).getUser_id_list().split(",", -1);
			String[] user_name_list = p_ret_json.get(i).getUser_name_list().split(",", -1);
			String[] user_memo_list = p_ret_json.get(i).getUser_memo_list().split("@", -1);
			
			//change key name
			jsonArray.getJSONObject(i).put("검사(환자) ID",	jsonArray.getJSONObject(i).get("psg_id"));
			jsonArray.getJSONObject(i).put("검수완료여부",jsonArray.getJSONObject(i).get("done_yn"));
			
			jsonArray.getJSONObject(i).put("검수일치결과",jsonArray.getJSONObject(i).get("res_desc"));
			
			if(same_yn.equals("N")){
				jsonArray.getJSONObject(i).put("검수일치여부",jsonArray.getJSONObject(i).get("same_yn"));
			}else{
				jsonArray.getJSONObject(i).put("검수일치여부",jsonArray.getJSONObject(i).get("done_same_yn"));
			}
			
			
			//remove
			jsonArray.getJSONObject(i).remove("user_id_list");
			jsonArray.getJSONObject(i).remove("user_name_list");
			jsonArray.getJSONObject(i).remove("user_memo_list");
			jsonArray.getJSONObject(i).remove("psg_id");
			jsonArray.getJSONObject(i).remove("done_yn");
			jsonArray.getJSONObject(i).remove("same_yn");
			jsonArray.getJSONObject(i).remove("done_same_yn");
			jsonArray.getJSONObject(i).remove("chk_res");
			jsonArray.getJSONObject(i).remove("res_desc");
		
			for(int j = 0; j < user_id_list.length; j++){
				String[] id_list = user_id_list[j].split("/", -1);
				String[] memo_list = user_memo_list[j].split("/", -1);
				String tooltip = "";
				
				obj = (JSONObject) jsonArray.get(i);
				
				obj.put(user_name_list[j], id_list[1]);
				tooltip = "<div class='tip_icon'>"+memo_list[1]+"</div>";
				obj.put(user_name_list[j]+" 메모", tooltip);
				
				jsonArray.set(i, obj);
			}
			
		}
		
		
		/** return map */
		map.put("rows", jsonArray);
		map.put("total", p_ret_json.size());
		
		return map;
		
	}
	
	/**
	 * Method : crossChkList
	 * 최초작성일 : 2021. 7. 9.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param model
	 * @return
	 * @throws Exception
	 * Method 설명 : 크로스체크 이벤트 리스트
	 */
	@RequestMapping(value="/analysis.eventList.do")
	@ResponseBody
	public Map<String, Object> eventList (HttpServletRequest request) throws Exception {
		logger.debug(">>>>>> AnalysisController.eventList() >>>>>>");
		System.out.println(">>>>>> AnalysisController.eventList() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		
		String psg_id = ((String[])paramMap.get("psg_id"))[0];
		String project_cd = ((String[])paramMap.get("project_cd"))[0];
		String user_id = "";
		
		jsonObject.put("PSG_ID", psg_id);
		jsonObject.put("PROJECT_CD", project_cd);
		
		List<Map<String, Object>> psgUserList = analysisService.psgUser(jsonObject);
		
		if(StringUtil.isNotBlank(((String[])paramMap.get("user_id"))[0])){
			user_id = ((String[])paramMap.get("user_id"))[0];
		}
		
		if(psgUserList.size() > 0){
			List<AnalysisEventVO> p_ret_json = new ArrayList<>();
			
			if(user_id.equals("")){
				jsonObject.put("USER_ID", psgUserList.get(0).get("userId"));
			}else{
				jsonObject.put("USER_ID", user_id);
			}
			
			Map<String, Object> resultMap = new HashMap<String, Object>();
			resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
			
			analysisService.eventList(resultMap);

			if((int)resultMap.get("p_ret_code") == 0){
				p_ret_json = (List<AnalysisEventVO>) resultMap.get("p_ret_json");
			}else{
				p_ret_json = null;
			}
			
			JSONArray jsonArray = JSONArray.fromObject(p_ret_json);
			
			for(int j = 0; j < p_ret_json.size(); j++){
				
				//change key name
				jsonArray.getJSONObject(j).put("이벤트 순번",	jsonArray.getJSONObject(j).get("event_seq"));
				jsonArray.getJSONObject(j).put("이벤트명",jsonArray.getJSONObject(j).get("event_nm"));
				jsonArray.getJSONObject(j).put("이벤트 타입",jsonArray.getJSONObject(j).get("event_tp_nm"));
				jsonArray.getJSONObject(j).put("이벤트 의미",jsonArray.getJSONObject(j).get("event_note"));
				jsonArray.getJSONObject(j).put("시작초",jsonArray.getJSONObject(j).get("beg_sec"));
				jsonArray.getJSONObject(j).put("종료초",jsonArray.getJSONObject(j).get("end_sec"));
				jsonArray.getJSONObject(j).put("시작일시","<a class='event_a' onclick='second("+jsonArray.getJSONObject(j).get("beg_sec")+")'>" + jsonArray.getJSONObject(j).get("beg_dt") + "</a>");
				jsonArray.getJSONObject(j).put("종료일시","<a class='event_a' onclick='second("+jsonArray.getJSONObject(j).get("end_sec")+")'>" + jsonArray.getJSONObject(j).get("end_dt") + "</a>");
//				jsonArray.getJSONObject(j).put("시작일시_TS",jsonArray.getJSONObject(j).get("beg_ts"));
//				jsonArray.getJSONObject(j).put("종료일시_TS",jsonArray.getJSONObject(j).get("end_ts"));
				jsonArray.getJSONObject(j).put("경과시간",jsonArray.getJSONObject(j).get("elapsed_sec"));
				jsonArray.getJSONObject(j).put("시작 EPOCH 번호",jsonArray.getJSONObject(j).get("beg_epo_no"));
				jsonArray.getJSONObject(j).put("종료 EPOCH 번호",jsonArray.getJSONObject(j).get("end_epo_no"));
				jsonArray.getJSONObject(j).put("검수결과",jsonArray.getJSONObject(j).get("chk_res"));
				jsonArray.getJSONObject(j).put("메모",jsonArray.getJSONObject(j).get("memo"));
				jsonArray.getJSONObject(j).put("검수일자",jsonArray.getJSONObject(j).get("work_date"));
				
				//remove
				jsonArray.getJSONObject(j).remove("event_seq");
				jsonArray.getJSONObject(j).remove("event_nm");
				jsonArray.getJSONObject(j).remove("event_tp_nm");
				jsonArray.getJSONObject(j).remove("event_note");
				jsonArray.getJSONObject(j).remove("beg_sec");
				jsonArray.getJSONObject(j).remove("end_sec");
				jsonArray.getJSONObject(j).remove("beg_dt");
				jsonArray.getJSONObject(j).remove("end_dt");
//				jsonArray.getJSONObject(j).remove("beg_ts");
//				jsonArray.getJSONObject(j).remove("end_ts");
				jsonArray.getJSONObject(j).remove("elapsed_sec");
				jsonArray.getJSONObject(j).remove("beg_epo_no");
				jsonArray.getJSONObject(j).remove("end_epo_no");
				jsonArray.getJSONObject(j).remove("chk_res");
				jsonArray.getJSONObject(j).remove("memo");
				jsonArray.getJSONObject(j).remove("work_date");
			
			}			
			
			/** return map */
			map.put("row", jsonArray);
			map.put("total", p_ret_json.size());
			map.put("user", jsonObject.get("USER_ID"));
			map.put("user_list", psgUserList);
			
		}
		
//		for(int i = 0; i < psgUserList.size(); i++){
//			List<AnalysisEventVO> p_ret_json = new ArrayList<>();
//			
//			jsonObject.put("USER_ID", psgUserList.get(i).get("userId"));
//			
//			Map<String, Object> resultMap = new HashMap<String, Object>();
//			resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
//			
//			analysisService.eventList(resultMap);
//		
//			if((int)resultMap.get("p_ret_code") == 0){
//				p_ret_json = (List<AnalysisEventVO>) resultMap.get("p_ret_json");
//			}else{
//				p_ret_json = null;
//			}
//
//			JSONArray jsonArray = JSONArray.fromObject(p_ret_json);
//			
//			JSONObject obj = new JSONObject();
//			for(int j = 0; j < p_ret_json.size(); j++){
//				
//				//change key name
//				jsonArray.getJSONObject(j).put("이벤트 순번",	jsonArray.getJSONObject(j).get("event_seq"));
//				jsonArray.getJSONObject(j).put("이벤트명",jsonArray.getJSONObject(j).get("event_nm"));
//				jsonArray.getJSONObject(j).put("이벤트 타입",jsonArray.getJSONObject(j).get("event_tp_nm"));
//				jsonArray.getJSONObject(j).put("이벤트 의미",jsonArray.getJSONObject(j).get("event_note"));
//				jsonArray.getJSONObject(j).put("시작초",jsonArray.getJSONObject(j).get("beg_sec"));
//				jsonArray.getJSONObject(j).put("종료초",jsonArray.getJSONObject(j).get("end_sec"));
//				jsonArray.getJSONObject(j).put("경과시간",jsonArray.getJSONObject(j).get("elapsed_sec"));
//				jsonArray.getJSONObject(j).put("시작 EPOCH 번호",jsonArray.getJSONObject(j).get("beg_epo_no"));
//				jsonArray.getJSONObject(j).put("종료 EPOCH 번호",jsonArray.getJSONObject(j).get("end_epo_no"));
//				jsonArray.getJSONObject(j).put("검수결과",jsonArray.getJSONObject(j).get("chk_res"));
//				jsonArray.getJSONObject(j).put("메모",jsonArray.getJSONObject(j).get("memo"));
//				jsonArray.getJSONObject(j).put("검수일자",jsonArray.getJSONObject(j).get("work_date"));
//				
//				//remove
//				jsonArray.getJSONObject(j).remove("event_seq");
//				jsonArray.getJSONObject(j).remove("event_nm");
//				jsonArray.getJSONObject(j).remove("event_tp_nm");
//				jsonArray.getJSONObject(j).remove("event_note");
//				jsonArray.getJSONObject(j).remove("beg_sec");
//				jsonArray.getJSONObject(j).remove("end_sec");
//				jsonArray.getJSONObject(j).remove("elapsed_sec");
//				jsonArray.getJSONObject(j).remove("beg_epo_no");
//				jsonArray.getJSONObject(j).remove("end_epo_no");
//				jsonArray.getJSONObject(j).remove("chk_res");
//				jsonArray.getJSONObject(j).remove("memo");
//				jsonArray.getJSONObject(j).remove("work_date");
//			
//			}
//			
//			/** return map */
//			map.put("row"+i, jsonArray);
//			map.put("total", p_ret_json.size());
//			map.put("user_list", psgUserList);
//		}
		
		return map;
		
	}
	
	
	/**
	 * Method : eventExcelDown
	 * 최초작성일 : 2021. 8. 10.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 이벤트 검수 결과 엑셀 다운로드
	 */
	@RequestMapping(value="/analysis.excelDown.do")
	@ResponseBody
	public Map<String, Object> eventExcelDown(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info(">>>>>> AnalysisController.eventExcelDown() >>>>>>");
		System.out.println(">>>>>> AnalysisController.eventExcelDown() >>>>>>");
		
		response.reset();
		response.setHeader("Set-Cookie", "fileDownload=true; path=/");
		
		/** Object 선언 **/
		Map<String, Object> map = new HashMap<>();
		Map<?, ?> paramMap = request.getParameterMap();	
		
		String project_cd  = ((String[])paramMap.get("project_cd"))[0];
		String psg_id  = ((String[])paramMap.get("psg_id"))[0];
		String user_id  = ((String[])paramMap.get("user_id"))[0];
		
		map.put("project_cd", project_cd);
		map.put("psg_id", psg_id);
		map.put("user_id", user_id);
		
		List<Map<String,Object>> dataList = analysisService.eventExcelDown(map);
		
		List<String> logical_list = new ArrayList();
		logical_list.add("이벤트 순번");
		logical_list.add("이벤트명");
		logical_list.add("이벤트 타입");
		logical_list.add("이벤트 의미");
		logical_list.add("시작초");
		logical_list.add("종료초");
		logical_list.add("경과시간");
		logical_list.add("시작 EPOCH 번호");
		logical_list.add("종료 EPOCH 번호");
		logical_list.add("검수결과");
		logical_list.add("메모");
		logical_list.add("검수일자");
		
		List<String> physical_list = new ArrayList();
		physical_list.add("EVENT_SEQ");
		physical_list.add("EVENT_NM");
		physical_list.add("EVENT_TP_NM");
		physical_list.add("EVENT_NOTE");
		physical_list.add("BEG_SEC");
		physical_list.add("END_SEC");
		physical_list.add("ELAPSED_SEC");
		physical_list.add("BEG_EPO_NO");
		physical_list.add("END_EPO_NO");
		physical_list.add("CHK_RES");
		physical_list.add("MEMO");
		physical_list.add("WORK_DATE");
		
		
		int[] type_int = null;
		int[][] cellRangeAddress = null;
		
		String downFileName = "이벤트검수결과_"+user_id+"_"+StringUtil.getSimpleDateFormat("yyyyMMdd");
		String[] logical_names = logical_list.toArray(new String[logical_list.size()]);
		String[] physical_names = physical_list.toArray(new String[physical_list.size()]);
		
		int[] widths = new int[logical_names.length];
		
		for(int i = 0; i < logical_names.length; i++){
			widths[i] = 25;
		}
		
		ExcelUtil.excelDownload(response, cellRangeAddress, logical_names, physical_names, widths, type_int, downFileName, dataList);
		
		map.put("result", "Y");
		
		return map;
	}	
	
	
}



















