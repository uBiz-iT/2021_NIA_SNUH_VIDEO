/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : ImageTitleVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
public class ImageTitleVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String row_num;		//순번
	private String code_name;		//프로젝트코드명
	private String project_name;	//프로젝트명
	private String image_cnt;		//프로젝트별 이미지개수
	private String image_sub_cnt;	//이미지별 서브이미지개수
	private String image_ref_cnt;	//프로젝트별 참조이미지개수
	private String project_user;	//프로젝트 참여인원
	
	public String getRow_num() {
		return row_num;
	}
	public void setRow_num(String row_num) {
		this.row_num = row_num;
	}
	public String getCode_name() {
		return code_name;
	}
	public void setCode_name(String code_name) {
		this.code_name = code_name;
	}
	public String getProject_name() {
		return project_name;
	}
	public void setProject_name(String project_name) {
		this.project_name = project_name;
	}
	public String getImage_cnt() {
		return image_cnt;
	}
	public void setImage_cnt(String image_cnt) {
		this.image_cnt = image_cnt;
	}
	public String getImage_sub_cnt() {
		return image_sub_cnt;
	}
	public void setImage_sub_cnt(String image_sub_cnt) {
		this.image_sub_cnt = image_sub_cnt;
	}
	public String getImage_ref_cnt() {
		return image_ref_cnt;
	}
	public void setImage_ref_cnt(String image_ref_cnt) {
		this.image_ref_cnt = image_ref_cnt;
	}
	public String getProject_user() {
		return project_user;
	}
	public void setProject_user(String project_user) {
		this.project_user = project_user;
	}
	
}
