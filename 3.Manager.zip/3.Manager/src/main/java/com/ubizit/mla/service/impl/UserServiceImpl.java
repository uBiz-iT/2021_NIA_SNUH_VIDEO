/**
 * 
 */
package com.ubizit.mla.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ubizit.mla.service.UserService;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * @Class Name : UserServiceImpl.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
@Service("userService")
public class UserServiceImpl extends EgovAbstractServiceImpl implements UserService{

	private static final Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);
	
	@Resource(name="userDAO")
	private UserDAO userDAO;
	
	@Override
	public void getUserSearchList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> UserServiceImpl.getUserSearchList >>>>>>");
		System.out.println(">>>>>> UserServiceImpl.getUserSearchList >>>>>>");
		
		userDAO.getUserSearchList(map);
	}

	@Override
	public void saveUserList(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> UserServiceImpl.saveUserList >>>>>>");
		System.out.println(">>>>>> UserServiceImpl.saveUserList >>>>>>");
		
		userDAO.saveUserList(map);
		
	}

	@Override
	public List<Map<String, Object>> userExcelDown(Map<String, Object> map) throws Exception {
		LOGGER.info(">>>>>> UserServiceImpl.userExcelDown >>>>>>");
		System.out.println(">>>>>> UserServiceImpl.userExcelDown >>>>>>");
		
		return userDAO.userExcelDown(map);
	}

}
