/**
 * 
 */
package com.ubizit.mla.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ubizit.mla.model.LabelVO;
import com.ubizit.mla.model.TargetVO;
import com.ubizit.mla.service.LabelService;
import com.ubizit.mla.util.StringUtil;

import net.sf.json.JSONObject;

/**
 * @Class Name : LabelController.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
@Controller
public class LabelController {

	/** LabelService **/
	@Resource(name="labelService")
	private LabelService labelService;
	
	private final static Logger logger = Logger.getLogger(LabelController.class);
	
	/**
	 * 
	 * Method : labelList
	 * 최초작성일 : 2021. 5. 12.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param labelReqVO
	 * @param model
	 * @param request
	 * @return
	 * @throws Exception
	 * Method 설명 : 라벨 등록 현황 메인 화면
	 */
	@RequestMapping(value="/label.labelList.do")
	public String labelList(ModelMap model, HttpServletRequest request, HttpSession session) throws Exception {
		logger.info(">>>>>> LabelController >>>>>>");
		System.out.println(">>>>>> LabelController >>>>>>");
		
		String mission_cd = (String) session.getAttribute("mission_cd");
		List<TargetVO> list = labelService.getTargetInfo(mission_cd);
		
		model.addAttribute("targetVO", list);
		
		return "label_list";
	}
	
	
	/**
	 * Method : getLabelSearchList
	 * 최초작성일 : 2021. 5. 12.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @param session
	 * @return
	 * @throws Exception
	 * Method 설명 : 타겟 탭 별 라벨 목록 조회
	 */
	@RequestMapping(value="/label.target.search.do")
	@ResponseBody
	public Map<String, Object> getLabelSearchList(HttpServletRequest request, HttpSession session) throws Exception {
		logger.info(">>>>>> LabelController.getLabelSearchList() >>>>>>");
		System.out.println(">>>>>> LabelController.getLabelSearchList() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<LabelVO> p_ret_json = new ArrayList<>();
		
		String mission_cd = (String) session.getAttribute("mission_cd");
		String target_cd = ((String[])paramMap.get("target_cd"))[0];
		
		jsonObject.put("MISSION_CD", mission_cd);
		jsonObject.put("TARGET_CD", Integer.parseInt(target_cd));
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		labelService.getLabelSearchList(resultMap);
		
		if((int)resultMap.get("p_ret_code") == 0){
			p_ret_json = (List<LabelVO>) resultMap.get("p_ret_json");
		}else{
			p_ret_json = null;
		}
		
		/** return map */
		map.put("rows", p_ret_json);
		
		return map;
	}
	

	/**
	 * Method : saveLabelList
	 * 최초작성일 : 2021. 5. 17.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param request
	 * @param session
	 * @return
	 * @throws Exception
	 * Method 설명 : 라벨 등록 현황에서 변경된 라벨 내용 저장하기 위한 기능
	 */
	@RequestMapping(value="/label.save.do")
	@ResponseBody
	public Map<String, Object> saveLabelList(HttpServletRequest request, HttpSession session) throws Exception{
		logger.info(">>>>>> LabelController.saveLabelList() >>>>>>");
		System.out.println(">>>>>> LabelController.saveLabelList() >>>>>>");
		
		/** Object 선언 **/
		Map<?, ?> paramMap = request.getParameterMap();
		JSONObject jsonObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		String p_ret_msg = "";
		int p_ret_code = 0;
		
		String mission_cd = (String) session.getAttribute("mission_cd");
		String reg_user_id = (String) session.getAttribute("user_id");
		String label_list = ((String[])paramMap.get("label"))[0];
		
		jsonObject.put("MISSION_CD", mission_cd);
		jsonObject.put("REG_USER_ID", reg_user_id);	
		jsonObject.put("LABEL_LIST", label_list);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("p_rcv_json", StringUtil.parseJsonObjectToString(jsonObject));
		
		labelService.saveLabelList(resultMap);
		
		p_ret_msg = (String) resultMap.get("p_ret_msg");
		p_ret_code = (int) resultMap.get("p_ret_code");
		
		/** return map **/
		map.put("p_ret_msg", p_ret_msg);
		map.put("p_ret_code", p_ret_code);
		
		return map;
	}
	
	
}








