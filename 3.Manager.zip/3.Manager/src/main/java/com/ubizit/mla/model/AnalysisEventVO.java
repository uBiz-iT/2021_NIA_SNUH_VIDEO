/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : AnalysisEventVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 7. 13.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 7. 13.
 * @version : 1.0
 * 
 */
public class AnalysisEventVO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String event_seq;
	private String event_nm;
	private String event_tp_nm;
	private String event_note;
	private String beg_sec;
	private String end_sec;
	private String beg_dt;
	private String end_dt;
//	private String beg_ts;
//	private String end_ts;
	private String elapsed_sec;
    private String beg_epo_no;
    private String end_epo_no;
    private String chk_res;
    private String memo;
    private String work_date;
    
	public String getEvent_seq() {
		return event_seq;
	}
	public void setEvent_seq(String event_seq) {
		this.event_seq = event_seq;
	}
	public String getEvent_nm() {
		return event_nm;
	}
	public void setEvent_nm(String event_nm) {
		this.event_nm = event_nm;
	}
	public String getEvent_tp_nm() {
		return event_tp_nm;
	}
	public void setEvent_tp_nm(String event_tp_nm) {
		this.event_tp_nm = event_tp_nm;
	}
	public String getEvent_note() {
		return event_note;
	}
	public void setEvent_note(String event_note) {
		this.event_note = event_note;
	}
	public String getBeg_sec() {
		return beg_sec;
	}
	public void setBeg_sec(String beg_sec) {
		this.beg_sec = beg_sec;
	}
	public String getEnd_sec() {
		return end_sec;
	}
	public void setEnd_sec(String end_sec) {
		this.end_sec = end_sec;
	}
	public String getBeg_dt() {
		return beg_dt;
	}
	public void setBeg_dt(String beg_dt) {
		this.beg_dt = beg_dt;
	}
	public String getEnd_dt() {
		return end_dt;
	}
	public void setEnd_dt(String end_dt) {
		this.end_dt = end_dt;
	}
//	public String getBeg_ts() {
//		return beg_ts;
//	}
//	public void setBeg_ts(String beg_ts) {
//		this.beg_ts = beg_ts;
//	}
//	public String getEnd_ts() {
//		return end_ts;
//	}
//	public void setEnd_ts(String end_ts) {
//		this.end_ts = end_ts;
//	}
	public String getElapsed_sec() {
		return elapsed_sec;
	}
	public void setElapsed_sec(String elapsed_sec) {
		this.elapsed_sec = elapsed_sec;
	}
	public String getBeg_epo_no() {
		return beg_epo_no;
	}
	public void setBeg_epo_no(String beg_epo_no) {
		this.beg_epo_no = beg_epo_no;
	}
	public String getEnd_epo_no() {
		return end_epo_no;
	}
	public void setEnd_epo_no(String end_epo_no) {
		this.end_epo_no = end_epo_no;
	}
	public String getChk_res() {
		return chk_res;
	}
	public void setChk_res(String chk_res) {
		this.chk_res = chk_res;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public String getWork_date() {
		return work_date;
	}
	public void setWork_date(String work_date) {
		this.work_date = work_date;
	}
    
}
