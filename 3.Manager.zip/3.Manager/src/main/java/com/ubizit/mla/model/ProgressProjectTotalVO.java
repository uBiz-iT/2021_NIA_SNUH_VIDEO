/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : ProgressProjectTotalVO.java
 * @Description : PSG등록건수 / 검수완료건수 / 검수PASS건수 / 검수FAIL건수
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 5. 18.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 5. 18.
 * @version : 1.0
 *
 */
public class ProgressProjectTotalVO implements Serializable{

	private static final long serialVersionUID = 1L;

	private String psg_cnt;		//PSG등록건수
	private String work_cnt;		//검수완료건수
	private String pass_cnt;		//검수PASS건수
	private String fail_cnt;		//검수FAIL건수
	private String n_psg_cnt;		//검수미완료건수
	
	public String getPsg_cnt() {
		return psg_cnt;
	}
	public void setPsg_cnt(String psg_cnt) {
		this.psg_cnt = psg_cnt;
	}
	public String getWork_cnt() {
		return work_cnt;
	}
	public void setWork_cnt(String work_cnt) {
		this.work_cnt = work_cnt;
	}
	public String getPass_cnt() {
		return pass_cnt;
	}
	public void setPass_cnt(String pass_cnt) {
		this.pass_cnt = pass_cnt;
	}
	public String getFail_cnt() {
		return fail_cnt;
	}
	public void setFail_cnt(String fail_cnt) {
		this.fail_cnt = fail_cnt;
	}
	public String getN_psg_cnt() {
		return n_psg_cnt;
	}
	public void setN_psg_cnt(String n_psg_cnt) {
		this.n_psg_cnt = n_psg_cnt;
	}
	
	
	
	
}
