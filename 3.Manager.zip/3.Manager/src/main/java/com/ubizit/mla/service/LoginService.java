/**
 * 
 */
package com.ubizit.mla.service;

import java.util.Map;

import com.ubizit.mla.model.LoginVO;

/**
 * @Class Name : LoginService.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
public interface LoginService {

	/**
	 * Method : getLoginUser
	 * 최초작성일 : 2021. 5. 3.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param map
	 * Method 설명 : 로그인 정보 조회
	 */
	void getLoginUser(Map<String, Object> map) throws Exception;

	
}
