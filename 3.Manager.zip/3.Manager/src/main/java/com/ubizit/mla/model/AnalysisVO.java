/**
 * 
 */
package com.ubizit.mla.model;

import java.io.Serializable;

/**
 * @Class Name : AnalysisVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
public class AnalysisVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String psg_id;	
	private String done_yn;
	private String chk_res;
	private String res_desc;
	private String same_yn;
	private String done_same_yn;
	private String user_id_list;
	private String user_name_list;
	private String user_memo_list;
	
	public String getPsg_id() {
		return psg_id;
	}
	public void setPsg_id(String psg_id) {
		this.psg_id = psg_id;
	}
	public String getDone_yn() {
		return done_yn;
	}
	public void setDone_yn(String done_yn) {
		this.done_yn = done_yn;
	}
	public String getChk_res() {
		return chk_res;
	}
	public void setChk_res(String chk_res) {
		this.chk_res = chk_res;
	}
	public String getRes_desc() {
		return res_desc;
	}
	public void setRes_desc(String res_desc) {
		this.res_desc = res_desc;
	}
	public String getSame_yn() {
		return same_yn;
	}
	public void setSame_yn(String same_yn) {
		this.same_yn = same_yn;
	}
	public String getDone_same_yn() {
		return done_same_yn;
	}
	public void setDone_same_yn(String done_same_yn) {
		this.done_same_yn = done_same_yn;
	}
	public String getUser_id_list() {
		return user_id_list;
	}
	public void setUser_id_list(String user_id_list) {
		this.user_id_list = user_id_list;
	}
	public String getUser_name_list() {
		return user_name_list;
	}
	public void setUser_name_list(String user_name_list) {
		this.user_name_list = user_name_list;
	}
	public String getUser_memo_list() {
		return user_memo_list;
	}
	public void setUser_memo_list(String user_memo_list) {
		this.user_memo_list = user_memo_list;
	}
	
}
