/**
 * 
 */
package com.ubizit.ila.web;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.core.io.ClassPathResource;
import org.springframework.util.FileCopyUtils;

import com.ubizit.ila.util.EgovResourceCloseHelper;
import com.ubizit.ila.util.StringUtil;

/**
 * @Class Name : FileDownLoadController.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 4. 22.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 4. 22.
 * @version : 1.0
 * 
 */
public class FileDownLoadController {

	
	public Map<String, Object> downVideo(Map<String, Object> params, HttpServletResponse response) throws Exception {
		System.out.println("help 요청");
		
		Map<String, Object> retMap = new HashMap<String, Object>();
		String file_name = (String) params.get("file_name");
		String file_path = (String) params.get("file_path");
		
		String mkdir = "D:/ubiz/" + file_path;
		File file = new File(mkdir + "/" + file_name);
		
		return retMap;
	}

	
	public void videoDownload(Map<String, Object> params, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		Map<String, Object> retMap = new HashMap<String, Object>();
		
		System.out.println("파일 다운로드 요청");
		System.out.println("trying file download : " + params.get("file_name"));
		
		if(StringUtil.isEmpty(params.get("file_name")) || StringUtil.isEmpty(params.get("file_path"))){
			retMap.put("success", false);
			retMap.put("err_msg", "file is null");
			
		}

		String file_name = (String) params.get("file_name");
		String file_path = (String) params.get("file_path");
		
		ClassPathResource resource = new ClassPathResource("db.properties");
		String path = resource.getURI().getPath();
		
		FileReader fr = new FileReader(path);
		Properties properties = new Properties();
		
		properties.load(fr);
		String rootPath = properties.getProperty("path");
		
//		String mkdir = rootPath + file_path;
		String mkdir = "D:/ubiz/" + file_path;
		
		File file = new File(mkdir + "/" + file_name);
		
		if(!file.exists()){
			//exception 에러 처리
			//response 응답 에러 보내기
			response.sendError(HttpServletResponse.SC_UNAUTHORIZED); //401 에러
			
			System.out.println("파일이 존재하지 않습니다.");
			
			retMap.put("success", false);
			retMap.put("err_msg", "file download failed, No files");
			
		} else {

			String mimetype = "application/x-msdownload";
			response.setContentType(mimetype);
			
			response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + "\";");
			response.setHeader("Content-Transfer-Encoding", "binary");
			response.setHeader("Content-Length", Long.toString(file.length()));
			response.setHeader("Keep-Alive", "timeout = 5, max = 99");
			
			BufferedInputStream in = null;
			BufferedOutputStream out = null;
			
			try{
				
				in = new BufferedInputStream(new FileInputStream(file));
				out = new BufferedOutputStream(response.getOutputStream());
				
				FileCopyUtils.copy(in, out);
				out.close();
				
			} catch (IOException ex) {
//				EgovBasicLogger.ignore("IO Exception", ex);
				
				RequestDispatcher dd= request.getRequestDispatcher("error.jsp");
		        dd.include(request, response);
				
			} finally {
				EgovResourceCloseHelper.close(in, out);
			}
			
		}
		
	}
	
	
	public Map<String, Object> downloadVideo(Map<String, Object> params, HttpServletResponse response) throws IOException {
		
		Map<String, Object> retMap = new HashMap<String, Object>();
		
		System.out.println("파일 다운로드 요청");
		System.out.println("trying file download : " + params.get("file_name"));
		
		if(StringUtil.isEmpty(params.get("file_name")) || StringUtil.isEmpty(params.get("file_path"))){
			retMap.put("success", false);
			retMap.put("err_msg", "file is null");
			
			return retMap;
		}
		
		String file_name = (String) params.get("file_name");
		String file_path = (String) params.get("file_path");
		
		ClassPathResource resource = new ClassPathResource("db.properties");
		String path = resource.getURI().getPath();
		
		FileReader fr = new FileReader(path);
		Properties properties = new Properties();
		
		properties.load(fr);
		String rootPath = properties.getProperty("path");
		
		String mkdir = rootPath + file_path;
//		String mkdir = "D:/ubiz/" + file_path;
		
		File file = new File(mkdir + "/" + file_name);
		
		if(!file.exists()){
			//exception 에러 처리
			//response 응답 에러 보내기
			
			System.out.println("파일이 존재하지 않습니다.");
			
			retMap.put("success", false);
			retMap.put("err_msg", "file download failed, No files");
			
		} else {
	         
			OutputStream outStream = response.getOutputStream();
			FileInputStream fileStream = new FileInputStream(file);
			
			response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + "\";");
			response.setHeader("Content-Transfer-Encoding", "binary");
			response.setHeader("Content-Length", Long.toString(file.length()));
			response.setHeader("Keep-Alive", "timeout = 5, max = 99");
			
			
			boolean clientCancel = false;
			try{
				
				int readCount = 0;
				byte[] byteStream = new byte[1024];

				while (!clientCancel && (readCount = fileStream.read(byteStream)) != -1) {
					outStream.write(byteStream, 0, readCount);
				}

				retMap.put("success", true);
				retMap.put("ret_msg", mkdir);
				
			}catch(Exception e){
				System.out.println("error message : " + e.getMessage());
				
				if (e.getClass().getName().equals("org.apache.catalina.connector.ClientAbortException")) {
					System.out.println("e.getClass().getName() : " + e.getClass().getName());
					clientCancel = true;
				}
				
				retMap.put("success", false);
				retMap.put("err_msg", e.getMessage()); 

			}finally{
	             
	            if(fileStream != null){
	                 
	                try{
	                	fileStream.close();
	                }catch(Exception e){}
	            }
	             
	        }
	         
			if(!clientCancel){
				outStream.flush();
				outStream.close();
			}

		}

		
		return retMap;
	}

	
}










