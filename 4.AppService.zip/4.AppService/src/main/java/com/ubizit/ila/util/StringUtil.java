/**
 * 
 */
package com.ubizit.ila.util;

import java.io.Reader;
import java.lang.reflect.Array;
import java.sql.Clob;
import java.sql.NClob;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.apache.commons.lang3.StringUtils;


import com.fasterxml.jackson.databind.ObjectMapper;

import net.sf.json.JSONObject;

/**
 * @Class Name : StringUtil.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 9. 2.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 9. 2.
 * @version : 1.0
 * 
 */
public class StringUtil extends StringUtils {

	private final static Logger logger = LogManager.getLogger(StringUtil.class);
	
	/** instance **/
	private static StringUtil instance;
	
	private StringUtil(){
		super();
		logger.debug(">>>>>> StringUtil >>>>>>");
	}
	
	public static StringUtil getInstance(){
		if(instance == null){
			instance = new StringUtil();
		}
		return instance;
	}
	
	/**
	 * Method : getCodestrFromArray
	 * 최초작성일 : 2020. 9. 2.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param arr
	 * @param separate
	 * @return
	 * Method 설명 : 문자열 배열로부터 구분자로 구분한 단일 문자열을 생성하기 위함
	 */
	public static String getCodestrFromArray(String[] arr, String separate){
		String result = "";
		
		if(arr != null){
			for(int i = 0; i < arr.length; i++){
				if(i > 0) result += separate;
				
				result += arr[i];
			}
		}
	
		return result;
	}

	/**
	 * Method : getClobToString
	 * 최초작성일 : 2020. 9. 2.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param obj
	 * @return
	 * Method 설명 : CLOB to STRING
	 */
	public static String getClobToString(Clob clob) {
		Reader reader = null;
		StringBuffer sb = new StringBuffer();
		
		try{
			
			reader = clob.getCharacterStream();
			
			char[] buff = new char[1024];
			
			int nchars = 0;
			while ((nchars = reader.read(buff)) > 0)
				sb.append(""+(char) nchars);
				
		} catch (Exception e){
			System.out.println("Connection Exception occurred");
		}
		
		return sb.toString();
	}

	/**
	 * Method : getNClobToString
	 * 최초작성일 : 2020. 9. 2.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param obj
	 * @return
	 * Method 설명 : NCLOB to String
	 */
	public static String getNClobToString(NClob nclob) {
		Reader reader = null;
		StringBuffer sb = new StringBuffer();
		
		try{
			
			reader = nclob.getCharacterStream();
			
			char[] buff = new char[1024];
			
			int nchars = 0;
			while ((nchars = reader.read(buff)) > 0)
				sb.append(buff, 0, nchars);
				
		} catch (Exception e){
			System.out.println("Connection Exception occurred");
		}
		
		return sb.toString();
	}
	
	/**
	 * Method : isEmpty
	 * 최초작성일 : 2020. 9. 3.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param obj
	 * @return
	 * Method 설명 : Object type 변수가 비어있는지 체크
	 */
	public static boolean isEmpty(Object obj){
		
		if (obj instanceof String) return obj == null || "".equals(obj.toString().trim());
		else if (obj instanceof List) return obj == null || ((List) obj).isEmpty();
		else if (obj instanceof Map) return obj == null || ((Map) obj).isEmpty();
		else if (obj instanceof Object[]) return obj == null || Array.getLength(obj) == 0;
		else return obj == null;
		
	}
	
	
	/**
	 * Method : parseJsonObjectToMap
	 * 최초작성일 : 2020. 9. 3.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param jsonObject
	 * @param key
	 * @return
	 * Method 설명 : JSONObject to String to Map(single)
	 */
	public static String parseJsonObjectToString (JSONObject jsonObject){
		String jsonData = "";
		if(jsonObject != null && jsonObject.size() > 0){
			try{
				ObjectMapper mapper = new ObjectMapper();
				jsonData = mapper.writeValueAsString(jsonObject);
				
			} catch (Exception e) {
				System.out.println("Connection Exception occurred");
			}
		}
		
		return jsonData;
	}

	/** MLA 작업때만 사용 가능 **/
	public static Map<String, Object> getSqlMapSendData(Map<String, Object> sqlMap, List<?> p_ret_json) {
		
		Map<String, Object> map = new HashMap<String, Object>();
		
		try{
			int p_ret_code = (int) sqlMap.get("p_ret_code");
			
			if(p_ret_code == 0){
				p_ret_json = (List<?>) sqlMap.get("p_ret_json");
				
				map.put("data", p_ret_json);
			}else{
				map.put("data", null);
			}

			
		} catch (Exception e) {
			logger.debug(">>>>>> getSqlMapSendData() FAIL >>>>>>");
		}
		
		
		return map;
	}
	
	
	/**
	 * Method : getSimpleDateFormat
	 * 최초작성일 : 2020. 2. 7.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param time
	 * @return
	 * Method 설명 : 날짜형식을 인자값으로 원하는 형식으로 날짜 반환하는 메서드
	 */
	public static String getSimpleDateFormat(String time){
	
		SimpleDateFormat format = new SimpleDateFormat(time);
		
		Calendar cal = Calendar.getInstance();
		
		String format_time = format.format(cal.getTime());
		
		return format_time;
	}
	
	/**
	 * Method : getInputDateFormat
	 * 최초작성일 : 2020. 3. 10.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param date
	 * @return
	 * Method 설명 : '-' 포함한 Date 형식의 문자를 반환하는 메서드
	 */
	public static String getInputDateFormat(String date){
		
		Calendar cal = Calendar.getInstance();
		
		int intYear =  cal.get(cal.YEAR);
		int intMonth =  cal.get(cal.MONTH)+1; 
		int intDay =  cal.get(cal.DATE);
		
		String stringMonth = Integer.toString(intMonth);
		String stringDay = Integer.toString(intDay);
		
		if(intMonth < 10){
			stringMonth = "0" + stringMonth;
		}
		if(intDay < 10){
			stringDay = "0" + stringDay;
		}
		
		if(date.isEmpty()){
			return Integer.toString(intYear)+"-"+stringMonth+"-"+stringDay;
		}else{
			return date;
		}
		
	}
	
	/**
	 * Method : getMonthBeforeDateFormat
	 * 최초작성일 : 2020. 4. 13.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param date
	 * @return
	 * Method 설명 : '-' 포함한 한 달 전 Date 형식의 문자를 반환하는 메서드
	 */
	public static String getMonthBeforeDateFormat(String date){
		
		Calendar cal = Calendar.getInstance();
		
		cal.add(Calendar.MONTH, -1);
		
		int intYear =  cal.get(cal.YEAR);
		int intMonth =  cal.get(cal.MONTH)+1; 
		int intDay =  cal.get(cal.DATE);
		
		String stringMonth = Integer.toString(intMonth);
		String stringDay = Integer.toString(intDay);
		
		if(intMonth < 10){
			stringMonth = "0" + stringMonth;
		}
		if(intDay < 10){
			stringDay = "0" + stringDay;
		}
		
		if(date.isEmpty()){
			return Integer.toString(intYear)+"-"+stringMonth+"-"+stringDay;
		}else{
			return date;
		}
		
	}
	
	/**
	 * Method : strSubstring
	 * 최초작성일 : 2020. 2. 7.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param str : 문자열
	 * @param num : 순번
	 * @type : Integer - 순번(1~8)
	 * @return
	 * Method 설명 : 문자열 자르기 위한 메서드
	 */
	public static String strSubstring(String str, int num){
		
		String zero = "";
		/** 순번만큼 0 붙이기 */
		for(int i = 0; i < num; i++){
			zero += "0" + zero;
		}
		str = zero + str;
		
		String result = str.substring(str.length()-num, str.length());
		
		return result;
	}
	
	/**
	 * Method : dateCnt
	 * 최초작성일 : 2020. 3. 16.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param date1
	 * @param date2
	 * @return
	 * Method 설명 : 두 날짜 간의 일수 계산 (시작일 포함)
	 */
	public static long dateCnt(String date1, String date2){
		
		try {
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			
			Date begDate = format.parse(date1);
			Date endDate = format.parse(date2);
			
			long calDate = begDate.getTime() - endDate.getTime();
			
			long calDateDays = calDate / (1000*60*60*24) + 1;
			
			calDateDays = Math.abs(calDateDays);
			
			return calDateDays;
			
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}
	
	/**
	 * Method : MonthSubstring
	 * 최초작성일 : 2020. 9. 11.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param month
	 * @return
	 * Method 설명 : 1~9월의 앞자리 0생략
	 */
	public static String monthSubstring(String month){
		
		if("0".equals(month.substring(0, 1))){
			month = month.substring(1);
		}
		
		return month;
	}
	
}
