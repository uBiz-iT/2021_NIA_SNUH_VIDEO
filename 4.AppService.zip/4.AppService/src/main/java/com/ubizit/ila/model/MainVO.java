/**
 * 
 */
package com.ubizit.ila.model;

import java.io.Serializable;

/**
 * @Class Name : MainVO.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 4. 15.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 4. 15.
 * @version : 1.0
 * 
 */
public class MainVO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String p_rcv_json;
	private int p_ret_code;
	private String p_ret_json;
	private String p_ret_msg;
	
	public String getP_rcv_json() {
		return p_rcv_json;
	}
	public void setP_rcv_json(String p_rcv_json) {
		this.p_rcv_json = p_rcv_json;
	}
	public int getP_ret_code() {
		return p_ret_code;
	}
	public void setP_ret_code(int p_ret_code) {
		this.p_ret_code = p_ret_code;
	}
	public String getP_ret_json() {
		return p_ret_json;
	}
	public void setP_ret_json(String p_ret_json) {
		this.p_ret_json = p_ret_json;
	}
	public String getP_ret_msg() {
		return p_ret_msg;
	}
	public void setP_ret_msg(String p_ret_msg) {
		this.p_ret_msg = p_ret_msg;
	}
	
	
	
}
