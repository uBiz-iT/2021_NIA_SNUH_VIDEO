/**
 * 
 */
package com.ubizit.ila.util;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.springframework.core.io.ClassPathResource;

/**
 * @Class Name : DBConnection.java
 * @Description : DB 연결
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 4. 12.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 4. 12.
 * @version : 1.0
 * 
 */
public class DBConnection {

	public static Connection dbConn;
	
	public static Connection getConnection(){
		
		Connection conn = null;
		
		try{
			ClassPathResource resource = new ClassPathResource("db.properties");
			String path = resource.getURI().getPath();
			
			FileReader fr = new FileReader(path);
			Properties properties = new Properties();
			
			properties.load(fr);
			String user = properties.getProperty("user");
			String password = properties.getProperty("password");
			String url = properties.getProperty("connectionString");
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			conn = DriverManager.getConnection(url, user, password);
			
			System.out.println("Database Connection Success.");
			
		} catch (ClassNotFoundException cnfe) {
			System.out.println("DB Driver Loading Failed!!");
		} catch (SQLException sqle) {
			System.out.println("DB Connection Failed!!");
		} catch (Exception e) {
			System.out.println("Unknown Error");
			e.printStackTrace();
		}
		
		return conn;
		
	}
}

