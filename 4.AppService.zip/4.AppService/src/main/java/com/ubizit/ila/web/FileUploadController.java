/**
 * 
 */
package com.ubizit.ila.web;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.json.simple.JSONObject;
import org.springframework.core.io.ClassPathResource;
import org.springframework.web.multipart.MultipartFile;

/**
 * @Class Name : FileUploadController.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 4. 19.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 4. 19.
 * @version : 1.0
 * 
 */
public class FileUploadController {

	/**
	 * Method : saveFile
	 * 최초작성일 : 2021. 4. 21.
	 * 작성자 : 엄소현
	 * 변경이력 :
	 * @param params
	 * @return
	 * @throws Exception
	 * Method 설명 : 파일 업로드
	 */
	public Map<String, Object> saveFile(Map<String, Object> params) throws Exception {
		
		Map<String, Object> retMap = new HashMap<String, Object>();
		
		String save_name = (String) params.get("save_name");	//11000008_COCO
		String save_path = (String) params.get("save_path");	//image/testmm/annotation/ubiz/1/10002
		MultipartFile mf = (MultipartFile) params.get("file_name");
		
		if(mf == null){
			retMap.put("success", false);
			retMap.put("err_msg", "file_name is null");
			
			return retMap;
		}
		
		System.out.println("파일 업로드 요청");
		System.out.println("trying save file, save path : " + save_name + ", " + save_path);
		
		ClassPathResource resource = new ClassPathResource("db.properties");
		String path = resource.getURI().getPath();
		
		FileReader fr = new FileReader(path);
		Properties properties = new Properties();
		
		properties.load(fr);
		String rootPath = properties.getProperty("path");
		
		String mkdir = rootPath + save_path;
//		String mkdir = "D:/ubiz/" + save_path;
		
		//디렉토리가 없으면 생성
		File file = new File(mkdir);
		
		if(!file.exists()){
			
			try {
				file.mkdirs();
				System.out.println("폴더 생성 완료");
				
			} catch (Exception e) {
				e.printStackTrace();
				
				retMap.put("success", false);
				retMap.put("err_msg", e.getMessage());
			}
			
		} else {
			System.out.println("기존 폴더 존재");
		}
		
		//서버에 저장할 파일 명
		
		try {
			int exsIndex = mf.getOriginalFilename().lastIndexOf(".");
			String replaceName = save_name + mf.getOriginalFilename().substring(exsIndex, mf.getOriginalFilename().length());
			
			mf.transferTo(new File(mkdir, replaceName));
			
			File targetFile = new File(mkdir + "/" + replaceName);
			
			if(targetFile.exists()){
				//모든권한제거
				targetFile.setReadable(false, false);
				targetFile.setWritable(false, false);
				targetFile.setExecutable(false, false);
			
				Path p = Paths.get(mkdir + "/" + replaceName);
				Set<PosixFilePermission> posixPermissions = PosixFilePermissions.fromString("rwxrwxrwx");
				Files.setPosixFilePermissions(p, posixPermissions);
			}
			
			
			System.out.println("파일 업로드 완료");
			
			retMap.put("success", true);
			retMap.put("file",  save_path + "/" + replaceName);
			
		} catch (IOException e) {
			e.printStackTrace();
			
			retMap.put("success", false);
			retMap.put("err_msg", e.getMessage());
			
		}
		
		
		return retMap;
	}
	
	/**
	 * Method : upload
	 * 최초작성일 : 2021. 4. 21.
	 * 작성자 : 엄소현
	 * 변경이력 :
	 * @param params
	 * @return
	 * @throws Exception
	 * Method 설명 : 업로드 성공/실패 후 dicom 파일 처리 여부
	 */
	public Map<String, Object> upload(Map<String, Object> params) throws Exception {
		
		Map<String, Object> save_file_msg = saveFile(params);
		JSONObject jsonObject = new JSONObject();
		
		if(!(boolean) save_file_msg.get("success")){
			
			return save_file_msg;
			
		} else {
			
			boolean isCOCOfile = false;
			String cocofile = (String) save_file_msg.get("file");
			cocofile = cocofile.substring(cocofile.length()-9, cocofile.length());
			
			if(cocofile.equals("COCO.json")){
				isCOCOfile = true;
			}
			
			if(isCOCOfile){
				
				String dicom_path = (String) params.get("dicom_path");
				String save_path = (String) params.get("save_path");
				
				System.out.println("DICOM_PATH : " + dicom_path);
			}
			
			
			return save_file_msg;
			
		}
		
	}
	
}
