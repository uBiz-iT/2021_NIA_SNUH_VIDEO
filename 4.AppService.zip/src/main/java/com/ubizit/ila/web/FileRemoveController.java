/**
 * 
 */
package com.ubizit.ila.web;

import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.json.simple.JSONObject;
import org.springframework.core.io.ClassPathResource;

/**
 * @Class Name : FileRemoveController.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 4. 21.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 4. 21.
 * @version : 1.0
 * 
 */
public class FileRemoveController {

	/**
	 * Method : removeFile
	 * 최초작성일 : 2021. 4. 22.
	 * 작성자 : 엄소현
	 * 변경이력 :
	 * @param jsonObject
	 * @return
	 * @throws Exception
	 * Method 설명 : 파일 삭제
	 */
	public Map<String, Object> removeFile(JSONObject jsonObject) throws Exception {
		
		Map<String, Object> retMap = new HashMap<String, Object>();
		retMap.put("success", false);
		
		String image_id = (String) jsonObject.get("image_id");
		String image_path = (String) jsonObject.get("image_path");
		
		ClassPathResource resource = new ClassPathResource("db.properties");
		String path = resource.getURI().getPath();
		
		FileReader fr = new FileReader(path);
		Properties properties = new Properties();
		
		properties.load(fr);
		String rootPath = properties.getProperty("path");
		
		String mkdir = rootPath + image_path;		//서버
//		String mkdir = "D:/ubiz/" + image_path;		//로컬
		
		try {
			
			File FileList = new File(mkdir);
			
			//해당 폴더의 전체 파일리스트 조회
			String fileList[] = FileList.list();
			
			int count = 0;
			//전체 파일
			for(int i = 0; i < fileList.length; i++){
				String fileName = fileList[i];

				//파일명이 image_id 값과 동일한지 체크
				if(fileName.contains(image_id)){
					//존재하면 파일삭제
					File deleteFile = new File(mkdir+"/"+fileName);
					deleteFile.delete();
					
					count++;
				}
				
			}
			
			retMap.put("success", true);
			retMap.put("ret_msg", "Number of deleted files : " + count + " cases");
			
		} catch (Exception e) {
			e.printStackTrace();
			
			retMap.put("success", false);
			retMap.put("err_msg", e.getMessage());
		}
			
		
		return retMap;
	}
	
}









