/**
 * 
 */
package com.ubizit.ila.web;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.sql.SQLException;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ubizit.ila.service.MainService;
import com.ubizit.ila.util.EgovBasicLogger;
import com.ubizit.ila.util.StringUtil;

/**
 * @Class Name : MainController.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 4. 14.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 4. 14.
 * @version : 1.0
 * 
 */
@RestController
public class MainController {

	@Resource(name="mainService")
	private MainService mainService;
	
	/** index.html 요청 */
	@RequestMapping("/")
	@ResponseBody
	public String getRoot(HttpServletRequest request){
		System.out.println("root 요청");
		
		String path = request.getServletContext().getRealPath("/html/index.html");
		
		StringBuilder contentBuilder = new StringBuilder();
		try {
//			BufferedReader in = new BufferedReader(new FileReader(path));
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(path), "UTF-8"));
			String str;
			while ((str = in.readLine()) != null) {
				contentBuilder.append(str);
			}
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		String content = contentBuilder.toString();
		
		return content;
	}
	
	/** about.html 요청 */
	@RequestMapping("/about")
	@ResponseBody
	public String getAbout(HttpServletRequest request, HttpServletResponse response){
		System.out.println("about 요청");
		
		String path = request.getServletContext().getRealPath("/html/ila_about.html");
		
		StringBuilder contentBuilder = new StringBuilder();
		try {
//			BufferedReader in = new BufferedReader(new FileReader(path));
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(path), "UTF-8"));
			
			String str;
			while ((str = in.readLine()) != null) {
				contentBuilder.append(str);
			}
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		String content = contentBuilder.toString();
		
		return content;
	}
	
	/** 도움말 다운로드 */
	@RequestMapping("/help")
	public String getHepl(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("help 요청");
		
		String path = request.getServletContext().getRealPath("/html/ila_help.pdf");
		
		response.setHeader("Content-Disposition", "attachment; filename=\"" + "ila_help.pdf" + "\";");
        response.setHeader("Content-Transfer-Encoding", "binary");
         
        OutputStream out = response.getOutputStream();
        FileInputStream fis = null;
        
		try {
			
			File f = new File(path);
			fis = new FileInputStream(f);
			FileCopyUtils.copy(fis, out);
			
		} catch (Exception e) {
			e.printStackTrace();
			
		} finally{
            
           if(fis != null){
                
               try{
                   fis.close();
               }catch(Exception e){}
           }
            
       }
        
       out.flush();

		return path;
	}

	
	/** 로그아웃 호출 */
	@RequestMapping("/logout")
	public void doLogout(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
		System.out.println("로그아웃 요청");
		
		session.removeAttribute("user_id");
	}
	
	
	/** 로그인 호출 */
	@RequestMapping("/login")
	public String dbLogin(HttpServletRequest request, HttpServletResponse response, HttpSession session, @RequestBody String jsonFormData) throws Exception {
		System.out.println("로그인 요청");		
		
		boolean isDbExecuted = false;
		String databaseError = "";
		String p_ret_json = "";
		String ret_json = "";
		
		if(!StringUtil.isNotBlank((String)session.getAttribute("user_id"))){
			session.invalidate();
		}
		
		session = request.getSession(true);
		session.setAttribute("user_id", request.getParameter("id"));
		
		try{
			Map<String, Object> resultMap = new HashMap<String, Object>();
			resultMap.put("p_rcv_json", jsonFormData);
			
			mainService.getMainExecute(resultMap);
			
			p_ret_json = (String) resultMap.get("p_ret_json");

			JSONParser parser = new JSONParser();
			Object object = parser.parse(p_ret_json);
			JSONObject jsonObject = (JSONObject) object;
			
			if((boolean)jsonObject.get("success")){
				
				jsonObject.put("session_id", session.getId());
				
				try{
					ObjectMapper mapper = new ObjectMapper();
					p_ret_json = mapper.writeValueAsString(jsonObject);
					
				} catch (Exception e) {}
				
			}
			
			StringBuffer sb = new StringBuffer();
			for(int i = 0; i < p_ret_json.length(); i++){
				if ('\\' == p_ret_json.charAt(i) && 'u' == p_ret_json.charAt(i + 1)) {
					// 그 뒤 네글자는 유니코드의 16진수 코드이다. int형으로 바꾸어서 다시 char 타입으로 강제 변환한다.
					Character r = (char) Integer.parseInt(p_ret_json.substring(i + 2, i + 6), 16);
					// 변환된 글자를 버퍼에 넣는다.
					sb.append(r);
					// for의 증가 값 1과 5를 합해 6글자를 점프
					i += 5;
				} else {
					// ascii코드면 그대로 버퍼에 넣는다.
					sb.append(p_ret_json.charAt(i));
				}

			}
			
			ret_json = sb.toString();
			
			if(ret_json.length() > 2000){
				System.out.println(" " + ret_json.substring(0, 2000) + "...}" + "[" + ret_json.length() + "]");
			}else{
				System.out.println(" " + ret_json + "[" + ret_json.length() + "]");
			}
			
			if((int)resultMap.get("p_ret_code") != 0){
				databaseError = (String) resultMap.get("p_ret_msg");
			}
			
			isDbExecuted = true;
			
			
		} catch (SQLException sqle) {
			System.out.println("P_MAIN Call Error : " + sqle);
			System.err.println(sqle);
			
		} catch (Exception e) {
			System.out.println("P_MAIN Call Error : " + e);
			System.err.println(e);
			e.printStackTrace();
		}
		
		return p_ret_json;
		
	}
	
	
	/** 프로시저 호출 */
	@RequestMapping("/proc")
	public String dbProc(HttpSession session, HttpServletRequest request, HttpServletResponse response, @RequestBody String jsonFormData) throws Exception {
		System.out.println("데이터 처리 요청");		
		
		JSONObject jsonObject = new JSONObject();
		String ret_msg = "";
		String param_id = "";
		String user_id = "";
		
		if(StringUtil.isNotBlank(request.getParameter("id")) && StringUtil.isNotBlank((String)session.getAttribute("user_id"))){
			param_id = request.getParameter("id");
			user_id = (String)session.getAttribute("user_id");
			
			if(!user_id.equals(param_id)){
//				jsonObject.put("success", false);
//				jsonObject.put("err_msg", "session is fail");
//				
//				ret_msg = jsonObject.toJSONString();
//				return ret_msg;
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED); //401 에러
			}
		}else{
//			jsonObject.put("success", false);
//			jsonObject.put("err_msg", "session is null");
//			
//			ret_msg = jsonObject.toJSONString();
//			return ret_msg;
			response.sendError(HttpServletResponse.SC_UNAUTHORIZED); //401 에러
		}
		
		
		boolean isDbExecuted = false;
		String databaseError = "";
		String p_ret_json = "";
		String ret_json = "";
		
		try{
			Map<String, Object> resultMap = new HashMap<String, Object>();
			resultMap.put("p_rcv_json", jsonFormData);
			
			mainService.getMainExecute(resultMap);
			
			p_ret_json = (String) resultMap.get("p_ret_json");
			
			StringBuffer sb = new StringBuffer();
			for(int i = 0; i < p_ret_json.length(); i++){
				if ('\\' == p_ret_json.charAt(i) && 'u' == p_ret_json.charAt(i + 1)) {
					// 그 뒤 네글자는 유니코드의 16진수 코드이다. int형으로 바꾸어서 다시 char 타입으로 강제 변환한다.
					Character r = (char) Integer.parseInt(p_ret_json.substring(i + 2, i + 6), 16);
					// 변환된 글자를 버퍼에 넣는다.
					sb.append(r);
					// for의 증가 값 1과 5를 합해 6글자를 점프
					i += 5;
				} else {
					// ascii코드면 그대로 버퍼에 넣는다.
					sb.append(p_ret_json.charAt(i));
				}
				
			}
			
			ret_json = sb.toString();
			
			if(ret_json.length() > 2000){
				System.out.println(" " + ret_json.substring(0, 2000) + "...}" + "[" + ret_json.length() + "]");
			}else{
				System.out.println(" " + ret_json + "[" + ret_json.length() + "]");
			}
			
			System.out.println("code : " + resultMap.get("p_ret_code"));
			
			
			if((int)resultMap.get("p_ret_code") != 0){
				databaseError = (String) resultMap.get("p_ret_msg");
			}
			
			isDbExecuted = true;
			
		} catch (SQLException sqle) {
			System.out.println("P_MAIN Call SQLException : " + sqle);
			System.err.println(sqle);
			
		} catch (Exception e) {
			System.out.println("P_MAIN Call Exception : " + e);
			System.err.println(e);
		}
		
		return p_ret_json;
		
	}
	
	
	/** 이미지 호출 */
	@RequestMapping("/getImage") ///
	public String getImage1(HttpSession session, HttpServletRequest request, HttpServletResponse response) throws IOException {

		JSONObject jsonObject = new JSONObject();
		String ret_msg = "";
		String param_id = "";
		String user_id = "";
		
		if(StringUtil.isNotBlank(request.getParameter("id")) && StringUtil.isNotBlank((String)session.getAttribute("user_id"))){
			param_id = request.getParameter("id");
			user_id = (String)session.getAttribute("user_id");
			
			if(!user_id.equals(param_id)){
//				jsonObject.put("success", false);
//				jsonObject.put("err_msg", "session is fail");
//				
//				ret_msg = jsonObject.toJSONString();
//				return ret_msg;
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED); //401 에러
			}
			
		}else{
			response.sendError(HttpServletResponse.SC_UNAUTHORIZED); //401 에러
		}
		
		ClassPathResource resource = new ClassPathResource("db.properties");
		String path = resource.getURI().getPath();
		
		FileReader fr = new FileReader(path);
		Properties properties = new Properties();
		
		properties.load(fr);
		String rootPath = properties.getProperty("path");
		
		String file_name = rootPath + request.getParameter("file_name");
		
		System.out.println("파일 요청");
		System.out.println("FILE_NAME : " + file_name);
		
		FileInputStream input = null;
		OutputStream out = null;
		
		try {
			out = response.getOutputStream();
			
			File f = new File(file_name);
			if(! f.exists()){
				System.out.println("파일이 존재하지 않습니다.");
				
				jsonObject.put("success", false);
				jsonObject.put("err_msg", "file is null");
				ret_msg = jsonObject.toJSONString();
				
			} else {
				input = new FileInputStream(file_name);
				int length = 0;
				byte[] buffer = new byte[1024];
				while ((length = input.read(buffer)) != -1) {
					out.write(buffer, 0, length);
				}
				
				input.close();
				out.flush();
				out.close();
				
				ret_msg = "success";
				
			}
			
		} catch (Exception e) {
			response.sendError(HttpServletResponse.SC_UNAUTHORIZED);
		} finally {
			if(input != null){input.close();}
			if(out != null){out.close();}
		}
		
		
		return ret_msg;
		
	}

	/** 이미지업로드 */
	@RequestMapping("/uploadImage")
	public String getUploadImage(HttpServletRequest request) throws Exception {
		
		String save_name = request.getParameter("save_name");
		String save_path = request.getParameter("save_path");
		String dicom_path = request.getParameter("dicom_path");
		
		MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
		MultipartFile file = multipartRequest.getFile("file_name");
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("save_name", save_name);
		map.put("save_path", save_path);
		map.put("dicom_path", dicom_path);
		map.put("file_name", file);
		
		FileUploadController fu = new FileUploadController();
		Map<String, Object> retMap = fu.upload(map);
		
		JSONObject jsonObject = new JSONObject(retMap);
		String ret_msg = jsonObject.toJSONString();
		
		return ret_msg;
	}
	
	/** 이미지삭제 */
	@RequestMapping("/removeImage")
	public String removeImage(@RequestBody String jsonFormData) throws Exception {
		
		JSONParser parser = new JSONParser();
		Object object = parser.parse(jsonFormData);
		JSONObject jsonObject = (JSONObject) object;
		
		System.out.println("어노테이션 파일 삭제 요청");
		System.out.println(jsonFormData);
		
		FileRemoveController fr = new FileRemoveController();
		Map<String, Object> retMap = fr.removeFile(jsonObject);
		
		JSONObject ret_json = new JSONObject(retMap);
		String ret_msg = ret_json.toJSONString();
		
		return ret_msg;
		
	}
	
	/** 동영상 다운로드 */
	@RequestMapping("/getVideo")
	public void getViedo(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
		System.out.println("동영상 다운로드 호출");
		
		String range = "";
		
		Enumeration eHeader = request.getHeaderNames();
		while (eHeader.hasMoreElements()){
			String request_name = (String) eHeader.nextElement();
			String request_value = request.getHeader(request_name);
			
			if(request_name.equals("range")){range = request_value;}
			
			System.out.println("header_name : " + request_name + " => " + request_value);
		}
		
		JSONObject jsonObject = new JSONObject();
		String ret_msg = "";
		String user_id = "";
		String param_id = "";
		
		if(StringUtil.isNotBlank(request.getParameter("id")) && StringUtil.isNotBlank((String)session.getAttribute("user_id"))){
			param_id = request.getParameter("id");
			user_id = (String)session.getAttribute("user_id");
			
//			sessionCheck(session, response, user_id, param_id);
			
		}else{
//			sessionCheck(session, response, user_id, param_id);
//			response.sendError(HttpServletResponse.SC_UNAUTHORIZED); //401 에러
		}
		
		String file_name = request.getParameter("file_name");
		String file_path = request.getParameter("file_path");
		
		System.out.println("file_path : " + file_path);

		System.out.println("range : " + range);
		
		if(StringUtil.isNotBlank(range)){
			System.out.println("파일 다운로드 재요청");
		}else{
			System.out.println("파일 다운로드 요청");
		}
		
		System.out.println("trying file download : " + file_name);
		
		if(StringUtil.isEmpty(file_name) || StringUtil.isEmpty(file_path)){
			System.err.println("file is not exist");
		}

		ClassPathResource resource = new ClassPathResource("db.properties");
		String path = resource.getURI().getPath();
		
		FileReader fr = new FileReader(path);
		Properties properties = new Properties();
		
		properties.load(fr);
		String rootPath = properties.getProperty("path");
		
		String mkdir = rootPath + file_path;
//		String mkdir = "D:/ubiz/" + file_path;
		
		File file = new File(mkdir + "/" + file_name);
		
		if(!file.exists()){
			//exception 에러 처리
			System.err.println("file is not exist");
			response.sendError(HttpServletResponse.SC_NOT_FOUND); //403 에러
			
		} else {
//			String mimetype = "application/x-msdownload";
			response.setContentType("video/mp4");
			
			Date date = new Date(file.lastModified());
			
			BufferedInputStream in = null;
			BufferedOutputStream out = null;
			
			if(StringUtil.isNotBlank(range)){

				//bytes=8433792-
				range = range.trim().substring("bytes=".length());
				String[] index = range.split("-");
				
				long start = Long.parseLong(index[0]);
				long end = file.length() - 1;
				long contentLength = end - start + 1 ;
				
				System.out.println(">>>>> range >>>>> " + start + " : " + end);
				
				response.setHeader("Accept-Ranges", "bytes");
				response.setHeader("Connection", "Keep-Alive");
				response.setHeader("Content-Length", String.valueOf(contentLength));
				response.setHeader("Content-Range", "bytes " + start + "-" + end + "/" + file.length());
//				response.setContentType("video/mp4");
				response.setStatus(206);
				response.setHeader("Keep-Alive", "timeout=5, max=100");
				response.setHeader("Last-Modified", date.toString());
				response.setHeader("ETag", date.toString());
//				response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + "\";");
//				response.setHeader("Content-Transfer-Encoding", "binary");
					
				System.out.println(">>>>> bytes >>>>> " + start + "-" + end + "/" + file.length());
				
				try(RandomAccessFile randomAccessFile = new RandomAccessFile(file, "r");
			            ServletOutputStream sos = response.getOutputStream();	){
					
					 Integer bufferSize = 1024, data = 0;
					 byte[] buffer = new byte[bufferSize];
					 
					 randomAccessFile.seek(start);
					 
					 while(true){
						 
						 if(contentLength <= 2) {
			                    sos.flush();
			                    break;
			               }
						 
						 data = randomAccessFile.read(buffer, 0, buffer.length);
						 
						 if(start <= end) {
			                    sos.write(buffer, 0, data);
			                    start += bufferSize;
			                    randomAccessFile.seek(start);
			             } else {
			                    break;
			             }
						 
					 }
					 
					 sos.flush();
					 
				} catch (IOException ex) {
					EgovBasicLogger.ignore("IOException", ex);
				}
			
			}else{
				
//				response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + "\";");
//				response.setHeader("Content-Transfer-Encoding", "binary");
//				response.setHeader("Content-Length", Long.toString(file.length()));
//				response.setHeader("Keep-Alive", "timeout = 5, max = 100");
//				response.setHeader("Last-Modified", date.toString());
//				response.setHeader("ETag", date.toString());
//				response.setHeader("Accept-Ranges", "bytes");

				
				response.setHeader("Accept-Ranges", "bytes");
				response.setHeader("Connection", "Keep-Alive");
				response.setHeader("Content-Length", Long.toString(file.length()));
//				response.setHeader("Content-Range", "bytes " + start + "-" + end + "/" + file.length());
//				response.setContentType("video/mp4");
				response.setStatus(200);
				response.setHeader("Keep-Alive", "timeout=5, max=100");
				response.setHeader("Last-Modified", date.toString());
				response.setHeader("ETag", date.toString());
				
				try{
					in = new BufferedInputStream(new FileInputStream(file));
					out = new BufferedOutputStream(response.getOutputStream());
					
					FileCopyUtils.copy(in, out);
					
					
				} catch (IOException ex) {
					EgovBasicLogger.ignore("IOException", ex);
				}
			}
			
			
		}
		
		

		
	}
	
	
	/** 세션 체크 */
	public void sessionCheck(HttpSession session, HttpServletResponse response, String user_id, String param_id) throws Exception {

		if(user_id.equals("") || param_id.equals("")){
			response.sendError(HttpServletResponse.SC_UNAUTHORIZED); //401 에러
		}
		
		if(!user_id.equals(param_id)){
			response.sendError(HttpServletResponse.SC_UNAUTHORIZED); //401 에러
		}
	
	}
	
}





