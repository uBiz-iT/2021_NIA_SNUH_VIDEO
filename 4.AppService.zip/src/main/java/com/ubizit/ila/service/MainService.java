/**
 * 
 */
package com.ubizit.ila.service;

import java.util.Map;

/**
 * @Class Name : MainService.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2020. 8. 28.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2020. 8. 28.
 * @version : 1.0
 * 
 */
public interface MainService {

	/**
	 * Method : getMainExecute
	 * 최초작성일 : 2021. 4. 14.
	 * 작성자 : USH
	 * 변경이력 :
	 * @param resultMap
	 * Method 설명 : call procedure 'P_MAIN'
	 */
	void getMainExecute(Map<String, Object> map) throws Exception;

}
