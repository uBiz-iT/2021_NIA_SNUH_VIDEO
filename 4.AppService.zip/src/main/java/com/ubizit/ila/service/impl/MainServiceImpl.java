/**
 * 
 */
package com.ubizit.ila.service.impl;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.ubizit.ila.service.MainService;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

/**
 * @Class Name : MainServiceImpl.java
 * @Description :
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2021. 4. 14.   엄소현         최초생성
 *
 * @author : USH
 * @since : 2021. 4. 14.
 * @version : 1.0
 * 
 */
@Service("mainService")
public class MainServiceImpl extends EgovAbstractServiceImpl implements MainService{

	@Resource(name="mainDAO")
	private MainDAO mainDAO;
	
	@Override
	public void getMainExecute(Map<String, Object> map) throws Exception {
		mainDAO.getMainExecute(map);
	}

}
