package com.ubizit.ila.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class ExcelUtil{
	
	/**
	 * Excel Download
	 * @param response
	 * @param logical_name : 엑셀의 타이틀
	 * @param physical_name : List에서 get을 위한 필드명
	 * @param widths : 셀들의 너비
	 * @param downFileName : 다운로드 파일명 downFileName.xls
	 * @param excelDataList : DB 데이터
	 * @throws IOException
	 */
	public static String excelDownload(HttpServletResponse response, int[][] cellRangeAddress, String[] logical_names, String[] physical_names, int[] widths, int[] type_int, String downFileName, List<Map<String, Object>> excelDataList) throws IOException
	{
		String returnMsg = "";

		if(physical_names.length != widths.length){
			returnMsg =  "physical_name != widths";
		}else{
		
			XSSFWorkbook workbook = makeXSSFWorkbook(cellRangeAddress, logical_names, physical_names, widths, type_int, downFileName, excelDataList);
			
			if(!workbook.equals(null)){
				response.setHeader("Content-Disposition", "attachment; filename=" + java.net.URLEncoder.encode(downFileName, "UTF-8")+".xlsx;");
				response.setHeader("Content-Description", "JSP Generated Data");
				response.setContentType("application/vnd.ms-excel");
				
				ServletOutputStream out = response.getOutputStream();
				workbook.write(out);
				out.close();
				
				returnMsg = "success";
			}else{
				returnMsg =  "지정한 파일을 찾을수 없습니다.";
			}
		}
		return returnMsg;
	}
		
	/**
	 * excel 화면 설정
	 * @param params
	 * @return
	 */
	public static XSSFWorkbook makeXSSFWorkbook(int[][] cellRangeAddress, String[] logical_names, String[] physical_names, int[] widths, int[] type_int, String downFileName, List<Map<String, Object>> excelDataList) {   	

		try {
			// 엑셀 workBook 생성
			XSSFWorkbook workbook = new XSSFWorkbook();
			// sheet 생성
			XSSFSheet sheet = workbook.createSheet(downFileName);//sheet명을 다운로드 받는 파일명과 동일하게 작명
			for (int i = 0, n = widths.length; i < n; i++) {
				sheet.setColumnWidth(i, widths[i] * 300);
			}
			
			// Style 지정
			XSSFCellStyle dataStyleNormalLeft = dataStyleNormalLeft(workbook);	
			XSSFCellStyle dataStyleNormalCenter = dataStyleNormalCenter(workbook);
			XSSFCellStyle dataStyleNormalRight = dataStyleNormalRight(workbook);

			/**
			 *  제목 란 생성
			 **/
			XSSFRow row = null;
			XSSFCell cell = null;
			int rowno = 0;
			if(cellRangeAddress != null){
				row = spanHeaderCreate(workbook, sheet, cellRangeAddress, logical_names);
			}else{
				row = headerCreate(workbook, sheet, logical_names);
			}
			rowno = sheet.getLastRowNum()+1;
			
			Map<String, Object> dataMap = null;
			if(excelDataList.size() > 0){
				//데이터 쓰기
				for (int i = 0;i<excelDataList.size(); i++) {
					row = sheet.createRow(rowno++);
					dataMap = (Map<String, Object>)excelDataList.get(i);
					
//					int num = 1;
					
					for (int i2 = 0; i2 < physical_names.length; i2++) {
						cell = row.createCell(i2);
						
						int intCell = (type_int != null ? type_int[i2] : -1);
						//intCell = (type_int != null ? type_int[i2] : -1);
						
						//cell type int형 처리
						if(intCell != -1){
							if(i2 == intCell){
								cell.setCellStyle(dataStyleNormalRight);
								cell.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
								cell.setCellValue((int)Integer.parseInt(Util.nullToStr(dataMap.get(physical_names[i2]), "0")));
								
//								if(num < type_int.length){
//									intCell = type_int[num];
//									num++;
//								}
							}else{
								cell.setCellStyle(dataStyleNormalLeft);
								cell.setCellType(XSSFCell.CELL_TYPE_STRING);
								cell.setCellValue(Util.nullToStr(dataMap.get(physical_names[i2])).toString());
							}
						}else{
							cell.setCellStyle(dataStyleNormalLeft);
							cell.setCellType(XSSFCell.CELL_TYPE_STRING);
							cell.setCellValue(Util.nullToStr(dataMap.get(physical_names[i2])).toString());
						}
					}
					
				}
			}else{
				row = sheet.createRow(rowno++);
				cell = row.createCell(0);
				cell.setCellStyle(dataStyleNormalCenter);
				cell.setCellValue("자료가 없습니다.");
			}

			return workbook;
		} catch (NullPointerException e) {
			return null;
		}
	}
	
	//기본 title header
	public static XSSFRow headerCreate(XSSFWorkbook workbook, XSSFSheet sheet, String[] logical_names) {
		XSSFRow row = null;
		XSSFCell cell = null;
		XSSFCellStyle subTitleStyle = subTitleStyle(workbook);
		
		//엑셀 상단 국문 컬럼명
		if(logical_names != null && logical_names.length > 0){			
			row = sheet.createRow(0);
			for (int i = 0; i < logical_names.length; i++) {
				cell = row.createCell(i);
				cell.setCellStyle(subTitleStyle);
				cell.setCellValue(Util.nullToStr(logical_names[i]));
			}
		}
		return row;
	}
	
	//title header 병합 
	public static XSSFRow spanHeaderCreate(XSSFWorkbook workbook, XSSFSheet sheet, int[][] cellRangeAddress, String[] logical_names) {
		int rowno = 0;
		XSSFRow row = null;
		XSSFCell cell = null;
		XSSFCellStyle subTitleStyle = subTitleStyle(workbook);	
		
		List<Integer> spanIdxList = new ArrayList<Integer>();			//상위 row column index
		List<Integer> duplicateIdxList = new ArrayList<Integer>(); 		//중복 row column index(병합되는 셀위치)
		List<Integer> exIdxList = new ArrayList<Integer>(); 			//하위 row column index
		
		
		//병합 셀 지정(cellRangeAddress( first_row, last_row, first_column, last_column ))
		for(int i=0; i < cellRangeAddress.length; i++) {
			sheet.addMergedRegion(new CellRangeAddress(cellRangeAddress[i][0], cellRangeAddress[i][1], cellRangeAddress[i][2], cellRangeAddress[i][3]));
			
			spanIdxList.add(cellRangeAddress[i][2]);			
			
			if(cellRangeAddress[i][2] != cellRangeAddress[i][3]){
				duplicateIdxList.add(cellRangeAddress[i][2]);   
				for(int i2=cellRangeAddress[i][2]; i2<=cellRangeAddress[i][3]; i2++){
					exIdxList.add(i2);
				}
			}
		}
		
		if(logical_names != null && logical_names.length > 0){		
			int duplicateCnt = 0; 
			row	= sheet.createRow(rowno++);
			
			for(int spanIdx : spanIdxList){
				cell = row.createCell(spanIdx);
				cell.setCellStyle(subTitleStyle);
				cell.setCellValue(Util.nullToStr(Util.nullToStr(logical_names[spanIdx+duplicateCnt])));
				
				for(int duplicateIdx : duplicateIdxList){
					if(spanIdx == duplicateIdx){
						duplicateCnt++;
					}
				}
			}
			
			duplicateCnt = 0;
			row = sheet.createRow(rowno++);
			
			for(int exIdx : exIdxList){
				for(int duplicateIdx : duplicateIdxList){
					if(exIdx == duplicateIdx){
						duplicateCnt++;
					}
				}
				cell = row.createCell(exIdx);
				cell.setCellStyle(subTitleStyle);
				cell.setCellValue(Util.nullToStr(Util.nullToStr(logical_names[exIdx+duplicateCnt])));
			}
		}
		return row;
	}
	
	// 제목
	public static XSSFCellStyle titleStyle(XSSFWorkbook workbook) {
		XSSFCellStyle titleStyle = workbook.createCellStyle();
		
		titleStyle.setAlignment(CellStyle.ALIGN_LEFT);
		titleStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		titleStyle.setFillForegroundColor(IndexedColors.BRIGHT_GREEN.getIndex());
		titleStyle.setFillForegroundColor(IndexedColors.GREY_40_PERCENT.getIndex());
		titleStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		
		titleStyle.setBorderBottom(CellStyle.BORDER_THIN);
		titleStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		titleStyle.setBorderLeft(CellStyle.BORDER_THIN);
		titleStyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		titleStyle.setBorderRight(CellStyle.BORDER_THIN);
		titleStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
		titleStyle.setBorderTop(CellStyle.BORDER_THIN);
		titleStyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
		
		return titleStyle;
	}
	// 컬럼 제목		
	public static XSSFCellStyle subTitleStyle(XSSFWorkbook workbook) {			
		XSSFCellStyle subTitleStyle = workbook.createCellStyle();	
		
		subTitleStyle.setAlignment(CellStyle.ALIGN_CENTER);
		subTitleStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		subTitleStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		subTitleStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		subTitleStyle.setBorderBottom(CellStyle.BORDER_THIN);
		subTitleStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		subTitleStyle.setBorderLeft(CellStyle.BORDER_THIN);
		subTitleStyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		subTitleStyle.setBorderRight(CellStyle.BORDER_THIN);
		subTitleStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
		subTitleStyle.setBorderTop(CellStyle.BORDER_THIN);
		subTitleStyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
		//폰트설정
		subTitleStyle.setFont(subFont(workbook));
		
		return subTitleStyle;
	}
	// 데이터 셀 스타일 Grey_0 Percent 왼쪽 정렬 좌우/상하		
	public static XSSFCellStyle dataStyleNormalLeft(XSSFWorkbook workbook) {			
		XSSFCellStyle dataStyleNormalLeft = workbook.createCellStyle();
		
		dataStyleNormalLeft.setAlignment(CellStyle.ALIGN_LEFT);
		dataStyleNormalLeft.setVerticalAlignment(CellStyle.ALIGN_CENTER);			
		dataStyleNormalLeft.setBorderBottom(CellStyle.BORDER_THIN);
		dataStyleNormalLeft.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		dataStyleNormalLeft.setBorderLeft(CellStyle.BORDER_THIN);
		dataStyleNormalLeft.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		dataStyleNormalLeft.setBorderRight(CellStyle.BORDER_THIN);
		dataStyleNormalLeft.setRightBorderColor(IndexedColors.BLACK.getIndex());
		dataStyleNormalLeft.setBorderTop(CellStyle.BORDER_THIN);
		dataStyleNormalLeft.setTopBorderColor(IndexedColors.BLACK.getIndex());			
		//폰트설정
		dataStyleNormalLeft.setFont(font(workbook));
		return dataStyleNormalLeft;
	}
	// 데이터 셀 스타일 Grey_0 Percent 가운데 정렬 좌우/상하		
	public static XSSFCellStyle dataStyleNormalCenter(XSSFWorkbook workbook) {			
		XSSFCellStyle dataStyleNormalCenter = workbook.createCellStyle();
		
		dataStyleNormalCenter.setAlignment(CellStyle.ALIGN_CENTER);
		dataStyleNormalCenter.setVerticalAlignment(CellStyle.ALIGN_CENTER);			
		dataStyleNormalCenter.setBorderBottom(CellStyle.BORDER_THIN);
		dataStyleNormalCenter.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		dataStyleNormalCenter.setBorderLeft(CellStyle.BORDER_THIN);
		dataStyleNormalCenter.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		dataStyleNormalCenter.setBorderRight(CellStyle.BORDER_THIN);
		dataStyleNormalCenter.setRightBorderColor(IndexedColors.BLACK.getIndex());
		dataStyleNormalCenter.setBorderTop(CellStyle.BORDER_THIN);
		dataStyleNormalCenter.setTopBorderColor(IndexedColors.BLACK.getIndex());			
		//폰트설정
		dataStyleNormalCenter.setFont(font(workbook));

		return dataStyleNormalCenter;
	}
	// 데이터 셀 스타일 Grey_0 Percent 가운데 정렬 좌우/상하		
	public static XSSFCellStyle dataStyleNormalRight(XSSFWorkbook workbook) {			
		XSSFCellStyle dataStyleNormalCenter = workbook.createCellStyle();
		
		dataStyleNormalCenter.setAlignment(CellStyle.ALIGN_RIGHT);
		dataStyleNormalCenter.setVerticalAlignment(CellStyle.ALIGN_CENTER);			
		dataStyleNormalCenter.setBorderBottom(CellStyle.BORDER_THIN);
		dataStyleNormalCenter.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		dataStyleNormalCenter.setBorderLeft(CellStyle.BORDER_THIN);
		dataStyleNormalCenter.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		dataStyleNormalCenter.setBorderRight(CellStyle.BORDER_THIN);
		dataStyleNormalCenter.setRightBorderColor(IndexedColors.BLACK.getIndex());
		dataStyleNormalCenter.setBorderTop(CellStyle.BORDER_THIN);
		dataStyleNormalCenter.setTopBorderColor(IndexedColors.BLACK.getIndex());			
		//폰트설정
		dataStyleNormalCenter.setFont(font(workbook));
		
		return dataStyleNormalCenter;
	}
	// 데이터 셀 스타일 Grey_25 Percent 정렬 좌우/상하		
	public static XSSFCellStyle dataStyleGray(XSSFWorkbook workbook) {			
		XSSFCellStyle dataStyleGray = workbook.createCellStyle();
		
		dataStyleGray.setFillForegroundColor(IndexedColors.DARK_YELLOW.getIndex());
		dataStyleGray.setFillPattern(CellStyle.SOLID_FOREGROUND);
		dataStyleGray.setAlignment(CellStyle.ALIGN_LEFT);
		dataStyleGray.setVerticalAlignment(CellStyle.ALIGN_CENTER);			
		dataStyleGray.setBorderBottom(CellStyle.BORDER_THIN);
		dataStyleGray.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		dataStyleGray.setBorderLeft(CellStyle.BORDER_THIN);
		dataStyleGray.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		dataStyleGray.setBorderRight(CellStyle.BORDER_THIN);
		dataStyleGray.setRightBorderColor(IndexedColors.BLACK.getIndex());
		dataStyleGray.setBorderTop(CellStyle.BORDER_THIN);
		dataStyleGray.setTopBorderColor(IndexedColors.BLACK.getIndex());	
		//폰트설정
		dataStyleGray.setFont(font(workbook));
		
		return dataStyleGray;
	}
	// 폰트 스타일
	public static XSSFFont titleFont(XSSFWorkbook workbook) {	
		XSSFFont titleFont = workbook.createFont();
		titleFont.setFontName("맑은고딕");
		titleFont.setColor((short) Font.BOLDWEIGHT_BOLD);
		titleFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		titleFont.setFontHeightInPoints((short)16);
		
		return titleFont;
	}
	//SUB TITLE 폰트 설정
	public static XSSFFont subFont(XSSFWorkbook workbook) {	
		XSSFFont subFont = workbook.createFont();
		subFont.setFontName("맑은고딕");
		subFont.setColor((short) Font.BOLDWEIGHT_BOLD);
		subFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		
		return subFont;
	}
	//DATA 폰트 설정
	public static XSSFFont font(XSSFWorkbook workbook) {	
		XSSFFont font = workbook.createFont();
		font.setFontName("맑은고딕");
		font.setColor((short) Font.BOLDWEIGHT_NORMAL);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL);
		
		return font;
	}
}
